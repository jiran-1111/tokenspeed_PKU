# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import json
import os
import sys
from pathlib import Path

require_cpu = (
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0"
    and os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
)
assert require_cpu
sys.modules["torch_npu"] = None
import torch

from analysis_binding import CORE, load_model, sha, verify_unchanged
from analyze_history import analyze_history

torch.set_num_threads(1)
here = Path(__file__).resolve().parent
task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
out = here / "output"
out.mkdir(exist_ok=False)
summary = {
    "scope": "All original 4B/9B Prefill and Decode GDN input/state histories and FA cache continuity",
    "core_source_sha256": CORE,
    "runtime_math_changed": False,
    "thresholds_added": False,
    "original_failures_preserved": True,
    "models": {},
}
for model in ("9b", "4b"):
    print(f"Binding all {model} input files", flush=True)
    data = load_model(task, model=model, torch=torch)
    results = {}
    for label in data["records"]:
        print(f"Analyzing {model} {label} complete history", flush=True)
        results[label] = analyze_history(data, label=label)
    verify_unchanged(data)
    manifest = {
        (
            path.relative_to(task).as_posix()
            if path.is_relative_to(task)
            else f"checkpoint/{model}/{path.name}"
        ): digest
        for path, digest in data["files"].items()
    }
    record = {
        "ranks": results,
        "source_and_inputs_unchanged_after": True,
        "input_manifest": manifest,
        "input_files": len(manifest),
        "original_logits_byte_preserved": data["steps"] * 3,
    }
    with (out / f"{model}_history.json").open("x") as stream:
        json.dump(record, stream, indent=2, allow_nan=False)
    summary["models"][model] = {
        "analysis_sha256": sha(out / f"{model}_history.json"),
        "input_files": len(manifest),
        "original_logits_byte_preserved": data["steps"] * 3,
    }
    del data
with (out / "summary.json").open("x") as stream:
    json.dump(summary, stream, indent=2)
print("ALL ORIGINAL HISTORIES CPU ANALYSIS COMPLETE", flush=True)
