# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Bind full original histories to their collector, source and actual weights."""

import hashlib
import json
from pathlib import Path

import numpy as np

CORE = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def compare(actual, reference):
    a, b = np.asarray(actual), np.asarray(reference)
    require(a.shape == b.shape and a.size > 0, "comparison shape mismatch")
    require(np.isfinite(a).all() and np.isfinite(b).all(), "nonfinite comparison")
    x, y = a.astype(np.float64), b.astype(np.float64)
    difference = x - y
    denominator = float(np.linalg.norm(y.ravel()))
    return {
        "shape": list(a.shape),
        "relative_l2": (
            float(np.linalg.norm(difference.ravel()) / denominator)
            if denominator
            else None
        ),
        "max_abs": float(np.abs(difference).max()),
        "different_elements": int(np.count_nonzero(a != b)),
        "elements": int(a.size),
        "zero_reference": denominator == 0,
    }


def validate_metadata(meta, *, step, rank, tp, case):
    require(
        meta["case_id"] == case["case_id"]
        and meta["step"] == step
        and meta["rank"] == rank
        and meta["tp"] == tp,
        "frontier metadata mismatch",
    )
    require(
        meta["position"] == 127 + step
        and meta["prefix_length_after"] == 128 + step
        and meta["prefix_length_before"] == (0 if step == 0 else 127 + step),
        "prefix extent mismatch",
    )
    require(
        meta["all_layers"] == list(range(32))
        and meta["fa_layers"] == list(range(3, 32, 4))
        and meta["gdn_layers"] == [i for i in range(32) if i % 4 != 3],
        "layer coverage mismatch",
    )
    require(
        not meta["performance_eligible"] and not meta["runtime_state_written"],
        "observation scope mismatch",
    )


def convert(value, *, torch):
    if isinstance(value, torch.Tensor):
        require(value.device.type == "cpu", "CPU mapped capture required")
        return (
            value.float().numpy().copy()
            if value.dtype == torch.bfloat16
            else value.numpy().copy()
        )
    if isinstance(value, dict):
        return {key: convert(item, torch=torch) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [convert(item, torch=torch) for item in value]
    require(
        value is None or type(value) in (str, bool, int, float),
        "unexpected capture object",
    )
    return value


def load_model(task, *, model, torch):
    source = task / "source_final"
    tools = task / "fullpath_history_r3_20261028"
    state_path = tools / "state.json"
    state = read(state_path)
    require(
        state["status"] == "collected" and state["original_queue_retained_paused"],
        "full four-job cohort must finish first",
    )
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(sha(core) == CORE, "core source identity mismatch")
    require(
        all(sha(source / name) == expected for name, expected in read(core).items()),
        "core content mismatch",
    )
    cfg = read(source / f"configs/homework2/qwen35_{model}_tp1.yaml")
    checkpoint = source / cfg["local_model_path"]
    artifacts = read(source / "docs/evidence/homework2_20261023/model_artifacts.json")
    artifact = next(
        row
        for row in artifacts["models"]
        if row["model_id"] == cfg["model_id"]
        and row["model_revision"] == cfg["model_revision"]
    )
    frozen_files = {
        state_path: sha(state_path),
        core: sha(core),
        tools / "tool_manifest.json": sha(tools / "tool_manifest.json"),
    }
    tool_manifest = read(tools / "tool_manifest.json")
    require(
        all(sha(tools / name) == expected for name, expected in tool_manifest.items()),
        "collector tool changed",
    )
    require(
        sha(tools / "tool_manifest.json")
        == "f78fe7be4614d2571f89d7e23d11cfdcbcf9d0873c2861a98b3be5007808ba1d",
        "unexpected collector",
    )
    case_path = tools / f"case_{model}.json"
    case = read(case_path)
    count = 10 if model == "9b" else 18
    require(
        len(case["input_ids"]) == 128 and len(case["continuation_ids"]) == count - 1,
        "case extent mismatch",
    )
    records, certificates, logits = {}, {}, {}
    for tp, rank in ((1, 0), (2, 0), (2, 1)):
        label = f"tp{tp}_rank{rank}"
        name = f"fullpath_{model}_tp{tp}_20261028_r3"
        directory = source / "results/raw/homework2_20261028" / name
        run_path = directory / "diagnostic.json"
        run, receipt = read(run_path), state["finished"][name]
        baseline = tools / f"{name}.baseline.json"
        guard = run["guard"]
        require(
            receipt["exit_code"] == 0
            and receipt["own_contexts_released"]
            and receipt["npu_id"] == 3,
            "collector exit/card/release failed",
        )
        require(
            run["status"] == "collected"
            and run["case"] == case
            and run["case_sha256"] == sha(case_path),
            "run/case binding failed",
        )
        require(
            guard["parent_pid"] == receipt["pid"]
            and guard["baseline_sha256"] == sha(baseline),
            "collector PID/baseline mismatch",
        )
        require(
            guard["sources_sha"] == guard["sources_after_sha"] == CORE
            and guard["sources_unchanged"]
            and guard["own_children_released"]
            and not guard["violations"],
            "guard/source failed",
        )
        identity_path = directory / f"rank_{rank}/full_parameter_identity.json"
        certificate = read(identity_path)
        require(
            certificate["all_exact"]
            and certificate["parameter_checks"] == 412
            and certificate["rank"] == rank
            and certificate["tp"] == tp,
            "actual parameter scope failed",
        )
        require(
            all(
                row["exact_match"]
                and row["actual_sha256"] == row["checkpoint_expected_sha256"]
                for row in certificate["parameters"].values()
            ),
            "actual parameter certificate failed",
        )
        require(
            certificate["checkpoint_files_before"]
            == certificate["checkpoint_files_after"],
            "checkpoint changed in capture",
        )
        for filename, expected in certificate["checkpoint_files_before"].items():
            require(
                expected == artifact["files"][filename]["sha256"],
                "checkpoint artifact mismatch",
            )
            path = checkpoint / filename
            if path not in frozen_files:
                require(sha(path) == expected, "checkpoint bytes mismatch")
                frozen_files[path] = expected
        for path in (
            case_path,
            run_path,
            baseline,
            identity_path,
            source / f"configs/homework2/qwen35_{model}_tp{tp}.yaml",
        ):
            frozen_files[path] = sha(path)
        require(
            sha(source / f"configs/homework2/qwen35_{model}_tp{tp}.yaml")
            == certificate["config_sha256"],
            "config certificate mismatch",
        )
        captures, output_vectors = [], []
        for step in range(count):
            path = directory / f"rank_{rank}/fullpath_step{step}.pt"
            meta_path = directory / f"rank_{rank}/fullpath_step{step}_metadata.json"
            frozen_files[path] = sha(path)
            frozen_files[meta_path] = sha(meta_path)
            raw = torch.load(path, map_location="cpu", weights_only=True)
            item = convert(raw, torch=torch)
            meta = item["metadata"]
            validate_metadata(meta, step=step, rank=rank, tp=tp, case=case)
            require(
                json.loads(json.dumps(meta)) == read(meta_path),
                "duplicate metadata mismatch",
            )
            o = item["observed"]
            require(
                len(o["modules"]) == 264
                and len(o["norm_boundaries"]) == 65
                and set(o["backend"]) == set(meta["gdn_layers"]),
                "capture operation coverage mismatch",
            )
            original_path = (
                source
                / "results/raw/homework2_20261024"
                / f"frontier_diagnostic_{model}_tp{tp}_20261024_r2/rank_{rank}/step_{step:02d}.pt"
            )
            output_path = directory / f"rank_{rank}/step_{step:02d}.pt"
            original = torch.load(original_path, map_location="cpu", weights_only=True)
            current = torch.load(output_path, map_location="cpu", weights_only=True)
            for field in (
                "input_ids",
                "positions",
                "rank",
                "step",
                "case_id",
                "original_dtype",
                "raw_greedy_id",
            ):
                require(
                    original[field] == current[field],
                    "original frontier output contract changed",
                )
            require(
                torch.equal(
                    original["logits"].view(torch.uint8),
                    current["logits"].view(torch.uint8),
                ),
                "original logits bytes changed",
            )
            frozen_files[original_path] = sha(original_path)
            frozen_files[output_path] = sha(output_path)
            output_vectors.append(current["logits"].float().numpy().copy())
            captures.append(item)
            del raw
        records[label], certificates[label], logits[label] = (
            captures,
            certificate,
            output_vectors,
        )
    return {
        "model": model,
        "config": cfg,
        "checkpoint": checkpoint,
        "index": read(checkpoint / "model.safetensors.index.json")["weight_map"],
        "records": records,
        "certificates": certificates,
        "logits": logits,
        "files": frozen_files,
        "steps": count,
        "case": case,
    }


def load_parameter(data, *, label, name, torch):
    from parameter_identity import expected_block
    from safetensors import safe_open

    certificate = data["certificates"][label]["parameters"][name]
    pieces = []
    for part in certificate["checkpoint_parts"]:
        with safe_open(
            data["checkpoint"] / data["index"][part["key"]],
            framework="pt",
            device="cpu",
        ) as reader:
            value = reader.get_slice(part["key"])[part["start"] : part["stop"]]
            if part["columns"] is not None:
                value = value[:, part["columns"][0] : part["columns"][1]]
            pieces.append(
                expected_block(value, mode=certificate["projection"], torch=torch)
            )
    result = torch.cat(pieces, dim=0).contiguous()
    digest = hashlib.sha256(result.view(torch.uint8).numpy().tobytes()).hexdigest()
    require(
        digest == certificate["actual_sha256"]
        and list(result.shape) == certificate["shape"]
        and str(result.dtype) == certificate["dtype"],
        "parameter value/certificate mismatch",
    )
    return result


def verify_unchanged(data):
    require(
        all(sha(path) == expected for path, expected in data["files"].items()),
        "analysis inputs changed",
    )
    source = data["checkpoint"].parent.parent
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(
        sha(core) == CORE
        and all(
            sha(source / name) == expected for name, expected in read(core).items()
        ),
        "core source changed after analysis",
    )
