import hashlib
import json
import os
import sys
from pathlib import Path

assert os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0" and os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
sys.modules["torch_npu"] = None
import numpy as np
import torch

torch.set_num_threads(1)
task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
here = Path(__file__).resolve().parent
history = task / "fullpath_history_analysis_r1_20261028/output"
operations = task / "fullpath_operations_analysis_r1_20261028/output"


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_text())


def scores(vector, competing):
    first = int(vector.argmax())
    remaining = vector.copy()
    remaining[first] = -np.inf
    second = int(remaining.argmax())
    return {"argmax": first, "second": second, "top1_minus_top2": float(np.float64(vector[first]) - np.float64(vector[second])),
            "competing_scores": {str(token): float(vector[token]) for token in competing}}


result = {"models": {}, "scope": "Actual gating and full replicated-tensor connections plus exact saved head margins; no new model math or numerical acceptance threshold"}
for model, steps in (("9b", 10), ("4b", 18)):
    old = read(history / f"{model}_history.json")
    report = read(operations / f"{model}_operations.json")
    count, failures = 0, []
    used = {}

    def exact(name, left, right):
        global count
        count += 1
        if left.dtype != right.dtype or left.numel() != right.numel() or not torch.equal(left.reshape(-1), right.reshape(-1)):
            failures.append(name)

    for step in range(steps):
        replicas = {}
        for tp, rank in ((1, 0), (2, 0), (2, 1)):
            name = f"fullpath_{model}_tp{tp}_20261028_r3"
            path = task / f"source_final/results/raw/homework2_20261028/{name}/rank_{rank}/fullpath_step{step}.pt"
            key = path.relative_to(task).as_posix()
            assert sha(path) == old["input_manifest"][key]
            used[path] = old["input_manifest"][key]
            data = torch.load(path, map_location="cpu", weights_only=True)
            o = data["observed"]
            for layer, backend in o["backend"].items():
                raw = backend["extend" if step == 0 else "decode"]
                scan = backend["prefill_scans"][0] if step == 0 else backend["scan"]
                assert step != 0 or len(backend["prefill_scans"]) == 1
                for field in ("a", "b", "A_log", "dt_bias"):
                    exact(f"tp{tp}r{rank}/step{step}/l{layer}/gate_{field}", raw[field], scan[field])
                if step == 0:
                    exact(f"tp{tp}r{rank}/l{layer}/prefill_scan_to_extend", scan["outputs"][0], raw["output"])
            if tp == 2:
                replicas[rank] = o["norm_boundaries"]
        for name in replicas[0]:
            one, two = replicas[0][name]["outputs"], replicas[1][name]["outputs"]
            assert len(one) == len(two)
            for index, (left, right) in enumerate(zip(one, two)):
                if left is not None and right is not None:
                    exact(f"step{step}/{name}/full_rank_output{index}", left, right)
                else:
                    assert left is None and right is None
    assert all(sha(path) == expected for path, expected in used.items())
    array_path = operations / f"{model}_vectors.npz"
    assert sha(array_path) == report["arrays_sha256"]
    arrays = np.load(array_path, allow_pickle=False)
    own1 = arrays[f"{model}_tp1_rank0_head_reference"]
    own2 = np.concatenate([arrays[f"{model}_tp2_rank0_head_reference"], arrays[f"{model}_tp2_rank1_head_reference"]], axis=-1)
    actual1 = arrays[f"{model}_tp1_rank0_head_actual"]
    actual2 = np.concatenate([arrays[f"{model}_tp2_rank0_head_actual"], arrays[f"{model}_tp2_rank1_head_actual"]], axis=-1)
    competing = [25389, 35378] if model == "9b" else [198, 271]
    result["models"][model] = {"connection_checks": count, "connection_failures": failures, "input_files_rehashed": len(used),
        "all_own_head_reference_argmax_reproduced": bool(np.array_equal(actual1.argmax(axis=1), own1.argmax(axis=1)) and np.array_equal(actual2.argmax(axis=1), own2.argmax(axis=1))),
        "final_step_head_scores": {"actual_tp1": scores(actual1[-1], competing), "actual_tp2": scores(actual2[-1], competing),
            "own_reference_tp1": scores(own1[-1], competing), "own_reference_tp2": scores(own2[-1], competing)},
        "history_sha256": sha(history / f"{model}_history.json"), "operations_sha256": sha(operations / f"{model}_operations.json")}
result["passed"] = all(not row["connection_failures"] and row["all_own_head_reference_argmax_reproduced"] for row in result["models"].values())
result["script_sha256"] = sha(Path(__file__))
with (here / "connections.json").open("x") as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result), flush=True)
