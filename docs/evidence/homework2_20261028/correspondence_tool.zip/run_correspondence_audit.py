"""Cross-bind both CPU analyses and check all real graph connections exactly."""

import json
import os
import sys
from pathlib import Path

assert os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0" and os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
sys.modules["torch_npu"] = None
import numpy as np
import torch

from analysis_binding import load_model, read, require, sha, verify_unchanged

torch.set_num_threads(1)
here = Path(__file__).resolve().parent
task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
history = task / "fullpath_history_analysis_r1_20261028"
operations = task / "fullpath_operations_analysis_r1_20261028"
result = {"models": {}, "scope": "Exact data correspondence, stored boolean invariants and actual inter-operator connections; no model numerical threshold"}
false_expected = {"actual_conv_has_initial_history", "null_slot_data_read", "runtime_state_written", "performance_eligible", "runtime_math_changed", "thresholds_added"}


def bool_audit(value, prefix):
    checked, failures = 0, []
    if isinstance(value, dict):
        if "relative_l2" in value:
            return checked, failures
        for name, item in value.items():
            if type(item) is bool:
                checked += 1
                expected = name not in false_expected
                if item != expected:
                    failures.append(f"{prefix}/{name}")
            else:
                count, items = bool_audit(item, f"{prefix}/{name}")
                checked += count; failures.extend(items)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            count, items = bool_audit(item, f"{prefix}/{index}")
            checked += count; failures.extend(items)
    return checked, failures


for model in ("9b", "4b"):
    data = load_model(task, model=model, torch=torch)
    old = read(history / f"output/{model}_history.json")
    new = read(operations / f"output/{model}_operations.json")
    manifest = {path.relative_to(task).as_posix() if path.is_relative_to(task) else f"checkpoint/{model}/{path.name}": digest for path, digest in data["files"].items()}
    require(manifest == old["input_manifest"], "history/operations exact input correspondence failed")
    require(new["parent_history_sha256"] == sha(history / f"output/{model}_history.json"), "parent analysis hash mismatch")
    counts, failures = bool_audit(old, "history")
    count, items = bool_audit(new, "operations")
    counts += count; failures += items
    connections, mismatches = 0, []

    def connection(name, actual, expected):
        global connections
        connections += 1
        if actual is None or expected is None or not np.array_equal(actual, expected):
            mismatches.append(name)

    for label, records in data["records"].items():
        for step, entry in enumerate(records):
            o = entry["observed"]
            norms, modules = o["norm_boundaries"], o["modules"]
            for layer in range(32):
                prefix = f"fa{layer}" if layer % 4 == 3 else f"l{layer}"
                first = norms[f"layers.{layer}.input_layernorm"]
                post = norms[f"layers.{layer}.post_attention_layernorm"]
                projection = f"{prefix}.qkv_proj" if layer % 4 == 3 else f"{prefix}.linear_attn.in_proj_qkvzba"
                name = f"{label}/step{step}/layer{layer}"
                connection(f"{name}/normalized_to_attention_projection", first["outputs"][0], modules[projection]["inputs"][0])
                connection(f"{name}/postnorm_to_mlp_projection", post["outputs"][0], modules[f"{prefix}.mlp.gate_up_proj"]["inputs"][0])
                residual = first["outputs"][1] if len(first["outputs"]) > 1 else first["inputs"][0]
                connection(f"{name}/attention_residual_carry", residual, post["inputs"][1])
                after = norms[f"layers.{layer + 1}.input_layernorm"] if layer < 31 else norms["final_norm"]
                connection(f"{name}/mlp_residual_carry", post["outputs"][1], after["inputs"][1])
                if layer % 4 != 3:
                    z = o["backend"][layer]["extend" if step == 0 else "decode"]["z"]
                    connection(f"{name}/actual_z_to_gated_norm", z.reshape(-1, 128), modules[f"{prefix}.linear_attn.norm"]["inputs"][1].reshape(-1, 128))
    for step in range(data["steps"]):
        common = data["records"]["tp1_rank0"][step]["observed"]["norm_boundaries"]["layers.0.input_layernorm"]["inputs"][0]
        for label in ("tp2_rank0", "tp2_rank1"):
            actual = data["records"][label][step]["observed"]["norm_boundaries"]["layers.0.input_layernorm"]["inputs"][0]
            connection(f"{label}/step{step}/full_actual_embedding_input", actual, common)
    verify_unchanged(data)
    result["models"][model] = {"all_input_files_identical_between_analyses": True, "input_files": len(manifest),
        "stored_boolean_invariants_checked": counts, "stored_boolean_invariant_failures": failures,
        "actual_connections_checked": connections, "actual_connection_failures": mismatches,
        "new_captured_parameter_digest_checks_bound_to_same_history": True,
        "history_analysis_sha256": sha(history / f"output/{model}_history.json"), "operations_analysis_sha256": sha(operations / f"output/{model}_operations.json")}
    del data
for folder, expected in ((history, "093243efbb06e3c9280ac2670e90680a92e31e213c32888692003ad617ccfa1c"),
                         (operations, "07f517cdc67b8fd7af7532ee8af97e690e1b650a4e4b73d21d409781c3d9bcb3")):
    manifest = folder / "tool_manifest.json"
    require(sha(manifest) == expected and all(sha(folder / name) == digest for name, digest in read(manifest).items()), "executed analysis source changed")
result["passed"] = all(not value["stored_boolean_invariant_failures"] and not value["actual_connection_failures"] for value in result["models"].values())
result["script_sha256"] = sha(Path(__file__))
with (here / "correspondence.json").open("x") as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result), flush=True)
