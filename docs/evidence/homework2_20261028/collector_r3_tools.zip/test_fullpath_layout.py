# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from types import SimpleNamespace as NS

import pytest
from cached_capture import selected_layers, targets_for_layers


def model_fixture():
    layers = []
    for index in range(32):
        layer = NS(
            input_layernorm=object(),
            post_attention_layernorm=object(),
            mlp=NS(gate_up_proj=object(), down_proj=object()),
        )
        if index % 4 == 3:
            layer.qkv_proj = object()
            layer.rotary_emb = object()
            layer.attn = object()
            layer.o_proj = object()
        else:
            layer.linear_attn = NS(
                layer_id=index,
                in_proj_qkvzba=object(),
                norm=object(),
                out_proj=object(),
            )
        layers.append(layer)
    return NS(model=NS(layers=layers))


def test_all_32_layers_have_exact_expected_families_and_modules():
    all_layers, fa, gdn = selected_layers()
    assert len(all_layers) == 32 and len(fa) == 8 and len(gdn) == 24
    assert set(fa).isdisjoint(gdn) and set(fa) | set(gdn) == set(all_layers)
    layers, targets = targets_for_layers(model_fixture())
    assert len(layers) == 32 and len(targets) == 264
    assert "fa31.mlp.down_proj" in targets and "l0.linear_attn" in targets
    assert "fa3.rotary_emb" in targets and "l30.linear_attn.norm" in targets


def test_missing_layer_and_wrong_actual_layer_id_rejected():
    model = model_fixture()
    model.model.layers.pop()
    with pytest.raises(ValueError):
        targets_for_layers(model)
    model = model_fixture()
    model.model.layers[4].linear_attn.layer_id = 5
    with pytest.raises(ValueError):
        targets_for_layers(model)
