# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read all original decoder operations at one fixed cached frontier."""

import json
import re
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch


def selected_layers():
    return (
        tuple(range(32)),
        tuple(range(3, 32, 4)),
        tuple(i for i in range(32) if i % 4 != 3),
    )


def targets_for_layers(model):
    layers = list(model.model.layers)
    if len(layers) != 32:
        raise ValueError("Exactly 32 text decoder layers required")
    targets = {}
    for index, layer in enumerate(layers):
        prefix = f"fa{index}" if index % 4 == 3 else f"l{index}"
        targets[f"{prefix}.input_layernorm"] = layer.input_layernorm
        targets[f"{prefix}.post_attention_layernorm"] = layer.post_attention_layernorm
        targets[f"{prefix}.mlp.gate_up_proj"] = layer.mlp.gate_up_proj
        targets[f"{prefix}.mlp.down_proj"] = layer.mlp.down_proj
        if index % 4 == 3:
            targets[prefix] = layer
            targets[f"{prefix}.qkv_proj"] = layer.qkv_proj
            targets[f"{prefix}.rotary_emb"] = layer.rotary_emb
            targets[f"{prefix}.attn"] = layer.attn
            targets[f"{prefix}.o_proj"] = layer.o_proj
        else:
            gdn = layer.linear_attn
            if gdn.layer_id != index:
                raise ValueError("Actual GDN layer ID mismatch")
            targets[f"{prefix}.linear_attn"] = gdn
            targets[f"{prefix}.linear_attn.in_proj_qkvzba"] = gdn.in_proj_qkvzba
            targets[f"{prefix}.linear_attn.norm"] = gdn.norm
            targets[f"{prefix}.linear_attn.out_proj"] = gdn.out_proj
    if len(targets) != 264:
        raise ValueError("All-layer module coverage mismatch")
    return layers, targets


@contextmanager
def observe_cached_targets(
    targets,
    ctx,
    backend,
    *,
    torch,
    kv_capture,
    gdn_capture,
    capture_kv,
    capture_state,
    prefill,
):
    observed = {"modules": {}, "kv": {}, "states": {}, "backend": {}}
    handles = []
    active_fa = None
    active_gdn = None

    def clone(value):
        return value.detach().cpu().clone() if isinstance(value, torch.Tensor) else None

    def copies(value):
        return [clone(x) for x in (value if isinstance(value, tuple) else (value,))]

    def pre(key):
        def hook(module, inputs):
            nonlocal active_fa, active_gdn
            fa = re.fullmatch(r"fa(\d+)", key)
            if fa:
                if active_fa is not None:
                    raise ValueError("FA nesting mismatch")
                active_fa = int(fa[1])
            rotary = re.fullmatch(r"fa(\d+)\.rotary_emb", key)
            if rotary and active_fa != int(rotary[1]):
                return
            if key in observed["modules"]:
                raise ValueError(f"{key} called more than once")
            observed["modules"][key] = {"inputs": copies(inputs)}
            attention = re.fullmatch(r"fa(\d+)\.attn", key)
            if attention:
                layer = int(attention[1])
                if inputs[3] is not ctx or active_fa != layer:
                    raise ValueError("FA context/identity mismatch")
                if capture_kv:
                    observed["kv"][layer] = {
                        "before": kv_capture(ctx, module, torch=torch, phase="before")
                    }
            gdn = re.fullmatch(r"l(\d+)\.linear_attn", key)
            if gdn:
                if (
                    inputs[1] is not ctx
                    or active_gdn is not None
                    or int(gdn[1]) % 4 == 3
                ):
                    raise ValueError("GDN context/identity/nesting mismatch")
                active_gdn = int(gdn[1])
                if capture_state:
                    observed["states"][active_gdn] = {
                        "before": gdn_capture(
                            ctx, layer_id=active_gdn, torch=torch, phase="before"
                        )
                    }

        return hook

    def post(key):
        def hook(module, inputs, output):
            nonlocal active_fa, active_gdn
            rotary = re.fullmatch(r"fa(\d+)\.rotary_emb", key)
            if rotary and active_fa != int(rotary[1]):
                return
            if output is not None:
                observed["modules"][key]["outputs"] = copies(output)
                attention = re.fullmatch(r"fa(\d+)\.attn", key)
                if attention and capture_kv:
                    layer = int(attention[1])
                    observed["kv"][layer]["after"] = kv_capture(
                        ctx, module, torch=torch, phase="after"
                    )
                gdn = re.fullmatch(r"l(\d+)\.linear_attn", key)
                if gdn and capture_state:
                    layer = int(gdn[1])
                    observed["states"][layer]["after"] = gdn_capture(
                        ctx, layer_id=layer, torch=torch, phase="after"
                    )
            if re.fullmatch(r"fa\d+", key):
                active_fa = None
            if re.fullmatch(r"l\d+\.linear_attn", key):
                active_gdn = None

        return hook

    original_decode = type(backend).forward_decode
    original_scan = type(backend)._decode_scan
    original_extend = type(backend).forward_extend
    original_prefill_scan = type(backend)._prefill_scan

    def decode(this, *args, **kwargs):
        if this is not backend or active_gdn is None:
            return original_decode(this, *args, **kwargs)
        record = observed["backend"].setdefault(active_gdn, {})
        if "decode" in record:
            raise ValueError("Duplicate GDN decode")
        record["decode"] = {
            name: clone(kwargs[name])
            for name in (
                "mixed_qkv",
                "conv_weights",
                "bias",
                "A_log",
                "dt_bias",
                "a",
                "b",
                "z",
            )
        }
        record["decode"]["metadata"] = {
            name: kwargs[name]
            for name in (
                "activation",
                "key_dim",
                "value_dim",
                "attention_tp_size",
                "head_k_dim",
                "head_v_dim",
                "seq_len",
            )
        }
        result = original_decode(this, *args, **kwargs)
        record["decode"]["output"] = clone(result)
        return result

    def scan(this, *args, **kwargs):
        if this is not backend or active_gdn is None:
            return original_scan(this, *args, **kwargs)
        record = observed["backend"].setdefault(active_gdn, {})
        if "scan" in record or len(args) != 6:
            raise ValueError("Duplicate/unknown GDN scan")
        record["scan"] = {
            name: clone(value)
            for name, value in zip(
                ("q", "k", "v", "pool", "read_indices", "write_indices"), args
            )
            if name != "pool"
        }
        record["scan"].update(
            {name: clone(kwargs[name]) for name in ("A_log", "dt_bias", "a", "b")}
        )
        result = original_scan(this, *args, **kwargs)
        record["scan"]["output"] = clone(result)
        return result

    def extend(this, *args, **kwargs):
        if this is not backend or active_gdn is None:
            return original_extend(this, *args, **kwargs)
        record = observed["backend"].setdefault(active_gdn, {})
        if not prefill or "extend" in record:
            raise ValueError("Duplicate/unexpected GDN Prefill")
        record["extend"] = {
            name: clone(kwargs[name])
            for name in (
                "mixed_qkv",
                "conv_weights",
                "bias",
                "A_log",
                "dt_bias",
                "a",
                "b",
                "z",
            )
        }
        original_conv = original_extend.__globals__["causal_conv1d_fn"]

        def conv(*conv_args, **conv_kwargs):
            entry = {
                name: clone(conv_kwargs[name])
                for name in ("has_initial_state", "cache_indices", "query_start_loc")
            }
            flag = conv_kwargs["has_initial_state"]
            entry["has_initial_state_python"] = (
                flag if flag is None or type(flag) is bool else None
            )
            entry["activation"] = conv_kwargs["activation"]
            record.setdefault("actual_conv_calls", []).append(entry)
            result = original_conv(*conv_args, **conv_kwargs)
            entry["output"] = clone(result)
            return result

        with patch.dict(original_extend.__globals__, {"causal_conv1d_fn": conv}):
            result = original_extend(this, *args, **kwargs)
        record["extend"]["output"] = clone(result)
        return result

    def prefill_scan(this, *args, **kwargs):
        if this is not backend or active_gdn is None:
            return original_prefill_scan(this, *args, **kwargs)
        record = observed["backend"].setdefault(active_gdn, {})
        if not prefill or len(args) != 5:
            raise ValueError("Unknown Prefill scan contract")
        entry = {
            name: clone(value)
            for name, value in zip(
                ("q", "k", "v", "initial_state", "query_start_loc"), args
            )
        }
        record.setdefault("prefill_scans", []).append(entry)
        entry.update(
            {name: clone(kwargs[name]) for name in ("A_log", "dt_bias", "a", "b")}
        )
        entry["metadata"] = {
            name: kwargs[name]
            for name in ("seq_len", "num_real_tokens", "lower_bound", "inputs_packed")
        }
        original_chunk = original_prefill_scan.__globals__["gdn_chunk_prefill"]

        def chunk(*chunk_args, **chunk_kwargs):
            if len(chunk_args) != 5 or "actual_chunk_g" in entry:
                raise ValueError("Unknown or repeated actual Prefill kernel")
            entry["actual_chunk_g"] = clone(chunk_args[3])
            entry["actual_chunk_beta"] = clone(chunk_args[4])
            entry["actual_chunk_initial_state"] = clone(chunk_kwargs["initial_state"])
            return original_chunk(*chunk_args, **chunk_kwargs)

        with patch.dict(
            original_prefill_scan.__globals__, {"gdn_chunk_prefill": chunk}
        ):
            result = original_prefill_scan(this, *args, **kwargs)
        entry["outputs"] = copies(result)
        return result

    try:
        for key, module in targets.items():
            handles.append(module.register_forward_pre_hook(pre(key)))
            handles.append(
                module.register_forward_hook(
                    post(key),
                    always_call=re.fullmatch(r"fa\d+|l\d+\.linear_attn", key)
                    is not None,
                )
            )
        with patch.object(type(backend), "forward_decode", decode), patch.object(
            type(backend), "_decode_scan", scan
        ), patch.object(type(backend), "forward_extend", extend), patch.object(
            type(backend), "_prefill_scan", prefill_scan
        ):
            yield observed
    finally:
        active_fa = active_gdn = None
        for handle in handles:
            handle.remove()


@contextmanager
def capture_cached(model, ctx, *, torch, output, rank, case, step, capture_step):
    from functools import partial

    from decode_kv_capture import capture_decode_kv
    from gdn_state_capture import capture_gdn_state
    from norm_boundaries import observe_norm_boundaries
    from output_head_capture import observe_output_head
    from prefill_state_capture import capture_prefill_state

    all_layers, fa_layers, gdn_layers = selected_layers()
    if (
        not 0 <= step <= capture_step
        or capture_step != len(case["continuation_ids"])
        or len(case["input_ids"]) != 128
        or capture_step not in (9, 17)
    ):
        raise ValueError("Original final common-frontier contract mismatch")
    prefill = step == 0
    if (
        ctx.bs != 1
        or ctx.input_num_tokens != (128 if prefill else 1)
        or ctx.num_extends != (1 if prefill else 0)
        or (not prefill and not ctx.forward_mode.is_decode())
    ):
        raise ValueError("Original Prefill/cached decode extent required")
    layers, targets = targets_for_layers(model)
    backend = ctx.attn_backend.linear_attn_backend
    tp = layers[3].attn_tp_size
    communication = {}
    for index, layer in enumerate(layers):
        item = {
            "should_fuse": layer.comm_manager.should_fuse(ctx.input_num_tokens),
            "use_all_reduce": layer.comm_manager.use_all_reduce(layer.is_moe),
            "attention_tp_rank": layer.mapping.attn.tp_rank,
            "attention_tp_size": layer.mapping.attn.tp_size,
            "dense_tp_rank": layer.mapping.dense.tp_rank,
            "dense_tp_size": layer.mapping.dense.tp_size,
        }
        if (
            item["should_fuse"]
            or not item["use_all_reduce"]
            or (
                item["attention_tp_rank"],
                item["dense_tp_rank"],
                item["attention_tp_size"],
                item["dense_tp_size"],
            )
            != (rank, rank, tp, tp)
        ):
            raise ValueError("Unobserved communication path/rank")
        communication[index] = item
    with observe_cached_targets(
        targets,
        ctx,
        backend,
        torch=torch,
        kv_capture=partial(capture_decode_kv, capture_step=capture_step),
        gdn_capture=capture_prefill_state if prefill else capture_gdn_state,
        capture_kv=step == capture_step,
        capture_state=step in (0, capture_step),
        prefill=prefill,
    ) as observed, observe_norm_boundaries(
        model, torch=torch
    ) as norms, observe_output_head(
        model, torch=torch
    ) as head:
        yield
    if set(observed["modules"]) != set(targets) or any(
        "outputs" not in row for row in observed["modules"].values()
    ):
        raise ValueError("Full decoder module observation incomplete")
    if (
        set(observed["kv"]) != (set(fa_layers) if step == capture_step else set())
        or set(observed["states"])
        != (set(gdn_layers) if step in (0, capture_step) else set())
        or set(observed["backend"]) != set(gdn_layers)
    ):
        raise ValueError("Full decoder state observation incomplete")
    metadata = {
        "case_id": case["case_id"],
        "step": step,
        "rank": rank,
        "tp": tp,
        "position": 127 + step,
        "prefix_length_before": 0 if prefill else 127 + step,
        "prefix_length_after": 128 + step,
        "all_layers": all_layers,
        "fa_layers": fa_layers,
        "gdn_layers": gdn_layers,
        "communication": communication,
        "precision": {
            "matmul_hf32": torch.npu.matmul.allow_hf32,
            "conv_hf32": torch.npu.conv.allow_hf32,
            "matmul_precision": torch.get_float32_matmul_precision(),
        },
        "performance_eligible": False,
        "runtime_state_written": False,
    }
    observed["norm_boundaries"] = norms
    observed["output_head"] = head
    observed["fa_constants"] = {
        index: {
            "q_gamma": layers[index].q_norm.gemma_weight.detach().cpu().clone(),
            "k_gamma": layers[index].k_norm.gemma_weight.detach().cpu().clone(),
            "epsilon": layers[index].q_norm.variance_epsilon,
            "scaling": layers[index].scaling,
            "rotary_dim": layers[index].rotary_emb.rotary_dim,
            "rotary_is_neox_style": layers[index].rotary_emb.is_neox_style,
            "rotary_cache": layers[index]
            .rotary_emb.cos_sin_cache[: 128 + step]
            .detach()
            .cpu()
            .clone(),
            "heads": layers[index].num_heads,
            "kv_heads": layers[index].num_kv_heads,
            "head_dim": layers[index].head_dim,
        }
        for index in fa_layers
    }
    with (output / f"fullpath_step{step}.pt").open("xb") as stream:
        torch.save({"metadata": metadata, "observed": observed}, stream)
    with (output / f"fullpath_step{step}_metadata.json").open("x") as stream:
        json.dump(metadata, stream, indent=2)
