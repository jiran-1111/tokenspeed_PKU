# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from types import SimpleNamespace

import numpy as np
import pytest
from norm_boundaries import observe_norm_boundaries, targets_for_norm_boundaries
from test_tensor_helpers import ForwardTensor


class Norm:
    def __init__(self):
        self.pre = []
        self.post = []
        self.gemma_weight = ForwardTensor([1.0, 2.0])
        self.variance_epsilon = 1e-6

    def register_forward_pre_hook(self, hook):
        self.pre.append(hook)
        return SimpleNamespace(remove=lambda: self.pre.remove(hook))

    def register_forward_hook(self, hook):
        self.post.append(hook)
        return SimpleNamespace(remove=lambda: self.post.remove(hook))

    def __call__(self, value, residual=None):
        inputs = (value, residual)
        for hook in self.pre:
            hook(self, inputs)
        if residual is not None:
            residual.values += value.values
        output = (value, residual)
        for hook in self.post:
            hook(self, inputs, output)
        return output


def model_fixture():
    modules = {}
    for index in range(32):
        modules[f"model.layers.{index}"] = object()
        for kind in ("input_layernorm", "post_attention_layernorm"):
            modules[f"model.layers.{index}.{kind}"] = Norm()
    modules["model.norm"] = Norm()
    return SimpleNamespace(named_modules=lambda: list(modules.items())), modules


def test_all_65_boundaries_preserve_inputs_before_residual_mutation_and_r3_names():
    model, modules = model_fixture()
    targets = targets_for_norm_boundaries(model)
    assert len(targets) == 65
    assert "layers.0.input_layernorm" in targets and "final_norm" in targets
    torch = SimpleNamespace(Tensor=ForwardTensor)
    with observe_norm_boundaries(model, torch=torch) as observed:
        for module in targets.values():
            module(ForwardTensor([[1.0, 2.0]]), ForwardTensor([[3.0, 4.0]]))
    assert len(observed) == 65
    item = observed["layers.0.input_layernorm"]
    np.testing.assert_array_equal(item["inputs"][1].values, [[3.0, 4.0]])
    np.testing.assert_array_equal(item["outputs"][1].values, [[4.0, 6.0]])
    np.testing.assert_array_equal(item["normalized"].values, [1.0, 2.0])
    assert item["epsilon"] == 1e-6
    np.testing.assert_array_equal(item["effective_gamma"].values, [1.0, 2.0])
    assert all(not module.pre and not module.post for module in targets.values())


@pytest.mark.parametrize("failure", ["original", "duplicate", "incomplete"])
def test_boundary_failure_removes_every_hook(failure):
    model, _ = model_fixture()
    targets = targets_for_norm_boundaries(model)
    with pytest.raises((ValueError, RuntimeError)):
        with observe_norm_boundaries(
            model, torch=SimpleNamespace(Tensor=ForwardTensor)
        ):
            module = targets["final_norm"]
            module(ForwardTensor([[1.0, 2.0]]))
            if failure == "original":
                raise RuntimeError("original forward failed")
            if failure == "duplicate":
                module(ForwardTensor([[1.0, 2.0]]))
    assert all(not module.pre and not module.post for module in targets.values())


@pytest.mark.parametrize(
    "missing", ["model.layers.31", "model.norm", "model.layers.0.input_layernorm"]
)
def test_unknown_or_incomplete_model_structure_is_rejected(missing):
    model, modules = model_fixture()
    del modules[missing]
    with pytest.raises(ValueError):
        targets_for_norm_boundaries(model)
