# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Record fresh Prefill mappings and actual output states without reading null data."""


def capture_prefill_state(ctx, *, layer_id, torch, phase):
    if phase not in ("before", "after") or layer_id not in tuple(
        i for i in range(32) if i % 4 != 3
    ):
        raise ValueError("Unknown Prefill state target")
    if (
        ctx.bs != 1
        or ctx.num_extends != 1
        or ctx.input_num_tokens != 128
        or ctx.forward_mode.is_decode()
    ):
        raise ValueError("Original single fresh128 Prefill required")
    router = ctx.attn_backend
    backend = router.linear_attn_backend
    pool = ctx.token_to_kv_pool
    if (
        router.cache_pool is not pool
        or backend.cache_pool is not pool
        or not backend.state_paging_active
    ):
        raise ValueError("Prefill cache pool identity mismatch")
    group = pool.state_group_by_layer[layer_id]
    metadata = backend.forward_metadata
    incoming = metadata.state_in_blocks_by_group[group]
    outgoing = metadata.state_out_blocks_by_group[group]
    if (
        incoming.dtype != torch.int32
        or outgoing.dtype != torch.int32
        or tuple(incoming.shape) != (1,)
        or tuple(outgoing.shape) != (1,)
    ):
        raise ValueError("Prefill mapping dtype/shape mismatch")
    state_in, state_out = int(incoming.cpu().item()), int(outgoing.cpu().item())
    conv = pool.get_component(layer_id, "conv_state")
    ssm = pool.get_component(layer_id, "recurrent_state")
    if (
        conv.ndim != 3
        or ssm.ndim != 4
        or conv.shape[0] != ssm.shape[0]
        or state_in != 0
        or not 0 < state_out < conv.shape[0]
    ):
        raise ValueError("Fresh Prefill requires null input and real output mapping")
    if conv.dtype != torch.bfloat16 or ssm.dtype != torch.float32:
        raise ValueError("Frozen Prefill storage dtype mismatch")
    result = {
        "metadata": {
            "phase": phase,
            "layer_id": layer_id,
            "state_in_slot": state_in,
            "state_out_slot": state_out,
            "fresh_input": True,
            "null_slot_data_read": False,
            "effective_initial_state_captured_at_scan": True,
            "group_id": group,
            "pool_rank": pool.rank,
            "conv_shape": list(conv.shape[1:]),
            "ssm_shape": list(ssm.shape[1:]),
            "runtime_state_written": False,
        }
    }
    if phase == "after":
        result["conv_state"] = conv[state_out].detach().cpu().clone()
        result["ssm_state"] = ssm[state_out].detach().cpu().clone()
    return result
