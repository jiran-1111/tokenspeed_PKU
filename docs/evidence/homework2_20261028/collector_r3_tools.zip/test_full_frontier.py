# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import json
from contextlib import contextmanager, nullcontext
from types import SimpleNamespace as NS
from unittest.mock import patch

import numpy as np
import pytest
from frontier_capture import install
from test_decode_kv_capture import TORCH
from test_tensor_helpers import ForwardTensor


@pytest.mark.parametrize("last_step", [9, 17])
def test_all_original_forwards_captured_once_identity_once_and_logits_unchanged(
    tmp_path, last_step
):
    case = {
        "case_id": f"original_{last_step}",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(last_step)),
        "capture_step": last_step,
        "output": str(tmp_path),
        "config_path": str(tmp_path / "config.json"),
    }
    arm = tmp_path / "arm.json"
    arm.write_text(json.dumps(case))
    vector = ForwardTensor(np.arange(248320).reshape(1, -1))
    captures, saved = [], []

    class Runner:
        global_rank = 0
        model = NS(model=NS(layers=[None] * 3 + [NS(attn_tp_size=1)]))

        def forward(self, ctx, input_ids, positions):
            return NS(next_token_logits=vector)

    class Executor:
        def _run_sampling(self, logits_output, sampling_info, ctx, candidates=None):
            return ForwardTensor([248319]), ForwardTensor([1])

    @contextmanager
    def capture(model, ctx, **kwargs):
        captures.append(kwargs["step"])
        yield

    torch = NS(
        isfinite=TORCH.isfinite,
        equal=lambda a, b: np.array_equal(a.values, b.values),
        save=lambda record, stream: saved.append(record),
    )
    with patch("cached_capture.capture_cached", capture), patch(
        "parameter_identity.verify_model"
    ) as identity, patch(
        "parameter_identity.text_forward_scope", lambda model: nullcontext()
    ):
        install(Runner, Executor, torch=torch, arm_path=arm, capture_step=last_step)
        runner, executor = Runner(), Executor()
        for step in range(last_step + 1):
            ids = (
                case["input_ids"] if step == 0 else [case["continuation_ids"][step - 1]]
            )
            pos = list(range(128)) if step == 0 else [127 + step]
            result = runner.forward(None, ForwardTensor(ids), ForwardTensor(pos))
            assert result.next_token_logits is vector
            emitted, _ = executor._run_sampling(result, None, None)
            assert emitted.item() == (
                case["continuation_ids"][step] if step < last_step else 248319
            )
        assert identity.call_count == 1
        with pytest.raises(ValueError):
            runner.forward(None, ForwardTensor([1]), ForwardTensor([128 + last_step]))
    assert captures == list(range(last_step + 1))
    assert len(saved) == last_step + 1
    assert all(np.array_equal(row["logits"].values, vector.values[0]) for row in saved)
