#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import unittest
from pathlib import Path
from types import SimpleNamespace


class CachedCaptureTests(unittest.TestCase):
    def setUp(self):
        path = Path(__file__).with_name("cached_capture.py")
        self.assertTrue(path.exists(), "cached capture implementation is missing")
        spec = importlib.util.spec_from_file_location("cached_capture", path)
        self.capture = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.capture)
        import pytest

        torch = pytest.importorskip(
            "torch",
            reason="local environment has no Torch; server verification must run zero skips",
        )

        self.torch = torch

    def fixture(self, fail=False):
        torch = self.torch
        trace = []

        class Backend:
            def forward_extend(self, *args, **kwargs):
                raise AssertionError("Unexpected Prefill")

            def _prefill_scan(self, *args, **kwargs):
                raise AssertionError("Unexpected Prefill scan")

            def _decode_scan(self, q, k, v, state, read, write, **kwargs):
                trace.append("original_scan")
                return q

            def forward_decode(self, *args, **kwargs):
                trace.append("original_decode")
                return self._decode_scan(
                    kwargs["mixed_qkv"],
                    kwargs["mixed_qkv"],
                    kwargs["mixed_qkv"],
                    None,
                    None,
                    None,
                    A_log=kwargs["A_log"],
                    dt_bias=kwargs["dt_bias"],
                    a=kwargs["a"],
                    b=kwargs["b"],
                )

        backend = Backend()

        class GDN(torch.nn.Module):
            def forward(self, x, ctx):
                if fail:
                    raise RuntimeError("original failed")
                return backend.forward_decode(
                    None,
                    None,
                    None,
                    None,
                    None,
                    1,
                    mixed_qkv=x,
                    conv_weights=x,
                    bias=None,
                    activation="silu",
                    key_dim=2,
                    value_dim=2,
                    attention_tp_size=1,
                    head_k_dim=2,
                    head_v_dim=2,
                    seq_len=1,
                    A_log=x,
                    dt_bias=x,
                    a=x,
                    b=x,
                    z=x,
                )

        gdn = GDN()

        def kv(ctx, module, *, torch, phase):
            trace.append("kv_" + phase)
            return {"phase": phase}

        def state(ctx, *, layer_id, torch, phase):
            trace.append(f"state_{layer_id}_{phase}")
            return {"phase": phase, "copy": torch.ones(2)}

        return backend, gdn, kv, state, trace

    def test_backend_wrappers_preserve_calls_outputs_and_restore_class(self):
        torch = self.torch
        backend, gdn, kv, state, trace = self.fixture()
        ctx = object()
        original_decode = type(backend).forward_decode
        original_scan = type(backend)._decode_scan
        value = torch.ones((1, 2), dtype=torch.bfloat16)
        with self.capture.observe_cached_targets(
            {"l8.linear_attn": gdn},
            ctx,
            backend,
            torch=torch,
            kv_capture=kv,
            gdn_capture=state,
            capture_kv=True,
            capture_state=True,
            prefill=False,
        ) as observed:
            self.assertIs(gdn(value, ctx), value)
        self.assertEqual(
            trace,
            ["state_8_before", "original_decode", "original_scan", "state_8_after"],
        )
        self.assertEqual(observed["backend"][8]["scan"]["q"].dtype, torch.bfloat16)
        self.assertTrue(
            torch.equal(observed["backend"][8]["decode"]["mixed_qkv"], value)
        )
        self.assertIs(type(backend).forward_decode, original_decode)
        self.assertIs(type(backend)._decode_scan, original_scan)
        self.assertFalse(gdn._forward_hooks or gdn._forward_pre_hooks)

    def test_exception_preserves_error_and_cleans_all_hooks(self):
        backend, gdn, kv, state, trace = self.fixture(fail=True)
        ctx = object()
        original = type(backend).forward_decode
        with self.assertRaisesRegex(RuntimeError, "original failed"):
            with self.capture.observe_cached_targets(
                {"l8.linear_attn": gdn},
                ctx,
                backend,
                torch=self.torch,
                kv_capture=kv,
                gdn_capture=state,
                capture_kv=True,
                capture_state=True,
                prefill=False,
            ):
                gdn(self.torch.ones(1, 2), ctx)
        self.assertIs(type(backend).forward_decode, original)
        self.assertFalse(gdn._forward_hooks or gdn._forward_pre_hooks)
        self.assertNotIn("state_8_after", trace)

    def test_shared_rotary_outside_fa7_is_excluded(self):
        torch = self.torch
        backend, gdn, kv, state, trace = self.fixture()
        ctx = object()
        rotary = torch.nn.Identity()

        class FA(torch.nn.Module):
            def forward(self, x):
                return rotary(x)

        fa = FA()
        value = torch.ones(1, 2)
        with self.capture.observe_cached_targets(
            {"fa7": fa, "fa7.rotary_emb": rotary},
            ctx,
            backend,
            torch=torch,
            kv_capture=kv,
            gdn_capture=state,
            capture_kv=True,
            capture_state=True,
            prefill=False,
        ) as observed:
            rotary(value * 2)
            self.assertIs(fa(value), value)
            rotary(value * 3)
        self.assertTrue(
            torch.equal(observed["modules"]["fa7.rotary_emb"]["inputs"][0], value)
        )

    def test_copies_inputs_before_inplace_mutation_and_rejects_duplicate(self):
        torch = self.torch
        backend, gdn, kv, state, trace = self.fixture()
        ctx = object()

        class Norm(torch.nn.Module):
            def forward(self, value, residual):
                residual.add_(value)
                return value, residual

        norm = Norm()
        x = torch.ones(1, 2, dtype=torch.bfloat16)
        residual = torch.ones_like(x)
        with self.assertRaisesRegex(ValueError, "more than once"):
            with self.capture.observe_cached_targets(
                {"l8.input_layernorm": norm},
                ctx,
                backend,
                torch=torch,
                kv_capture=kv,
                gdn_capture=state,
                capture_kv=True,
                capture_state=True,
                prefill=False,
            ) as observed:
                norm(x, residual)
                self.assertTrue(
                    torch.equal(
                        observed["modules"]["l8.input_layernorm"]["inputs"][1], x
                    )
                )
                self.assertTrue(
                    torch.equal(
                        observed["modules"]["l8.input_layernorm"]["outputs"][1], x * 2
                    )
                )
                norm(x, residual)
        self.assertFalse(norm._forward_hooks or norm._forward_pre_hooks)


if __name__ == "__main__":
    unittest.main()
