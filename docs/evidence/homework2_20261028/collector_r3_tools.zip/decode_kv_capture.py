#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read the real FA7 selected cached decode prefix without forwarding or copying the pool."""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def capture_decode_kv(ctx, paged_layer, *, torch, phase, capture_step: int) -> dict:
    """Return only the selected step's valid before/after prefix as CPU clones.

    The caller selects the actual PagedAttention pre/post hooks and
    independently captures input positions/Q/K/V. No prefix is recomputed.
    """
    try:
        return _capture_decode_kv(
            ctx, paged_layer, torch=torch, phase=phase, capture_step=capture_step
        )
    except (AttributeError, KeyError) as error:
        raise ValueError(f"Unknown frozen decode cache structure: {error}") from error


def _capture_decode_kv(ctx, layer, *, torch, phase, capture_step: int) -> dict:
    require(
        type(capture_step) is int and capture_step in (8, 9, 17),
        "capture_step must be explicitly 8 or 9",
    )
    position = 128 + capture_step - 1
    prefix_length_after = position + 1
    require(phase in ("before", "after"), "phase must be before or after")
    require(
        type(layer.layer_id) is int and layer.layer_id in tuple(range(3, 32, 4)),
        "decode KV capture requires an actual FA layer",
    )
    require(
        ctx.forward_mode.is_decode()
        and ctx.bs == 1
        and ctx.num_extends == 0
        and ctx.input_num_tokens == 1,
        "decode KV capture requires one plain decode token",
    )
    require(
        layer.sliding_window_size == -1
        and layer.logit_cap == 0.0
        and layer.scaling == 0.0625,
        "unsupported full-attention options",
    )
    require(layer.tp_q_head_num in (8, 16), "unsupported local query heads")
    tp = 16 // layer.tp_q_head_num
    heads = 4 // tp
    require(
        layer.tp_k_head_num == layer.tp_v_head_num == heads
        and layer.qk_head_dim == layer.v_head_dim == 256,
        "unsupported local KV heads/dimensions",
    )

    hybrid = ctx.attn_backend
    require(
        type(hybrid).__name__ == "HybridLinearAttnBackend"
        and layer.layer_id in hybrid.full_attn_layers,
        "unknown full-attention hybrid route",
    )
    router = hybrid.full_attn_backend
    require(
        type(router).__name__ == "CacheGroupRouter"
        and router.is_draft is False
        and router._decode_request_offset == 0,
        "unknown or draft cache-group route",
    )
    leaf = router.leaves[layer.group_id]
    require(
        type(leaf).__name__ == "MHAAttnBackend" and leaf.block_decode_expansion == 1,
        "unknown or expanded decode leaf",
    )
    require(
        not leaf.is_fp8
        and not leaf.is_mxfp8
        and leaf.qkv_dtype == torch.bfloat16
        and leaf.kv_cache_dtype == torch.bfloat16,
        "only the actual dense BF16 cache path is supported",
    )
    page_size = leaf.kernel_page_size
    require(
        type(page_size) is int and page_size in (64, 128),
        "unsupported actual kernel page size",
    )

    pool = ctx.token_to_kv_pool
    require(
        type(pool).__name__ in ("HybridMHATokenToKVPool", "MHATokenToKVPool")
        and pool.dtype == torch.bfloat16,
        "unknown or non-BF16 cache pool",
    )
    require(
        type(pool.rank) is int and 0 <= pool.rank < tp,
        "cache pool rank differs from TP geometry",
    )
    require(
        pool.history_group_by_layer()[layer.layer_id] == layer.group_id,
        "pool/layer history group mismatch",
    )
    matching = [
        spec for spec in pool.arena.cache_group_specs if spec.group_id == layer.group_id
    ]
    require(len(matching) == 1, "cache group must have one actual arena specification")
    spec = matching[0]
    require(
        spec.family == "history"
        and spec.retention == "full_history"
        and spec.entry_stride_tokens == 1
        and spec.shard_count == 1
        and spec.block_granularity == spec.rows_per_page
        and spec.block_granularity % page_size == 0,
        "unsupported compressed, sliding, or sharded cache group",
    )

    actual = leaf.forward_decode_metadata
    page_table, seq_lens = actual.page_table, actual.seq_lens
    write_locations = router.write_locations(layer, ctx.forward_mode)
    for tensor in (page_table, seq_lens, write_locations):
        require(
            isinstance(tensor, torch.Tensor)
            and tensor.dtype in (torch.int32, torch.int64),
            "page table, sequence lengths, and write locations must be integer tensors",
        )
    require(
        page_table.ndim == 2
        and page_table.shape[0] == 1
        and tuple(seq_lens.shape) == (1,)
        and tuple(write_locations.shape) == (1,),
        "decode metadata requires one live request",
    )
    # Copy only tiny metadata here. No pool payload has been read or copied.
    page_table_cpu = page_table.detach().cpu().clone()
    seq_lens_cpu = seq_lens.detach().cpu().clone()
    locations_cpu = write_locations.detach().cpu().clone()
    table, lengths, locations = (
        page_table_cpu.tolist(),
        seq_lens_cpu.tolist(),
        locations_cpu.tolist(),
    )
    require(
        lengths == [prefix_length_after],
        f"step{capture_step} decode metadata must have after-prefix length{prefix_length_after}",
    )
    valid_length = position if phase == "before" else prefix_length_after
    page_count = (valid_length + page_size - 1) // page_size
    require(
        page_table.shape[1] >= page_count,
        "actual page table is shorter than the valid prefix",
    )

    # This frozen MHA accessor performs the exact pool get_key/value_buffer
    # views consumed by forward_decode: [pages, kernel_page_size, heads, D].
    # It does not execute attention or read/copy the complete pool payload.
    k_cache, v_cache = leaf._get_kv_cache(layer, pool)
    require(
        isinstance(k_cache, torch.Tensor)
        and isinstance(v_cache, torch.Tensor)
        and k_cache.dtype == v_cache.dtype == torch.bfloat16,
        "actual K/V cache must retain its BF16 dtype",
    )
    require(
        k_cache.ndim == v_cache.ndim == 4
        and tuple(k_cache.shape) == tuple(v_cache.shape)
        and tuple(k_cache.shape[1:]) == (page_size, heads, 256),
        "actual MHA paged cache shape mismatch",
    )
    pages = table[0][:page_count]
    require(
        all(type(page) is int and 0 < page < k_cache.shape[0] for page in pages)
        and len(set(pages)) == page_count,
        "valid page table contains null, repeated, or out-of-range pages",
    )
    current_page = table[0][position // page_size]
    expected_location = current_page * page_size + position % page_size
    require(
        locations == [expected_location],
        "actual decode write slot disagrees with the kernel page table",
    )

    keys, values, spans = [], [], []
    for logical_page, physical_page in enumerate(pages):
        count = min(page_size, valid_length - logical_page * page_size)
        # In before phase the final slice stops BEFORE the current write slot.
        keys.append(k_cache[physical_page, :count].detach().cpu().clone())
        values.append(v_cache[physical_page, :count].detach().cpu().clone())
        spans.append(
            {
                "logical_page": logical_page,
                "physical_page": physical_page,
                "row_count": count,
            }
        )
    key, value = torch.cat(keys, dim=0), torch.cat(values, dim=0)
    require(
        tuple(key.shape) == tuple(value.shape) == (valid_length, heads, 256),
        "selected cache prefix shape mismatch",
    )
    require(
        bool(torch.isfinite(key).all()) and bool(torch.isfinite(value).all()),
        "selected valid cache rows must be finite",
    )
    metadata = {
        "phase": phase,
        "layer_id": layer.layer_id,
        "step": capture_step,
        "rank": pool.rank,
        "tp": tp,
        "forward_mode": ctx.forward_mode.name,
        "group_id": layer.group_id,
        "backend_path": [
            type(hybrid).__name__,
            type(router).__name__,
            type(leaf).__name__,
        ],
        "pool_class": type(pool).__name__,
        "kernel_solution": leaf.kernel_solution,
        "kernel_page_size": page_size,
        "block_granularity": spec.block_granularity,
        "rows_per_page": spec.rows_per_page,
        "entry_stride_tokens": spec.entry_stride_tokens,
        "shard_count": spec.shard_count,
        "cache_layout": "[kernel_pages,kernel_page_tokens,local_kv_heads,head_dim]",
        "cache_shape": list(k_cache.shape),
        "cache_stride": list(k_cache.stride()),
        "dtype": str(key.dtype),
        "local_q_heads": layer.tp_q_head_num,
        "local_kv_heads": heads,
        "head_dim": 256,
        "scaling": layer.scaling,
        "actual_seq_lens": lengths,
        "actual_page_table": table,
        "actual_write_locations": locations,
        "valid_length": valid_length,
        "valid_page_spans": spans,
        "current_position_contract": position,
        "current_kv_included": phase == "after",
        "prefix_recomputed": False,
        "entire_pool_exported": False,
    }
    return {
        "metadata": metadata,
        "k": key,
        "v": value,
        "page_table": page_table_cpu,
        "seq_lens": seq_lens_cpu,
        "write_locations": locations_cpu,
    }
