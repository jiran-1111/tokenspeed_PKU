# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from types import SimpleNamespace as NS

import pytest


def causal_conv1d_fn(x, **kwargs):
    return x


def gdn_chunk_prefill(q, k, v, g, beta, **kwargs):
    return NS(out=q, final_state=kwargs["initial_state"])


def test_actual_prefill_gate_state_and_outputs_are_copied_and_call_restored():
    torch = pytest.importorskip("torch")
    from cached_capture import observe_cached_targets

    class Backend:
        def forward_decode(self, *args, **kwargs):
            raise AssertionError("unexpected Decode")

        def _decode_scan(self, *args, **kwargs):
            raise AssertionError("unexpected Decode scan")

        def forward_extend(self, **kwargs):
            causal_conv1d_fn(
                kwargs["mixed_qkv"],
                has_initial_state=False,
                cache_indices=None,
                query_start_loc=None,
                activation="silu",
            )
            result, state = self._prefill_scan(
                kwargs["mixed_qkv"],
                kwargs["mixed_qkv"],
                kwargs["mixed_qkv"],
                kwargs["A_log"],
                kwargs["a"],
                A_log=kwargs["A_log"],
                dt_bias=kwargs["dt_bias"],
                a=kwargs["a"],
                b=kwargs["b"],
                seq_len=2,
                num_real_tokens=2,
                lower_bound=None,
                inputs_packed=False,
            )
            return result

        def _prefill_scan(self, q, k, v, state, offsets, **kwargs):
            result = gdn_chunk_prefill(
                q, k, v, kwargs["a"], kwargs["b"], initial_state=state
            )
            return result.out, result.final_state

    backend = Backend()

    class GDN(torch.nn.Module):
        def forward(self, x, ctx):
            return backend.forward_extend(
                mixed_qkv=x,
                conv_weights=x,
                bias=None,
                A_log=x,
                dt_bias=x,
                a=x,
                b=x,
                z=x,
            )

    ctx = object()
    module = GDN()
    value = torch.ones(1, 2)
    original = type(backend)._prefill_scan
    kernel = original.__globals__["gdn_chunk_prefill"]
    with observe_cached_targets(
        {"l0.linear_attn": module},
        ctx,
        backend,
        torch=torch,
        kv_capture=None,
        gdn_capture=None,
        capture_kv=False,
        capture_state=False,
        prefill=True,
    ) as observed:
        assert module(value, ctx) is value
    assert (
        observed["backend"][0]["actual_conv_calls"][0]["has_initial_state_python"]
        is False
    )
    entry = observed["backend"][0]["prefill_scans"][0]
    assert torch.equal(entry["actual_chunk_g"], value) and torch.equal(
        entry["actual_chunk_initial_state"], value
    )
    assert torch.equal(entry["outputs"][0], value)
    value.zero_()
    assert bool(entry["actual_chunk_g"].count_nonzero())
    assert (
        type(backend)._prefill_scan is original
        and original.__globals__["gdn_chunk_prefill"] is kernel
    )


def test_shared_rotary_hooks_are_bound_to_their_actual_fa_call():
    torch = pytest.importorskip("torch")
    from cached_capture import observe_cached_targets

    class Backend:
        def forward_decode(self, *a, **k):
            pass

        def _decode_scan(self, *a, **k):
            pass

        def forward_extend(self, *a, **k):
            pass

        def _prefill_scan(self, *a, **k):
            pass

    rotary = torch.nn.Identity()

    class FA(torch.nn.Module):
        def forward(self, x):
            return rotary(x)

    fa3, fa7 = FA(), FA()
    with observe_cached_targets(
        {"fa3": fa3, "fa7": fa7, "fa3.rotary_emb": rotary, "fa7.rotary_emb": rotary},
        object(),
        Backend(),
        torch=torch,
        kv_capture=None,
        gdn_capture=None,
        capture_kv=False,
        capture_state=False,
        prefill=False,
    ) as observed:
        fa3(torch.ones(1, 2))
        fa7(torch.full((1, 2), 2.0))
    assert float(observed["modules"]["fa3.rotary_emb"]["inputs"][0].sum()) == 2
    assert float(observed["modules"]["fa7.rotary_emb"]["inputs"][0].sum()) == 4
