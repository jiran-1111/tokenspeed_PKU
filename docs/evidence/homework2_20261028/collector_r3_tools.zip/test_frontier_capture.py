#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest

from frontier_capture import sampling_decision, validate_frontier


class FrontierTests(unittest.TestCase):
    def test_prefill_and_last_frontier(self):
        case = {"input_ids": [3, 4], "continuation_ids": [7, 8]}
        validate_frontier(case, step=0, input_ids=[3, 4], positions=[0, 1])
        validate_frontier(case, step=2, input_ids=[8], positions=[3])

    def test_wrong_or_extra_frontier_rejected(self):
        case = {"input_ids": [3, 4], "continuation_ids": [7, 8]}
        for step, ids, positions in ((1, [8], [2]), (2, [8], [4]), (3, [8], [4])):
            with self.assertRaises(ValueError):
                validate_frontier(case, step=step, input_ids=ids, positions=positions)

    def test_only_rank_zero_requires_local_argmax(self):
        with self.assertRaises(ValueError):
            sampling_decision(rank=0, greedy=5, sampled=6, accepted=1, forced=None)
        self.assertEqual(
            sampling_decision(rank=1, greedy=5, sampled=6, accepted=1, forced=None), 6
        )

    def test_fixed_continuation_overrides_only_emitted_token(self):
        self.assertEqual(
            sampling_decision(rank=0, greedy=5, sampled=5, accepted=1, forced=7), 7
        )
        self.assertEqual(
            sampling_decision(rank=1, greedy=4, sampled=5, accepted=1, forced=7), 7
        )

    def test_invalid_acceptance_rejected_on_both_ranks(self):
        for rank in (0, 1):
            with self.assertRaises(ValueError):
                sampling_decision(rank=rank, greedy=5, sampled=5, accepted=0, forced=7)


if __name__ == "__main__":
    unittest.main()
