# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Observe the original dense logits head; export no weight matrix."""

from contextlib import contextmanager
from unittest.mock import patch


@contextmanager
def observe_output_head(model, *, torch):
    head, processor = model.lm_head, model.logits_processor
    observed = {
        "weight": {"shape": list(head.weight.shape), "dtype": str(head.weight.dtype)},
        "precision": {
            "npu_matmul_allow_hf32": torch.npu.matmul.allow_hf32,
            "npu_conv_allow_hf32": torch.npu.conv.allow_hf32,
            "float32_matmul_precision": torch.get_float32_matmul_precision(),
        },
    }
    original_get_logits = type(processor)._get_logits
    original_matmul = torch.matmul
    active = False

    def clone(value):
        return value.detach().cpu().clone()

    def matmul(*args, **kwargs):
        if not active:
            return original_matmul(*args, **kwargs)
        if "matmul" in observed or len(args) != 2 or kwargs:
            raise ValueError("Unexpected original dense head matmul call contract")
        left, right = args
        if tuple(right.shape) != tuple(reversed(head.weight.shape)) or str(
            right.dtype
        ) != str(head.weight.dtype):
            raise ValueError("Original head matmul weight shape/dtype mismatch")
        item = {
            "input": clone(left),
            "rhs_shape": list(right.shape),
            "rhs_dtype": str(right.dtype),
            "weight_exported": False,
        }
        observed["matmul"] = item
        result = original_matmul(*args, **kwargs)
        item["output"] = clone(result)
        return result

    def get_logits(this, hidden_states, lm_head, *args, **kwargs):
        nonlocal active
        if this is not processor:
            return original_get_logits(this, hidden_states, lm_head, *args, **kwargs)
        if active or "input" in observed or lm_head is not head:
            raise ValueError("Original head identity/nesting/call count mismatch")
        observed["input"] = clone(hidden_states)
        active = True
        try:
            result = original_get_logits(this, hidden_states, lm_head, *args, **kwargs)
            observed["output"] = clone(result)
            return result
        finally:
            active = False

    with patch.object(type(processor), "_get_logits", get_logits), patch.object(
        torch, "matmul", matmul
    ):
        yield observed
    if (
        "output" not in observed
        or "matmul" not in observed
        or "output" not in observed["matmul"]
    ):
        raise ValueError("Original dense output head observation incomplete")
