# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from types import SimpleNamespace as NS

import numpy as np
import pytest
from decode_kv_capture import capture_decode_kv
from test_decode_kv_capture import TORCH, Tensor, fixture


@pytest.mark.parametrize("layer_id", list(range(3, 32, 4)))
def test_every_actual_fa_layer_uses_its_own_history_mapping(layer_id):
    ctx, layer, leaf, router, pool, k, v, calls = fixture()
    layer.layer_id = layer_id
    ctx.attn_backend.full_attn_layers = {layer_id}
    pool.history_group_by_layer = lambda: {layer_id: layer.group_id}
    result = capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=8)
    assert result["metadata"]["layer_id"] == layer_id
    assert calls == [("k", layer_id), ("v", layer_id)]


def test_four_b_final_frontier_reads_exact_144_to_145_history_rows():
    ctx, layer, leaf, router, pool, key, value, _ = fixture()
    leaf.forward_decode_metadata.seq_lens = Tensor([145], "torch.int32")
    table = leaf.forward_decode_metadata.page_table.tolist()[0]
    for token in range(135, 145):
        page, offset = table[token // 128], token % 128
        key.values[page, offset] = token
        value.values[page, offset] = 1000 + token
    slot = table[1] * 128 + 16
    router.write_locations = lambda layer, mode: Tensor([slot], "torch.int64")
    before = capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=17)
    after = capture_decode_kv(ctx, layer, torch=TORCH, phase="after", capture_step=17)
    assert before["k"].shape == (144, 2, 256) and after["k"].shape == (145, 2, 256)
    np.testing.assert_array_equal(after["k"].values[:, 0, 0], np.arange(145))


def test_prefill_boundary_retains_all_rows_and_last_row_binding():
    from norm_boundaries import observe_norm_boundaries
    from test_norm_boundaries import model_fixture
    from test_tensor_helpers import ForwardTensor

    model, _ = model_fixture()
    with observe_norm_boundaries(model, torch=NS(Tensor=ForwardTensor)) as observed:
        for _, module in [
            (k, m)
            for k, m in model.named_modules()
            if not k.endswith(tuple(f"layers.{i}" for i in range(32)))
        ]:
            module(ForwardTensor(np.arange(256).reshape(128, 2)))
    assert observed["final_norm"]["inputs"][0].shape == (128, 2)
    np.testing.assert_array_equal(
        observed["final_norm"]["normalized"].values, [254, 255]
    )


def test_prefill_state_only_reads_real_output_and_preserves_state_dtype():
    torch = pytest.importorskip("torch")
    from prefill_state_capture import capture_prefill_state

    conv = torch.arange(60).reshape(5, 4, 3).to(torch.bfloat16)
    state = torch.arange(80).reshape(5, 4, 2, 2).float()
    pool = NS(
        rank=0,
        state_group_by_layer={0: "s0"},
        get_component=lambda layer, name: conv if name == "conv_state" else state,
    )
    backend = NS(
        cache_pool=pool,
        state_paging_active=True,
        forward_metadata=NS(
            state_in_blocks_by_group={"s0": torch.tensor([0], dtype=torch.int32)},
            state_out_blocks_by_group={"s0": torch.tensor([2], dtype=torch.int32)},
        ),
    )
    ctx = NS(
        bs=1,
        num_extends=1,
        input_num_tokens=128,
        forward_mode=NS(is_decode=lambda: False),
        token_to_kv_pool=pool,
        attn_backend=NS(cache_pool=pool, linear_attn_backend=backend),
    )
    before = capture_prefill_state(ctx, layer_id=0, torch=torch, phase="before")
    after = capture_prefill_state(ctx, layer_id=0, torch=torch, phase="after")
    assert (
        "ssm_state" not in before and before["metadata"]["null_slot_data_read"] is False
    )
    assert after["ssm_state"].dtype == torch.float32 and torch.equal(
        after["ssm_state"], state[2]
    )
    state[2].zero_()
    assert bool(after["ssm_state"].count_nonzero())
    backend.forward_metadata.state_in_blocks_by_group["s0"] = torch.tensor(
        [1], dtype=torch.int32
    )
    with pytest.raises(ValueError):
        capture_prefill_state(ctx, layer_id=0, torch=torch, phase="before")
