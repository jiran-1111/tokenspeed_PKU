# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib
import json
import sys
import unittest
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))


class FakeTensor:
    def __init__(self, array, dtype, device="npu"):
        self.array = np.asarray(array)
        self.dtype = dtype
        self.device = SimpleNamespace(type=device)

    @property
    def ndim(self):
        return self.array.ndim

    @property
    def shape(self):
        return self.array.shape

    def detach(self):
        return self

    def cpu(self):
        return FakeTensor(self.array, self.dtype, "cpu")

    def clone(self):
        return FakeTensor(self.array.copy(), self.dtype, self.device.type)

    def tolist(self):
        return self.array.tolist()

    def __getitem__(self, key):
        return FakeTensor(self.array[key], self.dtype, self.device.type)


FAKE_TORCH = SimpleNamespace(
    Tensor=FakeTensor,
    bfloat16="torch.bfloat16",
    float32="torch.float32",
    int32="torch.int32",
    no_grad=nullcontext,
)


class FakePool:
    def __init__(self, offset=0):
        self.rank, self.layer_num, self.offset = 1, 12, offset
        self.state_group_by_layer = {
            layer: f"linear_attention.{layer}" for layer in (8, 9, 10)
        }
        self.components, self.fields = {}, {}
        specs = []
        for layer, group in self.state_group_by_layer.items():
            conv = FakeTensor(
                np.arange(7 * 20 * 3, dtype=np.float16).reshape(7, 20, 3) + layer,
                FAKE_TORCH.bfloat16,
            )
            ssm = FakeTensor(
                np.arange(7 * 4 * 3 * 2, dtype=np.float32).reshape(7, 4, 3, 2) + layer,
                FAKE_TORCH.float32,
            )
            self.components[layer] = {"conv_state": conv, "recurrent_state": ssm}
            for plane, tensor in (("conv", conv), ("ssm", ssm)):
                field_id = f"layer.{layer + offset}.{plane}"
                self.fields[field_id] = SimpleNamespace(
                    field_id=field_id,
                    group_id=group,
                    shape=tuple(tensor.shape[1:]),
                    dtype=str(tensor.dtype).removeprefix("torch."),
                )
            specs.append(
                SimpleNamespace(
                    group_id=group,
                    family="state",
                    retention="full_history",
                    checkpoint_granularity=128,
                    shard_count=1,
                )
            )
        self.arena = SimpleNamespace(
            cache_group_specs=tuple(specs),
            plan=SimpleNamespace(field=self.fields.__getitem__),
            runtime_contract=SimpleNamespace(
                prefix_granularity=128,
                group_page_counts={
                    group: 7 for group in self.state_group_by_layer.values()
                },
            ),
        )

    def _field_layer_id(self, layer_id):
        return self.offset + layer_id

    def get_component(self, layer_id, component_name):
        return self.components[layer_id][component_name]


def make_context(offset=0):
    pool = FakePool(offset)
    groups = pool.state_group_by_layer.values()
    metadata = SimpleNamespace(
        state_in_blocks_by_group={
            group: FakeTensor([2], FAKE_TORCH.int32) for group in groups
        },
        state_out_blocks_by_group={
            group: FakeTensor([5], FAKE_TORCH.int32) for group in groups
        },
    )
    linear = SimpleNamespace(
        cache_pool=pool,
        state_paging_active=True,
        is_draft=False,
        spec_num_tokens=1,
        forward_metadata=metadata,
    )
    router = SimpleNamespace(
        linear_attn_backend=linear, cache_pool=pool, full_attn_layers={3, 7, 11}
    )
    return SimpleNamespace(
        bs=1,
        num_extends=0,
        input_num_tokens=1,
        forward_mode=SimpleNamespace(name="DECODE", is_decode=lambda: True),
        attn_backend=router,
        token_to_kv_pool=pool,
    )


class GDNStateCaptureTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue(
            (TASK / "gdn_state_capture.py").is_file(), "GDN state helper missing"
        )
        self.helper = importlib.import_module("gdn_state_capture")

    def capture(self, ctx, phase="before", layer=8):
        return self.helper.capture_gdn_state(
            ctx, layer_id=layer, torch=FAKE_TORCH, phase=phase
        )

    def test_before_reads_real_input_slot_and_returns_independent_cpu_copies(self):
        ctx = make_context()
        source = ctx.token_to_kv_pool.components[8]
        expected_conv, expected_ssm = (
            source["conv_state"].array[2].copy(),
            source["recurrent_state"].array[2].copy(),
        )
        result = self.capture(ctx)
        np.testing.assert_array_equal(result["conv_state"].array, expected_conv)
        np.testing.assert_array_equal(result["ssm_state"].array, expected_ssm)
        source["conv_state"].array[2] += 100
        source["recurrent_state"].array[2] -= 100
        np.testing.assert_array_equal(result["conv_state"].array, expected_conv)
        np.testing.assert_array_equal(result["ssm_state"].array, expected_ssm)
        self.assertEqual(result["conv_state"].device.type, "cpu")
        self.assertEqual(result["ssm_state"].device.type, "cpu")
        self.assertEqual(result["conv_state"].dtype, source["conv_state"].dtype)
        self.assertEqual(result["ssm_state"].dtype, source["recurrent_state"].dtype)

    def test_after_selects_different_actual_output_slot(self):
        ctx = make_context()
        before, after = self.capture(ctx), self.capture(ctx, "after")
        np.testing.assert_array_equal(
            after["conv_state"].array,
            ctx.token_to_kv_pool.components[8]["conv_state"].array[5],
        )
        np.testing.assert_array_equal(
            after["ssm_state"].array,
            ctx.token_to_kv_pool.components[8]["recurrent_state"].array[5],
        )
        self.assertEqual(before["metadata"]["selected_state_slot"], 2)
        self.assertEqual(after["metadata"]["selected_state_slot"], 5)
        self.assertFalse(
            np.array_equal(before["ssm_state"].array, after["ssm_state"].array)
        )

    def test_layer_mapping_heads_and_request_binding_are_truthful_json_metadata(self):
        ctx = make_context(offset=4)
        for layer in (8, 9, 10):
            result = self.capture(ctx, layer=layer)
            metadata = result["metadata"]
            json.dumps(metadata, allow_nan=False)
            self.assertEqual(metadata["layer_id"], layer)
            self.assertEqual(metadata["field_layer_id"], layer + 4)
            self.assertEqual(metadata["conv_field_id"], f"layer.{layer + 4}.conv")
            self.assertEqual(metadata["cache_group_id"], f"linear_attention.{layer}")
            self.assertEqual(
                metadata["heads"],
                {
                    "local_key_heads": 2,
                    "local_value_heads": 4,
                    "key_head_dim": 2,
                    "value_head_dim": 3,
                },
            )
            self.assertEqual(metadata["request_batch_row"], 0)
            self.assertEqual(metadata["runtime_request_id"], "not_available")
            self.assertTrue(metadata["caller_binding_required"])

    def test_multi_request_prefill_verify_or_mismatched_pool_are_rejected(self):
        variants = []
        for field, value in (("bs", 2), ("input_num_tokens", 2), ("num_extends", 1)):
            ctx = make_context()
            ctx.__dict__[field] = value
            variants.append(ctx)
        ctx = make_context()
        ctx.forward_mode = SimpleNamespace(name="EXTEND", is_decode=lambda: False)
        variants.append(ctx)
        ctx = make_context()
        ctx.attn_backend.linear_attn_backend.spec_num_tokens = 2
        variants.append(ctx)
        ctx = make_context()
        ctx.token_to_kv_pool = FakePool()
        variants.append(ctx)
        for ctx in variants:
            with self.subTest(ctx=ctx), self.assertRaises(ValueError):
                self.capture(ctx)

    def test_null_padding_out_of_range_and_wrong_index_dtype_are_rejected(self):
        for index in (0, -1, 7):
            for field in ("state_in_blocks_by_group", "state_out_blocks_by_group"):
                ctx = make_context()
                ctx.attn_backend.linear_attn_backend.forward_metadata.__dict__[field][
                    "linear_attention.8"
                ] = FakeTensor([index], FAKE_TORCH.int32)
                with self.subTest(index=index, field=field), self.assertRaises(
                    ValueError
                ):
                    self.capture(ctx)
        ctx = make_context()
        ctx.attn_backend.linear_attn_backend.forward_metadata.state_in_blocks_by_group[
            "linear_attention.8"
        ] = FakeTensor([2.5], FAKE_TORCH.float32)
        with self.assertRaises(ValueError):
            self.capture(ctx)

    def test_missing_metadata_or_unknown_context_is_rejected_without_fallback(self):
        with self.assertRaises(ValueError):
            self.capture(SimpleNamespace())
        ctx = make_context()
        ctx.attn_backend.linear_attn_backend.forward_metadata = None
        with self.assertRaises(ValueError):
            self.capture(ctx)
        ctx = make_context()
        del ctx.attn_backend.linear_attn_backend.forward_metadata.state_out_blocks_by_group[
            "linear_attention.8"
        ]
        with self.assertRaises(ValueError):
            self.capture(ctx)

    def test_cache_family_plan_geometry_and_layer_selection_are_verified(self):
        ctx = make_context()
        ctx.token_to_kv_pool.arena.cache_group_specs[0].family = "history"
        with self.assertRaises(ValueError):
            self.capture(ctx)
        ctx = make_context()
        ctx.token_to_kv_pool.fields["layer.8.conv"].group_id = "wrong_group"
        with self.assertRaises(ValueError):
            self.capture(ctx)
        ctx = make_context()
        ctx.token_to_kv_pool.fields["layer.8.ssm"].shape = (4, 2, 3)
        with self.assertRaises(ValueError):
            self.capture(ctx)
        for layer in (7, -1, True):
            with self.subTest(layer=layer), self.assertRaises(ValueError):
                self.capture(make_context(), layer=layer)

    def test_invalid_phase_and_non_tensor_state_are_rejected(self):
        with self.assertRaises(ValueError):
            self.capture(make_context(), "replacement")
        ctx = make_context()
        ctx.token_to_kv_pool.components[8]["recurrent_state"] = np.zeros((7, 4, 3, 2))
        with self.assertRaises(ValueError):
            self.capture(ctx)

    def test_module_does_not_import_torch_or_runtime(self):
        import builtins

        original = builtins.__import__

        def reject_runtime(name, *args, **kwargs):
            if name == "torch" or name.startswith(("torch_npu", "tokenspeed")):
                raise AssertionError("local helper must not import runtime/Torch")
            return original(name, *args, **kwargs)

        with patch.object(builtins, "__import__", side_effect=reject_runtime):
            importlib.reload(self.helper)
            self.capture(make_context())


if __name__ == "__main__":
    unittest.main()
