# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from types import SimpleNamespace

import numpy as np
import pytest
from output_head_capture import observe_output_head
from test_tensor_helpers import ForwardTensor


def fixture(*, fail):
    head = SimpleNamespace(weight=ForwardTensor(np.ones((4, 2)), "torch.float32"))
    torch = SimpleNamespace(
        Tensor=ForwardTensor,
        npu=SimpleNamespace(
            matmul=SimpleNamespace(allow_hf32=False),
            conv=SimpleNamespace(allow_hf32=True),
        ),
        get_float32_matmul_precision=lambda: "highest",
        matmul=lambda left, right: ForwardTensor(
            left.values @ right.values, "torch.float32"
        ),
    )

    class Processor:
        def _get_logits(self, hidden_states, lm_head, metadata, *, plan):
            if fail:
                raise RuntimeError("original head failure")
            cast = ForwardTensor(hidden_states.values, "torch.float32")
            return torch.matmul(
                cast, ForwardTensor(lm_head.weight.values.T, "torch.float32")
            )

    processor = Processor()
    model = SimpleNamespace(
        lm_head=head,
        logits_processor=processor,
        named_modules=lambda: [("lm_head", head), ("logits_processor", processor)],
    )
    return model, torch, processor, head


def test_head_observes_actual_cast_operands_precision_and_output_without_weights():
    model, torch, processor, head = fixture(fail=False)
    original_matmul = torch.matmul
    original_get_logits = type(processor)._get_logits
    hidden = ForwardTensor([[1.0, 2.0]], "torch.bfloat16")
    with observe_output_head(model, torch=torch) as observed:
        result = processor._get_logits(hidden, head, object(), plan=None)
    assert torch.matmul is original_matmul
    assert type(processor)._get_logits is original_get_logits
    assert observed["input"].dtype == "torch.bfloat16"
    assert observed["matmul"]["input"].dtype == "torch.float32"
    assert observed["matmul"]["rhs_dtype"] == "torch.float32"
    assert observed["weight"] == {"shape": [4, 2], "dtype": "torch.float32"}
    assert observed["precision"] == {
        "npu_matmul_allow_hf32": False,
        "npu_conv_allow_hf32": True,
        "float32_matmul_precision": "highest",
    }
    np.testing.assert_array_equal(observed["output"].values, result.values)
    assert "weight_tensor" not in observed


def test_tied_head_alias_is_resolved_even_when_named_modules_deduplicates_it():
    model, torch, processor, head = fixture(fail=False)
    hidden = ForwardTensor([[1.0, 2.0]], "torch.bfloat16")
    model.lm_head = head
    model.logits_processor = processor
    model.named_modules = lambda: [
        ("model.embed_tokens", head),
        ("logits_processor", processor),
    ]
    with observe_output_head(model, torch=torch) as observed:
        processor._get_logits(hidden, head, None, plan=None)
    assert "output" in observed and "matmul" in observed


def test_original_head_exception_restores_wrappers():
    model, torch, processor, head = fixture(fail=True)
    original_matmul = torch.matmul
    original_get_logits = type(processor)._get_logits
    with pytest.raises(RuntimeError, match="original head failure"):
        with observe_output_head(model, torch=torch):
            processor._get_logits(
                ForwardTensor([[1.0, 2.0]]), head, object(), plan=None
            )
    assert torch.matmul is original_matmul
    assert type(processor)._get_logits is original_get_logits
