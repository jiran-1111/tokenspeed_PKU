# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""External snapshots of live Qwen GDN state; imports neither runtime nor Torch."""

from __future__ import annotations


def capture_gdn_state(ctx: object, *, layer_id: int, torch: object, phase: str) -> dict:
    """Copy one actual state slot before/after a single-token target decode.

    ``ctx`` is the original ForwardContext passed to Qwen3_5GatedDeltaNet.
    Before reads the backend's state_in index; after reads its state_out index.
    Returned tensors are independent CPU clones with their source dtypes and
    per-slot shapes (conv channels/history; SSM value-head/value/key, K-last).

    ForwardContext does not carry request IDs, request-pool slots, or positions.
    The caller must bind this snapshot to its verified case, actual token IDs,
    positions and forward ordinal. No state is allocated in the runtime pool,
    no prefix is reconstructed, and no runtime component is modified.
    """
    if type(layer_id) is not int or layer_id not in tuple(
        i for i in range(32) if i % 4 != 3
    ):
        raise ValueError("GDN capture requires a zero-based target layer 8, 9 or 10")
    if phase not in ("before", "after"):
        raise ValueError("phase must be explicitly before or after")
    try:
        if (
            type(ctx.bs) is not int
            or ctx.bs != 1
            or type(ctx.input_num_tokens) is not int
            or ctx.input_num_tokens != 1
            or type(ctx.num_extends) is not int
            or ctx.num_extends != 0
        ):
            raise ValueError(
                "GDN capture requires one real request and one decode input token"
            )
        if (
            ctx.forward_mode is None
            or ctx.forward_mode.is_decode() is not True
            or ctx.forward_mode.name != "DECODE"
        ):
            raise ValueError("GDN state capture supports only DECODE")
        router = ctx.attn_backend
        backend = router.linear_attn_backend
        pool = ctx.token_to_kv_pool
        if (
            pool is None
            or router.cache_pool is not pool
            or backend.cache_pool is not pool
        ):
            raise ValueError(
                "context, hybrid router and GDN backend must share the same live cache pool"
            )
        if (
            layer_id in router.full_attn_layers
            or backend.is_draft is not False
            or type(backend.spec_num_tokens) is not int
            or backend.spec_num_tokens != 1
            or backend.state_paging_active is not True
        ):
            raise ValueError(
                "unsupported GDN layer, speculative/draft path or inactive state paging"
            )
        group_id = pool.state_group_by_layer[layer_id]
        group_specs = [
            spec for spec in pool.arena.cache_group_specs if spec.group_id == group_id
        ]
        if not isinstance(group_id, str) or not group_id or len(group_specs) != 1:
            raise ValueError("layer must map to exactly one declared state cache group")
        spec = group_specs[0]
        if (
            spec.family != "state"
            or spec.retention != "full_history"
            or type(spec.checkpoint_granularity) is not int
            or spec.checkpoint_granularity < 1
            or type(spec.shard_count) is not int
            or spec.shard_count != 1
        ):
            raise ValueError("unsupported state-family cache geometry")
        metadata = backend.forward_metadata
        if (
            metadata is None
            or metadata.state_in_blocks_by_group is None
            or metadata.state_out_blocks_by_group is None
        ):
            raise ValueError(
                "live GDN forward metadata with both state mappings is required"
            )
        input_indices = metadata.state_in_blocks_by_group[group_id]
        output_indices = metadata.state_out_blocks_by_group[group_id]
        for indices in (input_indices, output_indices):
            if (
                not isinstance(indices, torch.Tensor)
                or indices.dtype != torch.int32
                or tuple(indices.shape) != (1,)
            ):
                raise ValueError(
                    "state slot mappings must be actual int32 tensors of shape [1]"
                )
        state_in = input_indices.detach().cpu().tolist()[0]
        state_out = output_indices.detach().cpu().tolist()[0]
        conv = pool.get_component(layer_id, "conv_state")
        ssm = pool.get_component(layer_id, "recurrent_state")
        if not isinstance(conv, torch.Tensor) or not isinstance(ssm, torch.Tensor):
            raise ValueError(
                "state buffers must be the pool's actual Tensor components"
            )
        conv_shape, ssm_shape = tuple(conv.shape), tuple(ssm.shape)
        if (
            conv.ndim != 3
            or ssm.ndim != 4
            or any(value < 1 for value in (*conv_shape, *ssm_shape))
            or conv_shape[0] != ssm_shape[0]
        ):
            raise ValueError(
                "GDN requires [slots,channels,history] conv and [slots,Hv,V,K] recurrent storage"
            )
        if conv.dtype != torch.bfloat16 or ssm.dtype not in (
            torch.bfloat16,
            torch.float32,
        ):
            raise ValueError(
                "state component dtype violates the frozen Qwen GDN cache recipe"
            )
        capacity = pool.arena.runtime_contract.group_page_counts[group_id]
        if type(capacity) is not int or capacity != conv_shape[0]:
            raise ValueError("state slot capacity differs from the live cache contract")
        for slot in (state_in, state_out):
            if type(slot) is not int or not 0 < slot < capacity:
                raise ValueError(
                    "state slot must be real, positive and within both state buffers; null/pad slots are forbidden"
                )
        field_layer_id = pool._field_layer_id(layer_id)
        conv_field_id, ssm_field_id = (
            f"layer.{field_layer_id}.conv",
            f"layer.{field_layer_id}.ssm",
        )
        for field_id, tensor in ((conv_field_id, conv), (ssm_field_id, ssm)):
            field = pool.arena.plan.field(field_id)
            if (
                field.field_id != field_id
                or field.group_id != group_id
                or tuple(field.shape) != tuple(tensor.shape[1:])
                or field.dtype != str(tensor.dtype).removeprefix("torch.")
            ):
                raise ValueError(
                    "actual GDN state component disagrees with its mapped arena field"
                )
        value_heads, value_dim, key_dim = ssm_shape[1:]
        key_channels = conv_shape[1] - value_heads * value_dim
        if key_channels <= 0 or key_channels % (2 * key_dim):
            raise ValueError(
                "conv and K-last recurrent geometry cannot describe Qwen GDN heads"
            )
        key_heads = key_channels // (2 * key_dim)
        selected = state_in if phase == "before" else state_out
        with torch.no_grad():
            conv_cpu = conv[selected].detach().cpu().clone()
            ssm_cpu = ssm[selected].detach().cpu().clone()
        if (
            conv_cpu.device.type != "cpu"
            or ssm_cpu.device.type != "cpu"
            or conv_cpu.dtype != conv.dtype
            or ssm_cpu.dtype != ssm.dtype
        ):
            raise ValueError(
                "state snapshots must retain source dtype and reside on CPU"
            )
        return {
            "conv_state": conv_cpu,
            "ssm_state": ssm_cpu,
            "metadata": {
                "phase": phase,
                "layer_id": layer_id,
                "field_layer_id": field_layer_id,
                "conv_field_id": conv_field_id,
                "ssm_field_id": ssm_field_id,
                "cache_group_id": group_id,
                "cache_group_family": spec.family,
                "cache_group_retention": spec.retention,
                "checkpoint_granularity": spec.checkpoint_granularity,
                "prefix_granularity": pool.arena.runtime_contract.prefix_granularity,
                "cache_group_shard_count": spec.shard_count,
                "physical_state_slot_count": capacity,
                "pool_rank": pool.rank,
                "forward_mode": ctx.forward_mode.name,
                "request_batch_row": 0,
                "runtime_request_id": "not_available",
                "request_pool_slot": "not_available",
                "caller_binding_required": True,
                "binding_requirement": "same original forward: case_id, input_ids, positions, step and FA seq_lens evidence",
                "state_in_slot": state_in,
                "state_out_slot": state_out,
                "selected_state_slot": selected,
                "selected_mapping": (
                    "state_in_blocks_by_group"
                    if phase == "before"
                    else "state_out_blocks_by_group"
                ),
                "slot_mapping_source": "live linear_attn_backend.forward_metadata[group_id][batch_row=0]",
                "conv_pool_shape": list(conv_shape),
                "ssm_pool_shape": list(ssm_shape),
                "conv_snapshot_shape": list(conv_cpu.shape),
                "ssm_snapshot_shape": list(ssm_cpu.shape),
                "conv_dtype": str(conv.dtype),
                "ssm_dtype": str(ssm.dtype),
                "conv_source_device": str(conv.device.type),
                "ssm_source_device": str(ssm.device.type),
                "conv_layout": "packed q/k/v channels, kernel_size_minus_one history",
                "ssm_layout": "local_value_heads, value_head_dim, key_head_dim (K-last)",
                "conv_kernel_size": conv_shape[2] + 1,
                "heads": {
                    "local_key_heads": key_heads,
                    "local_value_heads": value_heads,
                    "key_head_dim": key_dim,
                    "value_head_dim": value_dim,
                },
                "head_geometry_source": "actual conv channels = 2*Hk*K+Hv*V and recurrent [Hv,V,K]",
                "state_source": "live cache pool components at the backend's actual read/write slot",
                "recomputed_prefix": False,
                "runtime_state_written": False,
            },
        }
    except (AttributeError, KeyError, IndexError, TypeError) as error:
        raise ValueError(
            "unsupported or incomplete live GDN capture context; no state fallback is allowed"
        ) from error
