"""Independent NumPy checks of exported norm/head metrics and difference vectors."""

import hashlib
import json
from pathlib import Path

import numpy as np

here = Path(__file__).resolve().parent
workspace = here.parents[1]
bundle = workspace / ".tmp/hw2-20261023/supplement_export_fullpath_analysis_20261028"
repo = workspace / "delivery/homework2-20261023"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


assert all(sha(bundle / name) == digest for name, digest in read(bundle / "export_manifest.json").items())
core = repo / "docs/evidence/homework2_20261023/source_manifest.json"
assert sha(core) == "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
assert all(sha(repo / name) == digest for name, digest in read(core).items())
ops = bundle / "fullpath_operations_analysis_r1_20261028"
history = bundle / "fullpath_history_analysis_r1_20261028"
correspondence = read(bundle / "fullpath_correspondence_20261028/correspondence.json")
additional = read(bundle / "fullpath_additional_connections_20261028/connections.json")
assert correspondence["passed"] and additional["passed"]
metrics = 0
vector_groups = 0
maximum_difference = 0.0


def check_float(value, expected):
    global maximum_difference
    delta = abs(value - expected)
    maximum_difference = max(maximum_difference, delta)
    assert delta <= 2e-13 * max(1.0, abs(value))


def metric(actual, reference, stored):
    global metrics
    a, b = actual.astype(np.float64), reference.astype(np.float64)
    difference = a - b
    denominator = float(np.sqrt(np.sum(b * b, dtype=np.float64)))
    numerator = float(np.sqrt(np.sum(difference * difference, dtype=np.float64)))
    assert list(a.shape) == stored["shape"] and a.size == stored["elements"]
    assert int(np.count_nonzero(actual != reference)) == stored["different_elements"]
    assert (denominator == 0) == stored["zero_reference"]
    if denominator:
        check_float(numerator / denominator, stored["relative_l2"])
    else:
        assert stored["relative_l2"] is None
    assert float(np.max(np.abs(difference))) == stored["max_abs"]
    metrics += 1


for model in ("4b", "9b"):
    data = read(ops / f"output/{model}_operations.json")
    assert sha(history / f"output/{model}_history.json") == data["parent_history_sha256"]
    for audit in (correspondence, additional):
        entry = audit["models"][model]
        assert entry["operations_analysis_sha256" if "operations_analysis_sha256" in entry else "operations_sha256"] == sha(ops / f"output/{model}_operations.json")
    arrays_path = ops / f"output/{model}_vectors.npz"
    assert sha(arrays_path) == data["arrays_sha256"]
    arrays = np.load(arrays_path, allow_pickle=False)
    for name, item in data["cross_norm_boundaries"].items():
        one = arrays[f"{model}_tp1_rank0_{name}_normalized"]
        left = arrays[f"{model}_tp2_rank0_{name}_normalized"]
        right = arrays[f"{model}_tp2_rank1_{name}_normalized"]
        assert np.array_equal(left.view(np.uint32), right.view(np.uint32)) == item["tp2_rank0_rank1_exact"]
        for step, stored in enumerate(item["per_step"]):
            metric(left[step], one[step], stored)
    for label, item in data["projections"]["head"]["ranks"].items():
        a = arrays[f"{model}_{label}_head_actual"]
        b = arrays[f"{model}_{label}_head_reference"]
        metric(a, b, item["actual_local_vs_fp64_final_storage"])
        for step, stored in enumerate(item["per_step"]):
            metric(a[step], b[step], stored)
    for layer, group in data["projections"]["layers"].items():
        for module, item in group.items():
            if "row_path" not in item:
                continue
            vectors = {name: arrays[f"{model}_l{layer}_{module.split('.')[-1]}_{name}"] for name in ("difference", "inherited", "partition", "residual", "reconstructed", "reconstruction_residual")}
            np.testing.assert_array_equal(vectors["reconstructed"], (vectors["inherited"] + vectors["partition"]) + vectors["residual"])
            np.testing.assert_array_equal(vectors["reconstruction_residual"], vectors["difference"] - vectors["reconstructed"])
            for name, array in vectors.items():
                stored = item["row_path"]["decomposition_per_step"][-1]["vectors"][name]
                check_float(float(np.sqrt(np.sum(array * array, dtype=np.float64))), stored["l2"])
                assert float(np.max(np.abs(array))) == stored["max_abs"]
            vector_groups += 1
    for step in data["projections"]["head"]["per_step_argmax"]:
        index = step["step"]
        one = arrays[f"{model}_tp1_rank0_head_actual"][index]
        two = np.concatenate([arrays[f"{model}_tp2_rank0_head_actual"][index], arrays[f"{model}_tp2_rank1_head_actual"][index]])
        assert int(one.argmax()) == step["actual_tp1"]
        assert int(two.argmax()) == step["actual_tp2"]
result = {"passed": True, "metric_groups_independently_recomputed": metrics, "ordered_difference_vector_groups_verified": vector_groups,
    "max_float_metric_difference": maximum_difference, "core_files_rehashed": 1531, "archive_files_rehashed": 42,
    "scope": "Exported actual norm/head metrics, all saved last-step difference vectors and argmax; no local checkpoint GEMM or raw PT extraction",
    "model_numerical_threshold_added": False, "script_sha256": sha(Path(__file__))}
with (here / "local_export_verification.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result))
