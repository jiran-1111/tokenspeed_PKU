import csv
import hashlib
import io
import json
import os
import sys
import zipfile
from pathlib import Path

here = Path(__file__).resolve().parent
workspace = here.parents[1]
repo = workspace / "delivery/homework2-20261023"
bundle = workspace / ".tmp/hw2-20261023/supplement_export_fullpath_analysis_20261028"
evidence = repo / "docs/evidence/homework2_20261028"
evidence.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text(encoding="utf-8"))


def write(name, value):
    (evidence / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


archives = {}


def pack(name, entries, source_label):
    entries = dict(sorted(entries.items()))
    with zipfile.ZipFile(evidence / name, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for member, path in entries.items():
            info = zipfile.ZipInfo(member, date_time=(2026, 10, 28, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            target.writestr(info, path.read_bytes(), compresslevel=9)
    assert (evidence / name).stat().st_size < 512000
    with zipfile.ZipFile(evidence / name) as target:
        assert all(target.read(member) == path.read_bytes() for member, path in entries.items())
    archives[name] = {"sha256": sha(evidence / name), "bytes": (evidence / name).stat().st_size,
                      "source": source_label, "members": {member: sha(path) for member, path in entries.items()}}


collector = here / "tools_r3"
collector_manifest = read(collector / "tool_manifest.json")
assert len(collector_manifest) == 32
assert all(sha(collector / name) == value for name, value in collector_manifest.items())
entries = {name: collector / name for name in collector_manifest if name != "authorization.json"}
entries["tool_manifest.json"] = collector / "tool_manifest.json"
pack("collector_r3_tools.zip", entries, "fullpath_history_r3_20261028")
for kind in ("history", "operations"):
    folder = bundle / f"fullpath_{kind}_analysis_r1_20261028"
    manifest = read(folder / "tool_manifest.json")
    assert all(sha(folder / name) == value for name, value in manifest.items())
    entries = {name: folder / name for name in manifest}
    entries["tool_manifest.json"] = folder / "tool_manifest.json"
    pack(f"{kind}_cpu_tools.zip", entries, folder.name)
    for model in ("4b", "9b"):
        source = folder / f"output/{model}_{kind}.json"
        pack(f"{model}_{kind}.zip", {source.name: source}, f"{folder.name}/output")
for dirname, basename in (("fullpath_correspondence_20261028", "correspondence"),
                         ("fullpath_additional_connections_20261028", "additional_connections")):
    folder = bundle / dirname
    filename = "connections.json" if basename == "additional_connections" else "correspondence.json"
    write(filename, read(folder / filename))
    script = folder / f"run_{basename if basename != 'correspondence' else 'correspondence_audit'}.py"
    pack(f"{basename}_tool.zip", {script.name: script}, dirname)
pack("local_metric_verifier.zip", {"verify_exports_local.py": here / "verify_exports_local.py"}, "local NumPy recomputation")
write("local_metric_verification.json", read(here / "local_export_verification.json"))
write("tool_and_result_archives.json", archives)

full = read(here / "numerical_summary.json")
summary = {"scope": "Original 128-token Prefill plus all 17/9 original continuation inputs through the first divergent output, all 32 layers; actual-operand references, not independently propagated CPU hidden states",
           "new_model_threshold": False, "original_greedy_failures_repaired": False,
           "models": {model: {key: value for key, value in item.items() if key not in ("head", "norm_curves")} for model, item in full["models"].items()}}
write("numerical_summary.json", summary)

rows = []
for model, item in full["models"].items():
    for boundary, (name, values) in enumerate(item["norm_curves"].items()):
        for step, metric in enumerate(values["per_step"]):
            rows.append({"model": model, "step": step, "boundary_index": boundary, "boundary": name,
                         "relative_l2": metric["relative_l2"], "max_abs": metric["max_abs"],
                         "different_elements": metric["different_elements"], "elements": metric["elements"]})
with (evidence / "norm_boundary_metrics.csv").open("w", encoding="utf-8", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
assert len(rows) == 1820

sys.path.insert(0, str(workspace / ".deps/hw2-publication"))
os.environ["MPLCONFIGDIR"] = str(here / "matplotlib-cache")
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties

font = FontProperties(fname="C:/Windows/Fonts/msyh.ttc")
plt.rcParams.update({"font.family": font.get_name(), "axes.unicode_minus": False, "font.size": 9})
fig, axes = plt.subplots(1, 2, figsize=(9, 3.25), layout="constrained")
for axis, model in zip(axes, ("4b", "9b")):
    curves = full["models"][model]["norm_curves"]
    names = list(curves)
    last_step = len(curves[names[0]]["per_step"]) - 1
    for step, label, color in ((0, "Prefill末行", "#257586"), (last_step, f"首差输出前 Decode step{last_step}", "#c1663b")):
        values = np.array([curves[name]["per_step"][step]["relative_l2"] for name in names])
        assert values[0] == 0 and np.all(values[1:] > 0)
        axis.plot(np.arange(65), np.where(values == 0, np.nan, values), label=label, color=color, linewidth=1.5)
    axis.set_yscale("log")
    axis.set_ylim(.0008, 1.3)
    axis.set_xticks([0, 16, 32, 48, 64], ["输入", "层8前", "层16前", "层24前", "末归一化"])
    axis.set_ylabel("TP2 相对 TP1 的 relative-L2")
    axis.set_title(f"Qwen3.5-{model.upper()}：实际归一化输出")
    axis.grid(axis="y", alpha=.18)
    axis.annotate("输入差异为0（对数轴不绘制）", xy=(.03, .95), xycoords="axes fraction", va="top", fontsize=8)
    axis.legend(loc="lower right", fontsize=7.6)
figure = repo / "docs/report/hw2_figures/homework2_norm_propagation_20261028.png"
fig.savefig(figure, dpi=180, facecolor="white")
plt.close(fig)
assert figure.stat().st_size < 512000
local_figure = workspace / "hw2_figures" / figure.name
local_figure.write_bytes(figure.read_bytes())
write("figure_identity.json", {"figure_sha256": sha(figure), "csv_sha256": sha(evidence / "norm_boundary_metrics.csv"),
                              "metrics": 1820, "plotted_steps": {"4b": [0, 17], "9b": [0, 9]},
                              "zero_values": "Exactly zero at the first boundary, explicitly omitted from log axis; no epsilon substituted"})
print(json.dumps({"evidence_files": len(list(evidence.iterdir())), "archives": len(archives), "figure_bytes": figure.stat().st_size}))
