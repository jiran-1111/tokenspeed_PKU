import json
from pathlib import Path

here = Path(__file__).resolve().parent
bundle = here.parent / "hw2-20261023/supplement_export_fullpath_analysis_20261028"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
history = bundle / "fullpath_history_analysis_r1_20261028/output"
operations = bundle / "fullpath_operations_analysis_r1_20261028/output"
summary = {"models": {}, "correspondence": read(bundle / "fullpath_correspondence_20261028/correspondence.json"),
           "additional_connections": read(bundle / "fullpath_additional_connections_20261028/connections.json")}
for model in ("4b", "9b"):
    old = read(history / f"{model}_history.json")
    new = read(operations / f"{model}_operations.json")
    global_projection, per_step_projection, local = [], [], {}
    for layer, group in new["projections"]["layers"].items():
        for name, item in group.items():
            for rank, value in item["ranks"].items():
                global_projection.append((value["actual_vs_fp64_final_bf16"]["relative_l2"], layer, name, rank, value["actual_vs_fp64_final_bf16"]))
                per_step_projection.extend((row["relative_l2"], layer, name, rank, step, row) for step, row in enumerate(value["per_step"]))
    for rank, value in new["local_math"].items():
        for step in value["steps"]:
            for family in ("norms", "fa", "gdn", "mlp"):
                for layer, item in step[family].items():
                    for kind, metric in item.items():
                        if isinstance(metric, dict) and metric.get("relative_l2") is not None:
                            local.setdefault(f"{family}/{kind}", []).append((metric["relative_l2"], rank, step["step"], layer, metric))
    result = {"max_global_projection_stored": max(global_projection, key=lambda row: row[0]),
        "max_step_projection_stored": max(per_step_projection, key=lambda row: row[0]),
        "local_reference_peaks": {name: max(values, key=lambda row: row[0]) for name, values in local.items()},
        "max_prefill_state_relative_l2": max(item["prefill_state_actual_vs_fp32"]["relative_l2"] for rank in old["ranks"].values() for item in rank["gdn"].values()),
        "max_final_trajectory_state_relative_l2": max(item["decode"][-1]["ssm_after_vs_actual_prefill_seeded_history"]["relative_l2"] for rank in old["ranks"].values() for item in rank["gdn"].values()),
        "max_final_own_state_relative_l2": max(item["decode"][-1]["ssm_after_vs_actual_own_state_reference"]["relative_l2"] for rank in old["ranks"].values() for item in rank["gdn"].values()),
        "head": new["projections"]["head"], "norm_curves": new["cross_norm_boundaries"]}
    summary["models"][model] = result
(here / "numerical_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({model: {"max_global_projection": item["max_global_projection_stored"], "max_step_projection": item["max_step_projection_stored"],
    "local_reference_relative_peaks": {name: row[0] for name, row in item["local_reference_peaks"].items()},
    "max_prefill_state": item["max_prefill_state_relative_l2"], "max_final_state": item["max_final_trajectory_state_relative_l2"]} for model, item in summary["models"].items()}))
