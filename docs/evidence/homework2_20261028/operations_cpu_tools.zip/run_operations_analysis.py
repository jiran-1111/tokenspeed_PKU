# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import json
import os
import sys
from pathlib import Path

assert (
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0"
    and os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
)
sys.modules["torch_npu"] = None
import numpy as np
import torch

from analysis_binding import (
    CORE,
    compare,
    load_model,
    read,
    require,
    sha,
    verify_unchanged,
)
from analyze_operations import analyze_local_math, analyze_projections

torch.set_num_threads(8)
here = Path(__file__).resolve().parent
task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
parent = task / "fullpath_history_analysis_r1_20261028/output"
parent_summary = read(parent / "summary.json")
require(parent_summary["core_source_sha256"] == CORE, "parent history source mismatch")
out = here / "output"
out.mkdir(exist_ok=False)
summary = {
    "scope": "All original 32-layer operations, original full histories, actual parameter identities and complete head outputs",
    "source_core_sha256": CORE,
    "parent_history_summary_sha256": sha(parent / "summary.json"),
    "runtime_math_changed": False,
    "thresholds_added": False,
    "original_failures_preserved": True,
    "models": {},
}
for model in ("9b", "4b"):
    print(f"Binding {model} complete original history", flush=True)
    require(
        sha(parent / f"{model}_history.json")
        == parent_summary["models"][model]["analysis_sha256"],
        "parent history result mismatch",
    )
    data = load_model(task, model=model, torch=torch)
    exports = {}
    result = {
        "model": model,
        "source_core_sha256": CORE,
        "parent_history_sha256": sha(parent / f"{model}_history.json"),
        "local_math": {},
        "cross_norm_boundaries": {},
    }
    for label in data["records"]:
        print(f"{model} {label}: all local norms, MLP, FA and GDN gates", flush=True)
        result["local_math"][label] = analyze_local_math(data, label=label, torch=torch)
    names = data["records"]["tp1_rank0"][0]["observed"]["norm_boundaries"].keys()
    for name in names:
        arrays = {}
        for label, records in data["records"].items():
            rows = []
            for entry in records:
                sample = entry["observed"]["norm_boundaries"][name]
                require(
                    np.array_equal(
                        sample["normalized"],
                        sample["outputs"][0].reshape(-1, sample["normalized"].size)[-1],
                    ),
                    "duplicate normalized row mismatch",
                )
                rows.append(sample["normalized"])
            arrays[label] = np.stack(rows)
            exports[f"{model}_{label}_{name}_normalized"] = arrays[label]
        result["cross_norm_boundaries"][name] = {
            "per_step": [
                compare(arrays["tp2_rank0"][i], arrays["tp1_rank0"][i])
                for i in range(data["steps"])
            ],
            "tp2_rank0_rank1_exact": bool(
                np.array_equal(arrays["tp2_rank0"], arrays["tp2_rank1"])
            ),
        }
    result["projections"] = analyze_projections(data, torch=torch, exports=exports)
    verify_unchanged(data)
    arrays_path = out / f"{model}_vectors.npz"
    np.savez_compressed(arrays_path, **exports)
    result.update(
        inputs_unchanged_after=True,
        original_logits_byte_preserved=data["steps"] * 3,
        arrays_sha256=sha(arrays_path),
        tool_manifest_sha256=sha(here / "tool_manifest.json"),
    )
    with (out / f"{model}_operations.json").open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    summary["models"][model] = {
        "analysis_sha256": sha(out / f"{model}_operations.json"),
        "arrays_sha256": sha(arrays_path),
        "original_logits_byte_preserved": data["steps"] * 3,
    }
    del data, exports, result
with (out / "summary.json").open("x") as stream:
    json.dump(summary, stream, indent=2)
print("FULL ORIGINAL OPERATIONS CPU ANALYSIS COMPLETE", flush=True)
