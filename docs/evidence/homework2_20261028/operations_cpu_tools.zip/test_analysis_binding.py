# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy
import hashlib

import numpy as np
import pytest

from analysis_binding import compare, load_parameter, validate_metadata
from analyze_history import scan


def metadata(step):
    return {
        "case_id": "fixed",
        "step": step,
        "rank": 0,
        "tp": 1,
        "position": 127 + step,
        "prefix_length_after": 128 + step,
        "prefix_length_before": 0 if step == 0 else 127 + step,
        "all_layers": list(range(32)),
        "fa_layers": list(range(3, 32, 4)),
        "gdn_layers": [i for i in range(32) if i % 4 != 3],
        "performance_eligible": False,
        "runtime_state_written": False,
    }


@pytest.mark.parametrize("step", [0, 9, 17])
def test_actual_both_model_prefix_extents(step):
    validate_metadata(
        metadata(step), step=step, rank=0, tp=1, case={"case_id": "fixed"}
    )


@pytest.mark.parametrize(
    "bad", ["prefix_length_before", "position", "all_layers", "rank", "case_id"]
)
def test_wrong_capture_metadata_rejected(bad):
    item = metadata(9)
    item[bad] = [] if bad == "all_layers" else "changed"
    with pytest.raises(ValueError):
        validate_metadata(item, step=9, rank=0, tp=1, case={"case_id": "fixed"})


def test_delta_replay_has_exact_same_state_across_explicit_call_boundaries():
    q = np.zeros((2, 1, 128), dtype=np.float32)
    q[:, :, 0] = 1
    v = np.array([[[1.0]], [[3.0]]], dtype=np.float32)
    g = np.zeros((2, 1), dtype=np.float32)
    beta = np.full((2, 1), 0.5, dtype=np.float32)
    initial = np.zeros((1, 1, 128), dtype=np.float32)
    full = scan(q, q, v, g, beta, initial)
    first = scan(q[:1], q[:1], v[:1], g[:1], beta[:1], initial)
    second = scan(q[1:], q[1:], v[1:], g[1:], beta[1:], first["state"])
    np.testing.assert_array_equal(full["state"], second["state"])
    np.testing.assert_array_equal(full["core"][1:], second["core"])
    assert np.count_nonzero(initial) == 0


def test_parameter_loader_checks_projected_bytes_including_logical_columns(tmp_path):
    torch = pytest.importorskip("torch")
    from safetensors.torch import save_file

    value = torch.tensor([[1.001, 2.003, 3.01], [4.01, 5.003, 6.001]])
    save_file({"w": value}, str(tmp_path / "test.safetensors"))
    expected = value[:, 1:].bfloat16().contiguous()
    certificate = {
        "checkpoint_parts": [{"key": "w", "start": 0, "stop": 2, "columns": [1, 3]}],
        "projection": "bfloat16",
        "shape": [2, 2],
        "dtype": "torch.bfloat16",
        "actual_sha256": hashlib.sha256(
            expected.view(torch.uint8).numpy().tobytes()
        ).hexdigest(),
    }
    data = {
        "checkpoint": tmp_path,
        "index": {"w": "test.safetensors"},
        "certificates": {"rank": {"parameters": {"weight": certificate}}},
    }
    loaded = load_parameter(data, label="rank", name="weight", torch=torch)
    assert torch.equal(loaded, expected)
    certificate["actual_sha256"] = "0" * 64
    with pytest.raises(ValueError):
        load_parameter(data, label="rank", name="weight", torch=torch)
