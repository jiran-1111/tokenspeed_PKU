# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Own-input references for all 32 layers, row storage differences and the head."""

import numpy as np

from analysis_binding import compare, load_parameter, require
from prefill_oracle import bf16_storage, gated_norm, split_packed
from reference_math import (
    decode_gqa,
    decompose_difference,
    neox_rope,
    prefill_gqa,
    rmsnorm,
    sigmoid_gate,
    split_qkv,
)


def operand(observed, label, side, index):
    result = observed["modules"][label][side][index]
    require(isinstance(result, np.ndarray), "Actual tensor operand absent")
    return result


def offsets(data):
    return [(0, 128)] + [(127 + i, 128 + i) for i in range(1, data["steps"])]


def reduction_boundary(layer, module):
    if module.endswith("mlp.down_proj"):
        return f"layers.{layer + 1}.input_layernorm" if layer < 31 else "final_norm"
    return f"layers.{layer}.post_attention_layernorm"


def norm_references(observed):
    results = {}
    for name, item in observed["norm_boundaries"].items():
        actual = item["outputs"][0]
        residual = item["inputs"][1] if len(item["inputs"]) > 1 else None
        updated = item["outputs"][1] if len(item["outputs"]) > 1 else None
        source = item["inputs"][0] if residual is None else updated
        candidate = rmsnorm(
            source,
            item["effective_gamma"],
            epsilon=item["epsilon"],
            compute_dtype="float32",
            output_storage="bf16",
        )
        row = {"actual_vs_fp32_stored": compare(actual, candidate["output_stored"])}
        if residual is not None:
            require(updated is not None, "Actual updated residual missing")
            row["residual_actual_vs_bf16_add"] = compare(
                updated, bf16_storage(item["inputs"][0] + residual)
            )
        results[name] = row
    return results


def analyze_local_math(data, *, label, torch):
    records = data["records"][label]
    tp = records[0]["metadata"]["tp"]
    result = {
        "steps": [],
        "scope": "Each local reference starts at its own captured input; no chained reference hidden states",
    }
    histories = {index: {"k": [], "v": []} for index in range(3, 32, 4)}
    gdn_weights = {
        i: load_parameter(
            data,
            label=label,
            name=f"model.language_model.layers.{i}.linear_attn.norm.weight",
            torch=torch,
        )
        .float()
        .numpy()
        .copy()
        for i in range(32)
        if i % 4 != 3
    }
    for step, entry in enumerate(records):
        observed = entry["observed"]
        row = {
            "step": step,
            "norms": norm_references(observed),
            "fa": {},
            "gdn": {},
            "mlp": {},
        }
        for layer in range(32):
            prefix = f"fa{layer}" if layer % 4 == 3 else f"l{layer}"
            packed = operand(observed, f"{prefix}.mlp.gate_up_proj", "outputs", 0)
            gate, up = np.split(packed.astype(np.float32), 2, axis=-1)
            exp = np.exp(-np.abs(gate))
            sigmoid = np.where(gate >= 0, 1 / (1 + exp), exp / (1 + exp))
            expected = bf16_storage((gate * sigmoid) * up)
            row["mlp"][layer] = {
                "activation_actual_vs_fp32_stored": compare(
                    operand(observed, f"{prefix}.mlp.down_proj", "inputs", 0), expected
                )
            }
            if layer % 4 == 3:
                const = observed["fa_constants"][layer]
                heads, kv_heads, dim = (
                    const["heads"],
                    const["kv_heads"],
                    const["head_dim"],
                )
                qkv = split_qkv(
                    operand(observed, f"{prefix}.qkv_proj", "outputs", 0),
                    heads=heads,
                    kv_heads=kv_heads,
                    head_dim=dim,
                    compute_dtype="float32",
                )
                rotation = observed["modules"][f"{prefix}.rotary_emb"]
                positions = rotation["inputs"][0]
                if positions.ndim == 2:
                    require(
                        positions.shape[0] == 3
                        and np.array_equal(positions[0], positions[1])
                        and np.array_equal(positions[0], positions[2]),
                        "MRoPE text axes differ",
                    )
                    positions = positions[0]
                fa = {}
                for kind in ("q", "k"):
                    before = rotation["inputs"][1 if kind == "q" else 2].reshape(
                        -1, heads if kind == "q" else kv_heads, dim
                    )
                    normalized = rmsnorm(
                        qkv[kind],
                        const[f"{kind}_gamma"],
                        epsilon=const["epsilon"],
                        compute_dtype="float32",
                        output_storage="bf16",
                    )
                    fa[f"{kind}_norm_actual_vs_fp32_stored"] = compare(
                        before, normalized["output_stored"]
                    )
                    rotated = neox_rope(
                        before,
                        positions,
                        const["rotary_cache"],
                        rotary_dim=const["rotary_dim"],
                        cache_storage="bf16",
                        compute_dtype="float32",
                        output_storage="bf16",
                    )
                    fa[f"{kind}_rope_actual_vs_fp32_stored"] = compare(
                        rotation["outputs"][0 if kind == "q" else 1].reshape(
                            before.shape
                        ),
                        rotated["output_stored"],
                    )
                attention = observed["modules"][f"{prefix}.attn"]
                q = attention["inputs"][0].reshape(-1, heads, dim)
                k = attention["inputs"][1].reshape(-1, kv_heads, dim)
                v = attention["inputs"][2].reshape(-1, kv_heads, dim)
                fa["q_rope_to_attention_exact"] = bool(
                    np.array_equal(attention["inputs"][0], rotation["outputs"][0])
                )
                fa["k_rope_to_attention_exact"] = bool(
                    np.array_equal(attention["inputs"][1], rotation["outputs"][1])
                )
                fa["v_projection_to_attention_exact"] = bool(
                    np.array_equal(v, qkv["v"])
                )
                histories[layer]["k"].append(k)
                histories[layer]["v"].append(v)
                key_history = np.concatenate(histories[layer]["k"], axis=0)
                value_history = np.concatenate(histories[layer]["v"], axis=0)
                reference = (
                    prefill_gqa(
                        q,
                        k,
                        v,
                        scale=const["scaling"],
                        compute_dtype="float32",
                        output_storage="bf16",
                    )
                    if step == 0
                    else decode_gqa(
                        q,
                        key_history,
                        value_history,
                        scale=const["scaling"],
                        compute_dtype="float32",
                        output_storage="bf16",
                    )
                )
                actual_attention = attention["outputs"][0].reshape(q.shape)
                fa["attention_actual_vs_fp32_raw"] = compare(
                    actual_attention, reference["output"]
                )
                fa["attention_actual_vs_fp32_stored"] = compare(
                    actual_attention, reference["output_stored"]
                )
                gated = sigmoid_gate(
                    actual_attention,
                    qkv["gate"],
                    compute_dtype="float32",
                    output_storage="bf16",
                )
                fa["sigmoid_gate_actual_vs_fp32_stored"] = compare(
                    operand(observed, f"{prefix}.o_proj", "inputs", 0).reshape(q.shape),
                    gated["output_stored"],
                )
                row["fa"][layer] = fa
            else:
                packed = operand(
                    observed, f"{prefix}.linear_attn.in_proj_qkvzba", "outputs", 0
                )
                parts = split_packed(
                    packed,
                    hk=16 // tp,
                    hv=32 // tp,
                    key_dim=128,
                    value_dim=128,
                    compute_dtype="float32",
                )
                backend = observed["backend"][layer][
                    "extend" if step == 0 else "decode"
                ]
                raw_qkv = np.concatenate(
                    [
                        parts[kind].reshape(packed.shape[0], -1)
                        for kind in ("q", "k", "v")
                    ],
                    axis=-1,
                )
                norm = observed["modules"][f"{prefix}.linear_attn.norm"]
                core = norm["inputs"][0].reshape(-1, 32 // tp, 128)
                z = norm["inputs"][1].reshape(core.shape)
                own = gated_norm(
                    core,
                    z,
                    gdn_weights[layer],
                    norm_epsilon=1e-6,
                    compute_dtype="float32",
                )
                row["gdn"][layer] = {
                    "packed_qkv_to_backend_exact": bool(
                        np.array_equal(raw_qkv, backend["mixed_qkv"])
                    ),
                    "packed_z_to_backend_exact": bool(
                        np.array_equal(
                            parts["z"], backend["z"].reshape(parts["z"].shape)
                        )
                    ),
                    "packed_a_to_backend_exact": bool(
                        np.array_equal(
                            parts["a"], backend["a"].reshape(parts["a"].shape)
                        )
                    ),
                    "packed_b_to_backend_exact": bool(
                        np.array_equal(
                            parts["b"], backend["b"].reshape(parts["b"].shape)
                        )
                    ),
                    "core_backend_to_norm_exact": bool(
                        np.array_equal(core, backend["output"].reshape(core.shape))
                    ),
                    "gated_norm_actual_vs_fp32_stored": compare(
                        norm["outputs"][0].reshape(core.shape), own["output_bf16"]
                    ),
                    "norm_to_projection_exact": bool(
                        np.array_equal(
                            norm["outputs"][0].reshape(packed.shape[0], -1),
                            operand(
                                observed, f"{prefix}.linear_attn.out_proj", "inputs", 0
                            ),
                        )
                    ),
                }
        result["steps"].append(row)
    return result


def analyze_projections(data, *, torch, exports):
    labels = ("tp1_rank0", "tp2_rank0", "tp2_rank1")
    result = {
        "layers": {},
        "head": {},
        "scope": "FP64 matrix math on actual BF16 weight values; final storage candidates, not an intermediate-kernel emulator",
    }
    ranges = offsets(data)
    for layer in range(32):
        prefix = f"fa{layer}" if layer % 4 == 3 else f"l{layer}"
        checkpoint_prefix = f"model.language_model.layers.{layer}"
        operations = (
            [
                (
                    f"{prefix}.qkv_proj",
                    f"{checkpoint_prefix}.self_attn.qkv_proj.weight",
                    False,
                ),
                (
                    f"{prefix}.o_proj",
                    f"{checkpoint_prefix}.self_attn.o_proj.weight",
                    True,
                ),
            ]
            if layer % 4 == 3
            else [
                (
                    f"{prefix}.linear_attn.in_proj_qkvzba",
                    f"{checkpoint_prefix}.linear_attn.in_proj_qkvzba.weight",
                    False,
                ),
                (
                    f"{prefix}.linear_attn.out_proj",
                    f"{checkpoint_prefix}.linear_attn.out_proj.weight",
                    True,
                ),
            ]
        )
        operations += [
            (
                f"{prefix}.mlp.gate_up_proj",
                f"{checkpoint_prefix}.mlp.gate_up_proj.weight",
                False,
            ),
            (
                f"{prefix}.mlp.down_proj",
                f"{checkpoint_prefix}.mlp.down_proj.weight",
                True,
            ),
        ]
        layer_result = {}
        for module, parameter, row_parallel in operations:
            own, inputs, actuals, weights = {}, {}, {}, {}
            op = {"ranks": {}}
            for label in labels:
                captures = data["records"][label]
                x = np.concatenate(
                    [
                        operand(item["observed"], module, "inputs", 0)
                        for item in captures
                    ],
                    axis=0,
                )
                actual = np.concatenate(
                    [
                        operand(item["observed"], module, "outputs", 0)
                        for item in captures
                    ],
                    axis=0,
                )
                weight = load_parameter(
                    data, label=label, name=parameter, torch=torch
                ).double()
                raw = (torch.from_numpy(x.astype(np.float64)) @ weight.T).numpy()
                reference = bf16_storage(raw)
                op["ranks"][label] = {
                    "actual_vs_fp64_raw": compare(actual, raw),
                    "actual_vs_fp64_final_bf16": compare(actual, reference),
                    "per_step": [
                        compare(actual[start:stop], reference[start:stop])
                        for start, stop in ranges
                    ],
                }
                own[label], inputs[label], actuals[label], weights[label] = (
                    reference,
                    x,
                    actual,
                    weight,
                )
            if row_parallel:
                one, left, right = labels
                width = inputs[one].shape[-1] // 2
                require(
                    torch.equal(weights[left], weights[one][:, :width])
                    and torch.equal(weights[right], weights[one][:, width:]),
                    "row complementary weights mismatch",
                )
                common_parts = [
                    (
                        torch.from_numpy(
                            inputs[one][:, cut : cut + width].astype(np.float64)
                        )
                        @ weights[label].T
                    ).numpy()
                    for cut, label in ((0, left), (width, right))
                ]
                common = bf16_storage(
                    bf16_storage(common_parts[0]) + bf16_storage(common_parts[1])
                )
                own_partition = bf16_storage(own[left] + own[right])
                reduced = {}
                for label in labels:
                    next_values = []
                    for entry in data["records"][label]:
                        norm = entry["observed"]["norm_boundaries"]
                        boundary = reduction_boundary(layer, module)
                        next_values.append(norm[boundary]["inputs"][0])
                    reduced[label] = np.concatenate(next_values, axis=0)
                sum_candidate = bf16_storage(actuals[left] + actuals[right])
                decomposition = decompose_difference(
                    reduced[one],
                    reduced[left],
                    own[one],
                    common,
                    own_partition,
                    compute_dtype="float64",
                )
                op["row_path"] = {
                    "actual_rank_reduced_outputs_exact_equal": bool(
                        np.array_equal(reduced[left], reduced[right])
                    ),
                    "actual_hccl_equals_bf16_sum_of_actual_partials": bool(
                        np.array_equal(reduced[left], sum_candidate)
                    ),
                    "tp1_partial_connects_to_norm_exact": bool(
                        np.array_equal(actuals[one], reduced[one])
                    ),
                    "same_input_partition_vs_full": compare(common, own[one]),
                    "actual_tp2_vs_own_partition_reference": compare(
                        reduced[left], own_partition
                    ),
                    "actual_tp2_vs_tp1": compare(reduced[left], reduced[one]),
                    "decomposition_per_step": [],
                }
                for step, (start, stop) in enumerate(ranges):
                    details = {
                        name: {
                            "l2": float(np.linalg.norm(array[start:stop].ravel())),
                            "max_abs": float(np.abs(array[start:stop]).max()),
                        }
                        for name, array in decomposition.items()
                    }
                    op["row_path"]["decomposition_per_step"].append(
                        {"step": step, "vectors": details}
                    )
                # Full last-position vectors permit local, independent identity checks.
                for name, array in decomposition.items():
                    exports[
                        f"{data['model']}_l{layer}_{module.split('.')[-1]}_{name}"
                    ] = array[-1].copy()
            layer_result[module] = op
        result["layers"][layer] = layer_result
        print(
            f"{data['model']} layer {layer}: four actual projection references complete",
            flush=True,
        )
    head_results, local_outputs, local_refs = {}, {}, {}
    for label in labels:
        captures = data["records"][label]
        weight = load_parameter(data, label=label, name="lm_head.weight", torch=torch)
        inputs = np.concatenate(
            [entry["observed"]["output_head"]["matmul"]["input"] for entry in captures],
            axis=0,
        )
        expected = (
            torch.from_numpy(inputs.astype(np.float64)) @ weight.double().T
        ).numpy()
        expected = (
            bf16_storage(expected)
            if data["model"] == "4b"
            else expected.astype(np.float32)
        )
        actual = np.concatenate(
            [
                entry["observed"]["output_head"]["matmul"]["output"]
                for entry in captures
            ],
            axis=0,
        )
        complete = np.concatenate(
            [entry["observed"]["output_head"]["output"] for entry in captures], axis=0
        )
        continuity = []
        for entry, logits in zip(captures, data["logits"][label]):
            observed = entry["observed"]
            final = observed["norm_boundaries"]["final_norm"]["outputs"][0][-1:]
            head = observed["output_head"]
            continuity.append(
                {
                    "final_norm_to_actual_head_input_exact": bool(
                        np.array_equal(final, head["input"])
                    ),
                    "actual_head_cast_preserves_values": bool(
                        np.array_equal(head["input"], head["matmul"]["input"])
                    ),
                    "head_full_output_to_saved_logits_exact": bool(
                        np.array_equal(head["output"][0], logits)
                    ),
                }
            )
        head_results[label] = {
            "actual_local_vs_fp64_final_storage": compare(actual, expected),
            "continuity": continuity,
            "per_step": [compare(actual[i], expected[i]) for i in range(data["steps"])],
        }
        local_outputs[label], local_refs[label] = actual, expected
        exports[f"{data['model']}_{label}_head_actual"] = actual
        exports[f"{data['model']}_{label}_head_reference"] = expected
        del weight
    reference1 = local_refs[labels[0]]
    reference2 = np.concatenate([local_refs[labels[1]], local_refs[labels[2]]], axis=-1)
    gathered = np.concatenate(
        [local_outputs[labels[1]], local_outputs[labels[2]]], axis=-1
    )
    actual1 = np.stack(data["logits"][labels[0]])
    actual2 = np.stack(data["logits"][labels[1]])
    result["head"] = {
        "ranks": head_results,
        "actual_all_gather_exact": bool(np.array_equal(gathered, actual2)),
        "actual_tp2_ranks_full_logits_equal": bool(
            np.array_equal(actual2, np.stack(data["logits"][labels[2]]))
        ),
        "own_reference_tp2_vs_tp1": compare(reference2, reference1),
        "actual_tp2_vs_tp1": compare(actual2, actual1),
        "per_step_argmax": [
            {
                "step": i,
                "actual_tp1": int(actual1[i].argmax()),
                "actual_tp2": int(actual2[i].argmax()),
                "own_reference_tp1": int(reference1[i].argmax()),
                "own_reference_tp2": int(reference2[i].argmax()),
            }
            for i in range(data["steps"])
        ],
    }
    return result
