# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Small mathematical examples; no original model capture is consumed."""

import importlib.util
import inspect
from pathlib import Path

import numpy as np
import pytest


@pytest.fixture(scope="module")
def ref():
    path = Path(__file__).with_name("reference_math.py")
    assert path.is_file(), "FA reference module has not been implemented"
    spec = importlib.util.spec_from_file_location("fullpath_reference_math", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize("compute_dtype", ["float32", "float64"])
def test_packed_q_gate_are_interleaved_per_head(ref, compute_dtype):
    packed = np.arange(24).reshape(2, 12)
    result = ref.split_qkv(
        packed, heads=2, kv_heads=1, head_dim=2, compute_dtype=compute_dtype
    )
    assert set(result) == {"q", "gate", "k", "v"}
    np.testing.assert_array_equal(result["q"][0], [[0, 1], [4, 5]])
    np.testing.assert_array_equal(result["gate"][0], [[2, 3], [6, 7]])
    np.testing.assert_array_equal(result["k"][0], [[8, 9]])
    np.testing.assert_array_equal(result["v"][1], [[22, 23]])
    assert result["q"].dtype == np.dtype(compute_dtype)
    result["q"][:] = -1
    np.testing.assert_array_equal(packed, np.arange(24).reshape(2, 12))


def test_gemma_norm_uses_mean_epsilon_and_already_effective_gamma(ref):
    result = ref.rmsnorm(
        [[[3.0, 4.0]]],
        [2.0, 0.5],
        epsilon=3.5,
        compute_dtype="float64",
        output_storage="bf16",
    )
    # sqrt(mean(9,16)+3.5)=4; gamma is used directly, without another +1.
    np.testing.assert_array_equal(result["output"], [[[1.5, 0.5]]])
    np.testing.assert_array_equal(result["output_stored"], [[[1.5, 0.5]]])
    assert result["output"].dtype == np.float64
    assert result["output_stored"].dtype == np.float32


@pytest.mark.parametrize("compute_dtype", ["float32", "float64"])
def test_neox_half_rotation_leaves_partial_rope_tail_unchanged(ref, compute_dtype):
    value = np.array([[[1, 2, 3, 4, 9, 10], [5, 6, 7, 8, 11, 12]]])
    table = np.array([[1, 1, 0, 0], [0, 1, 1, 0]], dtype=np.float32)
    result = ref.neox_rope(
        value,
        np.array([1], dtype=np.int32),
        table,
        rotary_dim=4,
        cache_storage="as_supplied",
        compute_dtype=compute_dtype,
        output_storage="compute",
    )
    np.testing.assert_array_equal(
        result["output"], [[[-3, 2, 1, 4, 9, 10], [-7, 6, 5, 8, 11, 12]]]
    )
    np.testing.assert_array_equal(result["output_stored"], result["output"])


def test_rope_cache_bf16_conversion_is_explicit_before_rotation(ref):
    value = np.array([[[2.0, 3.0]]])
    table = np.array([[1 + 1 / 256, 0.0]], dtype=np.float64)
    parameters = dict(rotary_dim=2, compute_dtype="float64", output_storage="float32")
    direct = ref.neox_rope(
        value, np.array([0]), table, cache_storage="as_supplied", **parameters
    )
    bf16 = ref.neox_rope(
        value, np.array([0]), table, cache_storage="bf16", **parameters
    )
    np.testing.assert_array_equal(direct["output"], [[[2.0078125, 3.01171875]]])
    np.testing.assert_array_equal(bf16["output"], value)
    assert np.any(direct["output"] != bf16["output"])
    np.testing.assert_array_equal(table, [[1 + 1 / 256, 0.0]])


def test_rope_cache_float32_policy_does_not_silently_keep_float64_bits(ref):
    table = np.array([[1 + 2**-30, 0]], dtype=np.float64)
    parameters = dict(rotary_dim=2, compute_dtype="float64", output_storage="compute")
    direct = ref.neox_rope(
        [[[1.0, 0.0]]], np.array([0]), table, cache_storage="as_supplied", **parameters
    )
    stored = ref.neox_rope(
        [[[1.0, 0.0]]], np.array([0]), table, cache_storage="float32", **parameters
    )
    assert direct["output"][0, 0, 0] == 1 + 2**-30
    assert stored["output"][0, 0, 0] == 1


def test_prefill_causal_mask_and_contiguous_grouped_head_mapping(ref):
    q = np.ones((2, 4, 1))
    k = np.zeros((2, 2, 1))
    v = np.array([[[2.0], [10.0]], [[6.0], [18.0]]])
    result = ref.prefill_gqa(
        q, k, v, scale=1.0, compute_dtype="float64", output_storage="compute"
    )
    np.testing.assert_array_equal(
        result["output"][:, :, 0], [[2, 2, 10, 10], [4, 4, 14, 14]]
    )


def test_full_128_token_prefill_uses_each_queries_own_prefix(ref):
    length = 128
    q, k = np.ones((length, 2, 2)), np.zeros((length, 1, 2))
    v = (2 * np.arange(length) + 1.0)[:, None, None]
    result = ref.prefill_gqa(
        q, k, v, scale=2**-0.5, compute_dtype="float64", output_storage="compute"
    )
    # Mean of the first n odd integers is n, independently for each query head.
    expected = np.repeat(np.arange(1, length + 1)[:, None], 2, axis=1)
    np.testing.assert_allclose(result["output"][:, :, 0], expected, rtol=2e-15)


@pytest.mark.parametrize("length", [1, 128, 137, 145])
def test_decode_uses_every_valid_kv_row_without_hardcoded_history_length(ref, length):
    q = np.ones((1, 4, 2))
    k = np.zeros((length, 2, 2))
    v = np.stack((np.arange(length) + 2.0, np.arange(length) + 10.0), axis=1)[
        :, :, None
    ]
    result = ref.decode_gqa(
        q, k, v, scale=0.5, compute_dtype="float64", output_storage="compute"
    )
    first = (length - 1) / 2 + 2
    second = (length - 1) / 2 + 10
    np.testing.assert_allclose(
        result["output"][0, :, 0], [first, first, second, second], rtol=2e-15
    )


@pytest.mark.parametrize("scale,expected", [(1.0, 6.0), (2.0, 7.2)])
def test_attention_scale_is_applied_before_softmax(ref, scale, expected):
    result = ref.decode_gqa(
        [[[1.0]]],
        [[[0.0]], [[np.log(3.0)]]],
        [[[0.0]], [[8.0]]],
        scale=scale,
        compute_dtype="float64",
        output_storage="bf16",
    )
    np.testing.assert_allclose(result["output"], [[[expected]]], rtol=2e-15)
    np.testing.assert_array_equal(
        result["output_stored"], ref.bf16_storage(result["output"])
    )


@pytest.mark.parametrize("compute_dtype", ["float32", "float64"])
def test_prefill_last_query_matches_decode_on_same_full_kv(ref, compute_dtype):
    q = np.array([[[1.0, 2.0]], [[-1.0, 1.0]], [[0.5, -0.25]]])
    k = np.array([[[0.0, 1.0]], [[1.0, 0.0]], [[-0.5, 0.25]]])
    v = np.array([[[2.0]], [[3.0]], [[-1.0]]])
    parameters = dict(
        scale=2**-0.5, compute_dtype=compute_dtype, output_storage="compute"
    )
    prefill = ref.prefill_gqa(q, k, v, **parameters)
    decode = ref.decode_gqa(q[-1:], k, v, **parameters)
    np.testing.assert_array_equal(prefill["output"][-1:], decode["output"])


def test_sigmoid_gate_keeps_raw_and_declared_bf16_storage_candidate(ref):
    result = ref.sigmoid_gate(
        [[[1 + 1 / 256, 3.0, -5.0]]],
        [[[1000.0, 0.0, -1000.0]]],
        compute_dtype="float64",
        output_storage="bf16",
    )
    np.testing.assert_array_equal(result["output"], [[[1 + 1 / 256, 1.5, 0.0]]])
    np.testing.assert_array_equal(result["output_stored"], [[[1.0, 1.5, 0.0]]])


def test_bf16_storage_ties_negative_zero_nan_and_fp32_intermediate(ref):
    values = np.array(
        [1.00390625, 1.01171875, -1.00390625, -1.01171875, 0.0, -0.0, np.nan]
    )
    result = ref.bf16_storage(values)
    np.testing.assert_array_equal(result[:6], [1, 1.015625, -1, -1.015625, 0, -0.0])
    assert np.signbit(result[5]) and np.isnan(result[6])
    assert ref.bf16_storage(np.array([1.00390625 + 2**-30]))[0] == 1


def test_vector_decomposition_uses_the_stated_order_and_reconstructs_difference(ref):
    result = ref.decompose_difference(
        [1.0, 4.0],
        [10.0, 20.0],
        [2.0, 3.0],
        [4.0, 7.0],
        [9.0, 17.0],
        compute_dtype="float64",
    )
    np.testing.assert_array_equal(result["difference"], [9, 16])
    np.testing.assert_array_equal(result["inherited"], [5, 10])
    np.testing.assert_array_equal(result["partition"], [2, 4])
    np.testing.assert_array_equal(result["residual"], [2, 2])
    np.testing.assert_array_equal(result["reconstructed"], result["difference"])
    np.testing.assert_array_equal(result["reconstruction_residual"], [0, 0])
    assert not any("percent" in key or "ratio" in key for key in result)


def test_vector_decomposition_preserves_nonzero_floating_point_reconstruction_error(
    ref,
):
    result = ref.decompose_difference(
        [1.0], [2.0], [1e20], [0.0], [0.0], compute_dtype="float32"
    )
    np.testing.assert_array_equal(result["difference"], [1.0])
    np.testing.assert_array_equal(result["reconstruction_residual"], [1.0])


def test_norm_rope_attention_gate_and_decomposition_do_not_mutate_inputs(ref):
    q = np.array([[[1.0, 2.0]], [[3.0, 4.0]]])
    gamma, table = np.array([1.0, 2.0]), np.array([[1.0, 0.0], [0.0, 1.0]])
    before = [item.copy() for item in (q, gamma, table)]
    ref.rmsnorm(q, gamma, epsilon=1e-6, compute_dtype="float64", output_storage="bf16")
    ref.neox_rope(
        q,
        np.array([0, 1]),
        table,
        rotary_dim=2,
        cache_storage="bf16",
        compute_dtype="float64",
        output_storage="bf16",
    )
    ref.prefill_gqa(q, q, q, scale=0.5, compute_dtype="float64", output_storage="bf16")
    ref.decode_gqa(
        q[-1:], q, q, scale=0.5, compute_dtype="float64", output_storage="bf16"
    )
    ref.sigmoid_gate(q, q, compute_dtype="float64", output_storage="bf16")
    result = ref.decompose_difference(q, q, q, q, q, compute_dtype="float64")
    result["difference"][:] = -99
    for actual, original in zip((q, gamma, table), before):
        np.testing.assert_array_equal(actual, original)


@pytest.mark.parametrize("bad", ["heads", "width", "dtype"])
def test_invalid_packed_geometry_and_compute_dtype_fail(ref, bad):
    parameters = dict(heads=2, kv_heads=1, head_dim=2, compute_dtype="float32")
    packed = np.zeros((1, 12))
    if bad == "heads":
        parameters["heads"] = True
    elif bad == "width":
        packed = packed[:, :-1]
    else:
        parameters["compute_dtype"] = "float16"
    with pytest.raises(ValueError):
        ref.split_qkv(packed, **parameters)


@pytest.mark.parametrize("bad", ["positions", "range", "rotary", "cache", "storage"])
def test_invalid_rope_contracts_fail_without_guessing(ref, bad):
    positions = np.array([0])
    parameters = dict(
        rotary_dim=2,
        cache_storage="as_supplied",
        compute_dtype="float64",
        output_storage="compute",
    )
    if bad == "positions":
        positions = positions.astype(float)
    elif bad == "range":
        positions = np.array([-1])
    elif bad == "rotary":
        parameters["rotary_dim"] = 1
    elif bad == "cache":
        parameters["cache_storage"] = "automatic"
    else:
        parameters["output_storage"] = "automatic"
    with pytest.raises(ValueError):
        ref.neox_rope([[[1.0, 2.0]]], positions, [[1.0, 0.0]], **parameters)


@pytest.mark.parametrize("bad", ["head_ratio", "history", "decode_queries", "scale"])
def test_invalid_attention_geometry_and_scale_fail(ref, bad):
    q, k, v = np.ones((1, 4, 2)), np.ones((2, 2, 2)), np.ones((2, 2, 3))
    scale = 0.5
    if bad == "head_ratio":
        q = q[:, :3]
    elif bad == "history":
        v = v[:1]
    elif bad == "decode_queries":
        q = np.concatenate((q, q))
    else:
        scale = 0
    with pytest.raises(ValueError):
        ref.decode_gqa(
            q, k, v, scale=scale, compute_dtype="float64", output_storage="compute"
        )


def test_bad_norm_and_shape_contracts_and_nonfinite_values_fail(ref):
    with pytest.raises(ValueError):
        ref.rmsnorm(
            [[1, 2]],
            [1, 1],
            epsilon=0,
            compute_dtype="float32",
            output_storage="compute",
        )
    with pytest.raises(ValueError):
        ref.rmsnorm(
            [[1, 2]],
            [1],
            epsilon=1e-6,
            compute_dtype="float32",
            output_storage="compute",
        )
    with pytest.raises(ValueError):
        ref.sigmoid_gate(
            [[np.nan]], [[0]], compute_dtype="float32", output_storage="bf16"
        )
    with pytest.raises(ValueError):
        ref.decompose_difference([1], [1, 2], [1], [1], [1], compute_dtype="float64")


def test_public_math_calls_require_explicit_policies(ref):
    for name in (
        "split_qkv",
        "rmsnorm",
        "neox_rope",
        "prefill_gqa",
        "decode_gqa",
        "sigmoid_gate",
        "decompose_difference",
    ):
        assert all(
            parameter.default is inspect.Parameter.empty
            for parameter in inspect.signature(getattr(ref, name)).parameters.values()
        )
