# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Reconstruct each original GDN history and FA cache from observed operands."""

import numpy as np

from analysis_binding import compare, require
from prefill_oracle import bf16_storage, causal_conv_prefill, delta_scan, gate_terms


def scan(q, k, v, g, beta, state):
    return delta_scan(
        q,
        k,
        v,
        g,
        beta,
        state,
        qk_epsilon=1e-6,
        scale=128**-0.5,
        compute_dtype="float32",
    )


def analyze_history(data, *, label):
    records = data["records"][label]
    first, last = records[0]["observed"], records[-1]["observed"]
    tp = records[0]["metadata"]["tp"]
    hk, hv = 16 // tp, 32 // tp
    report = {
        "fa": {},
        "gdn": {},
        "scope": "Actual per-layer input histories; no reference hidden-state substitution or recomputed model prefix",
    }
    for layer in range(3, 32, 4):
        prefix = f"fa{layer}"
        keys, values = [], []
        for entry in records:
            item = entry["observed"]["modules"][f"{prefix}.attn"]
            keys.append(item["inputs"][1].reshape(-1, 4 // tp, 256))
            values.append(item["inputs"][2].reshape(-1, 4 // tp, 256))
        actual = last["kv"][layer]
        report["fa"][layer] = {
            "before_k_equals_all_previous_actual_keys": np.array_equal(
                actual["before"]["k"], np.concatenate(keys[:-1], axis=0)
            ),
            "before_v_equals_all_previous_actual_values": np.array_equal(
                actual["before"]["v"], np.concatenate(values[:-1], axis=0)
            ),
            "after_k_equals_all_actual_keys": np.array_equal(
                actual["after"]["k"], np.concatenate(keys, axis=0)
            ),
            "after_v_equals_all_actual_values": np.array_equal(
                actual["after"]["v"], np.concatenate(values, axis=0)
            ),
            "before_length": int(actual["before"]["k"].shape[0]),
            "after_length": int(actual["after"]["k"].shape[0]),
        }
    for layer in [i for i in range(32) if i % 4 != 3]:
        prefix = f"l{layer}.linear_attn"
        beginning = first["backend"][layer]
        prefill_states = first["states"][layer]
        scans = beginning["prefill_scans"]
        require(
            len(scans) == 1,
            "Expected original unsegmented128 Prefill scan; keep unknown captured layout for separate analysis",
        )
        s = scans[0]
        require(
            s["q"].shape == (1, 128, hk, 128) and s["v"].shape == (1, 128, hv, 128),
            "Prefill scan geometry mismatch",
        )
        require(
            s["query_start_loc"].tolist() == [0, 128]
            and s["metadata"]["num_real_tokens"] == 128,
            "Prefill live extent mismatch",
        )
        initial = s["initial_state"][0]
        require(
            np.array_equal(s["initial_state"], s["actual_chunk_initial_state"]),
            "actual kernel initial state differs from scan input",
        )
        require(
            len(beginning["actual_conv_calls"]) == 1
            and beginning["extend"]["bias"] is None,
            "Original bias-free Prefill conv expected",
        )
        conv_call = beginning["actual_conv_calls"][0]
        require(
            isinstance(conv_call["has_initial_state"], np.ndarray)
            and conv_call["has_initial_state"].shape == (1,),
            "Actual conv history flag absent",
        )
        conv_history = np.zeros((8192 // tp, 3), dtype=np.float32)
        conv = causal_conv_prefill(
            beginning["extend"]["mixed_qkv"],
            beginning["extend"]["conv_weights"],
            conv_history,
            compute_dtype="float32",
        )
        actual_mixed = np.concatenate(
            [
                s["q"][0].reshape(128, -1),
                s["k"][0].reshape(128, -1),
                s["v"][0].reshape(128, -1),
            ],
            axis=-1,
        )
        prefill_math = scan(
            s["q"][0],
            s["k"][0],
            s["v"][0],
            s["actual_chunk_g"][0],
            s["actual_chunk_beta"][0],
            initial,
        )
        naive = gate_terms(
            s["a"],
            s["b"],
            s["A_log"],
            s["dt_bias"],
            compute_dtype="float32",
            softplus_policy="naive",
        )
        stable = gate_terms(
            s["a"],
            s["b"],
            s["A_log"],
            s["dt_bias"],
            compute_dtype="float32",
            softplus_policy="stable",
        )
        item = {
            "fresh_mapping": prefill_states["before"]["metadata"],
            "actual_initial_state_all_zero": bool(np.count_nonzero(initial) == 0),
            "actual_conv_has_initial_history": bool(conv_call["has_initial_state"][0]),
            "actual_conv_cache_indices_equal_state_out": conv_call[
                "cache_indices"
            ].tolist()
            == [prefill_states["after"]["metadata"]["state_out_slot"]],
            "actual_conv_output_equals_scan_qkv": bool(
                np.array_equal(conv_call["output"].T, actual_mixed)
            ),
            "prefill_conv_actual_vs_fp32_stored": compare(
                actual_mixed, conv["output_bf16"]
            ),
            "prefill_conv_pool_exact_history": bool(
                np.array_equal(prefill_states["after"]["conv_state"], conv["history"])
            ),
            "prefill_gate_actual_vs_naive": compare(s["actual_chunk_g"][0], naive["g"]),
            "prefill_gate_actual_vs_stable": compare(
                s["actual_chunk_g"][0], stable["g"]
            ),
            "prefill_beta_actual_vs_fp32": compare(
                s["actual_chunk_beta"][0], naive["beta"]
            ),
            "prefill_naive_cancellation_indices": naive[
                "cancellation_indices"
            ].tolist(),
            "prefill_scan_actual_vs_fp32_stored": compare(
                s["outputs"][0][0], bf16_storage(prefill_math["core"])
            ),
            "prefill_state_actual_vs_fp32": compare(
                s["outputs"][1][0], prefill_math["state"]
            ),
            "prefill_state_pool_equals_kernel_output": bool(
                np.array_equal(prefill_states["after"]["ssm_state"], s["outputs"][1][0])
            ),
            "decode": [],
        }
        seeded = prefill_states["after"]["ssm_state"].copy()
        mathematical = prefill_math["state"].copy()
        conv_history = prefill_states["after"]["conv_state"].copy()
        previous_slot = prefill_states["after"]["metadata"]["state_out_slot"]
        for step in range(1, len(records)):
            observed = records[step]["observed"]
            backend = observed["backend"][layer]
            raw, qkv = backend["decode"], backend["scan"]
            require(
                qkv["q"].shape == (1, 1, hk, 128) and qkv["v"].shape == (1, 1, hv, 128),
                "Decode scan geometry mismatch",
            )
            q, k, v = qkv["q"][0], qkv["k"][0], qkv["v"][0]
            a, b = raw["a"].reshape(1, hv), raw["b"].reshape(1, hv)
            gates = gate_terms(
                a,
                b,
                raw["A_log"],
                raw["dt_bias"],
                compute_dtype="float32",
                softplus_policy="naive",
            )
            stable_gates = gate_terms(
                a,
                b,
                raw["A_log"],
                raw["dt_bias"],
                compute_dtype="float32",
                softplus_policy="stable",
            )
            conv_ref = causal_conv_prefill(
                raw["mixed_qkv"],
                raw["conv_weights"],
                conv_history,
                compute_dtype="float32",
            )
            actual_mixed = np.concatenate(
                [q.reshape(1, -1), k.reshape(1, -1), v.reshape(1, -1)], axis=-1
            )
            result = scan(q, k, v, gates["g"], gates["beta"], seeded)
            from_math = scan(q, k, v, gates["g"], gates["beta"], mathematical)
            row = {
                "step": step,
                "read_slot_follows_previous_write": qkv["read_indices"].tolist()
                == [previous_slot],
                "conv_actual_vs_history_reference": compare(
                    actual_mixed, conv_ref["output_bf16"]
                ),
                "scan_actual_vs_actual_prefill_seeded_reference": compare(
                    qkv["output"].reshape(1, hv, 128), bf16_storage(result["core"])
                ),
                "scan_actual_vs_math_prefill_seeded_reference": compare(
                    qkv["output"].reshape(1, hv, 128), bf16_storage(from_math["core"])
                ),
                "naive_cancellation_indices": gates["cancellation_indices"].tolist(),
                "naive_vs_stable_g": compare(gates["g"], stable_gates["g"]),
                "decode_scan_output_continuity": bool(
                    np.array_equal(raw["output"], qkv["output"])
                ),
                "scan_norm_input_continuity": bool(
                    np.array_equal(
                        observed["modules"][f"{prefix}.norm"]["inputs"][0],
                        qkv["output"].reshape(hv, 128),
                    )
                ),
            }
            if step == len(records) - 1:
                actual_state = observed["states"][layer]
                row["conv_before_exact_reconstructed_history"] = bool(
                    np.array_equal(actual_state["before"]["conv_state"], conv_history)
                )
                row["conv_after_exact_reconstructed_history"] = bool(
                    np.array_equal(
                        actual_state["after"]["conv_state"], conv_ref["history"]
                    )
                )
                row["ssm_before_vs_actual_prefill_seeded_history"] = compare(
                    actual_state["before"]["ssm_state"], seeded
                )
                row["ssm_after_vs_actual_prefill_seeded_history"] = compare(
                    actual_state["after"]["ssm_state"], result["state"]
                )
                row["ssm_after_vs_math_prefill_seeded_history"] = compare(
                    actual_state["after"]["ssm_state"], from_math["state"]
                )
                own = scan(
                    q,
                    k,
                    v,
                    gates["g"],
                    gates["beta"],
                    actual_state["before"]["ssm_state"],
                )
                row["ssm_after_vs_actual_own_state_reference"] = compare(
                    actual_state["after"]["ssm_state"], own["state"]
                )
                row["core_after_vs_actual_own_state_reference"] = compare(
                    qkv["output"].reshape(1, hv, 128), bf16_storage(own["core"])
                )
            seeded, mathematical, conv_history = (
                result["state"],
                from_math["state"],
                conv_ref["history"],
            )
            previous_slot = int(qkv["write_indices"][0])
            item["decode"].append(row)
        report["gdn"][layer] = item
    return report
