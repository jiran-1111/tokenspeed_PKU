# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import hashlib

import numpy as np
import pytest

from analysis_binding import check_captured_parameter
from analyze_operations import offsets, reduction_boundary


@pytest.mark.parametrize("dtype", ["torch.bfloat16", "torch.float32"])
def test_captured_parameter_values_are_bound_to_actual_bytes(dtype):
    values = np.array([[1.0, 2.0], [3.0, 4.0]], dtype=np.float32)
    raw = (
        (values.view(np.uint32) >> 16).astype("<u2").tobytes()
        if dtype == "torch.bfloat16"
        else values.astype("<f4").tobytes()
    )
    certificate = {
        "shape": [2, 2],
        "dtype": dtype,
        "actual_sha256": hashlib.sha256(raw).hexdigest(),
    }
    check_captured_parameter(values, certificate)
    values[0, 0] = 5
    with pytest.raises(ValueError):
        check_captured_parameter(values, certificate)


def test_final_mlp_reduction_connects_to_final_norm():
    assert reduction_boundary(31, "fa31.mlp.down_proj") == "final_norm"
    assert reduction_boundary(30, "l30.mlp.down_proj") == "layers.31.input_layernorm"
    assert reduction_boundary(31, "fa31.o_proj") == "layers.31.post_attention_layernorm"


@pytest.mark.parametrize("steps", [10, 18])
def test_concatenated_actual_prefill_decode_row_offsets(steps):
    spans = offsets({"steps": steps})
    assert spans[0] == (0, 128) and spans[-1] == (126 + steps, 127 + steps)
    assert all(left[1] == right[0] for left, right in zip(spans, spans[1:]))
