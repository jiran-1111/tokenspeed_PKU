# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Pure NumPy FA references and an ordered difference-vector identity.

The binder supplies actual operands, effective gamma, positions and RoPE table.
These are declared mathematical/storage candidates, not device arithmetic
emulation, provenance checks, model thresholds, or a claim of model correctness.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike, NDArray


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _dtype(name: str) -> np.dtype:
    _require(name in ("float32", "float64"), "compute_dtype must be float32 or float64")
    return np.dtype(name)


def _array(value: ArrayLike, dtype: np.dtype) -> NDArray:
    _require(not np.iscomplexobj(value), "real operands required")
    with np.errstate(over="ignore", invalid="ignore"):
        result = np.array(value, dtype=dtype, copy=True)
    _require(
        result.size > 0 and bool(np.isfinite(result).all()),
        "nonempty finite operands required",
    )
    return result


def _positive(value: float, dtype: np.dtype) -> np.floating:
    _require(
        isinstance(value, (int, float, np.integer, np.floating))
        and not isinstance(value, (bool, np.bool_)),
        "explicit positive scalar required",
    )
    converted = dtype.type(value)
    _require(
        bool(np.isfinite(converted)) and converted > 0,
        "finite positive scalar required",
    )
    return converted


def bf16_storage(value: ArrayLike) -> NDArray[np.float32]:
    """FP32 intermediate then BF16 RNE, represented by FP32 values.

    Even FP64 candidates pass through FP32 first. This is not ideal direct
    FP64-to-BF16 conversion or simulation of any intermediate kernel rounding.
    """
    _require(not np.iscomplexobj(value), "real storage values required")
    with np.errstate(over="ignore", invalid="ignore"):
        bits = np.asarray(value, dtype=np.float32).view(np.uint32)
        rounded = (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(
            0xFFFF0000
        )
        is_nan = (bits & np.uint32(0x7FFFFFFF)) > np.uint32(0x7F800000)
        rounded = np.where(
            is_nan, (bits & np.uint32(0xFFFF0000)) | np.uint32(0x00400000), rounded
        )
    return rounded.view(np.float32)


def _stored(value: NDArray, policy: str) -> NDArray:
    _require(
        policy in ("compute", "float32", "bf16"), "unknown output/cache storage policy"
    )
    if policy == "bf16":
        result = bf16_storage(value)
    elif policy == "float32":
        with np.errstate(over="ignore", invalid="ignore"):
            result = value.astype(np.float32)
    else:
        result = value.copy()
    _require(bool(np.isfinite(result).all()), "nonfinite storage candidate")
    return result


def _result(value: NDArray, storage: str) -> dict[str, NDArray]:
    _require(bool(np.isfinite(value).all()), "nonfinite mathematical result")
    return {"output": value, "output_stored": _stored(value, storage)}


def _sigmoid(value: NDArray) -> NDArray:
    one = np.ones_like(value)
    exponential = np.exp(-np.abs(value))
    return np.where(
        value >= 0, one / (one + exponential), exponential / (one + exponential)
    )


def split_qkv(
    packed: ArrayLike, *, heads: int, kv_heads: int, head_dim: int, compute_dtype: str
) -> dict[str, NDArray]:
    """Split [T,(2*Hq+2*Hkv)*D]; Q/gate are interleaved PER query head."""
    _require(
        all(type(item) is int and item > 0 for item in (heads, kv_heads, head_dim)),
        "positive integer head geometry required",
    )
    source = _array(packed, _dtype(compute_dtype))
    _require(
        source.ndim == 2 and source.shape[1] == (2 * heads + 2 * kv_heads) * head_dim,
        "packed Q/gate/K/V shape mismatch",
    )
    count = source.shape[0]
    q_end = 2 * heads * head_dim
    k_end = q_end + kv_heads * head_dim
    q_gate = source[:, :q_end].reshape(count, heads, 2, head_dim)
    return {
        "q": q_gate[:, :, 0].copy(),
        "gate": q_gate[:, :, 1].copy(),
        "k": source[:, q_end:k_end].reshape(count, kv_heads, head_dim).copy(),
        "v": source[:, k_end:].reshape(count, kv_heads, head_dim).copy(),
    }


def rmsnorm(
    value: ArrayLike,
    gamma: ArrayLike,
    *,
    epsilon: float,
    compute_dtype: str,
    output_storage: str,
) -> dict[str, NDArray]:
    """Last-axis mean(square)+epsilon RMSNorm; gamma is ALREADY effective.

    No +1, residual update, gamma projection, or hidden input-storage cast is
    applied. In particular, this function is not the GDN sum-based Q/K norm.
    """
    dtype = _dtype(compute_dtype)
    source, effective_gamma = _array(value, dtype), _array(gamma, dtype)
    _require(
        source.ndim >= 1 and effective_gamma.shape == (source.shape[-1],),
        "RMSNorm gamma shape mismatch",
    )
    eps = _positive(epsilon, dtype)
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        inverse = dtype.type(1) / np.sqrt(
            np.mean(source * source, axis=-1, keepdims=True, dtype=dtype) + eps
        )
        output = (source * inverse) * effective_gamma
    return _result(output, output_storage)


def neox_rope(
    value: ArrayLike,
    positions: ArrayLike,
    cos_sin_cache: ArrayLike,
    *,
    rotary_dim: int,
    cache_storage: str,
    compute_dtype: str,
    output_storage: str,
) -> dict[str, NDArray]:
    """Rotate the first rotary_dim features by half-split NeoX RoPE.

    Input [T,H,D], integer positions[T], table[P,rotary_dim] ordered [cos|sin].
    cache_storage is as_supplied, float32 or bf16 BEFORE compute conversion.
    output_storage affects only the separately returned final candidate.
    """
    dtype = _dtype(compute_dtype)
    source = _array(value, dtype)
    pos = np.asarray(positions)
    _require(
        source.ndim == 3
        and type(rotary_dim) is int
        and 0 < rotary_dim <= source.shape[-1]
        and rotary_dim % 2 == 0,
        "positive even partial rotary dimension required",
    )
    _require(
        pos.dtype.kind in "iu" and pos.shape == (source.shape[0],),
        "positions must be an integer vector with one entry per token",
    )
    _require(
        cache_storage in ("as_supplied", "float32", "bf16"),
        "explicit cache storage policy required",
    )
    # Validate the supplied table before a chosen narrowing policy can hide values.
    table = _array(cos_sin_cache, np.dtype("float64"))
    _require(
        table.ndim == 2 and table.shape[1] == rotary_dim, "RoPE table shape mismatch"
    )
    _require(
        bool(np.all(pos >= 0)) and bool(np.all(pos < table.shape[0])),
        "RoPE positions outside supplied cache",
    )
    if cache_storage != "as_supplied":
        table = _stored(table, cache_storage)
    table = table.astype(dtype)
    selected = table[pos]
    cos, sin = np.split(selected, 2, axis=-1)
    first, second = np.split(source[..., :rotary_dim], 2, axis=-1)
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        rotated = np.concatenate(
            (
                first * cos[:, None] - second * sin[:, None],
                second * cos[:, None] + first * sin[:, None],
            ),
            axis=-1,
        )
    return _result(
        np.concatenate((rotated, source[..., rotary_dim:]), axis=-1), output_storage
    )


def _gqa(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    *,
    scale: float,
    compute_dtype: str,
    output_storage: str,
    causal: bool,
) -> dict[str, NDArray]:
    dtype = _dtype(compute_dtype)
    query, key, value = (_array(item, dtype) for item in (q, k, v))
    _require(
        query.ndim == key.ndim == value.ndim == 3
        and key.shape[:2] == value.shape[:2]
        and query.shape[-1] == key.shape[-1]
        and query.shape[1] % key.shape[1] == 0,
        "GQA requires [Tq,Hq,D], [Tk,Hkv,D], [Tk,Hkv,V] with integral Hq/Hkv",
    )
    _require(
        query.shape[0] == key.shape[0] if causal else query.shape[0] == 1,
        "Prefill requires equal Q/K lengths; decode requires exactly one query",
    )
    scaling = _positive(scale, dtype)
    head = np.arange(query.shape[1]) // (query.shape[1] // key.shape[1])
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        scores = (
            np.einsum("thd,shd->hts", query, key[:, head], dtype=dtype, optimize=False)
            * scaling
        )
        if causal:
            mask = np.arange(key.shape[0])[None, :] > np.arange(query.shape[0])[:, None]
            scores = np.where(mask[None], dtype.type(-np.inf), scores)
        probability = np.exp(scores - np.max(scores, axis=-1, keepdims=True))
        probability /= np.sum(probability, axis=-1, keepdims=True, dtype=dtype)
        output = np.einsum(
            "hts,shv->thv", probability, value[:, head], dtype=dtype, optimize=False
        )
    return _result(output, output_storage)


def prefill_gqa(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    *,
    scale: float,
    compute_dtype: str,
    output_storage: str,
) -> dict[str, NDArray]:
    """Full causal Prefill, no earlier prefix; contiguous grouped-head mapping."""
    return _gqa(
        q,
        k,
        v,
        scale=scale,
        compute_dtype=compute_dtype,
        output_storage=output_storage,
        causal=True,
    )


def decode_gqa(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    *,
    scale: float,
    compute_dtype: str,
    output_storage: str,
) -> dict[str, NDArray]:
    """One current query against ALL supplied valid KV rows, including current KV.

    The binder supplies only the valid chronological prefix. No paging, hidden
    position offset, reconstructed past, padding mask, or fixed length is used.
    """
    return _gqa(
        q,
        k,
        v,
        scale=scale,
        compute_dtype=compute_dtype,
        output_storage=output_storage,
        causal=False,
    )


def sigmoid_gate(
    attention: ArrayLike,
    gate: ArrayLike,
    *,
    compute_dtype: str,
    output_storage: str,
) -> dict[str, NDArray]:
    """FA output * sigmoid(raw gate), using the actual PRE-gate attention value."""
    dtype = _dtype(compute_dtype)
    source, logits = _array(attention, dtype), _array(gate, dtype)
    _require(source.shape == logits.shape, "sigmoid gate shape mismatch")
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        output = source * _sigmoid(logits)
    return _result(output, output_storage)


def decompose_difference(
    y1: ArrayLike,
    y2: ArrayLike,
    f1_x1: ArrayLike,
    f2_x1: ArrayLike,
    f2_x2: ArrayLike,
    *,
    compute_dtype: str,
) -> dict[str, NDArray]:
    """Ordered vector identity; x includes any explicit history/state inputs.

    inherited = F2(x2)-F2(x1); partition = F2(x1)-F1(x1);
    residual = (y2-F2(x2))-(y1-F1(x1)). All candidates must already use the
    SAME logical output layout and chosen final-storage convention. Nothing
    is normalized into an additive causal fraction. Nonzero numerical
    reconstruction error is returned rather than overwritten with zero.
    """
    dtype = _dtype(compute_dtype)
    one, two, f_one, common, f_two = (
        _array(item, dtype) for item in (y1, y2, f1_x1, f2_x1, f2_x2)
    )
    _require(
        all(item.shape == one.shape for item in (two, f_one, common, f_two)),
        "decomposition output shapes must match",
    )
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        difference = two - one
        inherited = f_two - common
        partition = common - f_one
        residual = (two - f_two) - (one - f_one)
        reconstructed = (inherited + partition) + residual
        reconstruction_residual = difference - reconstructed
    return {
        "difference": difference,
        "inherited": inherited,
        "partition": partition,
        "residual": residual,
        "reconstructed": reconstructed,
        "reconstruction_residual": reconstruction_residual,
    }
