#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Conditional NumPy GDN prefill oracle with fixed BF16 storage boundaries.

No production/runtime/Triton imports or parameter/state mutation. Initial conv
history and K-last SSM state are explicit hypotheses supplied by the caller;
zero inputs are a zero-initial-state conditional reference, never evidence of
the actual historical prefill initialization.
"""

from __future__ import annotations

from typing import Any

import numpy as np
from numpy.typing import ArrayLike, NDArray


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _dtype(name: str) -> np.dtype:
    _require(
        name in ("float32", "float64"),
        "compute_dtype must be explicitly float32 or float64",
    )
    return np.dtype(name)


def _array(value: ArrayLike, dtype: np.dtype, *, name: str) -> NDArray:
    _require(not np.iscomplexobj(value), f"{name} must contain real numbers")
    result = np.array(value, dtype=dtype, copy=True)
    _require(
        result.size > 0 and bool(np.isfinite(result).all()),
        f"{name} must be nonempty and finite",
    )
    return result


def _positive(value: float, dtype: np.dtype, *, name: str) -> np.floating:
    _require(
        isinstance(value, (int, float, np.integer, np.floating))
        and not isinstance(value, (bool, np.bool_)),
        f"{name} must be an explicit positive scalar",
    )
    result = dtype.type(value)
    _require(
        bool(np.isfinite(result)) and result > 0,
        f"{name} must be finite and positive in the selected dtype",
    )
    return result


def _dimensions(hk: int, hv: int, key_dim: int, value_dim: int) -> None:
    _require(
        all(type(value) is int and value > 0 for value in (hk, hv, key_dim, value_dim))
        and hv % hk == 0,
        "positive explicit hk/hv/key_dim/value_dim with integral hv/hk ratio required",
    )


def bf16_storage(value: ArrayLike) -> NDArray[np.float32]:
    """FP32 storage conversion followed by BF16 round-to-nearest-even.

    The returned BF16 values are represented as FP32 NumPy arrays. FP64 inputs
    also pass through FP32 FIRST; this is not ideal direct FP64->BF16 rounding.
    This reproduces only the declared storage candidate, not kernel arithmetic.
    """
    with np.errstate(over="ignore", invalid="ignore"):
        bits = np.asarray(value, dtype=np.float32).view(np.uint32)
        rounded = (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(
            0xFFFF0000
        )
        is_nan = (bits & np.uint32(0x7FFFFFFF)) > np.uint32(0x7F800000)
        rounded = np.where(
            is_nan, (bits & np.uint32(0xFFFF0000)) | np.uint32(0x00400000), rounded
        )
    return rounded.view(np.float32)


def _sigmoid(value: NDArray) -> NDArray:
    one = np.ones_like(value)
    exponential = np.exp(-np.abs(value))
    return np.where(
        value >= 0, one / (one + exponential), exponential / (one + exponential)
    )


def split_packed(
    packed: ArrayLike,
    *,
    hk: int,
    hv: int,
    key_dim: int,
    value_dim: int,
    compute_dtype: str,
) -> dict[str, NDArray]:
    """Split [T,2*Hk*K+2*Hv*V+2*Hv] into Q,K,V,Z,B,A."""
    _dimensions(hk, hv, key_dim, value_dim)
    dtype = _dtype(compute_dtype)
    source = _array(packed, dtype, name="packed")
    widths = (hk * key_dim, hk * key_dim, hv * value_dim, hv * value_dim, hv, hv)
    _require(
        source.ndim == 2 and source.shape[1] == sum(widths),
        "packed Q/K/V/Z/B/A shape mismatch",
    )
    shapes = (
        (hk, key_dim),
        (hk, key_dim),
        (hv, value_dim),
        (hv, value_dim),
        (hv,),
        (hv,),
    )
    parts = np.split(source, np.cumsum(widths)[:-1], axis=1)
    return {
        name: value.reshape(source.shape[0], *shape).copy()
        for name, value, shape in zip(("q", "k", "v", "z", "b", "a"), parts, shapes)
    }


def causal_conv_prefill(
    mixed_qkv: ArrayLike, weights: ArrayLike, history: ArrayLike, *, compute_dtype: str
) -> dict[str, NDArray]:
    """Four taps oldest->newest, explicit [C,3] history, no bias, then SiLU."""
    dtype = _dtype(compute_dtype)
    mixed = _array(mixed_qkv, dtype, name="mixed_qkv")
    weight = _array(weights, dtype, name="conv_weights")
    before = _array(history, dtype, name="conv_history")
    _require(
        mixed.ndim == 2
        and weight.shape == (mixed.shape[1], 4)
        and before.shape == (mixed.shape[1], 3),
        "conv requires mixed[T,C], weights[C,4], history[C,3]",
    )
    count, channels = mixed.shape
    past = np.concatenate((before, mixed.T), axis=1)
    linear = np.zeros_like(mixed)
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        for tap in range(4):
            linear += past[:, tap : tap + count].T * weight[:, tap]
        output = linear * _sigmoid(linear)
    return {
        "preactivation": linear,
        "output": output,
        "output_bf16": bf16_storage(output),
        "history": past[:, -3:].copy(),
    }


def gate_terms(
    a: ArrayLike,
    b: ArrayLike,
    A_log: ArrayLike,
    dt_bias: ArrayLike,
    *,
    compute_dtype: str,
    softplus_policy: str,
) -> dict[str, NDArray]:
    """Softplus beta=1/threshold=20; report cancellation in naive log(1+exp)."""
    dtype = _dtype(compute_dtype)
    _require(
        softplus_policy in ("naive", "stable"),
        "softplus_policy must be explicitly naive or stable",
    )
    a_value, b_value, log_value, bias = (
        _array(value, dtype, name=name)
        for value, name in ((a, "a"), (b, "b"), (A_log, "A_log"), (dt_bias, "dt_bias"))
    )
    _require(
        a_value.ndim == 2
        and b_value.shape == a_value.shape
        and log_value.shape == bias.shape == (a_value.shape[1],),
        "gate inputs require a/b[T,Hv], A_log/dt_bias[Hv]",
    )
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        x = a_value + bias
        naive = x.copy()
        stable = x.copy()
        mask = x <= dtype.type(20)
        selected = x[mask]
        naive[mask] = np.log(dtype.type(1) + np.exp(selected))
        stable[mask] = np.maximum(selected, dtype.type(0)) + np.log1p(
            np.exp(-np.abs(selected))
        )
        softplus = naive if softplus_policy == "naive" else stable
        g = -np.exp(log_value) * softplus
        beta = _sigmoid(b_value)
    cancellation = (x < 0) & (naive == 0) & (stable > 0)
    return {
        "x": x,
        "softplus": softplus.copy(),
        "softplus_naive": naive,
        "softplus_stable": stable,
        "g": g,
        "beta": beta,
        "cancellation_indices": np.argwhere(cancellation),
    }


def delta_scan(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    g: ArrayLike,
    beta: ArrayLike,
    state: ArrayLike,
    *,
    qk_epsilon: float,
    scale: float,
    compute_dtype: str,
) -> dict[str, NDArray]:
    """Tokenwise K-last recurrence; state remains selected FP32/FP64 throughout.

    Value heads repeat each key head contiguously: h_key=h_value//(Hv/Hk).
    Decay precedes prediction and delta update; output reads the updated state.
    """
    dtype = _dtype(compute_dtype)
    q_value, k_value, v_value, decay_log, mixing, initial = (
        _array(value, dtype, name=name)
        for value, name in (
            (q, "q"),
            (k, "k"),
            (v, "v"),
            (g, "g"),
            (beta, "beta"),
            (state, "ssm_state"),
        )
    )
    _require(
        q_value.ndim == 3
        and k_value.shape == q_value.shape
        and v_value.ndim == 3
        and v_value.shape[0] == q_value.shape[0],
        "scan q/k[T,Hk,K] and v[T,Hv,V] shape mismatch",
    )
    count, hk, key_dim = q_value.shape
    _, hv, value_dim = v_value.shape
    _dimensions(hk, hv, key_dim, value_dim)
    _require(
        initial.shape == (hv, value_dim, key_dim)
        and decay_log.shape == mixing.shape == (count, hv),
        "scan requires K-last state[Hv,V,K] and g/beta[T,Hv]",
    )
    epsilon = _positive(qk_epsilon, dtype, name="qk_epsilon")
    scaling = _positive(scale, dtype, name="scale")
    _require(
        bool(np.all((mixing >= 0) & (mixing <= 1))) and bool(np.all(decay_log <= 0)),
        "scan requires nonpositive g and beta in [0,1]",
    )
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        normalized_q = q_value / np.sqrt(
            np.sum(q_value * q_value, axis=-1, keepdims=True, dtype=dtype) + epsilon
        )
        normalized_k = k_value / np.sqrt(
            np.sum(k_value * k_value, axis=-1, keepdims=True, dtype=dtype) + epsilon
        )
        key_head = np.arange(hv) // (hv // hk)
        result = np.empty((count, hv, value_dim), dtype=dtype)
        current = initial.copy()
        for token in range(count):
            local_k = normalized_k[token, key_head]
            scaled_q = normalized_q[token, key_head] * scaling
            decayed = current * np.exp(decay_log[token])[:, None, None]
            prediction = np.sum(decayed * local_k[:, None, :], axis=-1, dtype=dtype)
            delta = (v_value[token] - prediction) * mixing[token, :, None]
            current = decayed + delta[:, :, None] * local_k[:, None, :]
            result[token] = np.sum(current * scaled_q[:, None, :], axis=-1, dtype=dtype)
    return {
        "core": result,
        "state": current,
        "normalized_q": normalized_q,
        "normalized_k": normalized_k,
    }


def gated_norm(
    core: ArrayLike,
    z: ArrayLike,
    weight: ArrayLike,
    *,
    norm_epsilon: float,
    compute_dtype: str,
) -> dict[str, NDArray]:
    """Per-value-head mean+epsilon RMS normalization before SiLU(z), then BF16.

    weight[V] must already contain exactly representable BF16 values. No weight
    projection or mutation is performed here; the binder owns its provenance.
    """
    dtype = _dtype(compute_dtype)
    value, gate, gamma = (
        _array(array, dtype, name=name)
        for array, name in ((core, "core"), (z, "z"), (weight, "norm_weight"))
    )
    _require(
        value.ndim == 3
        and gate.shape == value.shape
        and gamma.shape == (value.shape[-1],),
        "gated norm requires core/z[T,Hv,V], norm_weight[V]",
    )
    _require(
        bool(
            np.array_equal(
                np.asarray(weight, dtype=np.float64),
                bf16_storage(weight).astype(np.float64),
            )
        ),
        "norm_weight must already contain verified BF16 values; no implicit projection",
    )
    epsilon = _positive(norm_epsilon, dtype, name="norm_epsilon")
    with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
        inverse_rms = dtype.type(1) / np.sqrt(
            np.mean(value * value, axis=-1, keepdims=True, dtype=dtype) + epsilon
        )
        normalized = (value * inverse_rms) * gamma
        output = normalized * (gate * _sigmoid(gate))
    return {"output": output, "output_bf16": bf16_storage(output)}


def prefill_reference(
    packed: ArrayLike,
    conv_weights: ArrayLike,
    A_log: ArrayLike,
    dt_bias: ArrayLike,
    norm_weight: ArrayLike,
    conv_history: ArrayLike,
    ssm_state: ArrayLike,
    *,
    hk: int,
    hv: int,
    key_dim: int,
    value_dim: int,
    qk_epsilon: float,
    norm_epsilon: float,
    scale: float,
    compute_dtype: str,
    softplus_policy: str,
) -> dict[str, Any]:
    """Complete conditional prefill for one request and explicit initial states.

    Fixed current-model storage chain: conv SiLU raw -> FP32 -> BF16 -> Q/K/V;
    recurrence state stays chosen FP32/FP64; core raw -> FP32 -> BF16 -> gated
    norm; gated norm raw -> FP32 -> BF16. All BF16 arrays are FP32 representations.
    This is mathematical recurrence with declared storage points, not Triton
    BF16 intermediate/dot/scan emulation, actual-initialization certification,
    a new numerical threshold, or evidence that any runtime bug was fixed.
    """
    dtype = _dtype(compute_dtype)
    parts = split_packed(
        packed,
        hk=hk,
        hv=hv,
        key_dim=key_dim,
        value_dim=value_dim,
        compute_dtype=compute_dtype,
    )
    count = parts["q"].shape[0]
    mixed = np.concatenate(
        (
            parts["q"].reshape(count, -1),
            parts["k"].reshape(count, -1),
            parts["v"].reshape(count, -1),
        ),
        axis=1,
    )
    conv = causal_conv_prefill(
        mixed, conv_weights, conv_history, compute_dtype=compute_dtype
    )
    conv_stored = conv["output_bf16"].astype(dtype)
    _require(
        bool(np.isfinite(conv_stored).all()), "nonfinite BF16 convolution candidate"
    )
    q_end = hk * key_dim
    k_end = q_end * 2
    q = conv_stored[:, :q_end].reshape(count, hk, key_dim)
    k = conv_stored[:, q_end:k_end].reshape(count, hk, key_dim)
    v = conv_stored[:, k_end:].reshape(count, hv, value_dim)
    gates = gate_terms(
        parts["a"],
        parts["b"],
        A_log,
        dt_bias,
        compute_dtype=compute_dtype,
        softplus_policy=softplus_policy,
    )
    scan = delta_scan(
        q,
        k,
        v,
        gates["g"],
        gates["beta"],
        ssm_state,
        qk_epsilon=qk_epsilon,
        scale=scale,
        compute_dtype=compute_dtype,
    )
    core_stored = bf16_storage(scan["core"])
    norm = gated_norm(
        core_stored.astype(dtype),
        parts["z"],
        norm_weight,
        norm_epsilon=norm_epsilon,
        compute_dtype=compute_dtype,
    )
    _require(
        bool(np.isfinite(norm["output_bf16"]).all()),
        "nonfinite BF16 gated norm candidate",
    )
    return {
        "conv": conv["output"],
        "conv_bf16": conv["output_bf16"],
        "conv_history_after": conv["history"],
        "core": scan["core"],
        "core_bf16": core_stored,
        "state": scan["state"],
        "norm": norm["output"],
        "norm_bf16": norm["output_bf16"],
        **gates,
        "metadata": {
            "reference": "conditional complete-prefill mathematical recurrence",
            "compute_dtype": compute_dtype,
            "softplus_policy": softplus_policy,
            "qk_epsilon": float(qk_epsilon),
            "norm_epsilon": float(norm_epsilon),
            "scale": float(scale),
            "hk": hk,
            "hv": hv,
            "key_dim": key_dim,
            "value_dim": value_dim,
            "tokens": count,
            "conv_history_is_zero": bool(np.count_nonzero(conv_history) == 0),
            "ssm_state_is_zero": bool(np.count_nonzero(ssm_state) == 0),
            "initial_state_contract": "caller supplied conditional hypotheses; never observed historical initialization",
            "actual_initial_state_certified": False,
            "storage_chain": "conv BF16 -> recurrence in chosen dtype -> core BF16 -> gated norm -> BF16",
            "bf16_rounding": "FP32 intermediate then BF16 RNE, including FP64-path candidates; not ideal direct FP64->BF16",
            "triton_intermediate_arithmetic_emulated": False,
            "thresholds_added": False,
            "runtime_modified": False,
            "runtime_bug_fixed": False,
            "cancellation_definition": "[token,value_head] where x<0 and naive softplus==0<stable softplus in the selected dtype",
        },
    }
