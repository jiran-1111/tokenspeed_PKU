#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Bind original R4 operands and checkpoint values to a conditional CPU oracle."""

import json
import os
import sys
from pathlib import Path

import numpy as np

from binding import compare, merge_packed, require, sha, validate_run, verify_files
from prefill_oracle import bf16_storage, prefill_reference


def read(path):
    return json.loads(path.read_text())


def main():
    require(os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0", "CPU backend autoload not disabled")
    require(os.environ["ASCEND_RT_VISIBLE_DEVICES"] == "", "CPU analysis must not see devices")
    sys.modules["torch_npu"] = None
    import torch
    from safetensors import safe_open

    torch.set_num_threads(1)
    here = Path(__file__).resolve().parent
    task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
    source = task / "source_final"
    specification = read(here / "inputs.json")
    verify_files(here, read(here / "tool_manifest.json"))
    verify_files(task, specification["files"])
    core_path = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(sha(core_path) == specification["core_manifest_sha256"], "core manifest mismatch")
    core = read(core_path)
    require(len(core) == 1531, "unexpected source scope")
    verify_files(source, core)
    artifacts_path = source / "docs/evidence/homework2_20261023/model_artifacts.json"
    require(sha(artifacts_path) == specification["artifacts_sha256"], "artifact identity mismatch")
    artifacts = read(artifacts_path)
    old_tools = task / "first_layer_diagnostic_r4"
    controller = read(old_tools / "state.json")
    require(controller["status"] == "collected", "historical controller incomplete")
    arrays = {}
    report = {"scope": "Conditional zero-initial-state first-layer Prefill reference on original operands; no new NPU execution",
              "source_manifest_sha256": sha(core_path), "models": {}, "actual_initial_state_observed": False,
              "actual_kernel_gate_observed": False, "runtime_math_changed": False, "thresholds_added": False,
              "original_failures_preserved": True, "model_correctness_pass_claimed": False}
    checkpoint_files = {}

    def tensor_sha(value):
        import hashlib
        return hashlib.sha256(value.contiguous().view(torch.uint8).numpy().tobytes()).hexdigest()

    for model in ("4b", "9b"):
        print(f"Binding {model}", flush=True)
        config = read(source / f"configs/homework2/qwen35_{model}_tp1.yaml")
        folder = source / config["local_model_path"]
        artifact = next(item for item in artifacts["models"] if item["model_id"] == config["model_id"] and item["model_revision"] == config["model_revision"])
        index_path = folder / "model.safetensors.index.json"
        index = read(index_path)["weight_map"]
        names = {suffix: f"model.language_model.layers.0.linear_attn.{suffix}" for suffix in ("conv1d.weight", "A_log", "dt_bias", "norm.weight")}
        used = {"config.json", "model.safetensors.index.json"} | {index[name] for name in names.values()}
        checkpoint_files[model] = {name: artifact["files"][name]["sha256"] for name in sorted(used)}
        verify_files(folder, checkpoint_files[model])
        geometry = read(folder / "config.json")["text_config"]
        require(geometry["linear_num_key_heads"] == 16 and geometry["linear_num_value_heads"] == 32, "head geometry mismatch")
        require(geometry["linear_key_head_dim"] == geometry["linear_value_head_dim"] == 128 and geometry["linear_conv_kernel_dim"] == 4, "state/conv geometry mismatch")
        require(geometry["rms_norm_eps"] == 1e-6, "norm epsilon mismatch")
        parameters = {}
        for suffix, name in names.items():
            with safe_open(folder / index[name], framework="pt", device="cpu") as reader:
                parameters[suffix] = reader.get_tensor(name)
        group = {"checkpoint_files": checkpoint_files[model], "ranks": {}, "cross_tp": {},
                 "qk_epsilon": 1e-6, "norm_epsilon": 1e-6, "scale": 128 ** -0.5}
        for tp, rank in ((1, 0), (2, 0), (2, 1)):
            key = f"tp{tp}_rank{rank}"
            prefix = f"{model}_{key}"
            job_name = f"first_layer_diagnostic_{model}_tp{tp}_20261024_r4"
            directory = source / "results/raw/homework2_20261024" / job_name
            case_path = old_tools / f"case_{model}.json"
            case = read(case_path)
            run = read(directory / "diagnostic.json")
            finished = controller["finished"][job_name]
            validate_run(run, finished, case, core=sha(core_path), baseline=sha(old_tools / f"{job_name}.baseline.json"), case_sha=sha(case_path))
            require(run["config"]["tp_size"] == tp and run["config"]["enforce_eager"], "runtime mode mismatch")
            for field in ("model_revision", "model_id", "dtype", "local_model_path", "memory_utilization", "max_model_len"):
                require(run["config"][field] == config[field], f"config field mismatch: {field}")
            record = torch.load(directory / f"rank_{rank}/first_layer_operands.pt", weights_only=True, map_location="cpu")
            anchor = torch.load(directory / f"rank_{rank}/step_00.pt", weights_only=True, map_location="cpu")
            require(record["rank"] == rank and record["tp"] == tp and record["input_length"] == 128, "capture rank/length mismatch")
            require(anchor["rank"] == rank and anchor["step"] == 0 and anchor["input_ids"] == case["input_ids"] and anchor["positions"] == list(range(128)), "first frontier mismatch")
            require(anchor["case_id"] == case["case_id"] and len(case["input_ids"]) == 128, "case identity mismatch")
            certificate = read(directory / f"rank_{rank}/first_layer_weights.json")
            require(certificate["rank"] == rank and certificate["tp"] == tp and len(certificate["weights"]) == 10, "weight certificate scope mismatch")
            weights = {}
            identities = {}
            for suffix, full in parameters.items():
                if suffix == "conv1d.weight":
                    pieces = full.split([2048, 2048, 4096], dim=0)
                    projected = torch.cat([part.chunk(tp, dim=0)[rank] for part in pieces], dim=0).to(torch.bfloat16).contiguous()
                elif suffix in ("A_log", "dt_bias"):
                    projected = full.chunk(tp, dim=0)[rank].float().contiguous()
                else:
                    projected = full.to(torch.bfloat16).contiguous()
                row = next(item for item in certificate["weights"] if item["name"] == f"linear_attn.{suffix}")
                require(row["exact_match"] and row["actual_sha256"] == row["checkpoint_expected_sha256"] == tensor_sha(projected), f"actual parameter mismatch: {suffix}")
                require(row["shape"] == list(projected.shape) and row["dtype"] == str(projected.dtype), "parameter shape/dtype mismatch")
                weights[suffix] = projected.float().numpy().copy()
                identities[suffix] = row
                arrays[f"{prefix}_weight_{suffix}"] = weights[suffix]
            packed = record["modules"]["linear_attn.in_proj_qkvzba"]["outputs"][0].numpy().copy()
            actual = record["modules"]["linear_attn.out_proj"]["inputs"][0].numpy().copy()
            require(packed.dtype == actual.dtype == np.float32, "capture dtype mismatch")
            require(packed.shape == (128, 12352 // tp) and actual.shape == (128, 4096 // tp), "capture shape mismatch")
            require(np.array_equal(packed, bf16_storage(packed)) and np.array_equal(actual, bf16_storage(actual)), "captured BF16 value mismatch")
            arrays[f"{prefix}_packed"] = packed
            arrays[f"{prefix}_actual"] = actual
            result = {"parameter_identity": identities, "card": finished["npu_id"], "chips": finished["chips"],
                      "raw_capture_sha256": sha(directory / f"rank_{rank}/first_layer_operands.pt"), "variants": {}}
            for precision in ("float32", "float64"):
                for policy in ("naive", "stable"):
                    variant = f"{precision}_{policy}"
                    ref = prefill_reference(packed, weights["conv1d.weight"][:, 0, :], weights["A_log"], weights["dt_bias"], weights["norm.weight"],
                        np.zeros((8192 // tp, 3), dtype=np.float32), np.zeros((32 // tp, 128, 128), dtype=np.float32),
                        hk=16 // tp, hv=32 // tp, key_dim=128, value_dim=128,
                        qk_epsilon=1e-6, norm_epsilon=1e-6, scale=128 ** -0.5, compute_dtype=precision, softplus_policy=policy)
                    expected = ref["norm_bf16"].reshape(128, 4096 // tp)
                    result["variants"][variant] = {"metadata": ref["metadata"], "actual_vs_reference": compare(actual, expected),
                        "per_token": [compare(actual[i], expected[i]) for i in range(128)],
                        "x_min": float(ref["x"].min()), "x_max": float(ref["x"].max()),
                        "predicted_softplus_cancellation_indices": ref["cancellation_indices"].tolist(),
                        "max_softplus_naive_stable_difference": float(np.max(np.abs(ref["softplus_naive"] - ref["softplus_stable"])))}
                    for name in ("conv_bf16", "core_bf16", "norm_bf16", "state", "x", "g", "beta"):
                        arrays[f"{prefix}_{variant}_{name}"] = ref[name]
                    print(f"{model} {key} {variant}: {result['variants'][variant]['actual_vs_reference']}", flush=True)
            group["ranks"][key] = result
        group["cross_tp"]["actual"] = compare(np.concatenate([arrays[f"{model}_tp2_rank0_actual"], arrays[f"{model}_tp2_rank1_actual"]], axis=-1), arrays[f"{model}_tp1_rank0_actual"])
        group["cross_tp"]["packed_projection"] = compare(merge_packed(arrays[f"{model}_tp2_rank0_packed"], arrays[f"{model}_tp2_rank1_packed"], widths=[2048, 2048, 4096, 4096, 32, 32]), arrays[f"{model}_tp1_rank0_packed"])
        for precision in ("float32", "float64"):
            for policy in ("naive", "stable"):
                variant = f"{precision}_{policy}"
                group["cross_tp"][variant] = compare(np.concatenate([arrays[f"{model}_tp2_rank0_{variant}_norm_bf16"], arrays[f"{model}_tp2_rank1_{variant}_norm_bf16"]], axis=1), arrays[f"{model}_tp1_rank0_{variant}_norm_bf16"])
        report["models"][model] = group
        verify_files(folder, checkpoint_files[model])
    output = here / "output"
    output.mkdir(exist_ok=False)
    np.savez_compressed(output / "arrays.npz", **arrays)
    verify_files(task, specification["files"])
    verify_files(source, core)
    verify_files(here, read(here / "tool_manifest.json"))
    report.update(inputs_sha256=sha(here / "inputs.json"), tool_manifest_sha256=sha(here / "tool_manifest.json"), raw_input_files=len(specification["files"]),
        core_files_verified=1531, source_and_inputs_unchanged_after=True, arrays_sha256=sha(output / "arrays.npz"),
        arrays={name: {"shape": list(value.shape), "dtype": str(value.dtype)} for name, value in arrays.items()})
    with (output / "analysis.json").open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print("CPU PREFILL CONDITIONAL ANALYSIS COMPLETE", flush=True)


if __name__ == "__main__":
    main()
