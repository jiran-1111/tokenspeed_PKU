#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy
import hashlib

import numpy as np
import pytest

from binding import compare, merge_packed, validate_run, verify_files


def fixture():
    case = {"input_ids": [1, 2], "continuation_ids": [3]}
    finished = {"pid": 10, "exit_code": 0, "own_contexts_released": True}
    run = {"status": "collected", "case": copy.deepcopy(case), "case_sha256": "case", "guard": {
        "parent_pid": 10, "baseline_sha256": "baseline", "sources_sha": "core",
        "sources_after_sha": "core", "sources_unchanged": True,
        "violations": [], "own_children_released": True}}
    return run, finished, case


def test_run_binding():
    run, finished, case = fixture()
    validate_run(run, finished, case, core="core", baseline="baseline", case_sha="case")


@pytest.mark.parametrize("change", ["pid", "exit", "release", "source", "baseline", "case", "violation"])
def test_mismatched_run_rejected(change):
    run, finished, case = copy.deepcopy(fixture())
    if change == "pid":
        finished["pid"] = 11
    elif change == "exit":
        finished["exit_code"] = 1
    elif change == "release":
        finished["own_contexts_released"] = False
    elif change == "source":
        run["guard"]["sources_after_sha"] = "other"
    elif change == "baseline":
        run["guard"]["baseline_sha256"] = "other"
    elif change == "case":
        run["case"]["input_ids"] = [9]
    else:
        run["guard"]["violations"] = ["new foreign process"]
    with pytest.raises(ValueError):
        validate_run(run, finished, case, core="core", baseline="baseline", case_sha="case")


def test_files_tamper(tmp_path):
    (tmp_path / "x").write_bytes(b"original")
    items = {"x": hashlib.sha256(b"original").hexdigest()}
    verify_files(tmp_path, items)
    (tmp_path / "x").write_bytes(b"changed")
    with pytest.raises(ValueError):
        verify_files(tmp_path, items)


def test_packed_segments_not_whole_rank_concat():
    a = np.array([[1, 3, 5]], dtype=np.float32)
    b = np.array([[2, 4, 6]], dtype=np.float32)
    np.testing.assert_array_equal(merge_packed(a, b, widths=[2, 2, 2]), [[1, 2, 3, 4, 5, 6]])


def test_metric_zero_denominator():
    item = compare(np.ones(2), np.zeros(2))
    assert item["relative_l2"] is None and item["zero_reference_norm"]
    assert item["max_abs"] == 1 and item["different_elements"] == 2


def test_metric_rejects_nonfinite_and_shape():
    with pytest.raises(ValueError):
        compare(np.array([np.nan]), np.array([0]))
    with pytest.raises(ValueError):
        compare(np.zeros(2), np.zeros(3))
