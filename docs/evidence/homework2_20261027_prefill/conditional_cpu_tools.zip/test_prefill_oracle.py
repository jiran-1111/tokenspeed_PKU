#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent small examples for the conditional full-prefill NumPy oracle."""

import numpy as np
import pytest

from prefill_oracle import (
    bf16_storage,
    causal_conv_prefill,
    delta_scan,
    gate_terms,
    gated_norm,
    prefill_reference,
    split_packed,
)


def test_packed_segments_are_q_k_v_z_b_a_in_head_order():
    packed = np.arange(24, dtype=np.float32).reshape(2, 12)
    parts = split_packed(
        packed, hk=1, hv=2, key_dim=2, value_dim=1, compute_dtype="float64"
    )
    assert [parts[key].shape for key in ("q", "k", "v", "z", "b", "a")] == [
        (2, 1, 2),
        (2, 1, 2),
        (2, 2, 1),
        (2, 2, 1),
        (2, 2),
        (2, 2),
    ]
    assert [
        parts[key][0].reshape(-1).tolist() for key in ("q", "k", "v", "z", "b", "a")
    ] == [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9], [10, 11]]
    assert all(value.dtype == np.float64 for value in parts.values())


@pytest.mark.parametrize("dtype", ["float32", "float64"])
def test_four_tap_conv_uses_oldest_to_newest_history_and_does_not_mutate(dtype):
    mixed = np.array([[4.0], [5.0]], dtype=np.float64)
    history = np.array([[1.0, 2.0, 3.0]], dtype=np.float64)
    weight = np.array([[1.0, 10.0, 100.0, 1000.0]], dtype=np.float64)
    before = history.copy()
    result = causal_conv_prefill(mixed, weight, history, compute_dtype=dtype)
    np.testing.assert_array_equal(result["preactivation"], [[4321.0], [5432.0]])
    np.testing.assert_array_equal(result["output"], result["preactivation"])
    np.testing.assert_array_equal(result["history"], [[3.0, 4.0, 5.0]])
    np.testing.assert_array_equal(history, before)
    assert result["output"].dtype == np.dtype(dtype)
    assert result["output_bf16"].dtype == np.float32


@pytest.mark.parametrize("dtype", ["float32", "float64"])
def test_delta_update_decays_then_predicts_then_updates_then_reads_new_state(dtype):
    q = np.ones((2, 1, 1))
    k = q.copy()
    v = np.full((2, 1, 1), 3.0)
    state = np.array([[[2.0]]])
    before = state.copy()
    g = np.full((2, 1), -np.log(2.0))
    beta = np.full((2, 1), 0.5)
    result = delta_scan(
        q, k, v, g, beta, state, qk_epsilon=3.0, scale=1.0, compute_dtype=dtype
    )
    np.testing.assert_allclose(
        result["core"].reshape(-1), [0.8125, 0.73046875], rtol=0, atol=0
    )
    np.testing.assert_allclose(result["state"], [[[1.4609375]]], rtol=0, atol=0)
    np.testing.assert_array_equal(state, before)
    assert result["state"].dtype == np.dtype(dtype)


def test_ratio_mapping_repeats_each_key_head_for_contiguous_value_heads():
    q = np.array([[[1.0, 0.0], [0.0, 1.0]]])
    k = q.copy()
    v = np.array([[[2.0], [4.0], [8.0], [16.0]]])
    result = delta_scan(
        q,
        k,
        v,
        np.zeros((1, 4)),
        np.ones((1, 4)),
        np.zeros((4, 1, 2)),
        qk_epsilon=3.0,
        scale=2**-0.5,
        compute_dtype="float64",
    )
    expected = np.array([2.0, 4.0, 8.0, 16.0]) * 0.25 * 2**-0.5
    np.testing.assert_allclose(result["core"].reshape(-1), expected, rtol=0, atol=0)
    np.testing.assert_array_equal(
        result["state"][:, 0, :], [[1.0, 0.0], [2.0, 0.0], [0.0, 4.0], [0.0, 8.0]]
    )


def test_qk_normalization_uses_sum_plus_epsilon_not_mean_or_clamp():
    q = np.array([[[1.0, 1.0]]])
    k = q.copy()
    v = np.ones((1, 1, 1))
    result = delta_scan(
        q,
        k,
        v,
        np.zeros((1, 1)),
        np.ones((1, 1)),
        np.zeros((1, 1, 2)),
        qk_epsilon=2.0,
        scale=2**-0.5,
        compute_dtype="float64",
    )
    np.testing.assert_array_equal(result["normalized_q"], [[[0.5, 0.5]]])
    np.testing.assert_array_equal(result["normalized_k"], [[[0.5, 0.5]]])


@pytest.mark.parametrize("dtype,x", [("float32", -20.0), ("float64", -40.0)])
def test_negative_tail_cancellation_is_explicit_and_threshold_is_twenty(dtype, x):
    a = np.array([[x, 21.0]])
    args = (a, np.zeros((1, 2)), np.zeros(2), np.zeros(2))
    naive = gate_terms(*args, compute_dtype=dtype, softplus_policy="naive")
    stable = gate_terms(*args, compute_dtype=dtype, softplus_policy="stable")
    assert naive["softplus"][0, 0] == 0 and stable["softplus"][0, 0] > 0
    assert naive["softplus"][0, 1] == stable["softplus"][0, 1] == 21
    assert naive["cancellation_indices"].tolist() == [[0, 0]]
    assert stable["cancellation_indices"].tolist() == [[0, 0]]
    assert naive["g"][0, 0] == 0 and stable["g"][0, 0] < 0
    np.testing.assert_array_equal(stable["beta"], [[0.5, 0.5]])


def test_bf16_rne_ties_sign_zero_nan_and_declared_float32_intermediate():
    value = np.array(
        [1.00390625, 1.01171875, -1.00390625, -1.01171875, 0.0, -0.0], dtype=np.float32
    )
    rounded = bf16_storage(value)
    np.testing.assert_array_equal(rounded, [1.0, 1.015625, -1.0, -1.015625, 0.0, -0.0])
    assert np.signbit(rounded[-1])
    near = np.array([1.00390625 + 2**-30], dtype=np.float64)
    assert (
        bf16_storage(near)[0] == 1.0
    )  # Explicit FP64 -> FP32 -> BF16, not ideal double->BF16.
    assert np.isnan(bf16_storage(np.array([np.nan], dtype=np.float32))[0])


def test_gated_norm_is_norm_before_silu_gate_and_preserves_weight():
    core = np.array([[[3.0, 4.0]]])
    z = np.array([[[0.0, np.log(3.0)]]])
    weight = np.array([1.0, 2.0], dtype=np.float32)
    original = weight.copy()
    result = gated_norm(core, z, weight, norm_epsilon=3.5, compute_dtype="float64")
    expected = np.array([[[0.0, 2 * np.log(3.0) * 0.75]]])
    np.testing.assert_allclose(result["output"], expected, rtol=1e-15, atol=0)
    np.testing.assert_array_equal(result["output_bf16"], bf16_storage(expected))
    np.testing.assert_array_equal(weight, original)


def inputs():
    # hk=hv=K=V=1, packed Q,K,V,Z,B,A.
    return dict(
        packed=np.array(
            [[1.0, 1.0, 2.0, 1.0, 0.0, 0.0], [2.0, 1.0, 3.0, -1.0, 0.0, 0.0]],
            dtype=np.float32,
        ),
        conv_weights=np.array([[0.0, 0.0, 0.0, 1.0]] * 3, dtype=np.float32),
        A_log=np.zeros(1, dtype=np.float32),
        dt_bias=np.zeros(1, dtype=np.float32),
        norm_weight=np.ones(1, dtype=np.float32),
        conv_history=np.zeros((3, 3), dtype=np.float32),
        ssm_state=np.zeros((1, 1, 1), dtype=np.float32),
    )


@pytest.mark.parametrize("dtype", ["float32", "float64"])
def test_full_prefill_uses_both_fixed_bf16_boundaries_and_never_claims_actual_initial_state(
    dtype,
):
    data = inputs()
    copies = {key: value.copy() for key, value in data.items()}
    result = prefill_reference(
        **data,
        hk=1,
        hv=1,
        key_dim=1,
        value_dim=1,
        qk_epsilon=1e-6,
        norm_epsilon=1e-6,
        scale=1.0,
        compute_dtype=dtype,
        softplus_policy="stable"
    )
    conv = causal_conv_prefill(
        data["packed"][:, :3],
        data["conv_weights"],
        data["conv_history"],
        compute_dtype=dtype,
    )
    gates = gate_terms(
        data["packed"][:, 5:],
        data["packed"][:, 4:5],
        data["A_log"],
        data["dt_bias"],
        compute_dtype=dtype,
        softplus_policy="stable",
    )
    cast = conv["output_bf16"].astype(dtype)
    scan = delta_scan(
        cast[:, :1].reshape(2, 1, 1),
        cast[:, 1:2].reshape(2, 1, 1),
        cast[:, 2:].reshape(2, 1, 1),
        gates["g"],
        gates["beta"],
        data["ssm_state"],
        qk_epsilon=1e-6,
        scale=1.0,
        compute_dtype=dtype,
    )
    norm = gated_norm(
        bf16_storage(scan["core"]).astype(dtype),
        data["packed"][:, 3:4].reshape(2, 1, 1),
        data["norm_weight"],
        norm_epsilon=1e-6,
        compute_dtype=dtype,
    )
    np.testing.assert_array_equal(result["core"], scan["core"])
    np.testing.assert_array_equal(result["core_bf16"], bf16_storage(scan["core"]))
    np.testing.assert_array_equal(result["norm_bf16"], norm["output_bf16"])
    np.testing.assert_array_equal(result["norm"], norm["output"])
    assert result["metadata"]["actual_initial_state_certified"] is False
    assert result["metadata"]["triton_intermediate_arithmetic_emulated"] is False
    assert result["metadata"]["thresholds_added"] is False
    for key, value in data.items():
        np.testing.assert_array_equal(value, copies[key])


@pytest.mark.parametrize(
    "bad",
    [
        "packed",
        "history",
        "state",
        "ratio",
        "dtype",
        "softplus",
        "qk_epsilon",
        "norm_epsilon",
        "scale",
        "nonfinite",
        "norm_weight",
    ],
)
def test_invalid_explicit_contracts_fail_without_fallback(bad):
    data = inputs()
    parameters = dict(
        hk=1,
        hv=1,
        key_dim=1,
        value_dim=1,
        qk_epsilon=1e-6,
        norm_epsilon=1e-6,
        scale=1.0,
        compute_dtype="float32",
        softplus_policy="stable",
    )
    if bad == "packed":
        data["packed"] = data["packed"][:, :5]
    elif bad == "history":
        data["conv_history"] = np.zeros((3, 4))
    elif bad == "state":
        data["ssm_state"] = np.zeros((1, 2, 1))
    elif bad == "ratio":
        parameters["hk"] = 2
    elif bad == "dtype":
        parameters["compute_dtype"] = "float16"
    elif bad == "softplus":
        parameters["softplus_policy"] = "auto"
    elif bad == "qk_epsilon":
        parameters["qk_epsilon"] = 0
    elif bad == "norm_epsilon":
        parameters["norm_epsilon"] = -1
    elif bad == "scale":
        parameters["scale"] = 0
    elif bad == "nonfinite":
        data["packed"][0, 0] = np.nan
    else:
        data["norm_weight"][0] = 1.0039
    with pytest.raises(ValueError):
        prefill_reference(**data, **parameters)


@pytest.mark.parametrize("dtype", ["float32", "float64"])
def test_complete_single_token_hand_calculation_with_nonzero_conditional_state(dtype):
    # SiLU(80) rounds to80 in either calculation dtype. q=k=80 and eps=19200
    # give normalized q=k=.5. State2 decays to1; pred=.5; delta=39.75;
    # new state20.875; core10.4375. eps147.05859375 makes norm denominator16.
    result = prefill_reference(
        np.array([[80.0, 80.0, 80.0, 80.0, 0.0, 0.0]]),
        np.array([[0.0, 0.0, 0.0, 1.0]] * 3),
        np.zeros(1),
        np.zeros(1),
        np.array([2.0]),
        np.zeros((3, 3)),
        np.array([[[2.0]]]),
        hk=1,
        hv=1,
        key_dim=1,
        value_dim=1,
        qk_epsilon=19200.0,
        norm_epsilon=147.05859375,
        scale=1.0,
        compute_dtype=dtype,
        softplus_policy="stable",
    )
    np.testing.assert_array_equal(result["conv_bf16"], [[80.0, 80.0, 80.0]])
    np.testing.assert_array_equal(result["state"], [[[20.875]]])
    np.testing.assert_array_equal(result["core"], [[[10.4375]]])
    np.testing.assert_array_equal(result["core_bf16"], [[[10.4375]]])
    np.testing.assert_array_equal(result["norm"], [[[104.375]]])
    np.testing.assert_array_equal(result["norm_bf16"], [[[104.5]]])
    assert result["metadata"]["ssm_state_is_zero"] is False
    assert result["metadata"]["actual_initial_state_certified"] is False


@pytest.mark.parametrize("dtype", ["float32", "float64"])
def test_explicit_condition_state_continuation_matches_whole_sequence(dtype):
    data = inputs()
    arguments = dict(
        hk=1,
        hv=1,
        key_dim=1,
        value_dim=1,
        qk_epsilon=1e-6,
        norm_epsilon=1e-6,
        scale=1.0,
        compute_dtype=dtype,
        softplus_policy="naive",
    )
    whole = prefill_reference(**data, **arguments)
    prefix = prefill_reference(**{**data, "packed": data["packed"][:1]}, **arguments)
    suffix = prefill_reference(
        **{
            **data,
            "packed": data["packed"][1:],
            "conv_history": prefix["conv_history_after"],
            "ssm_state": prefix["state"],
        },
        **arguments
    )
    for key in ("conv_bf16", "core", "core_bf16", "norm", "norm_bf16"):
        np.testing.assert_array_equal(
            whole[key], np.concatenate((prefix[key], suffix[key]), axis=0)
        )
    np.testing.assert_array_equal(whole["state"], suffix["state"])
    assert np.any(whole["state"] != bf16_storage(whole["state"]))


def test_norm_weight_is_validated_before_compute_dtype_cast():
    # This FP64 value becomes exactly1 if cast to FP32 first. It is not itself
    # a BF16 value, so accepting it would silently project a caller's weight.
    weight = np.array([np.nextafter(np.float64(1), np.float64(2))])
    with pytest.raises(ValueError, match="norm_weight"):
        gated_norm(
            np.ones((1, 1, 1)),
            np.ones((1, 1, 1)),
            weight,
            norm_epsilon=1e-6,
            compute_dtype="float32",
        )
