#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Pure CPU identity checks and descriptive metrics; no model pass threshold."""

import hashlib

import numpy as np


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def verify_files(root, items):
    for name, expected in items.items():
        path = root / name
        require(path.is_file() and sha(path) == expected, f"file identity mismatch: {name}")


def validate_run(run, finished, case, *, core, baseline, case_sha):
    guard = run["guard"]
    require(run["status"] == "collected", "run not collected")
    require(finished["exit_code"] == 0 and finished["own_contexts_released"], "outer exit/release failed")
    require(guard["parent_pid"] == finished["pid"], "collector PID mismatch")
    require(guard["own_children_released"] and not guard["violations"], "worker release/guard failed")
    require(guard["sources_sha"] == guard["sources_after_sha"] == core and guard["sources_unchanged"], "source identity mismatch")
    require(guard["baseline_sha256"] == baseline, "baseline identity mismatch")
    require(run["case"] == case and run["case_sha256"] == case_sha, "case mismatch")


def compare(actual, reference):
    require(actual.shape == reference.shape, "metric shape mismatch")
    a = np.asarray(actual, dtype=np.float64)
    r = np.asarray(reference, dtype=np.float64)
    require(np.isfinite(a).all() and np.isfinite(r).all(), "nonfinite metric input")
    denominator = float(np.linalg.norm(r.ravel()))
    delta = a - r
    return {"shape": list(a.shape), "relative_l2": float(np.linalg.norm(delta.ravel()) / denominator) if denominator else None,
            "zero_reference_norm": denominator == 0, "max_abs": float(np.max(np.abs(delta))),
            "different_elements": int(np.count_nonzero(actual != reference)), "elements": int(a.size)}


def merge_packed(left, right, *, widths):
    require(all(width % 2 == 0 for width in widths), "odd packed segment")
    require(left.shape == right.shape and left.shape[-1] == sum(widths) // 2, "packed shape mismatch")
    offsets = np.cumsum([width // 2 for width in widths])[:-1]
    a, b = np.split(left, offsets, axis=-1), np.split(right, offsets, axis=-1)
    return np.concatenate([np.concatenate([x, y], axis=-1) for x, y in zip(a, b)], axis=-1)
