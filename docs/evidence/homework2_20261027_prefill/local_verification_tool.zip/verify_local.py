#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independently recompute saved metrics and BF16 identities with local NumPy."""

import hashlib
import json
from pathlib import Path

import numpy as np

here = Path(__file__).resolve().parent
workspace = here.parents[1]
bundle = workspace / ".tmp/hw2-20261023/supplement_export_prefill_conditional_20261027"
raw = workspace / ".tmp/hw2-20261023/supplement_export_first_layer_r4_20261024"
repo = workspace / "delivery/homework2-20261023"
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
manifest = read(bundle / "export_manifest.json")
assert all(digest(bundle / name) == expected for name, expected in manifest.items())
one = bundle / "prefill_conditional_cpu_r1_20261027"
two = bundle / "prefill_row_cpu_r1_20261027"
a = read(one / "output/analysis.json")
b = read(two / "output/row_analysis.json")
assert a["source_manifest_sha256"] == b["source_manifest_sha256"] == digest(repo / "docs/evidence/homework2_20261023/source_manifest.json")
assert all(digest(repo / name) == expected for name, expected in read(repo / "docs/evidence/homework2_20261023/source_manifest.json").items())
assert b["prior_analysis_sha256"] == digest(one / "output/analysis.json")
assert b["prior_tool_manifest_sha256"] == digest(one / "tool_manifest.json")
for directory, result, filename in ((one, a, "arrays.npz"), (two, b, "row_arrays.npz")):
    assert all(digest(directory / name) == expected for name, expected in read(directory / "tool_manifest.json").items())
    assert digest(directory / "output" / filename) == result["arrays_sha256"]
    assert result["source_and_inputs_unchanged_after"] and not result["runtime_math_changed"] and not result["thresholds_added"]
inputs = read(one / "inputs.json")
for name, expected in inputs["files"].items():
    if name.startswith("source_final/results/raw/homework2_20261024/"):
        local = raw / "jobs" / name.removeprefix("source_final/results/raw/homework2_20261024/")
    else:
        local = raw / "tools" / name.removeprefix("first_layer_diagnostic_r4/")
    assert digest(local) == expected
arrays = np.load(one / "output/arrays.npz", allow_pickle=False)
rows = np.load(two / "output/row_arrays.npz", allow_pickle=False)
count = 0
max_difference = 0.0


def verify(actual, reference, item):
    global count, max_difference
    x, y = actual.astype(np.float64), reference.astype(np.float64)
    d = (x - y).ravel()
    denominator = float(np.sqrt(np.sum(y * y, dtype=np.float64)))
    metrics = {"relative_l2": float(np.sqrt(np.sum(d * d, dtype=np.float64)) / denominator) if denominator else None,
               "max_abs": float(np.max(np.abs(d)))}
    assert list(x.shape) == item["shape"] and x.size == item["elements"]
    assert int(np.count_nonzero(actual != reference)) == item["different_elements"]
    assert (denominator == 0) == item["zero_reference_norm"]
    for field, value in metrics.items():
        if value is None:
            assert item[field] is None
        else:
            difference = abs(value - item[field])
            max_difference = max(max_difference, difference)
            assert difference <= 2e-13 * max(1.0, abs(value)), (field, value, item[field])
    count += 1


def bf16(value):
    bits = np.asarray(value, dtype=np.float32).view(np.uint32)
    return ((bits + np.uint32(32767) + ((bits >> 16) & 1)) & np.uint32(0xffff0000)).view(np.float32)


for model in ("4b", "9b"):
    group = a["models"][model]
    for rank, item in group["ranks"].items():
        prefix = f"{model}_{rank}"
        observed = arrays[f"{prefix}_actual"]
        for variant, result in item["variants"].items():
            expected = arrays[f"{prefix}_{variant}_norm_bf16"].reshape(observed.shape)
            verify(observed, expected, result["actual_vs_reference"])
            for index, metric in enumerate(result["per_token"]):
                verify(observed[index], expected[index], metric)
        for suffix, certificate in item["parameter_identity"].items():
            values = arrays[f"{prefix}_weight_{suffix}"]
            if certificate["dtype"] == "torch.bfloat16":
                assert np.array_equal(values, bf16(values))
                data = (values.astype("<f4", copy=False).view("<u4") >> 16).astype("<u2").tobytes()
            else:
                assert certificate["dtype"] == "torch.float32"
                data = values.astype("<f4", copy=False).tobytes()
            assert hashlib.sha256(data).hexdigest() == certificate["actual_sha256"] == certificate["checkpoint_expected_sha256"]
    x = np.concatenate([arrays[f"{model}_tp2_rank0_actual"], arrays[f"{model}_tp2_rank1_actual"]], axis=-1)
    verify(x, arrays[f"{model}_tp1_rank0_actual"], group["cross_tp"]["actual"])
    for variant in ("float32_naive", "float32_stable", "float64_naive", "float64_stable"):
        x = np.concatenate([arrays[f"{model}_tp2_rank0_{variant}_norm_bf16"], arrays[f"{model}_tp2_rank1_{variant}_norm_bf16"]], axis=1)
        verify(x, arrays[f"{model}_tp1_rank0_{variant}_norm_bf16"], group["cross_tp"][variant])
    r = b["models"][model]
    get = lambda name: rows[f"{model}_{name}"]
    for rank, item in r["own_partial_projection"].items():
        verify(get(f"{rank}_partial"), get(f"{rank}_fp64_raw"), item["actual_vs_fp64_raw"])
        verify(get(f"{rank}_partial"), get(f"{rank}_fp64_bf16"), item["actual_vs_final_bf16_candidate"])
    verify(get("tp2_rank0_reduced"), bf16(get("tp2_rank0_partial") + get("tp2_rank1_partial")), r["observed_hccl_vs_bf16_sum_of_observed_partials"])
    pairs = {
        "same_input_unrounded_partition_vs_full_fp64": ("common_raw_sum", "tp1_rank0_fp64_raw"),
        "same_input_bf16_partition_vs_full": ("common_split", "common_full"),
        "actual_native_tp2_vs_tp1": ("tp2_rank0_reduced", "tp1_rank0_reduced"),
        "different_actual_inputs_bf16_partition_vs_tp1_full": ("own_input_split", "common_full"),
        "actual_tp2_vs_own_partition_reference": ("tp2_rank0_reduced", "own_input_split"),
        "actual_tp1_vs_own_full_reference": ("tp1_rank0_reduced", "common_full"),
        "actual_tp2_vs_common_input_partition_reference": ("tp2_rank0_reduced", "common_split"),
        "own_inputs_partition_vs_common_inputs_partition": ("own_input_split", "common_split"),
        "own_tp2_input_partition_vs_full": ("own_input_split", "own_input_full"),
    }
    for name, (left, right) in pairs.items():
        verify(get(left), get(right), r["comparisons"][name])
assert count == 3138, count
result = {"passed": True, "metric_groups_independently_recomputed": count, "max_metric_difference": max_difference,
          "raw_input_files_rehashed": len(inputs["files"]), "core_files_rehashed": 1531,
          "small_parameter_value_digests_recomputed": 24, "archive_files_verified": len(manifest),
          "cpu_reference_algorithm_independently_reimplemented": False, "checkpoint_bytes_reloaded_locally": False,
          "raw_pt_reextracted_locally": False, "scope": "Independent NumPy recomputation of saved metrics, BF16 sum and 24 small parameter byte digests; actual checkpoint/PT binding and mathematical reference execution performed by frozen server CPU tools.",
          "analysis_sha256": digest(one / "output/analysis.json"), "row_analysis_sha256": digest(two / "output/row_analysis.json"),
          "script_sha256": digest(Path(__file__)), "model_acceptance_threshold_added": False}
with (here / "local_verification.json").open("x", encoding="utf-8") as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result))
