#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Conditional first-layer row-projection decomposition using unchanged operands."""

import json
import os
import sys
from pathlib import Path

import numpy as np

from binding import compare, require, sha, verify_files
from prefill_oracle import bf16_storage


def main():
    require(os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0" and os.environ["ASCEND_RT_VISIBLE_DEVICES"] == "", "CPU-only environment required")
    sys.modules["torch_npu"] = None
    import torch
    from safetensors import safe_open

    torch.set_num_threads(8)
    here = Path(__file__).resolve().parent
    task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
    source = task / "source_final"
    prior = task / "prefill_conditional_cpu_r1_20261027"
    read = lambda path: json.loads(path.read_text())
    verify_files(here, read(here / "tool_manifest.json"))
    original = read(prior / "output/analysis.json")
    require(original["source_and_inputs_unchanged_after"] and original["actual_initial_state_observed"] is False, "prior scope mismatch")
    verify_files(prior, read(prior / "tool_manifest.json"))
    verify_files(task, read(prior / "inputs.json")["files"])
    core_path = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(sha(core_path) == original["source_manifest_sha256"], "source manifest mismatch")
    verify_files(source, read(core_path))
    require(sha(prior / "output/arrays.npz") == original["arrays_sha256"], "prior array mismatch")
    values = np.load(prior / "output/arrays.npz", allow_pickle=False)
    artifacts = read(source / "docs/evidence/homework2_20261023/model_artifacts.json")
    require(sha(source / "docs/evidence/homework2_20261023/model_artifacts.json") == read(prior / "inputs.json")["artifacts_sha256"], "artifact binding failed")
    report = {"scope": "First-layer actual operands plus explicit counterfactual row storage; not full-model causation or new runtime",
              "prior_analysis_sha256": sha(prior / "output/analysis.json"), "prior_tool_manifest_sha256": sha(prior / "tool_manifest.json"),
              "source_manifest_sha256": sha(core_path), "models": {}, "thresholds_added": False,
              "runtime_math_changed": False, "original_failures_preserved": True, "full_model_correctness_certified": False}
    output_arrays = {}
    for model in ("4b", "9b"):
        config = read(source / f"configs/homework2/qwen35_{model}_tp1.yaml")
        checkpoint = source / config["local_model_path"]
        artifact = next(item for item in artifacts["models"] if item["model_id"] == config["model_id"] and item["model_revision"] == config["model_revision"])
        index_path = checkpoint / "model.safetensors.index.json"
        key = "model.language_model.layers.0.linear_attn.out_proj.weight"
        index = read(index_path)["weight_map"]
        used_files = {name: artifact["files"][name]["sha256"] for name in ("model.safetensors.index.json", index[key])}
        verify_files(checkpoint, used_files)
        with safe_open(checkpoint / index[key], framework="pt", device="cpu") as reader:
            weight = reader.get_tensor(key).to(torch.bfloat16).contiguous()
        group = {"checkpoint_files": used_files, "own_partial_projection": {}}
        actual = {}
        for tp, rank in ((1, 0), (2, 0), (2, 1)):
            name = f"tp{tp}_rank{rank}"
            folder = source / "results/raw/homework2_20261024" / f"first_layer_diagnostic_{model}_tp{tp}_20261024_r4" / f"rank_{rank}"
            capture = torch.load(folder / "first_layer_operands.pt", map_location="cpu", weights_only=True)
            identity = next(item for item in read(folder / "first_layer_weights.json")["weights"] if item["name"] == "linear_attn.out_proj.weight")
            local_weight = weight.chunk(tp, dim=1)[rank].contiguous()
            import hashlib
            digest = hashlib.sha256(local_weight.view(torch.uint8).numpy().tobytes()).hexdigest()
            require(identity["exact_match"] and identity["actual_sha256"] == identity["checkpoint_expected_sha256"] == digest and identity["shape"] == list(local_weight.shape) and identity["dtype"] == str(local_weight.dtype), "actual row weight mismatch")
            sample = capture["modules"]["linear_attn.out_proj"]
            x = sample["inputs"][0]
            require(np.array_equal(x.numpy(), values[f"{model}_{name}_actual"]), "prior operand link mismatch")
            partial = sample["outputs"][0].numpy().copy()
            reduced = capture["modules"]["post_attention_layernorm"]["inputs"][0].numpy().copy()
            expected = (x.double() @ local_weight.double().T).numpy()
            actual[name] = {"x": x.double(), "partial": partial, "reduced": reduced, "expected_raw": expected,
                            "expected_stored": bf16_storage(expected)}
            group["own_partial_projection"][name] = {"actual_vs_fp64_raw": compare(partial, expected),
                "actual_vs_final_bf16_candidate": compare(partial, bf16_storage(expected)), "weight_certificate": identity}
            output_arrays[f"{model}_{name}_partial"] = partial
            output_arrays[f"{model}_{name}_fp64_raw"] = expected
            output_arrays[f"{model}_{name}_fp64_bf16"] = bf16_storage(expected)
            output_arrays[f"{model}_{name}_reduced"] = reduced
        one, left, right = (actual[name] for name in ("tp1_rank0", "tp2_rank0", "tp2_rank1"))
        require(np.array_equal(left["reduced"], right["reduced"]), "rank reduced outputs differ")
        observed_sum_candidate = bf16_storage(left["partial"] + right["partial"])
        group["observed_hccl_vs_bf16_sum_of_observed_partials"] = compare(left["reduced"], observed_sum_candidate)
        common = one["x"]
        halves = common.chunk(2, dim=1)
        shards = weight.chunk(2, dim=1)
        raw_parts = [(x @ w.double().T).numpy() for x, w in zip(halves, shards)]
        common_raw_sum = raw_parts[0] + raw_parts[1]
        common_full = one["expected_stored"]
        common_split = bf16_storage(bf16_storage(raw_parts[0]) + bf16_storage(raw_parts[1]))
        own_split = bf16_storage(left["expected_stored"] + right["expected_stored"])
        own_input_full = bf16_storage((torch.cat([left["x"], right["x"]], dim=1) @ weight.double().T).numpy())
        output_arrays.update({f"{model}_common_full": common_full, f"{model}_common_split": common_split,
            f"{model}_common_raw_sum": common_raw_sum, f"{model}_own_input_split": own_split,
            f"{model}_own_input_full": own_input_full, f"{model}_observed_sum_candidate": observed_sum_candidate})
        group["comparisons"] = {
            "same_input_unrounded_partition_vs_full_fp64": compare(common_raw_sum, one["expected_raw"]),
            "same_input_bf16_partition_vs_full": compare(common_split, common_full),
            "actual_native_tp2_vs_tp1": compare(left["reduced"], one["reduced"]),
            "different_actual_inputs_bf16_partition_vs_tp1_full": compare(own_split, common_full),
            "actual_tp2_vs_own_partition_reference": compare(left["reduced"], own_split),
            "actual_tp1_vs_own_full_reference": compare(one["reduced"], common_full),
            "actual_tp2_vs_common_input_partition_reference": compare(left["reduced"], common_split),
            "own_inputs_partition_vs_common_inputs_partition": compare(own_split, common_split),
            "own_tp2_input_partition_vs_full": compare(own_split, own_input_full)}
        group["interpretation"] = "Same-input partition is a mathematical counterfactual isolating the declared storage operations, not a claim about actual TP2 having TP1 inputs or additive causal shares. Kernel multiplication/reduction-order differences remain in actual-versus-candidate residuals."
        report["models"][model] = group
        verify_files(checkpoint, used_files)
        print(json.dumps({model: group["comparisons"]}), flush=True)
    out = here / "output"
    out.mkdir(exist_ok=False)
    np.savez_compressed(out / "row_arrays.npz", **output_arrays)
    verify_files(task, read(prior / "inputs.json")["files"])
    verify_files(source, read(core_path))
    verify_files(here, read(here / "tool_manifest.json"))
    report.update(source_and_inputs_unchanged_after=True, arrays_sha256=sha(out / "row_arrays.npz"), tool_manifest_sha256=sha(here / "tool_manifest.json"))
    with (out / "row_analysis.json").open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print("ROW CONDITIONAL CPU ANALYSIS COMPLETE", flush=True)


if __name__ == "__main__":
    main()
