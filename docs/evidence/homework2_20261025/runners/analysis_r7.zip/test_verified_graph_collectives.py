# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import os
import re
import unittest
from pathlib import Path

PATTERN = r'(?i)(?:"opName"\s*:\s*"Hccl(?:Allreduce|Allgather|Broadcast)"|^(?:allreduceAicpuKernel|allgatherAicpuKernel|broadcastAicpuKernel)$)'

class VerifiedGraphCollectiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"]) / "benchmarks/course_project/tp_timeline.py"
        spec = importlib.util.spec_from_file_location("graph_collective_core", path)
        cls.core = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.core)

    def classify(self, name, process="Ascend Hardware", thread="Stream 1", category=""):
        return self.core._classify({"name": name, "cat": category, "args": {"Task Type": "AI_CPU"}}, process_name=process, thread_name=thread, collective_patterns=[re.compile(PATTERN)])[0]

    def test_verified_graph_names_are_collectives_without_broad_ai_cpu_match(self):
        for name in ("allreduceAicpuKernel", "allgatherAicpuKernel", "broadcastAicpuKernel", '{"opName":"HcclAllreduce"}'):
            self.assertEqual(self.classify(name), "device_collective")
        for name in ("Cumsum", "FloorDiv", "ViewCopy", "Cumprod"):
            self.assertEqual(self.classify(name), "device_compute")
        self.assertEqual(self.classify("prefix_allreduceAicpuKernel"), "unknown")

    def test_host_enqueue_and_unverified_lanes_never_become_device_collectives(self):
        self.assertEqual(self.classify("allreduceAicpuKernel", process="CANN", category="enqueue"), "host_other")
        self.assertEqual(self.classify("allreduceAicpuKernel", thread="unverified"), "unknown")
        self.assertEqual(self.classify("allreduceAicpuKernel", category="cpu_op"), "unknown")
