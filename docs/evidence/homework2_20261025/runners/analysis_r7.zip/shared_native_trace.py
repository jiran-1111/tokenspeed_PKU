# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Build a separate measurement canonical from untouched CPU/native artifacts."""

from __future__ import annotations

import hashlib
import json
import re
from decimal import Decimal

_JSON_SPACE = " \t\r\n"
_STRUCTURAL = re.compile(r'"(?:[^"\\]|\\.)*"|[\[\]{}]')


def _reject_constant(value: str) -> None:
    raise ValueError(f"non-JSON numeric constant: {value}")


def _unique_object(pairs: list[tuple]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def _decoder() -> json.JSONDecoder:
    return json.JSONDecoder(
        parse_float=Decimal,
        parse_constant=_reject_constant,
        object_pairs_hook=_unique_object,
    )


def _space_end(text: str, position: int) -> int:
    while position < len(text) and text[position] in _JSON_SPACE:
        position += 1
    return position


def _event_array_content(text: str, document: list | dict) -> str:
    """Extract validated event text so epoch decimals never round through float."""
    position = _space_end(text, 0)
    if isinstance(document, list):
        return text[position + 1 : len(text.rstrip(_JSON_SPACE)) - 1]
    decoder = _decoder()
    position = _space_end(text, position + 1)
    while True:
        key, position = decoder.raw_decode(text, position)
        position = _space_end(text, position)
        position = _space_end(text, position + 1)  # Validated object key colon.
        if key == "traceEvents":
            start, depth = position, 0
            for match in _STRUCTURAL.finditer(text, start):
                token = text[match.start()]
                if token == '"':
                    continue
                depth += 1 if token in "[{" else -1
                if depth == 0:
                    return text[start + 1 : match.start()]
            raise ValueError("validated traceEvents array has no closing bracket")
        _, position = decoder.raw_decode(text, position)
        position = _space_end(text, position)
        position = _space_end(text, position + 1)  # Next key after validated comma.


def _read(
    raw: bytes, *, label: str, allow_prepared_array: bool
) -> tuple[list[dict], str, bool]:
    if not isinstance(raw, bytes):
        raise TypeError(f"{label} must be bytes")
    text = raw.decode("utf-8-sig")
    decoder = _decoder()
    was_open = False
    try:
        document = decoder.decode(text)
    except json.JSONDecodeError as error:
        if (
            not allow_prepared_array
            or not raw.startswith(b"[")
            or error.pos != len(text)
        ):
            raise ValueError(f"{label} is not complete strict JSON") from error
        try:
            document = decoder.decode(text + "]")
        except (json.JSONDecodeError, ValueError) as completion_error:
            raise ValueError(
                f"{label} is not an intentional open prepare array"
            ) from completion_error
        text += "]"
        was_open = True
    events = document.get("traceEvents") if isinstance(document, dict) else document
    if not isinstance(events, list) or any(
        not isinstance(event, dict) for event in events
    ):
        raise ValueError(
            f"{label} requires an event list or an object containing a traceEvents list"
        )
    return events, _event_array_content(text, document), was_open


def _valid_identifier(value: object) -> bool:
    return type(value) is int or isinstance(value, str) and bool(value)


def _metadata(events: list[dict], *, seen: dict) -> tuple[dict, dict]:
    processes, threads = {}, {}
    for event in events:
        kind = event.get("name")
        if event.get("ph") != "M" or kind not in ("process_name", "thread_name"):
            continue
        pid, tid = event.get("pid"), event.get("tid")
        args = event.get("args")
        if (
            not _valid_identifier(pid)
            or kind == "thread_name"
            and not _valid_identifier(tid)
        ):
            raise ValueError("process/thread metadata requires valid identifiers")
        if (
            not isinstance(args, dict)
            or not isinstance(args.get("name"), str)
            or not args["name"]
        ):
            raise ValueError("process/thread metadata requires a nonempty name")
        key = (kind, pid) if kind == "process_name" else (kind, pid, tid)
        if key in seen and seen[key] != args["name"]:
            raise ValueError(f"conflicting process/thread metadata for {key}")
        seen[key] = args["name"]
        if kind == "process_name":
            processes[pid] = args["name"]
        else:
            threads[(pid, tid)] = args["name"]
    return processes, threads


def assemble(cpu_prepare: bytes, native_trace: bytes) -> tuple[bytes, dict]:
    """Concatenate all CPU then native events into a new auditable canonical.

    Both artifacts must be strict JSON event arrays or objects with traceEvents.
    Only CPU JSON failing precisely at EOF may gain one array-closing bracket,
    and only when that alone makes an array starting at byte zero valid. Native
    JSON must be directly complete and independently contain Ascend Hardware,
    a corresponding Stream complete event, and a HW2_SYNC complete marker.

    Original bytes remain untouched; no event is deleted, synthesized, reordered
    within its input, or deduplicated. Event text is copied rather than converted
    through floating point. Conflicting process/thread name metadata is rejected.
    Device task classification and rank clock verification belong to analysis.
    """
    cpu, cpu_content, was_open = _read(
        cpu_prepare, label="CPU prepare", allow_prepared_array=True
    )
    native, native_content, _ = _read(
        native_trace, label="native trace", allow_prepared_array=False
    )
    seen: dict = {}
    _metadata(cpu, seen=seen)
    processes, threads = _metadata(native, seen=seen)
    hardware = {pid for pid, name in processes.items() if name == "Ascend Hardware"}
    stream_events, sync_markers = 0, 0
    for event in native:
        if event.get("ph") != "X":
            continue
        pid, tid, name = event.get("pid"), event.get("tid"), event.get("name")
        if (
            _valid_identifier(pid)
            and _valid_identifier(tid)
            and pid in hardware
            and re.fullmatch(r"Stream \d+", threads.get((pid, tid), ""))
        ):
            stream_events += 1
        if isinstance(name, str) and (
            name == "HW2_SYNC" or name.startswith("HW2_SYNC|")
        ):
            sync_markers += 1
    if not hardware or not stream_events or not sync_markers:
        raise ValueError(
            "native trace requires Ascend Hardware, a corresponding Stream X event, and HW2_SYNC X marker"
        )
    contents = [
        content.encode("utf-8")
        for events, content in ((cpu, cpu_content), (native, native_content))
        if events
    ]
    canonical = b'{"traceEvents":[' + b",".join(contents) + b"]}\n"
    provenance = {
        "scope": "measurement canonical assembled from CPU prepare and complete official native trace; raw inputs are not rewritten",
        "raw_inputs_rewritten": False,
        "prepared_array_was_open": was_open,
        "cpu_prepare_sha256": hashlib.sha256(cpu_prepare).hexdigest(),
        "native_trace_sha256": hashlib.sha256(native_trace).hexdigest(),
        "canonical_sha256": hashlib.sha256(canonical).hexdigest(),
        "cpu_event_count": len(cpu),
        "native_event_count": len(native),
        "canonical_event_count": len(cpu) + len(native),
        "native_hardware_process_count": len(hardware),
        "native_stream_x_event_count": stream_events,
        "native_sync_x_marker_count": sync_markers,
        "event_order": "all CPU events followed by all native events; no pruning or deduplication",
        "task_classification_verified": False,
        "rank_clock_verified": False,
    }
    return canonical, provenance
