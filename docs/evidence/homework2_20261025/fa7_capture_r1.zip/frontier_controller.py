#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Serialize FA7 observation; retain the original exclusive queue paused."""

import fcntl
import hashlib
import importlib.util
import json
import os
import shlex
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

from shared_helpers import check_memory

from benchmarks.course_project.native_performance import parse_target_hbm
from benchmarks.course_project.tp_devices import (
    check_sources,
    parse_mapping,
    target_process_pids,
)

BASE = Path.home() / "tokenspeed"
TASK = BASE / ".tmp/hw2-20261023"
SOURCE = TASK / "source_final"
TOOLS = TASK / "fa7_diagnostic_r1_20261025"


def query(args):
    with (BASE / ".tmp/hw2-query.lock").open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        return subprocess.check_output(
            ["npu-smi", "info", *args], text=True, timeout=20
        )


def identity(pid):
    path = Path(f"/proc/{pid}")
    return [
        path.stat().st_uid,
        (path / "stat").read_text().rpartition(")")[2].split()[19],
    ]


def alive(pid):
    path = Path(f"/proc/{pid}/stat")
    return path.exists() and path.read_text().rpartition(")")[2].split()[0] != "Z"


def save(state):
    state["updated_utc"] = datetime.now(timezone.utc).isoformat()
    tmp = TOOLS / "state.tmp"
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(TOOLS / "state.json")


def main():
    with (TASK / "preflight_control.lock").open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        gate = json.loads((TASK / "ready_gate.json").read_text())
        manifest = SOURCE / "docs/evidence/homework2_20261023/source_manifest.json"
        assert check_sources(SOURCE, manifest) == gate["source_manifest_sha256"]
        original = TASK / "queue_driver_final.py"
        assert (
            hashlib.sha256(original.read_bytes()).hexdigest() == gate["driver_sha256"]
        )
        tools_manifest = json.loads((TOOLS / "tool_manifest.json").read_text())
        assert all(
            hashlib.sha256((TOOLS / name).read_bytes()).hexdigest() == sha
            for name, sha in tools_manifest.items()
        )
        assert json.loads((TOOLS / "preparation.json").read_text())["passed"]
        old = json.loads((TASK / "queue_state.json").read_text())
        assert (
            old["status"] == "stopped_by_workspace_marker"
            and not old.get("current")
            and not old["finished"]
        )
        old_pid = int((TASK / "queue_driver_final.pid").read_text())
        assert not alive(old_pid)
        marker = TASK / "stop-queue"
        marker_text = marker.read_text()
        assert (
            marker_text
            == "User-authorized shared performance and Profiler cohort 20261025; protect background services.\n"
        )
        state = {
            "status": "starting",
            "finished": {},
            "performance_eligible": False,
            "source_manifest_sha256": gate["source_manifest_sha256"],
            "probe_scope": "FA7 complete128-row Prefill; cached step8 KV not captured",
        }
        save(state)
        spec = importlib.util.spec_from_file_location(
            "original_queue_helpers", original
        )
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        try:
            for model, minimum in (("4b", 24576), ("9b", 32768)):
                for tp in (1, 2):
                    mapping = parse_mapping(query(["-m"]))
                    table = query([])
                    candidates = []
                    for card in sorted({card for card, chip in mapping}):
                        all_chips = {chip: mapping[card, chip] for chip in (0, 1)}
                        memory = parse_target_hbm(
                            table, npu_id=card, chip_logic_ids=all_chips
                        )
                        all_pids = target_process_pids(
                            table, npu_id=card, chip_ids={0, 1}
                        )
                        options = (
                            [all_chips]
                            if tp == 2
                            else [
                                {chip: all_chips[chip]}
                                for chip in (0, 1)
                                if not all_pids[chip]
                            ]
                        )
                        for chips in options:
                            try:
                                check_memory(
                                    {chip: memory[chip] for chip in chips},
                                    minimum_free_mb=minimum,
                                )
                            except ValueError:
                                continue
                            pids = {chip: all_pids[chip] for chip in chips}
                            candidates.append(
                                (
                                    sum(len(values) for values in pids.values()),
                                    -min(
                                        memory[chip]["capacity_mb"]
                                        - memory[chip]["used_mb"]
                                        for chip in chips
                                    ),
                                    card,
                                    chips,
                                    pids,
                                )
                            )
                    if not candidates:
                        raise RuntimeError("no safe target for numerical diagnosis")
                    _, _, card, chips, pids = min(
                        candidates,
                        key=lambda item: (
                            item[0],
                            item[1],
                            item[2],
                            tuple(sorted(item[3])),
                        ),
                    )
                    for values in pids.values():
                        assert all(
                            identity(pid)[0] != os.getuid() for pid in values
                        ), "own experiment already on device"
                    job = f"fa7_diagnostic_{model}_tp{tp}_20261025_r1"
                    output = SOURCE / "results/raw/homework2_20261024" / job
                    baseline = {
                        chip: {pid: identity(pid) for pid in values}
                        for chip, values in pids.items()
                    }
                    baseline_path = TOOLS / f"{job}.baseline.json"
                    baseline_path.write_text(json.dumps(baseline, indent=2))
                    config_name = f"configs/homework2/qwen35_{model}_tp{tp}.yaml"
                    config = json.loads((SOURCE / config_name).read_text())
                    weights = json.loads((TASK / "weights_state.json").read_text())[
                        config["model_id"]
                    ]

                    def check_weights():
                        for name, expected in weights["files"].items():
                            stat = (SOURCE / config["local_model_path"] / name).stat()
                            assert [
                                stat.st_dev,
                                stat.st_ino,
                                stat.st_size,
                                stat.st_mtime_ns,
                            ] == expected

                    check_weights()
                    environment = {
                        "ASCEND_RT_VISIBLE_DEVICES": ",".join(
                            str(chips[chip]) for chip in sorted(chips)
                        ),
                        "TOKENSPEED_HW2_WORKSPACE": str(BASE),
                        "TOKENSPEED_SOURCE_SNAPSHOT": str(SOURCE),
                        "PYTHONPATH": ":".join(
                            map(
                                str,
                                [
                                    TOOLS / "bootstrap",
                                    TOOLS,
                                    SOURCE / "python",
                                    SOURCE / "tokenspeed-kernel/python",
                                    SOURCE / "tokenspeed-kernel-npu/python",
                                    SOURCE / "tokenspeed-scheduler/python",
                                    SOURCE,
                                ],
                            )
                        ),
                        "OMP_NUM_THREADS": "1",
                        "HF_HUB_OFFLINE": "1",
                        "TRANSFORMERS_OFFLINE": "1",
                        "PYTHONDONTWRITEBYTECODE": "1",
                        "TOKENSPEED_MAMBA_SSM_DTYPE": "float32",
                        "TOKENSPEED_NPU_PROFILER_LEVEL": "Level0",
                        "TOKENSPEED_HW2_DIAGNOSTIC_ARM": str(TOOLS / f"{job}.arm.json"),
                        "TOKENSPEED_HW2_SHARED_AUTHORIZATION": str(
                            TOOLS / "authorization.json"
                        ),
                        "TOKENSPEED_HW2_SHARED_MIN_FREE_MB": str(minimum),
                        "TOKENSPEED_HW2_SHARED_BASELINE": str(baseline_path),
                    }
                    command = [
                        str(SOURCE / ".conda-env/bin/python"),
                        str(TOOLS / "run_frontier_diagnostic.py"),
                        "--case",
                        str(TOOLS / f"case_{model}.json"),
                        "--config",
                        str(SOURCE / config_name),
                        "--output",
                        str(output),
                        "--npu-id",
                        str(card),
                        "--chips",
                        ",".join(f"{chip}:{value}" for chip, value in chips.items()),
                    ]
                    activation = (
                        "source "
                        + shlex.quote(str(SOURCE / "scripts/use_project_env.sh"))
                        + "\n"
                    )
                    activation += "\n".join(
                        f"export {key}={shlex.quote(value)}"
                        + (':"${PYTHONPATH:-}"' if key == "PYTHONPATH" else "")
                        for key, value in environment.items()
                    )
                    activation += "\nexec " + shlex.join(command)
                    receipt = {
                        "job": job,
                        "npu_id": card,
                        "chips": chips,
                        "started_utc": datetime.now(timezone.utc).isoformat(),
                    }
                    state.update(status="running", current=receipt)
                    with (TOOLS / f"{job}.log").open("x") as log:
                        process = subprocess.Popen(
                            ["bash", "--noprofile", "--norc", "-c", activation],
                            cwd=SOURCE,
                            stdout=log,
                            stderr=subprocess.STDOUT,
                            start_new_session=True,
                        )
                        start = identity(process.pid)[1]
                        receipt["pid"] = process.pid
                        save(state)
                        try:
                            process.wait(timeout=900)
                        finally:
                            for attempt in range(30):
                                try:
                                    helper.terminate_owned_group(
                                        process, expected_start=start
                                    )
                                    break
                                except RuntimeError:
                                    if attempt == 29:
                                        raise
                                    time.sleep(0.5)
                    receipt.update(
                        exit_code=process.returncode,
                        ended_utc=datetime.now(timezone.utc).isoformat(),
                    )
                    check_weights()
                    for attempt in range(15):
                        actual = target_process_pids(
                            query([]), npu_id=card, chip_ids=set(chips)
                        )
                        if all(
                            identity(pid)[0] != os.getuid()
                            for values in actual.values()
                            for pid in values
                        ):
                            receipt["own_contexts_released"] = True
                            break
                        time.sleep(1)
                    assert receipt.get(
                        "own_contexts_released"
                    ), "own NPU contexts remain"
                    assert (
                        check_sources(SOURCE, manifest)
                        == gate["source_manifest_sha256"]
                    )
                    state["finished"][job] = receipt
                    save(state)
                    assert (
                        process.returncode == 0
                    ), "diagnostic failed; raw artifacts retained"
            state["status"] = "collected"
        except BaseException as error:
            state.update(
                status="failed",
                error={"type": type(error).__name__, "message": str(error)},
            )
            raise
        finally:
            assert marker.read_text() == marker_text
            state["original_queue_retained_paused"] = True
            save(state)


if __name__ == "__main__":
    main()
