#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Observe FA7 without changing its tensors, mathematical path, or outputs."""

from __future__ import annotations

import hashlib
import json
import os
import re
from contextlib import contextmanager
from pathlib import Path
from typing import Any

MODULES = {
    "input_layernorm",
    "post_attention_layernorm",
    "qkv_proj",
    "rotary_emb",
    "attn",
    "o_proj",
    "mlp.gate_up_proj",
    "mlp.down_proj",
}


def projection_reduce_results(projection: Any) -> bool:
    if type(projection).__name__ == "ReplicatedLinear":
        return False
    if type(projection).__name__ == "RowParallelLinear":
        return projection.reduce_results
    raise ValueError("unknown projection reduction contract")


def module_key(name: str) -> str | None:
    if name.endswith("layers.8.input_layernorm"):
        return "next_input_layernorm"
    match = re.search(r"(?:^|\.)layers\.7(?:\.(.*))?$", name)
    if match is None:
        return None
    suffix = match.group(1)
    return "layer" if suffix is None else suffix if suffix in MODULES else None


def split_logical_rows(
    full: Any, *, sizes: list[int], rank: int, tp: int, torch: Any
) -> Any:
    if (
        tp < 1
        or not 0 <= rank < tp
        or sum(sizes) != full.shape[0]
        or any(size % tp for size in sizes)
    ):
        raise ValueError("invalid logical row partition")
    pieces = []
    offset = 0
    for size in sizes:
        width = size // tp
        pieces.append(full[offset + rank * width : offset + (rank + 1) * width])
        offset += size
    return torch.cat(pieces, dim=0)


@contextmanager
def observe_modules(model: Any, *, torch: Any):
    observed: dict[str, dict] = {}
    handles = []
    active = False

    def copy(values: Any) -> list:
        sequence = values if isinstance(values, tuple) else (values,)
        return [
            value.detach().cpu().clone() if isinstance(value, torch.Tensor) else None
            for value in sequence
        ]

    def pre(key: str):
        def hook(module: Any, inputs: tuple) -> None:
            nonlocal active
            if key == "layer":
                active = True
            if key == "rotary_emb" and not active:
                return
            if key in observed:
                raise ValueError(f"FA7 module {key} called more than once")
            observed[key] = {"inputs": copy(inputs)}

        return hook

    def post(key: str):
        def hook(module: Any, inputs: tuple, output: Any) -> None:
            nonlocal active
            if key == "rotary_emb" and not active:
                return
            observed[key]["outputs"] = copy(output)
            if key == "layer":
                active = False

        return hook

    for name, module in model.named_modules():
        key = module_key(name)
        if key is not None:
            handles.extend(
                [
                    module.register_forward_pre_hook(pre(key)),
                    module.register_forward_hook(post(key), always_call=key == "layer"),
                ]
            )
    try:
        yield observed
    finally:
        active = False
        for handle in handles:
            handle.remove()


class TargetModules:
    """List target objects explicitly, including the globally shared RoPE object."""

    def __init__(self, layer: Any, next_layer: Any):
        self.items: list[tuple[str, Any]] = [
            ("model.layers.7", layer),
            ("model.layers.7.input_layernorm", layer.input_layernorm),
            ("model.layers.7.post_attention_layernorm", layer.post_attention_layernorm),
            ("model.layers.7.qkv_proj", layer.qkv_proj),
            ("model.layers.7.rotary_emb", layer.rotary_emb),
            ("model.layers.7.attn", layer.attn),
            ("model.layers.7.o_proj", layer.o_proj),
            ("model.layers.7.mlp.gate_up_proj", layer.mlp.gate_up_proj),
            ("model.layers.7.mlp.down_proj", layer.mlp.down_proj),
            ("model.layers.8.input_layernorm", next_layer.input_layernorm),
        ]

    def named_modules(self):
        return iter(self.items)


def checkpoint_shards(
    layer: Any, *, torch: Any, rank: int, tp: int, case: dict
) -> list[dict]:
    from safetensors import safe_open

    source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
    model_name = (
        "4b"
        if "_4b_" in case["case_id"]
        else "9b" if "_9b_" in case["case_id"] else None
    )
    if model_name is None:
        raise ValueError("unexpected FA7 case identity")
    config = json.loads(
        (source / f"configs/homework2/qwen35_{model_name}_tp1.yaml").read_text()
    )
    checkpoint = source / config["local_model_path"]
    index = json.loads(next(checkpoint.glob("*.safetensors.index.json")).read_text())[
        "weight_map"
    ]

    def get(suffix: str):
        name = "model.language_model.layers.7." + suffix
        with safe_open(
            checkpoint / index[name], framework="pt", device="cpu"
        ) as reader:
            return reader.get_tensor(name)

    def digest(value: Any) -> str:
        return hashlib.sha256(
            value.contiguous().view(torch.uint8).numpy().tobytes()
        ).hexdigest()

    records = []
    for suffix, parameter in layer.named_parameters():
        if suffix == "qkv_proj.weight":
            q, k, v = (get(f"self_attn.{kind}_proj.weight") for kind in ("q", "k", "v"))
            full = torch.cat([q, k, v], dim=0)
            expected = split_logical_rows(
                full,
                sizes=[q.shape[0], k.shape[0], v.shape[0]],
                rank=rank,
                tp=tp,
                torch=torch,
            )
        elif suffix == "mlp.gate_up_proj.weight":
            gate, up = get("mlp.gate_proj.weight"), get("mlp.up_proj.weight")
            expected = split_logical_rows(
                torch.cat([gate, up], dim=0),
                sizes=[gate.shape[0], up.shape[0]],
                rank=rank,
                tp=tp,
                torch=torch,
            )
        elif suffix in ("o_proj.weight", "mlp.down_proj.weight"):
            full = get("self_attn." + suffix if suffix.startswith("o_proj") else suffix)
            width = full.shape[1] // tp
            expected = full[:, rank * width : (rank + 1) * width]
        else:
            expected = get(
                "self_attn." + suffix
                if suffix in ("q_norm.weight", "k_norm.weight")
                else suffix
            )
        actual = parameter.detach().cpu().contiguous()
        expected = expected.to(dtype=actual.dtype).contiguous()
        records.append(
            {
                "name": suffix,
                "shape": list(actual.shape),
                "dtype": str(actual.dtype),
                "actual_sha256": digest(actual),
                "checkpoint_expected_sha256": digest(expected),
                "exact_match": actual.shape == expected.shape
                and bool(torch.equal(actual, expected)),
            }
        )
    if len(records) != 8 or not all(row["exact_match"] for row in records):
        raise ValueError("FA7 actual checkpoint shard identity mismatch")
    return records


@contextmanager
def capture_fa7(model: Any, *, torch: Any, output: Path, rank: int, case: dict):
    layers = {
        int(match.group(1)): module
        for name, module in model.named_modules()
        if (match := re.search(r"(?:^|\.)layers\.(7|8)$", name)) is not None
    }
    if set(layers) != {7, 8}:
        raise ValueError("FA7/next layer objects were not uniquely located")
    layer, next_layer = layers[7], layers[8]
    tp = layer.attn_tp_size
    if rank != layer.attn_tp_rank or layer.layer_id != 7 or not layer.attn_output_gate:
        raise ValueError("unexpected FA7 geometry or rank")
    weights = checkpoint_shards(layer, torch=torch, rank=rank, tp=tp, case=case)
    with (output / "fa7_checkpoint_shards.json").open("x") as stream:
        json.dump({"rank": rank, "tp": tp, "weights": weights}, stream, indent=2)
    norms = {
        "input_layernorm": layer.input_layernorm,
        "post_attention_layernorm": layer.post_attention_layernorm,
        "q_norm": layer.q_norm,
        "k_norm": layer.k_norm,
        "next_input_layernorm": next_layer.input_layernorm,
    }
    parameters = {
        name: parameter.detach().cpu().clone()
        for name, parameter in layer.named_parameters()
    }
    parameters["next_input_layernorm.weight"] = (
        next_layer.input_layernorm.weight.detach().cpu().clone()
    )
    with (output / "fa7_parameters.pt").open("xb") as stream:
        torch.save(parameters, stream)
    with (output / "fa7_effective_norms.pt").open("xb") as stream:
        torch.save(
            {
                name: module.gemma_weight.detach().cpu().clone()
                for name, module in norms.items()
            },
            stream,
        )
    metadata = {
        "rank": rank,
        "tp": tp,
        "layer_id": 7,
        "step": 0,
        "input_length": 128,
        "heads": layer.num_heads,
        "kv_heads": layer.num_kv_heads,
        "head_dim": layer.head_dim,
        "scaling": layer.scaling,
        "rotary_dim": layer.rotary_emb.rotary_dim,
        "eps": {name: module.variance_epsilon for name, module in norms.items()},
        "cache_scope": "Actual first Prefill only; no prior cached history; cached step8 KV is not captured.",
        "original_graph_failures_preserved": True,
        "performance_eligible": False,
    }
    metadata["communication"] = {
        "should_fuse": layer.comm_manager.should_fuse(128),
        "next_should_fuse": next_layer.comm_manager.should_fuse(128),
        "use_all_reduce": layer.comm_manager.use_all_reduce(layer.is_moe),
        "attention_tp_rank": layer.mapping.attn.tp_rank,
        "attention_tp_size": layer.mapping.attn.tp_size,
        "dense_tp_rank": layer.mapping.dense.tp_rank,
        "dense_tp_size": layer.mapping.dense.tp_size,
        "o_proj_reduce_results": projection_reduce_results(layer.o_proj),
        "down_proj_reduce_results": projection_reduce_results(layer.mlp.down_proj),
    }
    comm = metadata["communication"]
    if (
        comm["should_fuse"]
        or comm["next_should_fuse"]
        or not comm["use_all_reduce"]
        or comm["o_proj_reduce_results"]
        or comm["down_proj_reduce_results"]
    ):
        raise ValueError(
            "FA7 observer does not cover the actual fused/communication path"
        )

    def context_pre(module: Any, inputs: tuple) -> None:
        from fa7_context import capture_attention_context

        if "attention_context" in metadata:
            raise ValueError("FA7 attention context called more than once")
        metadata["attention_context"] = capture_attention_context(
            inputs[3], module, torch=torch
        )

    context_handle = layer.attn.register_forward_pre_hook(context_pre)
    try:
        with observe_modules(TargetModules(layer, next_layer), torch=torch) as observed:
            yield
    finally:
        context_handle.remove()
    expected = MODULES | {"layer", "next_input_layernorm"}
    if set(observed) != expected or any(
        "outputs" not in value for value in observed.values()
    ):
        raise ValueError(f"incomplete FA7 operand coverage: {sorted(observed)}")
    if observed["qkv_proj"]["inputs"][0].shape[0] != 128:
        raise ValueError("FA7 capture did not observe the complete Prefill")
    positions = observed["rotary_emb"]["inputs"][0]
    metadata["rotary_class"] = type(layer.rotary_emb).__name__
    metadata["rotary_is_neox_style"] = layer.rotary_emb.is_neox_style
    metadata["rotary_cache_dtype"] = str(layer.rotary_emb.cos_sin_cache.dtype)
    metadata["rotary_cache_prefix_rows"] = int(positions.max()) + 1
    with (output / "fa7_rotary_cache.pt").open("xb") as stream:
        torch.save(
            layer.rotary_emb.cos_sin_cache[: metadata["rotary_cache_prefix_rows"]]
            .detach()
            .cpu()
            .clone(),
            stream,
        )
    with (output / "fa7_metadata.json").open("x") as stream:
        json.dump(metadata, stream, indent=2)
    with (output / "fa7_operands.pt").open("xb") as stream:
        torch.save({"rank": rank, "tp": tp, "step": 0, "modules": observed}, stream)
