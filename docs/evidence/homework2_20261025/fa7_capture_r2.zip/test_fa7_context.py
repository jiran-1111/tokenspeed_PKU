#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU-only contract tests; never import tokenspeed or NPU modules."""

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest


def capture(ctx, layer, torch=None):
    path = Path(__file__).with_name("fa7_context.py")
    assert path.exists(), "FA7 context capture helper is not implemented"
    spec = importlib.util.spec_from_file_location("fa7_context_under_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.capture_attention_context(ctx, layer, torch=torch)


def fixture():
    calls = []

    def plan(**kwargs):
        calls.append(kwargs)
        return {"extend_mode": "postwrite"}

    leaf = type("MHAAttnBackend", (SimpleNamespace,), {})(
        kernel_solution=None,
        qkv_dtype="torch.bfloat16",
        kv_cache_dtype="torch.bfloat16",
        is_fp8=False,
        is_mxfp8=False,
        skip_softmax_threshold=0.0,
        plan=plan,
        forward_extend_metadata=SimpleNamespace(
            seq_lens=[128],
            extend_seq_lens=[128],
            extend_prefix_lens=[0],
            cu_extend_seq_lens=[0, 128],
            cu_seqlens_kv=[0, 128],
            extend_seq_lens_cpu=[128],
            cu_extend_seq_lens_cpu=[0, 128],
            max_extend_seq_len=128,
            max_extend_prefix_len=0,
        ),
    )
    router = type("CacheGroupRouter", (SimpleNamespace,), {})(
        leaves={"full_attention": leaf, "unrelated": object()}
    )
    backend = type("HybridLinearAttnBackend", (SimpleNamespace,), {})(
        full_attn_backend=router, full_attn_layers={3, 7, 11}
    )
    ctx = SimpleNamespace(
        attn_backend=backend,
        bs=1,
        num_extends=1,
        input_num_tokens=128,
        forward_mode=SimpleNamespace(name="EXTEND", is_extend=lambda: True),
    )
    layer = SimpleNamespace(
        layer_id=7,
        group_id="full_attention",
        sliding_window_size=-1,
        logit_cap=0.0,
        scaling=0.0625,
        tp_q_head_num=8,
        tp_k_head_num=2,
        tp_v_head_num=2,
        qk_head_dim=256,
        v_head_dim=256,
    )
    return ctx, layer, leaf, calls


def test_routes_group_and_returns_only_json_values_without_running_forward():
    ctx, layer, leaf, calls = fixture()
    record = capture(ctx, layer)
    assert record["backend_path"] == [
        "HybridLinearAttnBackend",
        "CacheGroupRouter",
        "MHAAttnBackend",
    ]
    assert record["metadata"]["seq_lens"] == [128]
    assert record["branch"] == "_forward_prefill"
    assert record["branch_evidence"] == "frozen_source_predicate_at_attn_prehook"
    assert record["prefill_reads_kv_cache"] is False
    assert record["actual_branch_observed"] is False
    assert calls == [{"window_left": -1, "logit_cap": 0.0, "sinks": None}]
    assert json.loads(json.dumps(record)) == record


def test_tensor_metadata_is_detached_and_copied_to_cpu_lists():
    ctx, layer, leaf, _ = fixture()

    class FakeTensor:
        def __init__(self, values):
            self.values, self.events = values, []

        def detach(self):
            self.events.append("detach")
            return self

        def cpu(self):
            self.events.append("cpu")
            return self

        def tolist(self):
            self.events.append("tolist")
            return self.values

    tensor = FakeTensor([128])
    leaf.forward_extend_metadata.seq_lens = tensor
    record = capture(ctx, layer, torch=SimpleNamespace(Tensor=FakeTensor))
    assert record["metadata"]["seq_lens"] == [128]
    assert tensor.events == ["detach", "cpu", "tolist"]
    json.dumps(record)


@pytest.mark.parametrize(
    "field,value",
    [
        ("seq_lens", [129]),
        ("extend_prefix_lens", [1]),
        ("cu_extend_seq_lens", [0, 127]),
        ("cu_seqlens_kv", [0, 129]),
        ("cu_extend_seq_lens_cpu", [0, 127]),
        ("max_extend_prefix_len", 1),
    ],
)
def test_rejects_non_full_uncached_128_prefill(field, value):
    ctx, layer, leaf, _ = fixture()
    setattr(leaf.forward_extend_metadata, field, value)
    with pytest.raises(ValueError, match="metadata"):
        capture(ctx, layer)


def test_rejects_prewrite_plan():
    ctx, layer, leaf, _ = fixture()
    leaf.plan = lambda **kwargs: {"extend_mode": "prewrite"}
    with pytest.raises(ValueError, match="postwrite"):
        capture(ctx, layer)


@pytest.mark.parametrize(
    "bad",
    ["unknown_backend", "missing_group", "not_full_layer", "decode", "wrong_layer"],
)
def test_rejects_unknown_or_wrong_dispatch(bad):
    ctx, layer, _, _ = fixture()
    if bad == "unknown_backend":
        ctx.attn_backend = SimpleNamespace()
    elif bad == "missing_group":
        layer.group_id = "missing"
    elif bad == "not_full_layer":
        ctx.attn_backend.full_attn_layers = {3}
    elif bad == "decode":
        ctx.forward_mode.is_extend = lambda: False
    else:
        layer.layer_id = 3
    with pytest.raises(ValueError):
        capture(ctx, layer)


def test_rejects_missing_metadata_instead_of_guessing():
    ctx, layer, leaf, _ = fixture()
    del leaf.forward_extend_metadata.extend_prefix_lens
    with pytest.raises(ValueError, match="extend_prefix_lens"):
        capture(ctx, layer)


def test_rejects_non_json_plan_values():
    ctx, layer, leaf, _ = fixture()
    leaf.plan = lambda **kwargs: {"extend_mode": "postwrite", "unsupported": object()}
    with pytest.raises(ValueError, match="JSON"):
        capture(ctx, layer)
