#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace


class Fa7CaptureTests(unittest.TestCase):
    def setUp(self):
        path = Path(__file__).parent / "fa7_capture.py"
        self.assertTrue(path.exists(), "FA7 capture implementation is missing")
        spec = importlib.util.spec_from_file_location("fa7_capture", path)
        self.capture = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.capture)
        import torch

        self.torch = torch

    def test_only_exact_fa7_and_next_norm_are_selected(self):
        self.assertEqual(self.capture.module_key("model.layers.7.qkv_proj"), "qkv_proj")
        self.assertEqual(
            self.capture.module_key("model.layers.7.rotary_emb"), "rotary_emb"
        )
        self.assertEqual(
            self.capture.module_key("model.layers.8.input_layernorm"),
            "next_input_layernorm",
        )
        for name in (
            "model.layers.17.qkv_proj",
            "model.layers.7.q_norm",
            "model.layers.8.mlp.down_proj",
            "model.layers.6.qkv_proj",
        ):
            self.assertIsNone(self.capture.module_key(name), name)

    def test_logical_qgate_kv_and_mlp_rows_are_sharded_independently(self):
        torch = self.torch
        full = torch.arange(24).reshape(12, 2)
        actual = self.capture.split_logical_rows(
            full, sizes=[8, 2, 2], rank=1, tp=2, torch=torch
        )
        self.assertTrue(torch.equal(actual, full[[4, 5, 6, 7, 9, 11]]))
        for sizes, rank, tp in (([7, 3, 2], 0, 2), ([8, 2], 0, 2), ([8, 2, 2], 2, 2)):
            with self.assertRaises(ValueError):
                self.capture.split_logical_rows(
                    full, sizes=sizes, rank=rank, tp=tp, torch=torch
                )

    def test_pre_snapshot_keeps_bf16_and_original_residual_before_mutation(self):
        torch = self.torch

        class Layer(torch.nn.Module):
            def forward(self, value, residual):
                residual.add_(value)
                return value, residual

        layer = Layer()
        model = SimpleNamespace(
            named_modules=lambda: [("model.layers.7.post_attention_layernorm", layer)]
        )
        value = torch.full((128, 3), 2, dtype=torch.bfloat16)
        residual = torch.ones_like(value)
        with self.capture.observe_modules(model, torch=torch) as observed:
            output = layer(value, residual)
            self.assertIs(output[1], residual)
        record = observed["post_attention_layernorm"]
        self.assertEqual(record["inputs"][1].dtype, torch.bfloat16)
        self.assertTrue(torch.equal(record["inputs"][1], torch.ones_like(value)))
        self.assertTrue(torch.equal(record["outputs"][1], torch.full_like(value, 3)))
        residual.fill_(8)
        self.assertTrue(torch.equal(record["outputs"][1], torch.full_like(value, 3)))
        self.assertFalse(layer._forward_hooks or layer._forward_pre_hooks)

    def test_hooks_removed_after_failure_and_no_outputs_replaced(self):
        torch = self.torch

        class Layer(torch.nn.Module):
            def forward(self, value):
                raise RuntimeError("original forward failed")

        layer = Layer()
        model = SimpleNamespace(named_modules=lambda: [("model.layers.7.attn", layer)])
        with self.assertRaisesRegex(RuntimeError, "original forward failed"):
            with self.capture.observe_modules(model, torch=torch):
                layer(torch.ones(1))
        self.assertFalse(layer._forward_hooks or layer._forward_pre_hooks)

    def test_duplicate_calls_rejected_and_hooks_cleaned(self):
        torch = self.torch
        layer = torch.nn.Identity()
        model = SimpleNamespace(
            named_modules=lambda: [("model.layers.7.qkv_proj", layer)]
        )
        with self.assertRaisesRegex(ValueError, "more than once"):
            with self.capture.observe_modules(model, torch=torch):
                value = torch.ones(2, 2)
                self.assertIs(layer(value), value)
                layer(value)
        self.assertFalse(layer._forward_hooks or layer._forward_pre_hooks)

    def test_shared_rotary_module_is_observed_only_inside_target_layer(self):
        torch = self.torch
        rotary = torch.nn.Identity()

        class Layer(torch.nn.Module):
            def forward(self, value):
                return rotary(value)

        layer = Layer()
        model = SimpleNamespace(
            named_modules=lambda: [
                ("model.layers.7", layer),
                ("model.layers.7.rotary_emb", rotary),
            ]
        )
        value = torch.ones(128, 4, dtype=torch.bfloat16)
        with self.capture.observe_modules(model, torch=torch) as observed:
            rotary(value * 2)
            self.assertIs(layer(value), value)
            rotary(value * 3)
        self.assertTrue(torch.equal(observed["rotary_emb"]["inputs"][0], value))
        self.assertEqual(set(observed), {"layer", "rotary_emb"})

    def test_replicated_tp1_projection_has_no_internal_reduce_attribute(self):
        self.assertIn("projection_reduce_results", self.capture.__dict__)
        replicated = type("ReplicatedLinear", (), {})()
        row = type("RowParallelLinear", (), {"reduce_results": False})()
        self.assertFalse(self.capture.projection_reduce_results(replicated))
        self.assertFalse(self.capture.projection_reduce_results(row))
        row.reduce_results = True
        self.assertTrue(self.capture.projection_reduce_results(row))
        with self.assertRaises(ValueError):
            self.capture.projection_reduce_results(SimpleNamespace())


if __name__ == "__main__":
    unittest.main()
