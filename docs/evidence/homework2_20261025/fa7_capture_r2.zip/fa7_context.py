#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read only the frozen FA7 MHA routing/metadata at its real prefill prehook."""

import math


def _json_value(value, torch):
    if torch is not None and isinstance(value, torch.Tensor):
        return _json_value(value.detach().cpu().tolist(), torch)
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float) and math.isfinite(value):
        return value
    if isinstance(value, (list, tuple)):
        return [_json_value(item, torch) for item in value]
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        return {key: _json_value(item, torch) for key, item in value.items()}
    raise ValueError(f"Unsupported JSON attention value: {type(value).__name__}")


def capture_attention_context(ctx, paged_layer, *, torch) -> dict:
    """Validate the source's uncached-prefill predicate, without calling forward.

    This records a prehook predicate, not an observed kernel execution. Only the
    known Hybrid -> cache-group router -> MHA routing structure is accepted.
    """
    try:
        return _capture_attention_context(ctx, paged_layer, torch=torch)
    except AttributeError as error:
        raise ValueError(f"Missing frozen attention field: {error}") from error


def _capture_attention_context(ctx, paged_layer, *, torch) -> dict:
    if paged_layer.layer_id != 7:
        raise ValueError("Context capture requires FA layer 7")
    mode = ctx.forward_mode
    if not mode.is_extend():
        raise ValueError("Context capture requires an EXTEND prefill")
    counts = {
        "bs": ctx.bs,
        "num_extends": ctx.num_extends,
        "input_num_tokens": ctx.input_num_tokens,
    }
    if counts != {"bs": 1, "num_extends": 1, "input_num_tokens": 128}:
        raise ValueError("Context capture requires one complete 128-token prefill")

    backend = ctx.attn_backend
    path = [type(backend).__name__]
    if type(backend).__name__ == "HybridLinearAttnBackend":
        if 7 not in backend.full_attn_layers:
            raise ValueError("Hybrid backend does not route layer 7 to full attention")
        backend = backend.full_attn_backend
        path.append(type(backend).__name__)
    group_id = paged_layer.group_id
    if type(backend).__name__ == "CacheGroupRouter":
        leaves = backend.leaves
        if not isinstance(leaves, dict) or group_id not in leaves:
            raise ValueError("Layer 7 cache group is absent from router leaves")
        backend = leaves[group_id]
        path.append(type(backend).__name__)
    if type(backend).__name__ != "MHAAttnBackend":
        raise ValueError(f"Unknown frozen attention backend path: {path}")

    metadata = backend.forward_extend_metadata
    expected = {
        "seq_lens": [128],
        "extend_seq_lens": [128],
        "extend_prefix_lens": [0],
        "cu_extend_seq_lens": [0, 128],
        "cu_seqlens_kv": [0, 128],
        "extend_seq_lens_cpu": [128],
        "cu_extend_seq_lens_cpu": [0, 128],
        "max_extend_seq_len": 128,
        "max_extend_prefix_len": 0,
    }
    captured = _json_value(
        {
            "seq_lens": metadata.seq_lens,
            "extend_seq_lens": metadata.extend_seq_lens,
            "extend_prefix_lens": metadata.extend_prefix_lens,
            "cu_extend_seq_lens": metadata.cu_extend_seq_lens,
            "cu_seqlens_kv": metadata.cu_seqlens_kv,
            "extend_seq_lens_cpu": metadata.extend_seq_lens_cpu,
            "cu_extend_seq_lens_cpu": metadata.cu_extend_seq_lens_cpu,
            "max_extend_seq_len": metadata.max_extend_seq_len,
            "max_extend_prefix_len": metadata.max_extend_prefix_len,
        },
        torch,
    )
    for name, value in expected.items():
        if captured[name] != value:
            raise ValueError(f"Unexpected prefill metadata {name}: {captured[name]}")

    window_left = paged_layer.sliding_window_size
    logit_cap = paged_layer.logit_cap
    plan = _json_value(
        backend.plan(window_left=window_left, logit_cap=logit_cap, sinks=None), torch
    )
    if not isinstance(plan, dict) or plan.get("extend_mode") != "postwrite":
        raise ValueError("Uncached prefill proof requires a postwrite MHA plan")

    record = {
        "layer_id": 7,
        "group_id": group_id,
        "backend_path": path,
        "leaf_backend": type(backend).__name__,
        "forward_mode": mode.name,
        **counts,
        "metadata": captured,
        "plan": plan,
        "kernel_solution": backend.kernel_solution,
        "qkv_dtype": str(backend.qkv_dtype),
        "kv_cache_dtype": str(backend.kv_cache_dtype),
        "is_fp8": backend.is_fp8,
        "is_mxfp8": backend.is_mxfp8,
        "skip_softmax_threshold": backend.skip_softmax_threshold,
        "window_left": window_left,
        "logit_cap": logit_cap,
        "sinks": None,
        "scaling": paged_layer.scaling,
        "heads": {
            "tp_q_head_num": paged_layer.tp_q_head_num,
            "tp_k_head_num": paged_layer.tp_k_head_num,
            "tp_v_head_num": paged_layer.tp_v_head_num,
            "qk_head_dim": paged_layer.qk_head_dim,
            "v_head_dim": paged_layer.v_head_dim,
        },
        "branch": "_forward_prefill",
        "branch_evidence": "frozen_source_predicate_at_attn_prehook",
        "actual_branch_observed": False,
        "prefill_reads_kv_cache": False,
        "cache_write_verified": False,
    }
    return _json_value(record, torch)
