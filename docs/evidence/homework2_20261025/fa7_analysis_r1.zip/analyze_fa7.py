#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU-only FA7 references using each operator's captured operands."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path, PureWindowsPath

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
NORMS = (
    "input_layernorm",
    "post_attention_layernorm",
    "q_norm",
    "k_norm",
    "next_input_layernorm",
)
PARAMETERS = {
    "qkv_proj.weight",
    "o_proj.weight",
    "mlp.gate_up_proj.weight",
    "mlp.down_proj.weight",
    *(name + ".weight" for name in NORMS),
}
MODULES = {
    "input_layernorm",
    "post_attention_layernorm",
    "qkv_proj",
    "rotary_emb",
    "attn",
    "o_proj",
    "mlp.gate_up_proj",
    "mlp.down_proj",
    "layer",
    "next_input_layernorm",
}
FILES = (
    "fa7_operands.pt",
    "fa7_parameters.pt",
    "fa7_effective_norms.pt",
    "fa7_metadata.json",
    "fa7_checkpoint_shards.json",
    "fa7_rotary_cache.pt",
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def validate_positions(values, *, module, side, index):
    import numpy as np

    require(
        module in ("layer", "rotary_emb") and side == "inputs" and index == 0,
        "integer positions appear outside the two known input slots",
    )
    require(
        values.dtype.kind in "iu" and values.shape in ((128,), (3, 128)),
        "positions require integer shape [128] or [3,128]",
    )
    if values.ndim == 2:
        require(
            np.array_equal(values[0], values[1])
            and np.array_equal(values[0], values[2]),
            "three-axis text positions must have identical values",
        )
        return values[0].astype(np.int64)
    return values.astype(np.int64)


def select_jobs(root, manifest):
    root = Path(root).resolve()
    require(
        isinstance(manifest, dict) and set(manifest) == {"4b", "9b"},
        "jobs manifest model coverage mismatch",
    )
    selected = {}
    for model in ("4b", "9b"):
        require(
            isinstance(manifest[model], dict)
            and set(manifest[model]) == {"tp1", "tp2"},
            "jobs manifest TP coverage mismatch",
        )
        selected[model] = {}
        for tp in ("tp1", "tp2"):
            name = manifest[model][tp]
            require(
                isinstance(name, str) and bool(name),
                "jobs manifest path must be a nonempty relative string",
            )
            path = Path(name)
            require(
                not path.is_absolute()
                and not PureWindowsPath(name).drive
                and not PureWindowsPath(name).root,
                "jobs manifest paths must be relative",
            )
            resolved = (root / path).resolve()
            require(
                resolved != root and resolved.is_relative_to(root),
                "jobs manifest path escapes root",
            )
            selected[model][tp] = resolved
    return selected


def compare(actual, reference):
    import numpy as np

    actual, reference = np.asarray(actual), np.asarray(reference)
    require(
        actual.shape == reference.shape and actual.size > 0, "comparison shape mismatch"
    )
    require(
        np.isfinite(actual).all() and np.isfinite(reference).all(),
        "comparison requires finite values",
    )
    delta = actual.astype(np.float64) - reference.astype(np.float64)
    ref = reference.astype(np.float64)

    def relative(num, den):
        return float(num / den) if den else (0.0 if not num else None)

    result = {
        "shape": list(actual.shape),
        "relative_l2": relative(
            np.linalg.norm(delta.ravel()), np.linalg.norm(ref.ravel())
        ),
        "reference_zero": bool(not np.any(ref)),
        "max_abs": float(np.abs(delta).max()),
        "max_abs_index": [
            int(i) for i in np.unravel_index(np.abs(delta).argmax(), delta.shape)
        ],
        "different_elements": int(np.count_nonzero(delta)),
        "elements": int(delta.size),
    }
    if actual.ndim >= 2:
        rows, refs = delta.reshape(actual.shape[0], -1), ref.reshape(
            actual.shape[0], -1
        )
        result["per_row_relative_l2"] = [
            relative(np.linalg.norm(a), np.linalg.norm(b)) for a, b in zip(rows, refs)
        ]
        result["per_row_max_abs"] = np.abs(rows).max(axis=1).tolist()
    if actual.ndim == 3:
        result["per_head_relative_l2"] = [
            relative(np.linalg.norm(delta[:, h]), np.linalg.norm(ref[:, h]))
            for h in range(actual.shape[1])
        ]
        result["per_head_max_abs"] = np.abs(delta).max(axis=(0, 2)).tolist()
    return result


def split_qkv(packed, *, heads, kv_heads, dim):
    require(
        packed.ndim == 2 and packed.shape[-1] == (2 * heads + 2 * kv_heads) * dim,
        "packed QKV shape mismatch",
    )
    qend, kend = 2 * heads * dim, (2 * heads + kv_heads) * dim
    qg = packed[:, :qend].reshape(packed.shape[0], heads, 2, dim)
    return (
        qg[:, :, 0],
        qg[:, :, 1],
        packed[:, qend:kend].reshape(-1, kv_heads, dim),
        packed[:, kend:].reshape(-1, kv_heads, dim),
    )


def reassemble_packed(ranks, *, sizes):
    import numpy as np

    require(all(x.shape[-1] == sum(sizes) for x in ranks), "packed rank shape mismatch")
    pieces = [np.split(x, np.cumsum(sizes)[:-1], axis=-1) for x in ranks]
    return np.concatenate(
        [np.concatenate([p[i] for p in pieces], axis=-1) for i in range(len(sizes))],
        axis=-1,
    )


def round_bf16(value):
    import numpy as np

    value = np.asarray(value, dtype=np.float32)
    require(np.isfinite(value).all(), "BF16 reference requires finite values")
    bits = value.view(np.uint32)
    return (
        (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(0xFFFF0000)
    ).view(np.float32)


def rmsnorm(value, gamma, eps):
    import numpy as np

    value = np.asarray(value, dtype=np.float32)
    return (
        value
        * (
            np.float32(1)
            / np.sqrt(np.mean(value * value, axis=-1, keepdims=True) + np.float32(eps))
        )
        * gamma
    )


def rope(value, positions, table, *, rotary_dim):
    import numpy as np

    require(
        positions.ndim == 1 and len(positions) == value.shape[0],
        "RoPE position shape mismatch",
    )
    require(
        rotary_dim % 2 == 0 and table.shape[1] == rotary_dim,
        "RoPE table shape mismatch",
    )
    cache = table[positions]
    cos, sin = np.split(cache, 2, axis=-1)
    a, b = np.split(value[..., :rotary_dim], 2, axis=-1)
    rotated = np.concatenate(
        [a * cos[:, None] - b * sin[:, None], b * cos[:, None] + a * sin[:, None]],
        axis=-1,
    )
    return np.concatenate([rotated, value[..., rotary_dim:]], axis=-1)


def causal_gqa(q, k, v, scaling):
    import numpy as np

    require(
        q.ndim == k.ndim == v.ndim == 3
        and k.shape == v.shape
        and q.shape[0] == k.shape[0],
        "GQA shape mismatch",
    )
    require(
        q.shape[1] % k.shape[1] == 0 and q.shape[2] == k.shape[2],
        "GQA head shape mismatch",
    )
    index = np.arange(q.shape[1]) // (q.shape[1] // k.shape[1])
    scores = np.einsum("thd,shd->hts", q, k[:, index], optimize=True) * np.float32(
        scaling
    )
    scores[:, np.triu(np.ones((q.shape[0], q.shape[0]), dtype=bool), k=1)] = -np.inf
    prob = np.exp(scores - scores.max(axis=-1, keepdims=True))
    prob /= prob.sum(axis=-1, keepdims=True)
    return np.einsum("hts,shd->thd", prob, v[:, index], optimize=True)


def validate_run(run):
    require(run["status"] == "collected", "diagnostic is not collected")
    guard = run["guard"]
    require(
        guard["sources_sha"] == guard["sources_after_sha"] == CORE_SHA
        and guard["sources_unchanged"] is True
        and guard["own_children_released"] is True
        and guard["violations"] == [],
        "diagnostic guard mismatch",
    )
    require(
        run["diagnostic_only"] is True
        and run["execution_mode"] == "eager"
        and run["performance_eligible"] is False
        and run["original_graph_failures_preserved"] is True,
        "diagnostic scope mismatch",
    )


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_rank(directory, rank, tp, torch):
    import numpy as np

    paths = {name: directory / name for name in FILES}
    metadata = json.loads(paths["fa7_metadata.json"].read_text())
    identity = json.loads(paths["fa7_checkpoint_shards.json"].read_text())
    data = torch.load(paths["fa7_operands.pt"], map_location="cpu", weights_only=True)
    parameters = torch.load(
        paths["fa7_parameters.pt"], map_location="cpu", weights_only=True
    )
    gamma = torch.load(
        paths["fa7_effective_norms.pt"], map_location="cpu", weights_only=True
    )
    cache = torch.load(
        paths["fa7_rotary_cache.pt"], map_location="cpu", weights_only=True
    )
    for record in (metadata, identity, data):
        require(
            record["rank"] == rank and record["tp"] == tp, "capture rank/TP mismatch"
        )
    require(
        metadata["layer_id"] == 7
        and metadata["step"] == data["step"] == 0
        and metadata["input_length"] == 128,
        "capture layer/step/length mismatch",
    )
    require(
        (metadata["heads"], metadata["kv_heads"], metadata["head_dim"])
        == (16 // tp, 4 // tp, 256),
        "capture head geometry mismatch",
    )
    require(
        metadata["scaling"] == 0.0625 and metadata["rotary_is_neox_style"] is True,
        "capture scaling/rotary style mismatch",
    )
    require(
        set(data["modules"]) == MODULES
        and set(parameters) == PARAMETERS
        and set(gamma) == set(NORMS),
        "capture field coverage mismatch",
    )
    comm = metadata["communication"]
    require(
        comm["should_fuse"] is False
        and comm["next_should_fuse"] is False
        and comm["use_all_reduce"] is True
        and comm["o_proj_reduce_results"] is False
        and comm["down_proj_reduce_results"] is False,
        "unsupported communication path",
    )
    require(
        (
            comm["attention_tp_rank"],
            comm["attention_tp_size"],
            comm["dense_tp_rank"],
            comm["dense_tp_size"],
        )
        == (rank, tp, rank, tp),
        "attention/dense rank mapping mismatch",
    )
    context = metadata["attention_context"]
    require(
        context["branch"] == "_forward_prefill"
        and context["plan"]["extend_mode"] == "postwrite"
        and context["prefill_reads_kv_cache"] is False
        and context["actual_branch_observed"] is False,
        "uncached prefill predicate is missing",
    )
    require(
        context["metadata"]
        == {
            "seq_lens": [128],
            "extend_seq_lens": [128],
            "extend_prefix_lens": [0],
            "cu_extend_seq_lens": [0, 128],
            "cu_seqlens_kv": [0, 128],
            "extend_seq_lens_cpu": [128],
            "cu_extend_seq_lens_cpu": [0, 128],
            "max_extend_seq_len": 128,
            "max_extend_prefix_len": 0,
        },
        "attention metadata mismatch",
    )
    require(
        context["window_left"] == -1
        and context["logit_cap"] == 0
        and context["sinks"] is None
        and context["skip_softmax_threshold"] == 0
        and not context["is_fp8"]
        and not context["is_mxfp8"],
        "unsupported attention options",
    )
    require(
        context["heads"]
        == {
            "tp_q_head_num": 16 // tp,
            "tp_k_head_num": 4 // tp,
            "tp_v_head_num": 4 // tp,
            "qk_head_dim": 256,
            "v_head_dim": 256,
        }
        and context["scaling"] == metadata["scaling"]
        and context["qkv_dtype"] == "torch.bfloat16",
        "attention context geometry/dtype mismatch",
    )
    tensors = list(parameters.values()) + list(gamma.values()) + [cache]
    for module, sample in data["modules"].items():
        for side in ("inputs", "outputs"):
            require(isinstance(sample[side], list), "operand sides must be lists")
            for index, tensor in enumerate(sample[side]):
                if tensor is not None:
                    require(isinstance(tensor, torch.Tensor), "operand is not a Tensor")
                    if (
                        module in ("layer", "rotary_emb")
                        and side == "inputs"
                        and index == 0
                    ):
                        require(
                            not tensor.is_floating_point(),
                            "positions must have an integer dtype",
                        )
                        validate_positions(
                            tensor.numpy(), module=module, side=side, index=index
                        )
                    else:
                        require(
                            tensor.is_floating_point()
                            and tensor.dtype == torch.bfloat16,
                            "non-position operand original dtype is not BF16",
                        )
                        require(
                            tensor.ndim >= 1 and tensor.shape[0] == 128,
                            "operand does not contain all 128 rows",
                        )
                    tensors.append(tensor)
    for tensor in tensors:
        require(
            isinstance(tensor, torch.Tensor)
            and tensor.device.type == "cpu"
            and tensor.numel() > 0
            and bool(torch.isfinite(tensor).all()),
            "capture requires finite CPU tensors",
        )
    for name, tensor in parameters.items():
        require(tensor.dtype == torch.bfloat16, "parameter original dtype is not BF16")
    require(
        str(cache.dtype) == metadata["rotary_cache_dtype"],
        "rotary cache original dtype mismatch",
    )
    require(
        all(tensor.dtype == torch.float32 for tensor in gamma.values()),
        "effective gamma must remain FP32",
    )
    for name in NORMS:
        require(
            torch.equal(gamma[name], parameters[name + ".weight"].float() + 1.0),
            "effective gamma identity mismatch",
        )
        require(
            np.isfinite(metadata["eps"][name]) and metadata["eps"][name] > 0,
            "invalid norm epsilon",
        )
    require(
        len(identity["weights"]) == 8
        and {row["name"] for row in identity["weights"]}
        == PARAMETERS - {"next_input_layernorm.weight"},
        "checkpoint parameter coverage mismatch",
    )
    for row in identity["weights"]:
        tensor = parameters[row["name"]]
        digest = hashlib.sha256(
            tensor.contiguous().view(torch.uint8).numpy().tobytes()
        ).hexdigest()
        require(
            row["exact_match"] is True
            and digest == row["actual_sha256"] == row["checkpoint_expected_sha256"]
            and list(tensor.shape) == row["shape"]
            and str(tensor.dtype) == row["dtype"],
            "checkpoint shard digest mismatch",
        )
    return {
        "modules": data["modules"],
        "parameters": parameters,
        "gamma": gamma,
        "cache": cache,
        "metadata": metadata,
        "files": {
            name: {"path": str(path), "sha256": sha(path)}
            for name, path in paths.items()
        },
    }


def array(tensor):
    return tensor.float().numpy()


def operand(rank, name, side="outputs", index=0, shape=None):
    tensor = rank["modules"][name][side][index]
    require(
        tensor is not None and (shape is None or tuple(tensor.shape) == tuple(shape)),
        f"operand shape mismatch: {name}/{side}/{index}",
    )
    return array(tensor)


def analyze_rank(rank):
    import numpy as np

    meta, p = rank["metadata"], rank["parameters"]
    heads, kv, dim = meta["heads"], meta["kv_heads"], meta["head_dim"]
    hidden = p["o_proj.weight"].shape[0]
    intermediate = p["mlp.down_proj.weight"].shape[1]
    expected = {
        "qkv_proj.weight": ((2 * heads + 2 * kv) * dim, hidden),
        "o_proj.weight": (hidden, heads * dim),
        "mlp.gate_up_proj.weight": (2 * intermediate, hidden),
        "mlp.down_proj.weight": (hidden, intermediate),
    }
    for name, shape in expected.items():
        require(tuple(p[name].shape) == shape, f"parameter shape mismatch: {name}")
    for name in NORMS:
        require(
            tuple(p[name + ".weight"].shape)
            == ((dim,) if name in ("q_norm", "k_norm") else (hidden,)),
            "norm parameter shape mismatch",
        )
    continuity = (
        ("input_layernorm", "outputs", 0, "qkv_proj", "inputs", 0),
        ("post_attention_layernorm", "outputs", 0, "mlp.gate_up_proj", "inputs", 0),
        ("rotary_emb", "outputs", 0, "attn", "inputs", 0),
        ("rotary_emb", "outputs", 1, "attn", "inputs", 1),
        ("post_attention_layernorm", "outputs", 1, "next_input_layernorm", "inputs", 1),
        ("layer", "outputs", 0, "next_input_layernorm", "inputs", 0),
        ("layer", "outputs", 1, "next_input_layernorm", "inputs", 1),
    )
    for left, lside, li, right, rside, ri in continuity:
        require(
            np.array_equal(
                operand(rank, left, lside, li), operand(rank, right, rside, ri)
            ),
            f"captured boundary continuity mismatch: {left} -> {right}",
        )
    metrics = {}

    def metric(name, actual, reference):
        metrics[name] = {
            "fp32_reference": compare(actual, reference),
            "reference_rounded_bf16": compare(actual, round_bf16(reference)),
        }

    projections = (
        ("qkv_proj", "qkv_proj.weight"),
        ("o_proj", "o_proj.weight"),
        ("mlp.gate_up_proj", "mlp.gate_up_proj.weight"),
        ("mlp.down_proj", "mlp.down_proj.weight"),
    )
    local_refs = {}
    for module, weight in projections:
        x = operand(rank, module, "inputs", shape=(128, p[weight].shape[1]))
        actual = operand(rank, module, shape=(128, p[weight].shape[0]))
        reference = x @ array(p[weight]).T
        metric(module + ".gemm", actual, reference)
        local_refs[module] = reference
    packed = operand(rank, "qkv_proj")
    raw = split_qkv(packed, heads=heads, kv_heads=kv, dim=dim)
    projected = split_qkv(local_refs["qkv_proj"], heads=heads, kv_heads=kv, dim=dim)
    for name, actual, reference in zip(("q", "gate", "k", "v"), raw, projected):
        metric("qkv_proj." + name, actual, reference)
    qnorm = operand(rank, "rotary_emb", "inputs", 1, (128, heads * dim)).reshape(
        128, heads, dim
    )
    knorm = operand(rank, "rotary_emb", "inputs", 2, (128, kv * dim)).reshape(
        128, kv, dim
    )
    for name, value, normalized in (
        ("q_norm", raw[0], qnorm),
        ("k_norm", raw[2], knorm),
    ):
        metric(
            name,
            normalized,
            rmsnorm(value, array(rank["gamma"][name]), meta["eps"][name]),
        )
    positions_tensor = rank["modules"]["rotary_emb"]["inputs"][0]
    positions = validate_positions(
        positions_tensor.numpy(), module="rotary_emb", side="inputs", index=0
    )
    cache = array(rank["cache"])
    rotary_dim = meta["rotary_dim"]
    require(
        0 < rotary_dim <= dim
        and rotary_dim % 2 == 0
        and cache.ndim == 2
        and cache.shape == (meta["rotary_cache_prefix_rows"], rotary_dim)
        and positions.min() >= 0
        and positions.max() + 1 == cache.shape[0],
        "rotary cache prefix/position shape mismatch",
    )
    for name, value, nheads, index in (("q", qnorm, heads, 0), ("k", knorm, kv, 1)):
        actual = operand(
            rank, "rotary_emb", index=index, shape=(128, nheads * dim)
        ).reshape(128, nheads, dim)
        metric(
            "rope." + name + ".original_table_fp32",
            actual,
            rope(value, positions, cache, rotary_dim=rotary_dim),
        )
        metric(
            "rope." + name + ".table_cast_qdtype",
            actual,
            rope(value, positions, round_bf16(cache), rotary_dim=rotary_dim),
        )
    q = operand(rank, "attn", "inputs", 0, (128, heads * dim)).reshape(128, heads, dim)
    k = operand(rank, "attn", "inputs", 1, (128, kv * dim)).reshape(128, kv, dim)
    v = operand(rank, "attn", "inputs", 2, (128, kv * dim)).reshape(128, kv, dim)
    require(np.array_equal(v, raw[3]), "captured V continuity mismatch")
    actual_a = operand(rank, "attn", shape=(128, heads * dim)).reshape(128, heads, dim)
    metric("attention.causal_gqa", actual_a, causal_gqa(q, k, v, meta["scaling"]))
    gate = raw[1]
    sigmoid = np.exp(-np.logaddexp(np.float32(0), -gate))
    metric(
        "attention.sigmoid_gate",
        operand(rank, "o_proj", "inputs").reshape(128, heads, dim),
        actual_a * sigmoid,
    )
    gu = operand(rank, "mlp.gate_up_proj")
    g, up = np.split(gu, 2, axis=-1)
    metric(
        "mlp.silu_mul",
        operand(rank, "mlp.down_proj", "inputs"),
        g * np.exp(-np.logaddexp(np.float32(0), -g)) * up,
    )
    for name in ("input_layernorm", "post_attention_layernorm", "next_input_layernorm"):
        x = operand(rank, name, "inputs", 0, (128, hidden))
        residual = operand(rank, name, "inputs", 1, (128, hidden))
        actual_residual = operand(rank, name, index=1, shape=(128, hidden))
        metric(name + ".residual_add", actual_residual, x + residual)
        metric(
            name + ".rmsnorm_from_actual_residual",
            operand(rank, name, shape=(128, hidden)),
            rmsnorm(actual_residual, array(rank["gamma"][name]), meta["eps"][name]),
        )
    return {
        "metadata": meta,
        "files": rank["files"],
        "positions": positions.tolist(),
        "positions_original_shape": list(positions_tensor.shape),
        "metrics": metrics,
        "rope_precision_path_certified": False,
        "reference_scope": "Each operator uses its own captured BF16 operands; RoPE table precision has two candidates.",
    }, local_refs


def compare_model(ranks, refs):
    import numpy as np

    one, left, right = ranks
    result = {}
    # All three inputs may already differ. These are descriptive propagation comparisons.
    for name in ("input_layernorm", "post_attention_layernorm", "next_input_layernorm"):
        for side in ("inputs", "outputs"):
            result[name + "." + side + ".tp2_vs_tp1"] = compare(
                operand(left, name, side), operand(one, name, side)
            )
            result[name + "." + side + ".tp2_rank_equality"] = compare(
                operand(right, name, side), operand(left, name, side)
            )
    h, kv, dim = (
        left["metadata"]["heads"],
        left["metadata"]["kv_heads"],
        left["metadata"]["head_dim"],
    )
    raw = [
        split_qkv(
            operand(r, "qkv_proj"),
            heads=r["metadata"]["heads"],
            kv_heads=r["metadata"]["kv_heads"],
            dim=dim,
        )
        for r in ranks
    ]
    for i, key in enumerate(("raw_q", "raw_gate", "raw_k", "raw_v")):
        result[key] = compare(np.concatenate([raw[1][i], raw[2][i]], axis=1), raw[0][i])
    result["qkv_packed_logical_reassembly"] = compare(
        reassemble_packed(
            [operand(left, "qkv_proj"), operand(right, "qkv_proj")],
            sizes=[2 * h * dim, kv * dim, kv * dim],
        ),
        operand(one, "qkv_proj"),
    )
    for name, side, index, nheads in (
        ("rotary_emb", "inputs", 1, h),
        ("rotary_emb", "inputs", 2, kv),
        ("rotary_emb", "outputs", 0, h),
        ("rotary_emb", "outputs", 1, kv),
        ("attn", "inputs", 0, h),
        ("attn", "inputs", 1, kv),
        ("attn", "inputs", 2, kv),
        ("attn", "outputs", 0, h),
        ("o_proj", "inputs", 0, h),
    ):
        actual = np.concatenate(
            [
                operand(r, name, side, index).reshape(128, nheads, dim)
                for r in (left, right)
            ],
            axis=1,
        )
        result[f"{name}.{side}.{index}.head_reassembly"] = compare(
            actual, operand(one, name, side, index).reshape(128, 2 * nheads, dim)
        )
    width = left["parameters"]["mlp.down_proj.weight"].shape[1]
    result["mlp_gate_up_logical_reassembly"] = compare(
        reassemble_packed(
            [operand(left, "mlp.gate_up_proj"), operand(right, "mlp.gate_up_proj")],
            sizes=[width, width],
        ),
        operand(one, "mlp.gate_up_proj"),
    )
    result["mlp_activation_reassembly"] = compare(
        np.concatenate(
            [
                operand(left, "mlp.down_proj", "inputs"),
                operand(right, "mlp.down_proj", "inputs"),
            ],
            axis=-1,
        ),
        operand(one, "mlp.down_proj", "inputs"),
    )
    for module, boundary in (
        ("o_proj", "post_attention_layernorm"),
        ("mlp.down_proj", "next_input_layernorm"),
    ):
        actual_partials_sum = operand(left, module) + operand(right, module)
        fp32_local_ref_sum = refs[1][module] + refs[2][module]
        result[module + ".sum"] = {
            "actual_partials_fp32_sum_rounded_bf16_vs_each_return": [
                compare(operand(r, boundary, "inputs"), round_bf16(actual_partials_sum))
                for r in (left, right)
            ],
            "unrounded_fp32_local_references_vs_sum_return": compare(
                operand(left, boundary, "inputs"), fp32_local_ref_sum
            ),
            "tp1_partial_vs_return": compare(
                operand(one, boundary, "inputs"), operand(one, module)
            ),
        }
    result["interpretation"] = (
        "Cross-TP metrics include propagated input differences; SUM checks use actual observed BF16 partials. No new pass threshold or fix claim."
    )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        required=True,
        help="Directory containing the four fa7_diagnostic jobs",
    )
    parser.add_argument(
        "--jobs-manifest",
        type=Path,
        required=True,
        help="JSON selecting the four relative job directories",
    )
    parser.add_argument(
        "--output", type=Path, required=True, help="New private JSON report path"
    )
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    require(args.threads > 0, "threads must be positive")
    manifest = json.loads(args.jobs_manifest.read_text())
    selected_jobs = select_jobs(args.root, manifest)
    for key in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[key] = str(args.threads)
    require("torch_npu" not in sys.modules, "CPU analysis must start without torch_npu")
    sys.modules["torch_npu"] = None
    import torch

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "thresholds_added": False,
        "cpu_threads": args.threads,
        "core_source_sha256": CORE_SHA,
        "analyzer_sha256": sha(__file__),
        "models": {},
        "jobs_manifest": {
            "path": str(args.jobs_manifest),
            "sha256": sha(args.jobs_manifest),
            "selection": manifest,
        },
    }
    for model in ("4b", "9b"):
        ranks, references, analyses, cases, runs = [], [], {}, [], {}
        for tp in (1, 2):
            directory = selected_jobs[model][f"tp{tp}"]
            path = directory / "diagnostic.json"
            run = json.loads(path.read_text())
            validate_run(run)
            cases.append(run["case"])
            runs[f"tp{tp}"] = {
                "path": str(path),
                "sha256": sha(path),
                "guard_verified": True,
            }
            require(
                f"_{model}_" in run["case"]["case_id"]
                and len(run["case"]["input_ids"]) == 128
                and run["case"]["vector_count"] == (18 if model == "4b" else 10),
                "case frontier coverage mismatch",
            )
            for rank in range(tp):
                captured = load_rank(directory / f"rank_{rank}", rank, tp, torch)
                analysis, refs = analyze_rank(captured)
                ranks.append(captured)
                references.append(refs)
                analyses[f"tp{tp}_rank{rank}"] = analysis
        require(
            cases[0]["input_ids"] == cases[1]["input_ids"]
            and cases[0]["continuation_ids"] == cases[1]["continuation_ids"],
            "cross-TP case inputs differ",
        )
        require(
            all(
                analysis["positions"] == analyses["tp1_rank0"]["positions"]
                for analysis in analyses.values()
            ),
            "cross-TP positions differ",
        )
        report["models"][model] = {
            "runs": runs,
            "ranks": analyses,
            "cross_tp": compare_model(ranks, references),
        }
        del ranks, references
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "models": len(report["models"]),
                "rank_captures": 6,
                "diagnostic_only": True,
                "thresholds_added": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        # Private input paths belong in the saved report, never terminal output.
        print(
            json.dumps({"status": "failed", "error_type": type(error).__name__}),
            file=sys.stderr,
        )
        sys.exit(1)
