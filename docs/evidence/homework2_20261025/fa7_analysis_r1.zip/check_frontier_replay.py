#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Verify the new observer leaves all original fixed-frontier vectors intact."""

import hashlib
import json
import os
import sys
from pathlib import Path

assert "torch_npu" not in sys.modules
sys.modules["torch_npu"] = None
os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
import torch

torch.set_num_threads(8)
torch.set_num_interop_threads(1)
task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
source = task / "source_final"
raw = source / "results/raw/homework2_20261024"
state = json.loads((task / "fa7_diagnostic_r1_20261025/state.json").read_text())
retry = json.loads((task / "fa7_diagnostic_r2_20261025/state.json").read_text())
assert state["status"] == "failed" and len(state["finished"]) == 4
assert retry["status"] == "collected" and len(retry["finished"]) == 1
selected = json.loads(
    (task / "fa7_analysis_r1_20261025/selected_jobs.json").read_text()
)
all_jobs = {**state["finished"], **retry["finished"]}
assert all(
    all_jobs[name]["exit_code"] == 0 and all_jobs[name]["own_contexts_released"]
    for cases in selected.values()
    for name in cases.values()
)
result = {
    "diagnostic_only": True,
    "performance_eligible": False,
    "original_graph_failures_preserved": True,
    "source_manifest_sha256": "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3",
    "compared_vectors": 0,
    "all_vectors_bitwise_equal": True,
    "all_frontiers_and_decisions_equal": True,
    "models": {},
}
for model, count in (("4b", 18), ("9b", 10)):
    result["models"][model] = {}
    for tp in (1, 2):
        original = raw / f"first_layer_diagnostic_{model}_tp{tp}_20261024_r4"
        current = raw / selected[model][f"tp{tp}"]
        run = json.loads((current / "diagnostic.json").read_text())
        assert (
            run["status"] == "collected"
            and run["guard"]["sources_unchanged"]
            and run["guard"]["own_children_released"]
            and not run["guard"]["violations"]
        )
        records = []
        for rank in range(tp):
            for step in range(count):
                rel = f"rank_{rank}/step_{step:02d}.pt"
                one = original / rel
                two = current / rel
                a = torch.load(one, map_location="cpu", weights_only=True)
                b = torch.load(two, map_location="cpu", weights_only=True)
                fields = (
                    "rank",
                    "case_id",
                    "step",
                    "input_ids",
                    "positions",
                    "position_axes",
                    "prefix_length",
                    "original_dtype",
                    "raw_greedy_id",
                )
                metadata_equal = all(a[key] == b[key] for key in fields)
                aa = json.loads(one.with_suffix(".json").read_text())
                bb = json.loads(two.with_suffix(".json").read_text())
                equal = torch.equal(a["logits"], b["logits"])
                record = {
                    "rank": rank,
                    "step": step,
                    "original_sha256": hashlib.sha256(one.read_bytes()).hexdigest(),
                    "current_sha256": hashlib.sha256(two.read_bytes()).hexdigest(),
                    "logits_equal": equal,
                    "frontier_equal": metadata_equal,
                    "sampling_decision_equal": aa == bb,
                    "different_elements": int((a["logits"] != b["logits"]).sum()),
                    "max_abs": float((a["logits"] - b["logits"]).abs().max()),
                }
                result["compared_vectors"] += 1
                result["all_vectors_bitwise_equal"] &= equal
                result["all_frontiers_and_decisions_equal"] &= (
                    metadata_equal and aa == bb
                )
                records.append(record)
        result["models"][model][f"tp{tp}"] = records
assert result["compared_vectors"] == 84
path = task / "fa7_frontier_replay_check_20261025.json"
with path.open("x") as f:
    json.dump(result, f, indent=2)
print(
    json.dumps(
        {
            key: result[key]
            for key in (
                "compared_vectors",
                "all_vectors_bitwise_equal",
                "all_frontiers_and_decisions_equal",
            )
        }
    )
)
