#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU analysis only, after every selected capture and replay has passed."""

import json
import os
import subprocess
from pathlib import Path

task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
source = task / "source_final"
tools = task / "fa7_analysis_r1_20261025"
assert json.loads((tools / "preparation.json").read_text())["passed"]
env = dict(os.environ)
env.update(
    TORCH_DEVICE_BACKEND_AUTOLOAD="0",
    ASCEND_RT_VISIBLE_DEVICES="",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONPATH=str(tools),
    OMP_NUM_THREADS="8",
)
output = task / "fa7_analysis_20261025.json"
with (tools / "analysis.log").open("x") as log:
    p = subprocess.run(
        [
            str(source / ".conda-env/bin/python"),
            "-B",
            str(tools / "invoke.py"),
            "--root",
            str(source / "results/raw/homework2_20261024"),
            "--jobs-manifest",
            str(tools / "selected_jobs.json"),
            "--output",
            str(output),
            "--threads",
            "8",
        ],
        env=env,
        stdout=log,
        stderr=subprocess.STDOUT,
        timeout=600,
    )
record = {
    "status": "passed" if p.returncode == 0 else "failed",
    "exit_code": p.returncode,
    "npu_execution": False,
    "output_exists": output.exists(),
}
(tools / "state.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record))
