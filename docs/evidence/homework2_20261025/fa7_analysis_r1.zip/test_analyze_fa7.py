#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent NumPy tests, runnable without Torch or NPU."""

import importlib.util
from pathlib import Path

import numpy as np
import pytest


@pytest.fixture
def analyzer():
    path = Path(__file__).with_name("analyze_fa7.py")
    assert path.exists(), "FA7 analyzer is not implemented"
    spec = importlib.util.spec_from_file_location("analyze_fa7_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_qgate_head_layout_and_packed_rank_reassembly(analyzer):
    left = np.arange(12, dtype=np.float32).reshape(1, 12)
    right = left + 100
    q, gate, k, v = analyzer.split_qkv(left, heads=2, kv_heads=1, dim=2)
    np.testing.assert_array_equal(q, [[[0, 1], [4, 5]]])
    np.testing.assert_array_equal(gate, [[[2, 3], [6, 7]]])
    np.testing.assert_array_equal(k, [[[8, 9]]])
    np.testing.assert_array_equal(v, [[[10, 11]]])
    joined = analyzer.reassemble_packed([left, right], sizes=[8, 2, 2])
    np.testing.assert_array_equal(
        joined,
        np.array(
            [[*range(8), *range(100, 108), 8, 9, 108, 109, 10, 11, 110, 111]],
            dtype=np.float32,
        ),
    )
    assert not np.array_equal(joined, np.concatenate([left, right], axis=-1))


def test_causal_gqa_maps_four_query_heads_to_one_kv_head(analyzer):
    q = np.zeros((3, 8, 2), dtype=np.float32)
    k = np.zeros((3, 2, 2), dtype=np.float32)
    v = np.zeros_like(k)
    v[:, 0, :] = np.array([1, 3, 8], dtype=np.float32)[:, None]
    v[:, 1, :] = np.array([10, 30, 80], dtype=np.float32)[:, None]
    out = analyzer.causal_gqa(q, k, v, 0.5)
    np.testing.assert_allclose(out[:, 0, 0], [1, 2, 4])
    np.testing.assert_allclose(out[:, 7, 0], [10, 20, 40])


def test_rope_uses_positions_half_rotation_and_preserves_tail(analyzer):
    x = np.array([[[1, 2, 7, 8]], [[3, 4, 9, 10]]], dtype=np.float32)
    table = np.array([[1, 0], [0, 1]], dtype=np.float32)
    got = analyzer.rope(x, np.array([1, 0]), table, rotary_dim=2)
    np.testing.assert_array_equal(got, [[[-2, 1, 7, 8]], [[3, 4, 9, 10]]])


def test_bf16_rounds_ties_to_even_without_chained_low_precision_sum(analyzer):
    source = np.array([1.00390625, 1.01171875, -1.00390625], dtype=np.float32)
    np.testing.assert_array_equal(analyzer.round_bf16(source), [1.0, 1.015625, -1.0])
    partials = [np.array([256.0], dtype=np.float32), np.array([1.0], dtype=np.float32)]
    np.testing.assert_array_equal(analyzer.round_bf16(sum(partials)), [256.0])


def test_metrics_zero_reference_and_nonfinite_are_explicit(analyzer):
    assert analyzer.compare(np.zeros((2, 2)), np.zeros((2, 2)))["relative_l2"] == 0
    assert analyzer.compare(np.ones((2, 2)), np.zeros((2, 2)))["relative_l2"] is None
    with pytest.raises(ValueError, match="finite"):
        analyzer.compare(np.array([np.nan]), np.array([0]))
    with pytest.raises(ValueError, match="shape"):
        analyzer.compare(np.ones(2), np.ones(3))


def test_rmsnorm_keeps_effective_gamma_fp32(analyzer):
    x = np.array([[1, 1]], dtype=np.float32)
    gamma = np.array([1.00390625, 1.0009765625], dtype=np.float32)
    np.testing.assert_allclose(
        analyzer.rmsnorm(x, gamma, 0.0), gamma[None, :], rtol=0, atol=0
    )


def test_run_guard_rejects_stale_source_and_uncollected_status(analyzer):
    record = {
        "status": "collected",
        "diagnostic_only": True,
        "execution_mode": "eager",
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "guard": {
            "sources_sha": analyzer.CORE_SHA,
            "sources_after_sha": analyzer.CORE_SHA,
            "sources_unchanged": True,
            "own_children_released": True,
            "violations": [],
        },
    }
    analyzer.validate_run(record)
    for field, value in (
        ("sources_sha", "bad"),
        ("sources_after_sha", "bad"),
        ("sources_unchanged", False),
        ("own_children_released", False),
        ("violations", ["bad"]),
    ):
        bad = {**record, "guard": {**record["guard"], field: value}}
        with pytest.raises(ValueError, match="guard"):
            analyzer.validate_run(bad)
    with pytest.raises(ValueError, match="collected"):
        analyzer.validate_run({**record, "status": "running"})
    with pytest.raises(ValueError, match="collected"):
        analyzer.validate_run({**record, "status": "captured_pending_guard_exit"})


@pytest.mark.parametrize("module", ["layer", "rotary_emb"])
def test_positions_allow_only_text_128_or_three_equal_axes(analyzer, module):
    positions = np.arange(128, dtype=np.int64)
    for source in (positions, np.repeat(positions[None], 3, axis=0)):
        actual = analyzer.validate_positions(
            source, module=module, side="inputs", index=0
        )
        np.testing.assert_array_equal(actual, positions)
    unequal = np.repeat(positions[None], 3, axis=0)
    unequal[1, 7] += 1
    for bad in (
        unequal,
        np.arange(127),
        positions[None],
        np.zeros((3, 127), dtype=np.int64),
        positions.astype(np.float32),
    ):
        with pytest.raises(ValueError, match="positions"):
            analyzer.validate_positions(bad, module=module, side="inputs", index=0)


@pytest.mark.parametrize(
    "module,side,index",
    [("qkv_proj", "inputs", 0), ("layer", "outputs", 0), ("rotary_emb", "inputs", 1)],
)
def test_integer_positions_cannot_appear_in_other_operand_slots(
    analyzer, module, side, index
):
    with pytest.raises(ValueError, match="positions"):
        analyzer.validate_positions(
            np.arange(128), module=module, side=side, index=index
        )


def test_jobs_manifest_selects_r2_without_relabelling_r1(analyzer):
    tmp_path = Path(__file__).resolve().parent / "analysis_manifest_test_root"
    jobs = {
        model: {
            f"tp{tp}": f"fa7_diagnostic_{model}_tp{tp}_20261025_r{2 if model == '9b' and tp == 2 else 1}"
            for tp in (1, 2)
        }
        for model in ("4b", "9b")
    }
    selected = analyzer.select_jobs(tmp_path, jobs)
    assert selected["9b"]["tp2"] == tmp_path / "fa7_diagnostic_9b_tp2_20261025_r2"
    assert jobs["9b"]["tp2"].endswith("_r2")
    for path in ("../outside", str(tmp_path.parent / "outside"), "C:\\outside"):
        bad = {**jobs, "9b": {**jobs["9b"], "tp2": path}}
        with pytest.raises(ValueError, match="manifest"):
            analyzer.select_jobs(tmp_path, bad)
    with pytest.raises(ValueError, match="manifest"):
        analyzer.select_jobs(tmp_path, {"4b": jobs["4b"]})
