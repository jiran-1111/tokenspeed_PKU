#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture
def ref():
    p = Path(__file__).with_name("projection_reference.py")
    assert p.exists(), "projection reference not implemented"
    spec = importlib.util.spec_from_file_location("projection_under_test", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_column_sharding_splits_every_packed_segment(ref):
    w = np.arange(36, dtype=np.float32).reshape(18, 2)
    result = ref.column_shard(w, widths=[4, 4, 8, 2], rank=1, tp=2)
    np.testing.assert_array_equal(
        result, np.concatenate([w[2:4], w[6:8], w[12:16], w[17:18]])
    )
    assert not np.array_equal(result, w[9:])


def test_row_shard_selects_input_columns(ref):
    w = np.arange(24, dtype=np.float32).reshape(3, 8)
    np.testing.assert_array_equal(ref.row_shard(w, rank=1, tp=2), w[:, 4:])


def test_invalid_packed_width_and_rank_rejected(ref):
    with pytest.raises(ValueError):
        ref.column_shard(np.zeros((6, 2)), widths=[3, 3], rank=0, tp=2)
    with pytest.raises(ValueError):
        ref.row_shard(np.zeros((3, 4)), rank=2, tp=2)


def test_gated_norm_uses_mean_and_no_gemma_weight_offset(ref):
    x = np.array([[3.0, 4.0], [6.0, 8.0]], dtype=np.float32)
    z = np.zeros_like(x)
    np.testing.assert_array_equal(
        ref.gated_norm(x, z, np.array([2.0, 3.0]), eps=0.5), np.zeros_like(x)
    )
    z[:] = np.float32(1)
    expected = (
        x
        / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + np.float32(0.5))
        * np.array([2.0, 3.0], dtype=np.float32)
        / np.float32(1 + np.exp(-1.0))
    )
    np.testing.assert_allclose(
        ref.gated_norm(x, z, np.array([2.0, 3.0]), eps=0.5),
        expected,
        rtol=4 * np.finfo(np.float32).eps,
    )


def test_gated_norm_preserves_operands_and_checks_shape(ref):
    x = np.ones((2, 3), np.float32)
    z = x * 2
    before = x.copy()
    ref.gated_norm(x, z, np.ones(3), eps=1e-6)
    np.testing.assert_array_equal(x, before)
    with pytest.raises(ValueError):
        ref.gated_norm(x, z, np.ones(2), eps=1e-6)


def test_silu_mul_uses_gate_half_then_up_half(ref):
    gu = np.array([[0.0, 1.0, 3.0, 2.0]], dtype=np.float32)
    expected = np.array([[0.0, 2 / (1 + np.exp(-1.0))]], dtype=np.float32)
    np.testing.assert_allclose(
        ref.silu_mul(gu), expected, rtol=4 * np.finfo(np.float32).eps
    )


def test_gemm_orientation_and_shape(ref):
    x = np.array([[2.0, 3.0]], dtype=np.float32)
    w = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]], dtype=np.float32)
    np.testing.assert_array_equal(ref.gemm(x, w), [[8.0, 18.0, 28.0]])
    with pytest.raises(ValueError):
        ref.gemm(x, w.T)


def test_layer_references_use_each_actual_input_and_do_not_cascade(ref):
    modules = {}

    def put(name, inputs, output):
        modules["l8." + name] = {"inputs": inputs, "outputs": [output]}

    put(
        "linear_attn.in_proj_qkvzba",
        [np.ones((1, 2), np.float32)],
        np.ones((1, 12352), np.float32),
    )
    put(
        "linear_attn.norm",
        [np.ones((32, 128), np.float32), np.ones((32, 128), np.float32)],
        np.zeros((32, 128), np.float32),
    )
    put(
        "linear_attn.out_proj",
        [np.full((1, 4096), 3, np.float32)],
        np.zeros((1, 2), np.float32),
    )
    put("mlp.gate_up_proj", [np.ones((1, 2), np.float32)], np.ones((1, 8), np.float32))
    put("mlp.down_proj", [np.full((1, 4), 5, np.float32)], np.zeros((1, 2), np.float32))
    data = {
        "modules": modules,
        "observed": {
            "backend": {
                8: {
                    "decode": {
                        "mixed_qkv": np.ones((1, 8192), np.float32),
                        "z": np.ones((1, 32, 128), np.float32),
                        "b": np.ones((1, 32), np.float32),
                        "a": np.ones((1, 32), np.float32),
                    }
                }
            }
        },
    }
    cached = SimpleNamespace(
        operand=lambda d, n, side="outputs", index=0: d["modules"][n][side][index],
        compare=lambda a, b: {"reference_sum": float(np.sum(b))},
        storage_reference=lambda x, dtype: x,
    )
    weights = {
        "in": np.zeros((12352, 2), np.float32),
        "out": np.ones((2, 4096), np.float32),
        "gu": np.zeros((8, 2), np.float32),
        "down": np.ones((2, 4), np.float32),
        "norm": np.ones(128, np.float32),
    }
    _, refs, _ = ref.analyze_layer(
        data, layer=8, rank=0, tp=1, weights=weights, eps=1e-6, cached=cached
    )
    np.testing.assert_array_equal(refs["linear_attn.out_proj"], [[12288, 12288]])
    np.testing.assert_array_equal(refs["mlp.down_proj"], [[20, 20]])
    assert np.any(refs["linear_attn.norm"])
    assert np.any(refs["mlp.silu_mul"])


def test_cli_declares_required_inputs_without_loading_torch(ref):
    path = Path(__file__).with_name("projection_reference.py")
    p = subprocess.run(
        [sys.executable, "-B", str(path), "--help"], capture_output=True, text=True
    )
    assert p.returncode == 0
    for flag in ("--root", "--jobs-manifest", "--source-root", "--output", "--threads"):
        assert flag in p.stdout
