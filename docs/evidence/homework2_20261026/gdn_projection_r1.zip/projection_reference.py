#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Own-operand CPU references using checkpoint-expected GDN/MLP weights.

Captured projection/norm weights are unavailable. These references do not
certify their actual runtime identity or introduce acceptance thresholds.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def column_shard(weight, *, widths, rank, tp):
    import numpy as np

    w = np.asarray(weight)
    require(
        w.ndim == 2
        and tp > 0
        and 0 <= rank < tp
        and sum(widths) == w.shape[0]
        and all(v > 0 and v % tp == 0 for v in widths),
        "column shard geometry mismatch",
    )
    return np.concatenate(
        [
            np.split(v, tp, axis=0)[rank]
            for v in np.split(w, np.cumsum(widths)[:-1], axis=0)
        ],
        axis=0,
    )


def row_shard(weight, *, rank, tp):
    import numpy as np

    w = np.asarray(weight)
    require(
        w.ndim == 2 and tp > 0 and 0 <= rank < tp and w.shape[1] % tp == 0,
        "row shard geometry mismatch",
    )
    return np.split(w, tp, axis=1)[rank].copy()


def sigmoid(x):
    import numpy as np

    e = np.exp(-np.abs(x))
    return np.where(x >= 0, 1 / (1 + e), e / (1 + e))


def gated_norm(x, z, weight, *, eps):
    import numpy as np

    x, z, w = [np.asarray(v, dtype=np.float32) for v in (x, z, weight)]
    require(
        x.ndim == 2 and z.shape == x.shape and w.shape == (x.shape[-1],) and eps > 0,
        "gated norm geometry mismatch",
    )
    return (
        x
        / np.sqrt(
            np.mean(x * x, axis=-1, keepdims=True, dtype=np.float32) + np.float32(eps)
        )
        * w
        * (z * sigmoid(z))
    )


def silu_mul(gu):
    import numpy as np

    gu = np.asarray(gu, dtype=np.float32)
    require(gu.ndim == 2 and gu.shape[-1] % 2 == 0, "gate/up geometry mismatch")
    gate, up = np.split(gu, 2, axis=-1)
    return gate * sigmoid(gate) * up


def gemm(x, weight):
    import numpy as np

    x, w = [np.asarray(v, dtype=np.float32) for v in (x, weight)]
    require(
        x.ndim == w.ndim == 2 and x.shape[-1] == w.shape[-1], "GEMM geometry mismatch"
    )
    return x @ w.T


def analyze_layer(data, *, layer, rank, tp, weights, eps, cached):
    import numpy as np

    op = lambda name, side="outputs", index=0: cached.operand(
        data, f"l{layer}.{name}", side, index
    )
    qkvzba = weights["in"]
    gu = weights["gu"]
    matrices = {
        "linear_attn.in_proj_qkvzba": column_shard(
            qkvzba, widths=[2048, 2048, 4096, 4096, 32, 32], rank=rank, tp=tp
        ),
        "linear_attn.out_proj": row_shard(weights["out"], rank=rank, tp=tp),
        "mlp.gate_up_proj": column_shard(
            gu, widths=[gu.shape[0] // 2] * 2, rank=rank, tp=tp
        ),
        "mlp.down_proj": row_shard(weights["down"], rank=rank, tp=tp),
    }
    refs = {name: gemm(op(name, "inputs"), w) for name, w in matrices.items()}
    refs["linear_attn.norm"] = gated_norm(
        op("linear_attn.norm", "inputs", 0),
        op("linear_attn.norm", "inputs", 1),
        weights["norm"],
        eps=eps,
    )
    refs["mlp.silu_mul"] = silu_mul(op("mlp.gate_up_proj"))
    actual = {name: op(name) for name in matrices}
    actual["linear_attn.norm"] = op("linear_attn.norm")
    actual["mlp.silu_mul"] = op("mlp.down_proj", "inputs")
    metrics = {
        name: {
            "fp32": cached.compare(actual[name], value),
            "final_bf16_candidate": cached.compare(
                actual[name], cached.storage_reference(value, "torch.bfloat16")
            ),
        }
        for name, value in refs.items()
    }
    backend = data["observed"]["backend"][layer]
    raw = op("linear_attn.in_proj_qkvzba")
    split = np.split(
        raw,
        np.cumsum([2048 // tp, 2048 // tp, 4096 // tp, 4096 // tp, 32 // tp]),
        axis=-1,
    )
    continuity = {
        "projected_qkv_to_decode": cached.compare(
            backend["decode"]["mixed_qkv"], np.concatenate(split[:3], axis=-1)
        ),
        "projected_z_to_decode": cached.compare(
            backend["decode"]["z"].reshape(1, -1), split[3]
        ),
        "projected_b_to_decode": cached.compare(backend["decode"]["b"], split[4]),
        "projected_a_to_decode": cached.compare(backend["decode"]["a"], split[5]),
        "gated_norm_to_out_proj": cached.compare(
            op("linear_attn.out_proj", "inputs"), op("linear_attn.norm").reshape(1, -1)
        ),
    }
    return (
        {
            "metrics": metrics,
            "continuity": continuity,
            "runtime_projection_and_norm_weights_certified": False,
        },
        refs,
        actual,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "jobs-manifest", "source-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    require(args.threads > 0, "threads must be positive")
    for key in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[key] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    require("torch_npu" not in sys.modules, "CPU analyzer cannot start with torch_npu")
    sys.modules["torch_npu"] = None
    import hashlib

    import analyze_cached as cached
    import numpy as np
    import torch
    from safetensors import safe_open

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    source = args.source_root.resolve()
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(cached.sha(core) == cached.CORE_SHA, "source manifest mismatch")
    manifest = json.loads(core.read_text())
    require(
        len(manifest) == 1531
        and all(cached.sha(source / n) == s for n, s in manifest.items()),
        "source file mismatch",
    )
    config_path = source / "configs/homework2/qwen35_9b_tp1.yaml"
    config = json.loads(config_path.read_text())
    require(
        config["model_revision"] == "c202236235762e1c871ad0ccb60c8ee5ba337b9a"
        and config["dtype"] == "bfloat16",
        "model protocol mismatch",
    )
    checkpoint = source / config["local_model_path"]
    config_model = checkpoint / "config.json"
    text_config = json.loads(config_model.read_text())["text_config"]
    require(
        text_config["linear_num_key_heads"] == 16
        and text_config["linear_num_value_heads"] == 32
        and text_config["linear_key_head_dim"]
        == text_config["linear_value_head_dim"]
        == 128
        and text_config["hidden_act"] == "silu",
        "checkpoint geometry/activation mismatch",
    )
    indices = list(checkpoint.glob("*.safetensors.index.json"))
    require(len(indices) == 1, "checkpoint index ambiguity")
    index = json.loads(indices[0].read_text())["weight_map"]
    selection = json.loads(args.jobs_manifest.read_text())
    jobs = cached.select_jobs(args.root, selection)
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "thresholds_added": False,
        "original_graph_failures_preserved": True,
        "core_source_sha256": cached.CORE_SHA,
        "configured_model_revision": config["model_revision"],
        "runtime_projection_and_norm_weights_certified": False,
        "analyzer_sha256": cached.sha(__file__),
        "dependency_sha256": cached.sha(Path(__file__).with_name("analyze_cached.py")),
        "checkpoint_config_sha256": cached.sha(config_model),
        "checkpoint_index_sha256": cached.sha(indices[0]),
        "selection": selection,
        "ranks": {},
        "layers": {},
        "scope": "Checkpoint-expected BF16 matrices/norm with each actual input. Only captured conv/A_log/dt_bias receive actual runtime/checkpoint identity checks; no full-model oracle or fix.",
    }
    captures = []
    cases = []
    for tp in (1, 2):
        directory = jobs[f"tp{tp}"]
        run = json.loads((directory / "diagnostic.json").read_text())
        cached.validate_run(run)
        case = run["case"]
        cases.append(case)
        require(
            "_9b_" in case["case_id"]
            and len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) == 9
            and case["vector_count"] == 10,
            "case mismatch",
        )
        for rank in range(tp):
            path = directory / f"rank_{rank}/cached_step8.pt"
            dtypes = {}
            data = cached.convert_tensors(
                torch.load(path, map_location="cpu", weights_only=True),
                torch=torch,
                dtypes=dtypes,
            )
            cached.validate_capture(data, dtypes, rank=rank, tp=tp)
            require(
                data["metadata"]["case_id"] == case["case_id"], "capture case mismatch"
            )
            require(
                json.loads(json.dumps(data["metadata"]))
                == json.loads(path.with_name("cached_step8_metadata.json").read_text()),
                "sidecar mismatch",
            )
            captures.append((tp, rank, data))
            report["ranks"][f"tp{tp}_rank{rank}"] = {
                "capture_sha256": cached.sha(path),
                "metadata_sha256": cached.sha(
                    path.with_name("cached_step8_metadata.json")
                ),
            }
    require(
        cases[0]["input_ids"] == cases[1]["input_ids"]
        and cases[0]["continuation_ids"] == cases[1]["continuation_ids"],
        "cross-TP case mismatch",
    )
    for layer in (8, 9, 10):
        identities = {}

        def get(suffix, *, dtype):
            key = f"model.language_model.layers.{layer}.{suffix}"
            with safe_open(
                checkpoint / index[key], framework="pt", device="cpu"
            ) as reader:
                original = reader.get_tensor(key)
            value = original.to(dtype=dtype).contiguous()
            digest = lambda t: hashlib.sha256(
                t.contiguous().view(torch.uint8).numpy().tobytes()
            ).hexdigest()
            identities[suffix] = {
                "checkpoint_dtype": str(original.dtype),
                "checkpoint_tensor_sha256": digest(original),
                "expected_runtime_dtype": str(dtype),
                "expected_runtime_tensor_sha256": digest(value),
                "shape": list(value.shape),
            }
            return value.float().numpy()

        qkv = get("linear_attn.in_proj_qkv.weight", dtype=torch.bfloat16)
        z = get("linear_attn.in_proj_z.weight", dtype=torch.bfloat16)
        b = get("linear_attn.in_proj_b.weight", dtype=torch.bfloat16)
        a = get("linear_attn.in_proj_a.weight", dtype=torch.bfloat16)
        weights = {
            "in": np.concatenate([qkv, z, b, a], axis=0),
            "out": get("linear_attn.out_proj.weight", dtype=torch.bfloat16),
            "gu": np.concatenate(
                [
                    get("mlp.gate_proj.weight", dtype=torch.bfloat16),
                    get("mlp.up_proj.weight", dtype=torch.bfloat16),
                ],
                axis=0,
            ),
            "down": get("mlp.down_proj.weight", dtype=torch.bfloat16),
            "norm": get("linear_attn.norm.weight", dtype=torch.bfloat16),
        }
        conv = get("linear_attn.conv1d.weight", dtype=torch.bfloat16)
        require(conv.shape == (8192, 1, 4), "conv checkpoint geometry mismatch")
        conv = conv[:, 0, :]
        alog = get("linear_attn.A_log", dtype=torch.float32)
        dt = get("linear_attn.dt_bias", dtype=torch.float32)
        metrics = {}
        references = []
        actuals = []
        checks = {}
        for tp, rank, data in captures:
            name = f"tp{tp}_rank{rank}"
            scan = data["observed"]["backend"][layer]["scan"]
            actualconv = data["observed"]["backend"][layer]["decode"]["conv_weights"]
            checks[name] = {
                "conv": cached.compare(
                    actualconv,
                    column_shard(conv, widths=[2048, 2048, 4096], rank=rank, tp=tp),
                ),
                "A_log": cached.compare(scan["A_log"], np.split(alog, tp)[rank]),
                "dt_bias": cached.compare(scan["dt_bias"], np.split(dt, tp)[rank]),
            }
            require(
                all(v["value_bits_equal"] for v in checks[name].values()),
                "captured checkpoint operand mismatch",
            )
            metric, refs, actual = analyze_layer(
                data,
                layer=layer,
                rank=rank,
                tp=tp,
                weights=weights,
                eps=text_config["rms_norm_eps"],
                cached=cached,
            )
            metrics[name] = metric
            references.append(refs)
            actuals.append(actual)
        cross = {}
        widths = {
            "linear_attn.in_proj_qkvzba": [1024, 1024, 2048, 2048, 16, 16],
            "mlp.gate_up_proj": [weights["down"].shape[1] // 2] * 2,
        }
        for name in references[0]:

            def combine(rows):
                if name in widths:
                    return cached.join_packed(
                        [r[name] for r in rows[1:]], widths=widths[name], axis=1
                    )
                if name in ("linear_attn.out_proj", "mlp.down_proj"):
                    return rows[1][name] + rows[2][name]
                return np.concatenate(
                    [r[name] for r in rows[1:]],
                    axis=0 if name == "linear_attn.norm" else 1,
                )

            cross[name] = {
                "checkpoint_math_TP2_vs_TP1": cached.compare(
                    combine(references), references[0][name]
                ),
                "actual_TP2_vs_TP1": cached.compare(combine(actuals), actuals[0][name]),
                "row_projection_actual_is_fp32_sum_of_bf16_partials": name
                in ("linear_attn.out_proj", "mlp.down_proj"),
            }
        report["layers"][str(layer)] = {
            "checkpoint_tensor_identities": identities,
            "captured_parameter_checks": checks,
            "ranks": metrics,
            "cross_tp": cross,
        }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "passed": True,
                "layers": 3,
                "rank_captures": 3,
                "actual_projection_weights_certified": False,
                "npu_execution": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "reason": (
                        str(error)[:200]
                        if isinstance(error, ValueError)
                        else "see retained original input identities"
                    ),
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)
