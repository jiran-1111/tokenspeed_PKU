#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest


@pytest.fixture
def p():
    path = Path(__file__).with_name("quality_protocol.py")
    assert path.exists(), "protocol helper not implemented"
    spec = importlib.util.spec_from_file_location("quality_protocol_under_test", path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_fixed_history_makes_common_inputs_without_model_generated_history(p):
    cases = [
        SimpleNamespace(name="single", category="math", turns=["37*19?"]),
        SimpleNamespace(
            name="multi",
            category="multi_turn",
            turns=["Remember A", "Remember B", "What are A/B?"],
        ),
    ]
    rows = p.build_requests(
        cases, fixed_assistant_history={"single": [], "multi": ["OK A", "OK B"]}
    )
    assert len(rows) == 4
    assert rows[-1]["messages"] == [
        {"role": "user", "content": "Remember A"},
        {"role": "assistant", "content": "OK A"},
        {"role": "user", "content": "Remember B"},
        {"role": "assistant", "content": "OK B"},
        {"role": "user", "content": "What are A/B?"},
    ]
    rows[-1]["messages"][0]["content"] = "changed"
    assert rows[-2]["messages"][0]["content"] == "Remember A"


def test_missing_or_extra_fixed_history_rejected(p):
    cases = [SimpleNamespace(name="multi", category="multi_turn", turns=["A", "B"])]
    with pytest.raises(ValueError):
        p.build_requests(cases, fixed_assistant_history={"multi": []})
    with pytest.raises(ValueError):
        p.build_requests(cases, fixed_assistant_history={"multi": ["ok"], "other": []})


def test_duplicate_and_unsafe_case_ids_rejected(p):
    case = SimpleNamespace(name="one", category="x", turns=["A"])
    with pytest.raises(ValueError):
        p.build_requests([case, case], fixed_assistant_history={"one": []})
    case = SimpleNamespace(name="../one", category="x", turns=["A"])
    with pytest.raises(ValueError):
        p.build_requests([case], fixed_assistant_history={"../one": []})


def test_tokenizer_receives_frozen_explicit_options(p):
    calls = []

    def tokenize(messages, **kwargs):
        calls.append((messages, kwargs))
        return [1, 2, 3]

    tokenizer = SimpleNamespace(apply_chat_template=tokenize)
    assert p.tokenize_request(
        tokenizer,
        messages=[{"role": "user", "content": "X"}],
        thinking_enabled=False,
        max_model_len=10,
        max_new_tokens=4,
    ) == [1, 2, 3]
    assert calls[0][1] == {
        "tokenize": True,
        "add_generation_prompt": True,
        "enable_thinking": False,
    }


def test_oversize_inputs_not_silently_truncated(p):
    tokenizer = SimpleNamespace(apply_chat_template=lambda *a, **kw: [1] * 8)
    with pytest.raises(ValueError):
        p.tokenize_request(
            tokenizer,
            messages=[],
            thinking_enabled=False,
            max_model_len=10,
            max_new_tokens=4,
        )


def test_stop_ids_preserve_union_and_reject_bool(p):
    assert p.stop_ids(model_eos=7, generation_eos=[8, 7], tokenizer_eos=7) == [7, 8]
    with pytest.raises(ValueError):
        p.stop_ids(model_eos=7, generation_eos=True, tokenizer_eos=7)


def test_missing_optional_generation_metadata_uses_explicit_model_and_tokenizer_eos(p):
    assert p.stop_ids(model_eos=248044, generation_eos=None, tokenizer_eos=248044) == [
        248044
    ]
    assert p.stop_ids(model_eos=[7, 8], generation_eos=[9, 8], tokenizer_eos=None) == [
        7,
        8,
        9,
    ]
    with pytest.raises(ValueError):
        p.stop_ids(model_eos=None, generation_eos=None, tokenizer_eos=None)
