#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Tokenize and freeze all eight requests before any new quality generation."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

from quality_protocol import build_requests, stop_ids, tokenize_request


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-new-tokens", type=int, required=True)
    parser.add_argument("--thinking-enabled", choices=("true", "false"), required=True)
    args = parser.parse_args()
    if args.thinking_enabled != "false" or args.max_new_tokens != 128:
        raise ValueError("this frozen cohort requires no-thinking and max128")
    source = args.source_root.resolve()
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    if sha(core) != "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3":
        raise ValueError("core manifest mismatch")
    manifest = json.loads(core.read_text(encoding="utf-8"))
    if len(manifest) != 1531 or not all(
        sha(source / n) == s for n, s in manifest.items()
    ):
        raise ValueError("core source mismatch")
    sys.path.insert(0, str(source))
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    sys.modules["torch_npu"] = None
    from benchmarks.course_project.correctness import build_correctness_cases
    from transformers import AutoTokenizer

    cases = build_correctness_cases()
    history = {
        name: []
        for name in (
            "chinese_beijing",
            "english_capital",
            "math_arithmetic",
            "code_python",
            "long_context_recall",
        )
    }
    history["multi_turn_memory"] = [
        "已记住项目代号：天枢。",
        "已记住硬件型号：Ascend 910C。",
    ]
    rows = build_requests(cases, fixed_assistant_history=history)
    if len(rows) != 8:
        raise ValueError("expected original six categories/eight turns")
    artifacts_path = source / "docs/evidence/homework2_20261023/model_artifacts.json"
    artifacts = json.loads(artifacts_path.read_text(encoding="utf-8"))["models"]
    record = {
        "schema_version": 1,
        "protocol": "semantic_no_thinking_fixed_history_20261026",
        "source_manifest_sha256": sha(core),
        "model_artifacts_sha256": sha(artifacts_path),
        "thinking_enabled": False,
        "max_new_tokens": 128,
        "greedy": True,
        "stop_at_eos": True,
        "fixed_history_source": "predeclared assistant acknowledgements, independent of every generated answer",
        "requests": rows,
        "fixed_assistant_history": history,
        "models": {},
        "complete_logits_collected": False,
        "new_pass_threshold": None,
        "replaces_original_failures": False,
        "scope": "Independent multi-input output/quality observations, not HW1 vector gate, Session state, tool-wait, or performance.",
    }
    for name in ("0.8b", "4b", "9b", "27b"):
        config_names = {
            f"tp{tp}": (
                f"configs/homework2/candidates/qwen35_27b_tp{tp}_memory095.yaml"
                if name == "27b"
                else f"configs/homework2/qwen35_{name}_tp{tp}.yaml"
            )
            for tp in (1, 2)
        }
        configs = {
            key: json.loads((source / value).read_text(encoding="utf-8"))
            for key, value in config_names.items()
        }
        config = configs["tp1"]
        artifact_matches = [
            v
            for v in artifacts
            if (v["model_id"], v["model_revision"])
            == (config["model_id"], config["model_revision"])
        ]
        if len(artifact_matches) != 1:
            raise ValueError("no unique previously verified model artifact identity")
        expected_files = artifact_matches[0]["files"]
        common = lambda c: {k: v for k, v in c.items() if k != "tp_size"}
        if common(config) != common(configs["tp2"]):
            raise ValueError("paired quality configs differ beyond TP")
        checkpoint = source / config["local_model_path"]
        tokenizer = AutoTokenizer.from_pretrained(
            checkpoint,
            revision=config["model_revision"],
            local_files_only=True,
            trust_remote_code=False,
        )
        model_metadata = json.loads(
            (checkpoint / "config.json").read_text(encoding="utf-8")
        )
        model_eos = model_metadata["text_config"]["eos_token_id"]
        generation_path = checkpoint / "generation_config.json"
        generation_eos = None
        if generation_path.is_file():
            generation_eos = json.loads(generation_path.read_text(encoding="utf-8"))[
                "eos_token_id"
            ]
        stops = stop_ids(
            model_eos=model_eos,
            generation_eos=generation_eos,
            tokenizer_eos=tokenizer.eos_token_id,
        )
        eos_sources = {
            "model_text_config_eos": model_eos,
            "generation_config_present": generation_path.is_file(),
            "optional_generation_eos": generation_eos,
            "tokenizer_eos": tokenizer.eos_token_id,
            "policy": "union of all present explicit EOS sources; no metadata download",
        }
        inputs = {
            r["request_id"]: tokenize_request(
                tokenizer,
                messages=r["messages"],
                thinking_enabled=False,
                max_model_len=config["max_model_len"],
                max_new_tokens=args.max_new_tokens,
            )
            for r in rows
        }
        thinking_control = tokenizer.apply_chat_template(
            rows[0]["messages"],
            tokenize=True,
            add_generation_prompt=True,
            enable_thinking=True,
            return_dict=False,
        )
        if thinking_control == inputs[rows[0]["request_id"]]:
            raise ValueError("thinking flag has no demonstrated template effect")
        fingerprints = {
            p.name: sha(p)
            for p in checkpoint.iterdir()
            if p.is_file()
            and (
                p.name in ("config.json", "generation_config.json")
                or p.name.startswith(
                    ("tokenizer", "special_tokens_map", "chat_template")
                )
            )
        }
        record["models"][name] = {
            "expected_model_files": expected_files,
            "model_id": config["model_id"],
            "model_revision": config["model_revision"],
            "config_paths": config_names,
            "config_sha256": {
                key: sha(source / value) for key, value in config_names.items()
            },
            "tokenizer_and_config_sha256": fingerprints,
            "stop_token_ids": stops,
            "eos_sources": eos_sources,
            "input_ids": inputs,
            "max_model_len": config["max_model_len"],
            "tp1_27b_budget_candidate": name == "27b",
            "thinking_flag_changes_template": True,
            "thinking_true_control_ids": thinking_control,
        }
    canonical = json.dumps(
        record, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()
    with args.output.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    hashes = {
        "file_sha256": sha(args.output),
        "canonical_sha256": hashlib.sha256(canonical).hexdigest(),
    }
    with args.output.with_suffix(".sha256.json").open("x") as f:
        json.dump(hashes, f, indent=2)
    print(
        json.dumps(
            {
                "passed": True,
                "models": 4,
                "unique_requests": 8,
                "input_lengths": {
                    name: {key: len(ids) for key, ids in model["input_ids"].items()}
                    for name, model in record["models"].items()
                },
                **hashes,
            }
        )
    )


if __name__ == "__main__":
    main()
