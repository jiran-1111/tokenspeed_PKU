#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest


def load(name):
    path = Path(__file__).with_name(name + ".py")
    spec = importlib.util.spec_from_file_location(name + "_under_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def args(monkeypatch, tmp_path, *, timeout):
    source = tmp_path / "source"
    source.mkdir()
    tools = tmp_path / "tools"
    tools.mkdir()
    output = source / "result"
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "cpu_controller.py",
            "--source-root",
            str(source),
            "--manifest",
            str(source / "manifest.json"),
            "--manifest-sha",
            "abc",
            "--model",
            "0.8b",
            "--output",
            str(output),
            "--threads",
            "1",
            "--timeout-seconds",
            str(timeout),
        ],
    )
    return tools, output


def test_timeout_is_failed_record_and_preserves_partial_results(monkeypatch, tmp_path):
    module = load("cpu_controller")
    tools, output = args(monkeypatch, tmp_path, timeout=1)
    monkeypatch.setattr(module, "__file__", str(tools / "cpu_controller.py"))

    def run(*values, **kwargs):
        output.mkdir()
        (output / "state.json").write_text(
            json.dumps(
                {
                    "status": "collecting",
                    "records": [{"request_id": "already_complete"}],
                }
            )
        )
        raise subprocess.TimeoutExpired(values[0], kwargs["timeout"])

    monkeypatch.setattr(module.subprocess, "run", run)
    with pytest.raises(SystemExit) as error:
        module.main()
    assert error.value.code == 1
    record = json.loads((tools / "cpu_0.8b.controller.json").read_text())
    assert (
        record["status"] == "failed"
        and record["timed_out"]
        and record["failure_reason"] == "timeout"
    )
    state = json.loads((output / "state.json").read_text())
    assert state["status"] == "failed" and len(state["records"]) == 1


def test_zero_exit_with_invalid_completion_is_rejected(monkeypatch, tmp_path):
    module = load("cpu_controller")
    tools, output = args(monkeypatch, tmp_path, timeout=10)
    monkeypatch.setattr(module, "__file__", str(tools / "cpu_controller.py"))

    def run(*values, **kwargs):
        output.mkdir()
        (output / "state.json").write_text(
            json.dumps(
                {
                    "status": "collected",
                    "records": [{}] * 8,
                    "source_unchanged": False,
                    "npu_import_blocked": True,
                    "model_files_unchanged": True,
                    "reference_sources_unchanged": True,
                }
            )
        )
        return subprocess.CompletedProcess(values[0], 0)

    monkeypatch.setattr(module.subprocess, "run", run)
    with pytest.raises(SystemExit):
        module.main()
    assert (
        json.loads((tools / "cpu_0.8b.controller.json").read_text())["status"]
        == "failed"
    )
    assert json.loads((output / "state.json").read_text())["status"] == "failed"


def test_collector_exception_marks_failed_before_propagating(monkeypatch, tmp_path):
    module = load("collect_cpu_quality")
    _, output = args(monkeypatch, tmp_path, timeout=1)
    monkeypatch.setattr(sys, "argv", [v for v in sys.argv[:-2]])

    def collect(values):
        output.mkdir()
        (output / "state.json").write_text(
            json.dumps({"status": "verifying_completion", "records": [{}] * 8})
        )
        raise ValueError("deliberate final verification failure")

    monkeypatch.setattr(module, "collect", collect)
    with pytest.raises(ValueError):
        module.main()
    state = json.loads((output / "state.json").read_text())
    assert (
        state["status"] == "failed"
        and state["failed_stage"] == "verifying_completion"
        and len(state["records"]) == 8
    )
