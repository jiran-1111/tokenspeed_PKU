#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""A separately frozen multi-input cohort; never replaces earlier failures."""

from __future__ import annotations

import re


def build_requests(cases, *, fixed_assistant_history):
    names = [c.name for c in cases]
    if len(set(names)) != len(names) or set(names) != set(fixed_assistant_history):
        raise ValueError("case/history coverage must match exactly")
    rows = []
    for case in cases:
        if (
            not re.fullmatch("[a-z0-9_]+", case.name)
            or not case.turns
            or len(fixed_assistant_history[case.name]) != len(case.turns) - 1
        ):
            raise ValueError("invalid case or fixed history")
        messages = []
        for index, prompt in enumerate(case.turns):
            if not isinstance(prompt, str) or not prompt:
                raise ValueError("empty prompt")
            messages.append({"role": "user", "content": prompt})
            rows.append(
                {
                    "request_id": f"{case.name}_turn{index+1}",
                    "case": case.name,
                    "category": case.category,
                    "turn_index": index + 1,
                    "messages": [dict(value) for value in messages],
                }
            )
            if index < len(case.turns) - 1:
                reply = fixed_assistant_history[case.name][index]
                if not isinstance(reply, str) or not reply:
                    raise ValueError("invalid fixed assistant reply")
                messages.append({"role": "assistant", "content": reply})
    return rows


def tokenize_request(
    tokenizer, *, messages, thinking_enabled, max_model_len, max_new_tokens
):
    if type(thinking_enabled) is not bool or max_model_len < 1 or max_new_tokens < 1:
        raise ValueError("invalid explicit tokenization protocol")
    ids = tokenizer.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
        enable_thinking=thinking_enabled,
        return_dict=False,
    )
    if (
        not isinstance(ids, list)
        or not ids
        or any(type(n) is not int or n < 0 for n in ids)
    ):
        raise ValueError("tokenizer must return nonempty integer IDs")
    if len(ids) + max_new_tokens > max_model_len:
        raise ValueError("request exceeds frozen context budget; no truncation allowed")
    return ids


def stop_ids(*, model_eos, generation_eos, tokenizer_eos):
    values = []
    for source in (model_eos, generation_eos, tokenizer_eos):
        if source is None:
            continue
        values.extend(source if isinstance(source, list) else [source])
    if not values or any(type(n) is not int or n < 0 for n in values):
        raise ValueError("stop IDs must be nonnegative integers excluding bool")
    return sorted(set(values))
