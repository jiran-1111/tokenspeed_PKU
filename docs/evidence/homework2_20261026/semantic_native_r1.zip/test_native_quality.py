#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import json
from pathlib import Path

import pytest


@pytest.fixture
def module():
    p = Path(__file__).with_name("native_quality.py")
    assert p.exists(), "native quality collector not implemented"
    spec = importlib.util.spec_from_file_location("native_quality_under_test", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def protocol():
    return {
        "max_new_tokens": 128,
        "requests": [{"request_id": "first"}, {"request_id": "second"}],
    }, {"input_ids": {"first": [1, 2], "second": [3, 4, 5]}, "stop_token_ids": [9]}


class FakeEngine:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def generate(self, **kwargs):
        self.calls.append(kwargs)
        return self.responses.pop(0)


def response(ids, *, length, finish):
    return {
        "output_ids": ids,
        "text": "fixture",
        "meta_info": {"prompt_tokens": length, "finish_reason": finish},
    }


def test_same_frozen_ids_and_explicit_eos_sampling_for_each_independent_request(
    module, tmp_path
):
    p, s = protocol()
    engine = FakeEngine(
        [
            response([6], length=2, finish={"type": "stop", "matched": 9}),
            response([7] * 128, length=3, finish={"type": "length", "length": 128}),
        ]
    )
    records = []
    module.collect_requests(
        engine, protocol=p, model_spec=s, output=tmp_path, records=records
    )
    assert len(records) == 2 and all(r["status"] == "collected" for r in records)
    assert [v["input_ids"] for v in engine.calls] == [[1, 2], [3, 4, 5]]
    for call in engine.calls:
        assert call["session_id"] is None and call["stream"] is False
        assert call["sampling_params"] == {
            "temperature": 0,
            "top_p": 1,
            "top_k": 1,
            "ignore_eos": False,
            "stop_token_ids": [9],
            "max_new_tokens": 128,
            "skip_special_tokens": True,
            "no_stop_trim": False,
        }
    assert records[1]["output_ids"] == [7] * 128
    assert (
        json.loads((tmp_path / "second.response.json").read_text())["output_ids"]
        == [7] * 128
    )


def test_invalid_response_is_retained_and_stops_instead_of_skipping_case(
    module, tmp_path
):
    p, s = protocol()
    engine = FakeEngine(
        [response([6], length=99, finish={"type": "stop", "matched": 9})]
    )
    records = []
    with pytest.raises(ValueError):
        module.collect_requests(
            engine, protocol=p, model_spec=s, output=tmp_path, records=records
        )
    assert (
        len(records) == 1
        and records[0]["status"] == "failed"
        and len(engine.calls) == 1
    )
    assert (
        json.loads((tmp_path / "first.response.json").read_text())["meta_info"][
            "prompt_tokens"
        ]
        == 99
    )


def test_eos_immediate_empty_output_is_kept_as_observation(module, tmp_path):
    p, s = protocol()
    p["requests"] = p["requests"][:1]
    engine = FakeEngine([response([], length=2, finish={"type": "stop", "matched": 9})])
    records = []
    module.collect_requests(
        engine, protocol=p, model_spec=s, output=tmp_path, records=records
    )
    assert records[0]["output_ids"] == [] and records[0]["status"] == "collected"


def test_abort_and_unbounded_outputs_are_failures(module, tmp_path):
    p, s = protocol()
    p["requests"] = p["requests"][:1]
    for index, r in enumerate(
        [
            response([6], length=2, finish={"type": "abort"}),
            response([6] * 129, length=2, finish={"type": "length", "length": 129}),
        ]
    ):
        folder = tmp_path / str(index)
        folder.mkdir()
        records = []
        with pytest.raises(ValueError):
            module.collect_requests(
                FakeEngine([r]),
                protocol=p,
                model_spec=s,
                output=folder,
                records=records,
            )
        assert records[0]["status"] == "failed"
