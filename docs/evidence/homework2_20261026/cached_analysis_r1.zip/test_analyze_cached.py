#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""NumPy-only analyzer tests; do not require Torch or hardware."""

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


@pytest.fixture
def analyzer():
    path = Path(__file__).with_name("analyze_cached.py")
    assert path.exists(), "cached analyzer is not implemented"
    spec = importlib.util.spec_from_file_location("analyze_cached_under_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_cached_gqa_uses_all_136_real_kv_rows_and_contiguous_groups(analyzer):
    q = np.zeros((1, 8, 2), dtype=np.float32)
    k = np.zeros((136, 2, 2), dtype=np.float32)
    v = np.zeros_like(k)
    v[:, 0] = np.arange(136)[:, None]
    v[:, 1] = np.arange(136)[:, None] + 1000
    actual = analyzer.cached_gqa(q, k, v, scaling=0.5)
    np.testing.assert_allclose(actual[0, :4], 67.5)
    np.testing.assert_allclose(actual[0, 4:], 1067.5)


def test_kv_changed_prefix_is_reported_and_current_row_checked(analyzer):
    before = {
        name: np.arange(135 * 2 * 3, dtype=np.float32).reshape(135, 2, 3)
        for name in ("k", "v")
    }
    current = np.full((1, 2, 3), 99, dtype=np.float32)
    after = {
        name: np.concatenate([value, current], axis=0) for name, value in before.items()
    }
    result = analyzer.kv_checks(before, after, current, current)
    assert result["k_prefix_before_vs_after"]["exact_equal"]
    assert result["k_current_vs_actual_input"]["exact_equal"]
    after["k"][7, 0, 0] += 1
    after["v"][-1, 0, 0] += 1
    result = analyzer.kv_checks(before, after, current, current)
    assert not result["k_prefix_before_vs_after"]["exact_equal"]
    assert not result["v_current_vs_actual_input"]["exact_equal"]


def test_conv_cross_tp_splits_qkv_channels_before_rank_concat(analyzer):
    left = np.arange(8 * 3, dtype=np.float32).reshape(8, 3)
    right = left + 100
    joined = analyzer.join_packed([left, right], widths=[2, 2, 4], axis=0)
    np.testing.assert_array_equal(
        joined,
        np.concatenate(
            [left[:2], right[:2], left[2:4], right[2:4], left[4:], right[4:]], axis=0
        ),
    )
    assert not np.array_equal(joined, np.concatenate([left, right], axis=0))


def test_gdn_reference_receives_actual_scan_inputs_not_conv_reference(analyzer):
    q = np.array([[[[2.0]]]], dtype=np.float32)
    scan = {
        "q": q,
        "k": q + 1,
        "v": q + 2,
        "A_log": np.zeros(1, dtype=np.float32),
        "dt_bias": np.zeros(1, dtype=np.float32),
        "a": np.zeros((1, 1), dtype=np.float32),
        "b": np.zeros((1, 1), dtype=np.float32),
        "output": q + 3,
    }
    decode = {
        "mixed_qkv": np.zeros((1, 3), dtype=np.float32),
        "conv_weights": np.zeros((3, 4), dtype=np.float32),
        "metadata": {"activation": "silu"},
    }
    before = {
        "conv_state": np.zeros((3, 3), dtype=np.float32),
        "ssm_state": np.zeros((1, 1, 1), dtype=np.float32),
    }
    after = {
        "conv_state": before["conv_state"].copy(),
        "ssm_state": np.ones((1, 1, 1), dtype=np.float32),
    }
    calls = []

    def recurrence(q_value, k_value, v_value, state, **kwargs):
        calls.append(
            (q_value.copy(), k_value.copy(), v_value.copy(), state.copy(), kwargs)
        )
        return {
            "output": np.array([[5.0]], dtype=np.float32),
            "state": np.ones((1, 1, 1), dtype=np.float32),
        }

    reference = SimpleNamespace(
        conv_update_reference=lambda *args, **kwargs: {
            "output": np.zeros(3, dtype=np.float32),
            "conv_after": np.zeros((3, 3), dtype=np.float32),
        },
        gdn_decode_reference=recurrence,
    )
    result = analyzer.gdn_local_references(
        decode, scan, before, after, reference=reference, ssm_dtype="torch.float32"
    )
    np.testing.assert_array_equal(calls[0][0], [[2.0]])
    np.testing.assert_array_equal(calls[0][1], [[3.0]])
    np.testing.assert_array_equal(calls[0][2], [[4.0]])
    assert calls[0][4]["use_qk_l2norm"] is True
    assert result["recurrence_output_fp32"]["exact_equal"]
    assert result["recurrence_after_state_fp32"]["exact_equal"]


def test_bf16_storage_and_zero_reference_metrics_are_explicit(analyzer):
    np.testing.assert_array_equal(
        analyzer.storage_reference(
            np.array([1.00390625, 1.01171875], dtype=np.float32), "torch.bfloat16"
        ),
        [1.0, 1.015625],
    )
    assert analyzer.compare(np.ones(1), np.zeros(1))["relative_l2"] is None
    assert analyzer.compare(np.zeros(1), np.zeros(1))["relative_l2"] == 0
    with pytest.raises(ValueError, match="finite"):
        analyzer.compare(np.array([np.nan]), np.zeros(1))


def test_manifest_selection_rejects_escape_and_guard_rejects_failed_exit(analyzer):
    root = Path(__file__).resolve().parent / "manifest_test_root"
    valid = {
        "9b": {
            "tp1": "cached_diagnostic_9b_tp1_20261026_r1",
            "tp2": "cached_diagnostic_9b_tp2_20261026_r1",
        }
    }
    assert analyzer.select_jobs(root, valid)["tp2"].name == valid["9b"]["tp2"]
    for bad in ("../outside", "C:\\outside", str(root.parent / "outside")):
        with pytest.raises(ValueError, match="manifest"):
            analyzer.select_jobs(root, {"9b": {"tp1": valid["9b"]["tp1"], "tp2": bad}})
    run = {
        "status": "collected",
        "diagnostic_only": True,
        "execution_mode": "eager",
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "guard": {
            "sources_sha": analyzer.CORE_SHA,
            "sources_after_sha": analyzer.CORE_SHA,
            "sources_unchanged": True,
            "own_children_released": True,
            "violations": [],
        },
    }
    analyzer.validate_run(run)
    with pytest.raises(ValueError, match="guard"):
        analyzer.validate_run(
            {**run, "guard": {**run["guard"], "own_children_released": False}}
        )
    with pytest.raises(ValueError, match="collected"):
        analyzer.validate_run({**run, "status": "captured_pending_guard_exit"})


def test_actual_position_requires_135_on_all_three_axes(analyzer):
    np.testing.assert_array_equal(
        analyzer.text_position(np.array([[135], [135], [135]], dtype=np.int64)), [135]
    )
    for value in (np.array([134]), np.array([[135], [134], [135]]), np.array([135.0])):
        with pytest.raises(ValueError, match="position"):
            analyzer.text_position(value)
