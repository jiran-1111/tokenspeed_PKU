#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read-only identity checks for actual step8 GDN and MLP parameters."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


def column_shard(weight, *, widths, rank, tp):
    import numpy as np

    w = np.asarray(weight)
    if (
        w.ndim != 2
        or tp < 1
        or not 0 <= rank < tp
        or sum(widths) != w.shape[0]
        or any(n < 1 or n % tp for n in widths)
    ):
        raise ValueError("invalid logical column shard")
    offset = 0
    pieces = []
    for n in widths:
        pieces.append(w[offset + rank * (n // tp) : offset + (rank + 1) * (n // tp)])
        offset += n
    return np.concatenate(pieces, axis=0)


def row_shard(weight, *, rank, tp):
    import numpy as np

    w = np.asarray(weight)
    if w.ndim != 2 or tp < 1 or not 0 <= rank < tp or w.shape[1] % tp:
        raise ValueError("invalid row projection shard")
    width = w.shape[1] // tp
    return w[:, rank * width : (rank + 1) * width].copy()


def check_norm_metadata(value, *, expected_eps):
    if value != {
        "eps": expected_eps,
        "group_size": None,
        "norm_before_gate": True,
        "sigmoid_gate": False,
    }:
        raise ValueError("unobserved gated norm mode or epsilon")
    return value


def raw_identity(
    actual, expected, *, actual_shape, expected_shape, actual_dtype, expected_dtype
):
    return {
        "actual_shape": actual_shape,
        "expected_shape": expected_shape,
        "actual_dtype": actual_dtype,
        "expected_dtype": expected_dtype,
        "actual_sha256": hashlib.sha256(actual).hexdigest(),
        "checkpoint_expected_sha256": hashlib.sha256(expected).hexdigest(),
        "exact_match": actual_shape == expected_shape
        and actual_dtype == expected_dtype
        and actual == expected,
    }


def verify_actual_gdn(layers, *, torch, rank, tp, output):
    import numpy as np
    from safetensors import safe_open

    source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
    config = json.loads((source / "configs/homework2/qwen35_9b_tp1.yaml").read_text())
    if config["model_revision"] != "c202236235762e1c871ad0ccb60c8ee5ba337b9a":
        raise ValueError("9B revision mismatch")
    checkpoint = source / config["local_model_path"]
    model_config = checkpoint / "config.json"
    eps = json.loads(model_config.read_text())["text_config"]["rms_norm_eps"]
    indices = list(checkpoint.glob("*.safetensors.index.json"))
    if len(indices) != 1:
        raise ValueError("checkpoint index ambiguity")
    index = json.loads(indices[0].read_text())["weight_map"]
    digest = lambda t: hashlib.sha256(
        t.contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    result = {
        "rank": rank,
        "tp": tp,
        "model_revision": config["model_revision"],
        "layers": {},
        "parameter_checks": 0,
        "checkpoint_config_sha256": hashlib.sha256(
            model_config.read_bytes()
        ).hexdigest(),
        "checkpoint_index_sha256": hashlib.sha256(indices[0].read_bytes()).hexdigest(),
        "diagnostic_only": True,
        "performance_eligible": False,
        "runtime_state_written": False,
    }
    for number in (8, 9, 10):
        layer = layers[number]
        gdn = layer.linear_attn
        if (gdn.layer_id, gdn.attn_tp_rank, gdn.attn_tp_size) != (number, rank, tp):
            raise ValueError("actual GDN/rank mismatch")
        norm = check_norm_metadata(
            {
                "eps": gdn.norm.eps,
                "group_size": gdn.norm.group_size,
                "norm_before_gate": gdn.norm.norm_before_gate,
                "sigmoid_gate": gdn.norm.sigmoid_gate,
            },
            expected_eps=eps,
        )
        identities = {}

        def get(suffix):
            name = f"model.language_model.layers.{number}.{suffix}"
            with safe_open(checkpoint / index[name], framework="pt", device="cpu") as f:
                original = f.get_tensor(name)
            identities[suffix] = {
                "shape": list(original.shape),
                "dtype": str(original.dtype),
                "checkpoint_tensor_sha256": digest(original),
            }
            return original.float().numpy()

        packed = np.concatenate(
            [
                get("linear_attn.in_proj_qkv.weight"),
                get("linear_attn.in_proj_z.weight"),
                get("linear_attn.in_proj_b.weight"),
                get("linear_attn.in_proj_a.weight"),
            ],
            axis=0,
        )
        gu = np.concatenate(
            [get("mlp.gate_proj.weight"), get("mlp.up_proj.weight")], axis=0
        )
        conv = get("linear_attn.conv1d.weight")
        if conv.shape != (8192, 1, 4):
            raise ValueError("conv shape mismatch")
        expected = {
            "linear_attn.in_proj_qkvzba.weight": column_shard(
                packed, widths=[2048, 2048, 4096, 4096, 32, 32], rank=rank, tp=tp
            ),
            "linear_attn.out_proj.weight": row_shard(
                get("linear_attn.out_proj.weight"), rank=rank, tp=tp
            ),
            "linear_attn.norm.weight": get("linear_attn.norm.weight"),
            "mlp.gate_up_proj.weight": column_shard(
                gu, widths=[gu.shape[0] // 2] * 2, rank=rank, tp=tp
            ),
            "mlp.down_proj.weight": row_shard(
                get("mlp.down_proj.weight"), rank=rank, tp=tp
            ),
            "linear_attn.conv1d.weight": column_shard(
                conv[:, 0, :], widths=[2048, 2048, 4096], rank=rank, tp=tp
            )[:, None, :],
            "linear_attn.A_log": np.split(get("linear_attn.A_log"), tp)[rank],
            "linear_attn.dt_bias": np.split(get("linear_attn.dt_bias"), tp)[rank],
        }
        actual = {
            "linear_attn.in_proj_qkvzba.weight": gdn.in_proj_qkvzba.weight,
            "linear_attn.out_proj.weight": gdn.out_proj.weight,
            "linear_attn.norm.weight": gdn.norm.weight,
            "mlp.gate_up_proj.weight": layer.mlp.gate_up_proj.weight,
            "mlp.down_proj.weight": layer.mlp.down_proj.weight,
            "linear_attn.conv1d.weight": gdn.conv1d.weight,
            "linear_attn.A_log": gdn.A_log,
            "linear_attn.dt_bias": gdn.dt_bias,
        }
        records = {}
        for name, parameter in actual.items():
            value = parameter.detach().cpu().contiguous()
            wanted = (
                torch.from_numpy(np.ascontiguousarray(expected[name]))
                .to(dtype=value.dtype)
                .contiguous()
            )
            records[name] = raw_identity(
                value.view(torch.uint8).numpy().tobytes(),
                wanted.view(torch.uint8).numpy().tobytes(),
                actual_shape=list(value.shape),
                expected_shape=list(wanted.shape),
                actual_dtype=str(value.dtype),
                expected_dtype=str(wanted.dtype),
            )
            if (
                name in ("linear_attn.A_log", "linear_attn.dt_bias")
                and value.dtype != torch.float32
            ):
                records[name]["exact_match"] = False
            elif (
                name != "linear_attn.norm.weight"
                and name not in ("linear_attn.A_log", "linear_attn.dt_bias")
                and value.dtype != torch.bfloat16
            ):
                records[name]["exact_match"] = False
        result["parameter_checks"] += len(records)
        result["layers"][str(number)] = {
            "gated_norm": norm,
            "checkpoint_tensors": identities,
            "parameters": records,
        }
    result["all_exact"] = all(
        v["exact_match"]
        for layer in result["layers"].values()
        for v in layer["parameters"].values()
    )
    with (output / "gdn_actual_checkpoint_identity.json").open("x") as f:
        json.dump(result, f, indent=2)
    if result["parameter_checks"] != 24 or not result["all_exact"]:
        raise ValueError(
            "actual GDN checkpoint identity mismatch; retained identity record"
        )
    return result
