#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU fake-Tensor tests; no runtime, Torch, or NPU imports."""

import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest


class Tensor:
    def __init__(self, values, dtype="torch.bfloat16", reads=None):
        self.values = np.asarray(values)
        self.dtype = dtype
        self.reads = [] if reads is None else reads
        self.device = SimpleNamespace(type="npu")

    @property
    def shape(self):
        return self.values.shape

    @property
    def ndim(self):
        return self.values.ndim

    def numel(self):
        return self.values.size

    def stride(self):
        return tuple(int(s // self.values.itemsize) for s in self.values.strides)

    def detach(self):
        return self

    def cpu(self):
        self.reads.append(tuple(self.shape))
        return self

    def clone(self):
        return Tensor(self.values.copy(), self.dtype)

    def tolist(self):
        return self.values.tolist()

    def __getitem__(self, index):
        return Tensor(self.values[index], self.dtype, self.reads)


TORCH = SimpleNamespace(
    Tensor=Tensor,
    bfloat16="torch.bfloat16",
    int32="torch.int32",
    int64="torch.int64",
    isfinite=lambda value: np.isfinite(value.values),
    cat=lambda values, dim: Tensor(
        np.concatenate([v.values for v in values], axis=dim), values[0].dtype
    ),
)


def capture(ctx, layer, phase):
    path = Path(__file__).with_name("decode_kv_capture.py")
    assert path.exists(), "Decode KV capture helper is not implemented"
    spec = importlib.util.spec_from_file_location("decode_kv_capture_under_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.capture_decode_kv(ctx, layer, torch=TORCH, phase=phase)


def fixture(tp=2, page_size=128):
    heads, qheads = 4 // tp, 16 // tp
    pages = [3, 1] if page_size == 128 else [3, 1, 4]
    table = Tensor([pages + [0] * (8 - len(pages))], "torch.int32")
    k = Tensor(np.full((6, page_size, heads, 256), np.nan, dtype=np.float16))
    v = Tensor(np.full_like(k.values, np.nan))
    for token in range(135):
        page, offset = pages[token // page_size], token % page_size
        k.values[page, offset] = token
        v.values[page, offset] = token + 1000
    current_slot = pages[135 // page_size] * page_size + 135 % page_size
    spec = SimpleNamespace(
        group_id="history",
        family="history",
        retention="full_history",
        entry_stride_tokens=1,
        rows_per_page=128,
        block_granularity=128,
        shard_count=1,
    )
    calls = []
    pool = type("HybridMHATokenToKVPool", (SimpleNamespace,), {})(
        rank=tp - 1,
        dtype="torch.bfloat16",
        arena=SimpleNamespace(cache_group_specs=(spec,)),
        history_group_by_layer=lambda: {7: "history"},
        get_key_buffer=lambda layer_id: (calls.append(("k", layer_id)) or k),
        get_value_buffer=lambda layer_id: (calls.append(("v", layer_id)) or v),
    )
    leaf = type("MHAAttnBackend", (SimpleNamespace,), {})(
        kernel_page_size=page_size,
        kernel_solution=None,
        is_fp8=False,
        is_mxfp8=False,
        qkv_dtype="torch.bfloat16",
        kv_cache_dtype="torch.bfloat16",
        block_decode_expansion=1,
        forward_decode_metadata=SimpleNamespace(
            page_table=table, seq_lens=Tensor([136], "torch.int32")
        ),
        _get_kv_cache=lambda layer, actual_pool: (
            actual_pool.get_key_buffer(layer.layer_id),
            actual_pool.get_value_buffer(layer.layer_id),
        ),
    )
    locations = Tensor([current_slot], "torch.int64")
    router = type("CacheGroupRouter", (SimpleNamespace,), {})(
        is_draft=False,
        _decode_request_offset=0,
        leaves={"history": leaf},
        write_locations=lambda layer, mode: locations,
    )
    backend = type("HybridLinearAttnBackend", (SimpleNamespace,), {})(
        full_attn_layers={3, 7, 11}, full_attn_backend=router
    )
    ctx = SimpleNamespace(
        attn_backend=backend,
        token_to_kv_pool=pool,
        bs=1,
        num_extends=0,
        input_num_tokens=1,
        forward_mode=SimpleNamespace(name="DECODE", is_decode=lambda: True),
    )
    layer = SimpleNamespace(
        layer_id=7,
        group_id="history",
        sliding_window_size=-1,
        logit_cap=0.0,
        scaling=0.0625,
        tp_q_head_num=qheads,
        tp_k_head_num=heads,
        tp_v_head_num=heads,
        qk_head_dim=256,
        v_head_dim=256,
    )
    return ctx, layer, leaf, router, pool, k, v, calls


@pytest.mark.parametrize("tp,page_size", [(1, 128), (2, 128), (2, 64)])
def test_before_reads_only_135_valid_rows_and_preserves_dtype_and_page_order(
    tp, page_size
):
    ctx, layer, leaf, router, pool, k, v, calls = fixture(tp, page_size)
    result = capture(ctx, layer, "before")
    assert result["k"].shape == (135, 4 // tp, 256)
    assert result["k"].dtype == k.dtype
    np.testing.assert_array_equal(result["k"].values[:, 0, 0], np.arange(135))
    np.testing.assert_array_equal(result["v"].values[:, 0, 0], np.arange(135) + 1000)
    assert calls == [("k", 7), ("v", 7)]
    assert (6, page_size, 4 // tp, 256) not in k.reads
    assert sum(shape[0] for shape in k.reads) == 135
    assert result["metadata"]["valid_length"] == 135
    assert result["metadata"]["actual_seq_lens"] == [136]
    assert result["metadata"]["current_kv_included"] is False
    assert (
        result["page_table"].tolist()
        == leaf.forward_decode_metadata.page_table.tolist()
    )
    json.dumps(result["metadata"], allow_nan=False)
    result["k"].values.fill(-1)
    assert k.values[3, 0, 0, 0] == 0


def test_after_includes_actual_new_slot_without_recomputing_prefix():
    ctx, layer, leaf, router, pool, k, v, _ = fixture()
    k.values[1, 7] = 135
    v.values[1, 7] = 1135
    result = capture(ctx, layer, "after")
    assert result["k"].shape == (136, 2, 256)
    np.testing.assert_array_equal(result["k"].values[:, 0, 0], np.arange(136))
    assert result["metadata"]["current_kv_included"] is True
    assert result["write_locations"].tolist() == [135]
    assert result["seq_lens"].tolist() == [136]


@pytest.mark.parametrize(
    "bad",
    [
        "phase",
        "layer",
        "mode",
        "bs",
        "extends",
        "prefix_length",
        "zero_page",
        "negative_page",
        "out_of_range",
        "write_slot",
        "unknown_backend",
        "unknown_pool",
        "fp8",
        "sharded",
        "heads",
        "dtype",
        "expanded_decode",
    ],
)
def test_rejects_unknown_or_invalid_capture_paths(bad):
    ctx, layer, leaf, router, pool, k, v, _ = fixture()
    phase = "before"
    if bad == "phase":
        phase = "prefill"
    elif bad == "layer":
        layer.layer_id = 8
    elif bad == "mode":
        ctx.forward_mode.is_decode = lambda: False
    elif bad == "bs":
        ctx.bs = 2
    elif bad == "extends":
        ctx.num_extends = 1
    elif bad == "prefix_length":
        leaf.forward_decode_metadata.seq_lens.values[0] = 135
    elif bad == "zero_page":
        leaf.forward_decode_metadata.page_table.values[0, 0] = 0
    elif bad == "negative_page":
        leaf.forward_decode_metadata.page_table.values[0, 0] = -1
    elif bad == "out_of_range":
        leaf.forward_decode_metadata.page_table.values[0, 0] = 6
    elif bad == "write_slot":
        router.write_locations = lambda layer, mode: Tensor([134], "torch.int64")
    elif bad == "unknown_backend":
        ctx.attn_backend = SimpleNamespace()
    elif bad == "unknown_pool":
        ctx.token_to_kv_pool = SimpleNamespace()
    elif bad == "fp8":
        leaf.is_fp8 = True
    elif bad == "sharded":
        pool.arena.cache_group_specs[0].shard_count = 2
    elif bad == "heads":
        layer.tp_k_head_num = 1
    elif bad == "dtype":
        k.dtype = "torch.float32"
    else:
        leaf.block_decode_expansion = 2
    with pytest.raises(ValueError):
        capture(ctx, layer, phase)


def test_after_rejects_unwritten_current_kv_but_before_does_not_read_it():
    ctx, layer, *_ = fixture()
    capture(ctx, layer, "before")
    with pytest.raises(ValueError, match="finite"):
        capture(ctx, layer, "after")
