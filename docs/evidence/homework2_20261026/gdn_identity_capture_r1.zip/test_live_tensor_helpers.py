#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest


class LiveTensorHelpers(unittest.TestCase):
    def test_real_torch_kv_page_selection_ignores_unwritten_slot(self):
        import torch
        from decode_kv_capture import capture_decode_kv
        from test_decode_kv_capture import fixture

        ctx, layer, leaf, router, pool, k, v, calls = fixture()
        key = torch.tensor(k.values, dtype=torch.bfloat16)
        value = torch.tensor(v.values, dtype=torch.bfloat16)
        pool.dtype = torch.bfloat16
        pool.get_key_buffer = lambda layer_id: key
        pool.get_value_buffer = lambda layer_id: value
        leaf.qkv_dtype = leaf.kv_cache_dtype = torch.bfloat16
        leaf.forward_decode_metadata.page_table = torch.tensor(
            leaf.forward_decode_metadata.page_table.values, dtype=torch.int32
        )
        leaf.forward_decode_metadata.seq_lens = torch.tensor([136], dtype=torch.int32)
        router.write_locations = lambda layer, mode: torch.tensor(
            [135], dtype=torch.int64
        )
        before = capture_decode_kv(ctx, layer, torch=torch, phase="before")
        self.assertEqual(before["k"].shape, (135, 2, 256))
        self.assertTrue(
            torch.equal(before["k"][:, 0, 0], torch.arange(135).to(torch.bfloat16))
        )
        key[1, 7].fill_(135)
        value[1, 7].fill_(1135)
        after = capture_decode_kv(ctx, layer, torch=torch, phase="after")
        self.assertTrue(
            torch.equal(after["k"][-1], torch.full((2, 256), 135, dtype=torch.bfloat16))
        )
        key.fill_(-10)
        self.assertEqual(float(before["k"][0, 0, 0]), 0)
        self.assertEqual(float(after["k"][-1, 0, 0]), 135)

    def test_real_torch_state_snapshots_keep_fp32_and_distinct_slots(self):
        import torch
        from gdn_state_capture import capture_gdn_state
        from test_gdn_state_capture import make_context

        ctx = make_context()
        pool = ctx.token_to_kv_pool
        for components in pool.components.values():
            for name, tensor in list(components.items()):
                components[name] = torch.tensor(
                    tensor.array,
                    dtype=torch.bfloat16 if name == "conv_state" else torch.float32,
                )
        backend = ctx.attn_backend.linear_attn_backend
        for mapping in (
            backend.forward_metadata.state_in_blocks_by_group,
            backend.forward_metadata.state_out_blocks_by_group,
        ):
            for group, tensor in list(mapping.items()):
                mapping[group] = torch.tensor(tensor.array, dtype=torch.int32)
        before = capture_gdn_state(ctx, layer_id=8, torch=torch, phase="before")
        after = capture_gdn_state(ctx, layer_id=8, torch=torch, phase="after")
        self.assertEqual(before["metadata"]["selected_state_slot"], 2)
        self.assertEqual(after["metadata"]["selected_state_slot"], 5)
        self.assertEqual(before["conv_state"].dtype, torch.bfloat16)
        self.assertEqual(after["ssm_state"].dtype, torch.float32)
        expected = before["ssm_state"].clone()
        pool.components[8]["recurrent_state"].fill_(-1)
        self.assertTrue(torch.equal(before["ssm_state"], expected))


if __name__ == "__main__":
    unittest.main()
