#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Observe one original cached forward, never substitute cache or state."""

from __future__ import annotations

import json
import re
from contextlib import ExitStack, contextmanager
from pathlib import Path
from typing import Any
from unittest.mock import patch


@contextmanager
def observe_cached_targets(
    targets: dict,
    ctx: Any,
    backend: Any,
    *,
    torch: Any,
    kv_capture: Any,
    gdn_capture: Any,
):
    observed = {"modules": {}, "kv": {}, "states": {}, "backend": {}}
    handles = []
    fa_active = False
    gdn_active = None

    def clone(value):
        return value.detach().cpu().clone() if isinstance(value, torch.Tensor) else None

    def copies(values):
        return [
            clone(value)
            for value in (values if isinstance(values, tuple) else (values,))
        ]

    def pre(key):
        def hook(module, inputs):
            nonlocal fa_active, gdn_active
            if key == "fa7":
                fa_active = True
            if key == "fa7.rotary_emb" and not fa_active:
                return
            if key in observed["modules"]:
                raise ValueError(f"{key} called more than once")
            observed["modules"][key] = {"inputs": copies(inputs)}
            if key == "fa7.attn":
                if inputs[3] is not ctx:
                    raise ValueError("FA7 context differs from selected forward")
                observed["kv"]["before"] = kv_capture(
                    ctx, module, torch=torch, phase="before"
                )
            match = re.fullmatch(r"l(8|9|10)\.linear_attn", key)
            if match:
                if inputs[1] is not ctx or gdn_active is not None:
                    raise ValueError("GDN context or nesting mismatch")
                gdn_active = int(match[1])
                observed["states"][gdn_active] = {
                    "before": gdn_capture(
                        ctx, layer_id=gdn_active, torch=torch, phase="before"
                    )
                }

        return hook

    def post(key):
        def hook(module, inputs, output):
            nonlocal fa_active, gdn_active
            if key == "fa7.rotary_emb" and not fa_active:
                return
            if output is None:
                if key == "fa7":
                    fa_active = False
                if re.fullmatch(r"l(8|9|10)\.linear_attn", key):
                    gdn_active = None
                return
            observed["modules"][key]["outputs"] = copies(output)
            if key == "fa7.attn":
                observed["kv"]["after"] = kv_capture(
                    ctx, module, torch=torch, phase="after"
                )
            match = re.fullmatch(r"l(8|9|10)\.linear_attn", key)
            if match:
                layer = int(match[1])
                observed["states"][layer]["after"] = gdn_capture(
                    ctx, layer_id=layer, torch=torch, phase="after"
                )
                gdn_active = None
            if key == "fa7":
                fa_active = False

        return hook

    original_decode = type(backend).forward_decode
    original_scan = type(backend)._decode_scan

    def decode(this, *args, **kwargs):
        if this is not backend or gdn_active is None:
            return original_decode(this, *args, **kwargs)
        layer = gdn_active
        record = observed["backend"].setdefault(layer, {})
        if "decode" in record:
            raise ValueError("GDN decode called more than once")
        tensor_names = (
            "mixed_qkv",
            "conv_weights",
            "bias",
            "A_log",
            "dt_bias",
            "a",
            "b",
            "z",
        )
        record["decode"] = {name: clone(kwargs[name]) for name in tensor_names}
        record["decode"]["metadata"] = {
            name: kwargs[name]
            for name in (
                "activation",
                "key_dim",
                "value_dim",
                "attention_tp_size",
                "head_k_dim",
                "head_v_dim",
                "seq_len",
            )
        }
        result = original_decode(this, *args, **kwargs)
        record["decode"]["output"] = clone(result)
        return result

    def scan(this, *args, **kwargs):
        if this is not backend or gdn_active is None:
            return original_scan(this, *args, **kwargs)
        record = observed["backend"].setdefault(gdn_active, {})
        if "scan" in record:
            raise ValueError("GDN scan called more than once")
        if len(args) != 6:
            raise ValueError("Unexpected GDN scan positional contract")
        record["scan"] = {
            name: clone(value)
            for name, value in zip(
                ("q", "k", "v", "pool_not_saved", "read_indices", "write_indices"), args
            )
            if name != "pool_not_saved"
        }
        record["scan"].update(
            {name: clone(kwargs[name]) for name in ("A_log", "dt_bias", "a", "b")}
        )
        result = original_scan(this, *args, **kwargs)
        record["scan"]["output"] = clone(result)
        return result

    try:
        for key, module in targets.items():
            handles.extend(
                [
                    module.register_forward_pre_hook(pre(key)),
                    module.register_forward_hook(
                        post(key),
                        always_call=key == "fa7"
                        or re.fullmatch(r"l(8|9|10)\.linear_attn", key) is not None,
                    ),
                ]
            )
        with ExitStack() as stack:
            stack.enter_context(patch.object(type(backend), "forward_decode", decode))
            stack.enter_context(patch.object(type(backend), "_decode_scan", scan))
            yield observed
    finally:
        fa_active = False
        gdn_active = None
        for handle in handles:
            handle.remove()


def targets_for_layers(model):
    layers = {
        int(m[1]): module
        for name, module in model.named_modules()
        if (m := re.search(r"(?:^|\.)layers\.(7|8|9|10|11)$", name))
    }
    if set(layers) != {7, 8, 9, 10, 11}:
        raise ValueError("Selected decoder layer coverage mismatch")
    fa = layers[7]
    targets = {
        "fa7": fa,
        "fa7.input_layernorm": fa.input_layernorm,
        "fa7.post_attention_layernorm": fa.post_attention_layernorm,
        "fa7.qkv_proj": fa.qkv_proj,
        "fa7.rotary_emb": fa.rotary_emb,
        "fa7.attn": fa.attn,
        "fa7.o_proj": fa.o_proj,
        "fa7.mlp.gate_up_proj": fa.mlp.gate_up_proj,
        "fa7.mlp.down_proj": fa.mlp.down_proj,
    }
    for index in (8, 9, 10):
        layer = layers[index]
        gdn = layer.linear_attn
        if gdn.layer_id != index:
            raise ValueError("Actual GDN layer identity mismatch")
        targets.update(
            {
                f"l{index}.input_layernorm": layer.input_layernorm,
                f"l{index}.post_attention_layernorm": layer.post_attention_layernorm,
                f"l{index}.linear_attn": gdn,
                f"l{index}.linear_attn.in_proj_qkvzba": gdn.in_proj_qkvzba,
                f"l{index}.linear_attn.norm": gdn.norm,
                f"l{index}.linear_attn.out_proj": gdn.out_proj,
                f"l{index}.mlp.gate_up_proj": layer.mlp.gate_up_proj,
                f"l{index}.mlp.down_proj": layer.mlp.down_proj,
            }
        )
    targets["l11.input_layernorm"] = layers[11].input_layernorm
    return layers, targets


@contextmanager
def capture_cached(
    model, ctx, *, torch, output: Path, rank: int, case: dict, step: int
):
    from decode_kv_capture import capture_decode_kv
    from gdn_state_capture import capture_gdn_state

    if (
        step != 8
        or "_9b_" not in case["case_id"]
        or len(case["input_ids"]) != 128
        or len(case["continuation_ids"]) != 9
    ):
        raise ValueError("Cached capture does not match the original9Bstep8 case")
    if (
        ctx.bs != 1
        or ctx.input_num_tokens != 1
        or ctx.num_extends != 0
        or not ctx.forward_mode.is_decode()
    ):
        raise ValueError("Cached capture requires original single-token Decode")
    if type(ctx.attn_backend).__name__ != "HybridLinearAttnBackend":
        raise ValueError("Unknown hybrid backend")
    backend = ctx.attn_backend.linear_attn_backend
    layers, targets = targets_for_layers(model)
    fa = layers[7]
    tp = fa.attn_tp_size
    if fa.attn_tp_rank != rank:
        raise ValueError("Actual attention rank mismatch")
    comm = {}
    for index, layer in layers.items():
        state = {
            "should_fuse": layer.comm_manager.should_fuse(1),
            "use_all_reduce": layer.comm_manager.use_all_reduce(layer.is_moe),
            "attention_tp_rank": layer.mapping.attn.tp_rank,
            "attention_tp_size": layer.mapping.attn.tp_size,
            "dense_tp_rank": layer.mapping.dense.tp_rank,
            "dense_tp_size": layer.mapping.dense.tp_size,
        }
        if state["should_fuse"] or not state["use_all_reduce"]:
            raise ValueError("Unobserved fused/RSAG communication path")
        if (
            state["attention_tp_rank"],
            state["dense_tp_rank"],
            state["attention_tp_size"],
            state["dense_tp_size"],
        ) != (rank, rank, tp, tp):
            raise ValueError("Dense/attention TP mismatch")
        comm[index] = state
    metadata = {
        "case_id": case["case_id"],
        "step": step,
        "position": 135,
        "prefix_length_after": 136,
        "rank": rank,
        "tp": tp,
        "source_scope": "actual cached forward; caller validates original token and positions before entry",
        "runtime_request_id": "not_available_from_forward_context",
        "request_binding": "singlecase+inputIDs+actualpositions+step+ctx.bs1",
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "communication": comm,
        "fa": {
            "heads": fa.num_heads,
            "kv_heads": fa.num_kv_heads,
            "head_dim": fa.head_dim,
            "scaling": fa.scaling,
            "rotary_dim": fa.rotary_emb.rotary_dim,
            "rotary_is_neox_style": fa.rotary_emb.is_neox_style,
        },
    }
    with observe_cached_targets(
        targets,
        ctx,
        backend,
        torch=torch,
        kv_capture=capture_decode_kv,
        gdn_capture=capture_gdn_state,
    ) as observed:
        yield
    if set(observed["modules"]) != set(targets) or any(
        "outputs" not in value for value in observed["modules"].values()
    ):
        raise ValueError("Cached module observation incomplete")
    if (
        set(observed["kv"]) != {"before", "after"}
        or set(observed["states"]) != {8, 9, 10}
        or set(observed["backend"]) != {8, 9, 10}
    ):
        raise ValueError("Cached KV/state/backend observation incomplete")
    for layer in (8, 9, 10):
        if set(observed["states"][layer]) != {"before", "after"} or set(
            observed["backend"][layer]
        ) != {"decode", "scan"}:
            raise ValueError("GDN before/after coverage incomplete")
    norms = {
        key: module.gemma_weight.detach().cpu().clone()
        for key, module in targets.items()
        if key.endswith("input_layernorm") or key.endswith("post_attention_layernorm")
    }
    metadata["norm_eps"] = {
        key: module.variance_epsilon for key, module in targets.items() if key in norms
    }
    positions = observed["modules"]["fa7.rotary_emb"]["inputs"][0]
    if positions.reshape(-1).tolist() not in ([135], [135, 135, 135]):
        raise ValueError("Actual cached rotary positions mismatch")
    rotary_cache = fa.rotary_emb.cos_sin_cache[:136].detach().cpu().clone()
    with (output / "cached_step8.pt").open("xb") as stream:
        torch.save(
            {
                "metadata": metadata,
                "observed": observed,
                "effective_norms": norms,
                "rotary_cache": rotary_cache,
            },
            stream,
        )
    with (output / "cached_step8_metadata.json").open("x") as stream:
        json.dump(metadata, stream, indent=2)

    from gdn_checkpoint import verify_actual_gdn

    verify_actual_gdn(layers, torch=torch, rank=rank, tp=tp, output=output)
