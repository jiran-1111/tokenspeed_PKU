#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
from pathlib import Path

import numpy as np
import pytest


@pytest.fixture
def ref():
    p = Path(__file__).with_name("gdn_checkpoint.py")
    assert p.exists(), "actual checkpoint identity helper not implemented"
    spec = importlib.util.spec_from_file_location("gdn_checkpoint_under_test", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_split_each_logical_column_segment(ref):
    x = np.arange(36, dtype=np.float32).reshape(18, 2)
    actual = ref.column_shard(x, widths=[4, 4, 8, 2], rank=1, tp=2)
    np.testing.assert_array_equal(
        actual, np.concatenate([x[2:4], x[6:8], x[12:16], x[17:]])
    )
    assert not np.array_equal(actual, x[9:])


def test_row_shard_is_input_axis(ref):
    x = np.arange(24, dtype=np.float32).reshape(3, 8)
    np.testing.assert_array_equal(ref.row_shard(x, rank=1, tp=2), x[:, 4:])


def test_invalid_shape_or_rank_rejected(ref):
    with pytest.raises(ValueError):
        ref.column_shard(np.zeros((5, 3)), widths=[2, 3], rank=0, tp=2)
    with pytest.raises(ValueError):
        ref.row_shard(np.zeros((3, 8)), rank=2, tp=2)


def test_norm_metadata_accepts_only_observed_math(ref):
    valid = dict(eps=1e-6, group_size=None, norm_before_gate=True, sigmoid_gate=False)
    assert ref.check_norm_metadata(valid, expected_eps=1e-6) == valid
    for key, value in [
        ("eps", 1e-5),
        ("group_size", 64),
        ("norm_before_gate", False),
        ("sigmoid_gate", True),
    ]:
        with pytest.raises(ValueError):
            ref.check_norm_metadata(dict(valid, **{key: value}), expected_eps=1e-6)


def test_record_requires_exact_dtype_shape_and_bytes(ref):
    x = np.arange(4, dtype=np.float32).reshape(2, 2)
    assert ref.raw_identity(
        x.tobytes(),
        x.tobytes(),
        actual_shape=[2, 2],
        expected_shape=[2, 2],
        actual_dtype="float32",
        expected_dtype="float32",
    )["exact_match"]
    assert not ref.raw_identity(
        x.tobytes(),
        (x + 1).tobytes(),
        actual_shape=[2, 2],
        expected_shape=[2, 2],
        actual_dtype="float32",
        expected_dtype="float32",
    )["exact_match"]
    assert not ref.raw_identity(
        x.tobytes(),
        x.tobytes(),
        actual_shape=[2, 2],
        expected_shape=[4],
        actual_dtype="float32",
        expected_dtype="float32",
    )["exact_match"]
