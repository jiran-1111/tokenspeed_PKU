#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib.util
import os
from pathlib import Path

import pytest


@pytest.fixture
def collector():
    p = Path(__file__).with_name("collect_cpu_quality.py")
    spec = importlib.util.spec_from_file_location("quality_path_under_test", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_normal_model_file_within_explicit_workspace(collector, tmp_path):
    model = tmp_path / "model"
    model.mkdir()
    path = model / "config.json"
    path.write_text("{}")
    assert (
        collector.resolve_model_file(model, "config.json", workspace_root=tmp_path)
        == path.resolve()
    )


def test_lexical_parent_or_absolute_name_rejected(collector, tmp_path):
    model = tmp_path / "model"
    model.mkdir()
    with pytest.raises(ValueError):
        collector.resolve_model_file(model, "../other", workspace_root=tmp_path)
    with pytest.raises(ValueError):
        collector.resolve_model_file(
            model, str(tmp_path / "other"), workspace_root=tmp_path
        )


@pytest.mark.skipif(
    os.name == "nt", reason="actual symlink behavior is tested on Linux server"
)
def test_alias_to_same_workspace_model_store_is_allowed(collector, tmp_path):
    model = tmp_path / "source/models/model"
    model.mkdir(parents=True)
    store = tmp_path / "models/model"
    store.mkdir(parents=True)
    weight = store / "weight.safetensors"
    weight.write_bytes(b"fixed fixture")
    (model / weight.name).symlink_to(weight)
    assert (
        collector.resolve_model_file(model, weight.name, workspace_root=tmp_path)
        == weight.resolve()
    )


@pytest.mark.skipif(
    os.name == "nt", reason="actual symlink behavior is tested on Linux server"
)
def test_alias_outside_explicit_workspace_is_rejected(collector, tmp_path):
    workspace = tmp_path / "work"
    model = workspace / "source/models/model"
    model.mkdir(parents=True)
    outside = tmp_path / "outside"
    outside.mkdir()
    weight = outside / "weight.safetensors"
    weight.write_bytes(b"fixture")
    (model / weight.name).symlink_to(weight)
    with pytest.raises(ValueError):
        collector.resolve_model_file(model, weight.name, workspace_root=workspace)
