#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent NumPy FP32 math for one observed GDN decode token.

No runtime/kernel imports, paging, implicit input reconstruction, or claimed
emulation of Triton BF16 intermediates. See gdn_reference_notes.md for scope.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import ArrayLike, NDArray


def _sigmoid(x: NDArray[np.float32]) -> NDArray[np.float32]:
    exponential = np.exp(-np.abs(x))
    return np.where(x >= 0, 1 / (1 + exponential), exponential / (1 + exponential))


def gdn_decode_reference(
    q: ArrayLike,
    k: ArrayLike,
    v: ArrayLike,
    state: ArrayLike,
    *,
    A_log: ArrayLike,
    a: ArrayLike,
    dt_bias: ArrayLike,
    b: ArrayLike,
    use_qk_l2norm: bool,
) -> dict[str, NDArray[np.float32]]:
    """One request/token; q/k [Hk,K], v [Hv,V], state [Hv,V,K].

    All four gate inputs must be [Hv]. Frozen decode constants are norm
    epsilon=1e-6, softplus beta=1/threshold=20, and q scale=K**-0.5.
    normalized_q/k retain [Hk,K]; normalized_q excludes the later q scale.
    State and output are FP32 arithmetic references, without final BF16 casts.
    Inputs are never modified.
    """
    q, k, v, before = (np.asarray(x, dtype=np.float32) for x in (q, k, v, state))
    if q.ndim != 2 or k.shape != q.shape or v.ndim != 2:
        raise ValueError("q/k must be [Hk,K] and v must be [Hv,V]")
    hk, key_width = q.shape
    hv, value_width = v.shape
    if min(hk, hv, key_width, value_width) < 1 or hv % hk:
        raise ValueError(
            "value heads must be a positive integral multiple of key heads"
        )
    if before.shape != (hv, value_width, key_width):
        raise ValueError("state must be K-last [Hv,V,K]")
    A_log, a, dt_bias, b = (
        np.asarray(x, dtype=np.float32) for x in (A_log, a, dt_bias, b)
    )
    if any(x.shape != (hv,) for x in (A_log, a, dt_bias, b)):
        raise ValueError("A_log, a, dt_bias and b must each be [Hv]")

    x = a + dt_bias
    softplus = np.maximum(x, np.float32(0)) + np.log1p(np.exp(-np.abs(x)))
    softplus = np.where(x <= np.float32(20), softplus, x)
    g = -np.exp(A_log) * softplus
    beta = _sigmoid(b)
    if use_qk_l2norm:
        normalized_q = q / np.sqrt(
            np.sum(q * q, axis=-1, keepdims=True, dtype=np.float32) + np.float32(1e-6)
        )
        normalized_k = k / np.sqrt(
            np.sum(k * k, axis=-1, keepdims=True, dtype=np.float32) + np.float32(1e-6)
        )
    else:
        normalized_q, normalized_k = q.copy(), k.copy()

    key_head = np.arange(hv) // (hv // hk)
    local_k = normalized_k[key_head]
    scaled_q = normalized_q[key_head] * np.float32(key_width**-0.5)
    decayed = before * np.exp(g)[:, None, None]
    prediction = np.sum(decayed * local_k[:, None, :], axis=-1, dtype=np.float32)
    delta = (v - prediction) * beta[:, None]
    after = decayed + delta[:, :, None] * local_k[:, None, :]
    output = np.sum(after * scaled_q[:, None, :], axis=-1, dtype=np.float32)
    return {
        "output": output,
        "state": after,
        "g": g,
        "beta": beta,
        "normalized_q": normalized_q,
        "normalized_k": normalized_k,
    }


def _round_bf16(x: NDArray[np.float32]) -> NDArray[np.float32]:
    """BF16 round-to-nearest-even, represented as FP32; not kernel arithmetic."""
    bits = np.asarray(x, dtype=np.float32).view(np.uint32)
    rounded = (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(0xFFFF0000)
    is_nan = (bits & np.uint32(0x7FFFFFFF)) > np.uint32(0x7F800000)
    rounded = np.where(
        is_nan, (bits & np.uint32(0xFFFF0000)) | np.uint32(0x00400000), rounded
    )
    return rounded.view(np.float32)


def conv_update_reference(
    mixed_qkv: ArrayLike,
    conv_before: ArrayLike,
    weights: ArrayLike,
    *,
    activation: str | None,
) -> dict[str, NDArray[np.float32]]:
    """No-bias, four-tap single-token conv: [C], history [C,3], weights [C,4].

    History and weights run oldest -> newest. Output is FP32 after activation;
    *_bf16 are separate final-storage candidates, not BF16 arithmetic paths.
    """
    x, history, weight = (
        np.asarray(value, dtype=np.float32)
        for value in (mixed_qkv, conv_before, weights)
    )
    if x.ndim != 1 or history.shape != (x.size, 3) or weight.shape != (x.size, 4):
        raise ValueError("conv inputs must have shapes [C], [C,3], [C,4]")
    if activation not in (None, "silu", "swish"):
        raise ValueError("activation must be None, 'silu' or 'swish'")
    window = np.concatenate((history, x[:, None]), axis=1)
    output = np.zeros(x.size, dtype=np.float32)
    for tap in range(4):
        output = output + window[:, tap] * weight[:, tap]
    if activation is not None:
        output = output * _sigmoid(output)
    after = window[:, 1:].copy()
    return {
        "conv_after": after,
        "output": output,
        "conv_after_bf16": _round_bf16(after),
        "output_bf16": _round_bf16(output),
    }
