#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Small independent examples for the single-token CPU references."""

import unittest

import numpy as np

try:
    import gdn_reference as ref
except ModuleNotFoundError as exc:
    if exc.name != "gdn_reference":
        raise
    ref = None


def gates(heads):
    return {
        name: np.zeros(heads, dtype=np.float32)
        for name in ("A_log", "a", "dt_bias", "b")
    }


class GdnReferenceTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ref, "single-token references have not been implemented")

    def test_hand_computed_decay_then_delta_and_k_last_state(self):
        before = np.array([[[2, 4, 6], [1, 3, 5]]], dtype=np.float32)
        saved = before.copy()
        result = ref.gdn_decode_reference(
            [[1, 2, 0]], [[1, 0, 0]], [[3, 5]], before, **gates(1), use_qk_l2norm=False
        )
        np.testing.assert_allclose(
            result["state"], [[[2, 2, 3], [2.75, 1.5, 2.5]]], rtol=2e-7, atol=2e-7
        )
        np.testing.assert_allclose(
            result["output"], [[6 / np.sqrt(3), 5.75 / np.sqrt(3)]], rtol=2e-7
        )
        np.testing.assert_allclose(result["g"], [-np.log(2)], rtol=2e-7)
        np.testing.assert_array_equal(result["beta"], [0.5])
        np.testing.assert_array_equal(result["normalized_q"], [[1, 2, 0]])
        np.testing.assert_array_equal(before, saved)
        for value in result.values():
            self.assertEqual(value.dtype, np.dtype("float32"))

    def test_value_heads_repeat_key_heads_in_contiguous_groups(self):
        root_two = np.float32(np.sqrt(2))
        result = ref.gdn_decode_reference(
            [[root_two, 0], [0, root_two]],
            [[1, 0], [0, 1]],
            [[2], [4], [6], [8]],
            np.zeros((4, 1, 2)),
            **gates(4),
            use_qk_l2norm=False
        )
        np.testing.assert_allclose(result["output"], [[1], [2], [3], [4]], rtol=2e-7)
        np.testing.assert_array_equal(
            result["state"], [[[1, 0]], [[2, 0]], [[0, 3]], [[0, 4]]]
        )

    def test_l2_epsilon_is_added_inside_square_root(self):
        result = ref.gdn_decode_reference(
            [[1e-3]],
            [[1e-3]],
            [[1]],
            np.zeros((1, 1, 1)),
            **gates(1),
            use_qk_l2norm=True
        )
        np.testing.assert_allclose(
            result["normalized_q"], [[1 / np.sqrt(2)]], rtol=2e-7
        )
        np.testing.assert_allclose(
            result["normalized_k"], [[1 / np.sqrt(2)]], rtol=2e-7
        )
        np.testing.assert_allclose(result["output"], [[0.25]], rtol=3e-7)

    def test_zero_query_and_key_leave_only_decayed_state(self):
        result = ref.gdn_decode_reference(
            [[0, 0]],
            [[0, 0]],
            [[7]],
            np.array([[[2, 4]]]),
            **gates(1),
            use_qk_l2norm=True
        )
        np.testing.assert_array_equal(result["output"], [[0]])
        np.testing.assert_array_equal(result["state"], [[[1, 2]]])
        self.assertTrue(all(np.isfinite(value).all() for value in result.values()))

    def test_large_finite_gate_logits_do_not_overflow_softplus_or_sigmoid(self):
        args = gates(4)
        args["a"] = np.array([1000, -1000, 1000, -1000])
        args["b"] = np.array([1000, 1000, -1000, -1000])
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            result = ref.gdn_decode_reference(
                [[1]],
                [[1]],
                np.ones((4, 1)),
                np.ones((4, 1, 1)),
                **args,
                use_qk_l2norm=False
            )
        np.testing.assert_array_equal(result["g"], [-1000, 0, -1000, 0])
        np.testing.assert_array_equal(result["beta"], [1, 1, 0, 0])
        np.testing.assert_array_equal(result["output"], [[1], [1], [0], [1]])

    def test_head_ratio_must_be_integral(self):
        with self.assertRaisesRegex(ValueError, "heads"):
            ref.gdn_decode_reference(
                np.ones((2, 1)),
                np.ones((2, 1)),
                np.ones((3, 1)),
                np.zeros((3, 1, 1)),
                **gates(3),
                use_qk_l2norm=True
            )

    def test_rejects_k_first_state_instead_of_silently_transposing(self):
        with self.assertRaisesRegex(ValueError, "state"):
            ref.gdn_decode_reference(
                np.ones((1, 3)),
                np.ones((1, 3)),
                np.ones((1, 2)),
                np.zeros((1, 3, 2)),
                **gates(1),
                use_qk_l2norm=False
            )


class ConvReferenceTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ref, "single-token references have not been implemented")

    def test_chronological_four_tap_convolution_and_state_shift(self):
        before = np.array([[1, 2, 3], [5, 6, 7]], dtype=np.float32)
        saved = before.copy()
        result = ref.conv_update_reference(
            [4, 8], before, [[1, 10, 100, 1000], [1, -1, 2, -2]], activation=None
        )
        np.testing.assert_array_equal(result["output"], [4321, -3])
        np.testing.assert_array_equal(result["conv_after"], [[2, 3, 4], [6, 7, 8]])
        np.testing.assert_array_equal(before, saved)
        self.assertEqual(result["output"].dtype, np.dtype("float32"))

    def test_silu_and_swish_are_stable_for_large_finite_values(self):
        weight = np.zeros((3, 4), dtype=np.float32)
        weight[:, -1] = 1
        for activation in ("silu", "swish"):
            with np.errstate(over="raise", invalid="raise", divide="raise"):
                result = ref.conv_update_reference(
                    [-1000, 0, 1000], np.zeros((3, 3)), weight, activation=activation
                )
            np.testing.assert_array_equal(result["output"], [0, 0, 1000])

    def test_final_bf16_storage_candidate_uses_ties_to_even(self):
        values = np.array(
            [1 + 1 / 256, 1 + 3 / 256, -1 - 1 / 256, -1 - 3 / 256], dtype=np.float32
        )
        weight = np.zeros((4, 4), dtype=np.float32)
        weight[:, -1] = 1
        result = ref.conv_update_reference(
            values, np.zeros((4, 3)), weight, activation=None
        )
        np.testing.assert_array_equal(result["output"], values)
        np.testing.assert_array_equal(
            result["output_bf16"], [1, 1 + 1 / 64, -1, -1 - 1 / 64]
        )
        np.testing.assert_array_equal(
            result["conv_after_bf16"][:, -1], result["output_bf16"]
        )

    def test_unsupported_activation_is_not_silently_accepted(self):
        with self.assertRaisesRegex(ValueError, "activation"):
            ref.conv_update_reference(
                [1], [[0, 0, 0]], [[1, 1, 1, 1]], activation="relu"
            )


if __name__ == "__main__":
    unittest.main()
