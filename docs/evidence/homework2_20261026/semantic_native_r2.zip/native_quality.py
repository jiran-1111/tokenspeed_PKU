#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent native Engine output collection on the frozen semantic cohort."""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib
import json
import os
from pathlib import Path


def select_lease(mode, *, exclusive, shared):
    if mode == "exclusive":
        return exclusive
    if mode == "shared-functional":
        return shared
    raise ValueError("unknown explicit hardware lease mode")


def validate_quality_guard(guard, *, mode):
    if not guard["sources_unchanged"]:
        raise ValueError("source changed during collection")
    if mode == "exclusive":
        if not guard["engine_children_released"]:
            raise ValueError("exclusive engine children remain")
    elif mode == "shared-functional":
        if not guard["own_children_released"] or guard["violations"]:
            raise ValueError("shared collection protection failed")
    else:
        raise ValueError("unknown guard mode")


def collect_requests(engine, *, protocol, model_spec, output, records):
    for row in protocol["requests"]:
        ids = list(model_spec["input_ids"][row["request_id"]])
        sampling = {
            "temperature": 0,
            "top_p": 1,
            "top_k": 1,
            "ignore_eos": False,
            "stop_token_ids": list(model_spec["stop_token_ids"]),
            "max_new_tokens": protocol["max_new_tokens"],
            "skip_special_tokens": True,
            "no_stop_trim": False,
        }
        result = {
            "request_id": row["request_id"],
            "status": "starting",
            "input_ids": ids,
            "sampling_params": copy.deepcopy(sampling),
        }
        records.append(result)
        try:
            response = engine.generate(
                input_ids=list(ids),
                sampling_params=copy.deepcopy(sampling),
                stream=False,
                session_id=None,
            )
            with (output / (row["request_id"] + ".response.json")).open(
                "x", encoding="utf-8"
            ) as f:
                json.dump(response, f, indent=2, ensure_ascii=False, allow_nan=False)
            if (
                not isinstance(response, dict)
                or not isinstance(response["output_ids"], list)
                or any(type(n) is not int or n < 0 for n in response["output_ids"])
            ):
                raise ValueError("invalid native output IDs")
            tokens = response["output_ids"]
            meta = response["meta_info"]
            reason = meta["finish_reason"]
            if (
                len(tokens) > protocol["max_new_tokens"]
                or meta["prompt_tokens"] != len(ids)
                or not isinstance(response["text"], str)
            ):
                raise ValueError("native output shape or input token count mismatch")
            if not isinstance(reason, dict) or reason["type"] not in ("stop", "length"):
                raise ValueError("native request did not finish normally")
            if reason["type"] == "length" and len(tokens) != protocol["max_new_tokens"]:
                raise ValueError("native length termination differs from frozen budget")
            result.update(
                status="collected",
                output_ids=tokens,
                decoded_text=response["text"],
                finish_reason=reason,
                response_sha256=hashlib.sha256(
                    (output / (row["request_id"] + ".response.json")).read_bytes()
                ).hexdigest(),
            )
        except BaseException as error:
            result.update(status="failed", error_type=type(error).__name__)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("manifest", "config", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--manifest-sha", required=True)
    parser.add_argument("--model", choices=("0.8b", "4b", "9b", "27b"), required=True)
    parser.add_argument("--npu-id", type=int, required=True)
    parser.add_argument("--chips", required=True)
    parser.add_argument(
        "--lease-mode", choices=("exclusive", "shared-functional"), required=True
    )
    args = parser.parse_args()
    source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
    if hashlib.sha256(args.manifest.read_bytes()).hexdigest() != args.manifest_sha:
        raise ValueError("frozen input manifest mismatch")
    protocol = json.loads(args.manifest.read_text(encoding="utf-8"))
    spec = protocol["models"][args.model]
    config = json.loads(args.config.read_text(encoding="utf-8"))
    tp = config["tp_size"]
    if (
        hashlib.sha256(args.config.read_bytes()).hexdigest()
        != spec["config_sha256"][f"tp{tp}"]
    ):
        raise ValueError("paired config mismatch")
    if (
        config["model_id"] != spec["model_id"]
        or config["model_revision"] != spec["model_revision"]
    ):
        raise ValueError("model identity mismatch")
    if (
        protocol["max_new_tokens"] != 128
        or protocol["thinking_enabled"]
        or len(protocol["requests"]) != 8
    ):
        raise ValueError("wrong semantic cohort")
    if (
        config["prefix_caching"]
        or not config["disable_kvstore"]
        or config["overlap_schedule"]
        or config["enforce_eager"]
    ):
        raise ValueError("expected existing native graph/no-prefix/no-overlap configs")
    config.update(prometheus_port=39781, tokenspeed_metrics_port=39782)
    chips = {
        int(item.split(":")[0]): int(item.split(":")[1])
        for item in args.chips.split(",")
    }
    args.output.mkdir(parents=True, exist_ok=False)
    record = {
        "status": "starting",
        "model": args.model,
        "model_revision": spec["model_revision"],
        "tp": tp,
        "config": config,
        "execution_mode_configured": "graph_enabled",
        "lease_mode": args.lease_mode,
        "npu_id": args.npu_id,
        "chip_logic_ids": chips,
        "input_manifest_sha256": args.manifest_sha,
        "performance_eligible": False,
        "new_pass_threshold": None,
        "original_failures_replaced": False,
        "fixed_history_session_state_verified": False,
        "complete_logits_collected": False,
        "records": [],
    }
    from benchmarks.course_project.core import build_serve_command
    from benchmarks.course_project.tp_devices import (
        hardware_lease,
        verify_module_origins,
    )
    from scripts.run_session_kv import _engine_cli_args
    from shared_guard import shared_hardware_lease, stop_shared_monitor

    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    try:
        lease = select_lease(
            args.lease_mode, exclusive=hardware_lease, shared=shared_hardware_lease
        )
        with lease(
            source,
            npu_id=args.npu_id,
            chip_logic_ids=chips,
            tp_size=tp,
            output_dir=args.output,
            source_manifest=core,
        ) as guard:
            record["guard"] = guard
            modules = {
                name: importlib.import_module(name)
                for name in (
                    "tokenspeed.runtime.entrypoints.engine",
                    "tokenspeed_kernel",
                    "tokenspeed_kernel_npu",
                    "tokenspeed_scheduler",
                    "tokenspeed_scheduler.tokenspeed_scheduler_ext",
                )
            }
            paths = {name: Path(module.__file__) for name, module in modules.items()}
            dependency_path = (
                source / "docs/evidence/homework2_20261023/runtime_dependencies.json"
            )
            dependency_bytes = dependency_path.read_bytes()
            deps = json.loads(dependency_bytes)
            origins = verify_module_origins(
                source, paths, external_extensions=deps["external_extensions"]
            )
            core_files = json.loads(core.read_text())
            for name, origin in origins.items():
                if (
                    "path" in origin
                    and core_files.get(origin["path"]) != origin["sha256"]
                ):
                    if not (
                        name == "tokenspeed_scheduler.tokenspeed_scheduler_ext"
                        and deps["external_extensions"][paths[name].name]
                        == origin["sha256"]
                    ):
                        raise ValueError("loaded module differs from fixed source")
            record["runtime_origins"] = origins
            record["runtime_dependencies_sha256"] = hashlib.sha256(
                dependency_bytes
            ).hexdigest()
            from tokenspeed.runtime.utils.server_args import prepare_server_args

            Engine = modules["tokenspeed.runtime.entrypoints.engine"].Engine
            cli = _engine_cli_args(
                build_serve_command(config, host="127.0.0.1", port=18580)
            )
            record["engine_cli_args"] = cli
            with Engine(server_args=prepare_server_args(cli)) as engine:
                try:
                    collect_requests(
                        engine,
                        protocol=protocol,
                        model_spec=spec,
                        output=args.output,
                        records=record["records"],
                    )
                finally:
                    if args.lease_mode == "shared-functional":
                        stop_shared_monitor()
            if len(record["records"]) != 8 or not all(
                r["status"] == "collected" for r in record["records"]
            ):
                raise ValueError("native cohort incomplete")
            if (
                verify_module_origins(
                    source, paths, external_extensions=deps["external_extensions"]
                )
                != origins
                or dependency_path.read_bytes() != dependency_bytes
            ):
                raise ValueError("runtime source/extension identity changed")
            if (
                hashlib.sha256(args.manifest.read_bytes()).hexdigest()
                != args.manifest_sha
            ):
                raise ValueError("input manifest changed")
            record.update(runtime_origins_unchanged=True, input_manifest_unchanged=True)
            record["status"] = "captured_pending_guard_exit"
        validate_quality_guard(record["guard"], mode=args.lease_mode)
        record["status"] = "collected"
    except BaseException as error:
        record.update(
            failed_stage=record["status"],
            status="failed",
            error_type=type(error).__name__,
        )
        raise
    finally:
        with (args.output / "quality.json").open("x", encoding="utf-8") as f:
            json.dump(record, f, indent=2, ensure_ascii=False, allow_nan=False)


if __name__ == "__main__":
    main()
