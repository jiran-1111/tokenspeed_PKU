#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Prefer explicit snapshot paths over the existing scheduler editable redirect."""

import os
import sys
from pathlib import Path

snapshot = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"]).resolve(strict=True)
if not (snapshot / "python/tokenspeed").is_dir():
    raise SystemExit("the explicit TokenSpeed source snapshot is unavailable")
redirectors = [
    finder
    for finder in sys.meta_path
    if type(finder).__module__ == "_editable_skbc_tokenspeed_scheduler"
]
sys.meta_path[:] = [
    finder for finder in sys.meta_path if finder not in redirectors
] + redirectors
