#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU reanalysis linked to actual parameter identity in these captures."""

import hashlib
import json
import os
import subprocess
from pathlib import Path

task = Path.home() / "tokenspeed/.tmp/hw2-20261023"
source = task / "source_final"
tools = task / "cached_projection_r2_20261026"
assert json.loads((tools / "preparation.json").read_text())["passed"]
env = dict(os.environ)
env.update(
    TORCH_DEVICE_BACKEND_AUTOLOAD="0",
    ASCEND_RT_VISIBLE_DEVICES="",
    CUDA_VISIBLE_DEVICES="",
    PYTHONDONTWRITEBYTECODE="1",
    PYTHONPATH=str(tools),
    OMP_NUM_THREADS="8",
)
output = task / "gdn_identity_projection_20261026.json"
with (tools / "analysis.log").open("x") as log:
    p = subprocess.run(
        [
            str(source / ".conda-env/bin/python"),
            "-B",
            str(tools / "invoke.py"),
            "--root",
            str(source / "results/raw/homework2_20261024"),
            "--jobs-manifest",
            str(tools / "selected_jobs.json"),
            "--source-root",
            str(source),
            "--output",
            str(output),
            "--threads",
            "8",
        ],
        env=env,
        stdout=log,
        stderr=subprocess.STDOUT,
        timeout=600,
    )
record = {
    "status": "failed",
    "exit_code": p.returncode,
    "npu_execution": False,
    "output_exists": output.exists(),
}
if p.returncode == 0:
    report = json.loads(output.read_text())
    checks = 0
    identities = {}
    for tp in (1, 2):
        for rank in range(tp):
            key = f"tp{tp}_rank{rank}"
            directory = (
                source
                / "results/raw/homework2_20261024"
                / f"gdn_identity_9b_tp{tp}_20261026_r1"
                / f"rank_{rank}"
            )
            path = directory / "gdn_actual_checkpoint_identity.json"
            identity = json.loads(path.read_text())
            assert (
                identity["all_exact"]
                and identity["parameter_checks"] == 24
                and (identity["rank"], identity["tp"]) == (rank, tp)
            )
            assert (
                identity["checkpoint_config_sha256"]
                == report["checkpoint_config_sha256"]
                and identity["checkpoint_index_sha256"]
                == report["checkpoint_index_sha256"]
            )
            assert identity["model_revision"] == report["configured_model_revision"]
            assert (
                hashlib.sha256((directory / "cached_step8.pt").read_bytes()).hexdigest()
                == report["ranks"][key]["capture_sha256"]
            )
            for layer, values in identity["layers"].items():
                cpu = report["layers"][layer]["checkpoint_tensor_identities"]
                assert set(cpu) == set(values["checkpoint_tensors"])
                assert all(
                    cpu[name]["checkpoint_tensor_sha256"]
                    == values["checkpoint_tensors"][name]["checkpoint_tensor_sha256"]
                    for name in cpu
                )
                norm = values["parameters"]["linear_attn.norm.weight"]
                assert (
                    norm["actual_dtype"]
                    == cpu["linear_attn.norm.weight"]["expected_runtime_dtype"]
                    == "torch.bfloat16"
                )
                assert (
                    norm["actual_sha256"]
                    == cpu["linear_attn.norm.weight"]["expected_runtime_tensor_sha256"]
                )
                assert values["gated_norm"] == {
                    "eps": 1e-6,
                    "group_size": None,
                    "norm_before_gate": True,
                    "sigmoid_gate": False,
                }
                for item in values["parameters"].values():
                    assert (
                        item["exact_match"]
                        and item["actual_sha256"] == item["checkpoint_expected_sha256"]
                    )
                    checks += 1
            identities[key] = {
                "identity_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "capture_sha256": report["ranks"][key]["capture_sha256"],
            }
    assert checks == 72
    linked = {
        "passed": True,
        "parameter_checks": checks,
        "same_capture_identity_verified": True,
        "gated_norm_mode_verified": True,
        "npu_execution": False,
        "full_analysis_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "identities": identities,
        "interpretation": "The unchanged math analyzer reports its own checkpoint-expected scope. This separate cross-check verifies actual parameters and norm mode for these exact same captured forwards, not for unobserved historical runs.",
    }
    with (task / "gdn_identity_projection_link_20261026.json").open("x") as f:
        json.dump(linked, f, indent=2)
    record.update(
        status="passed",
        actual_parameter_checks=checks,
        same_capture_identity_verified=True,
    )
(tools / "state.json").write_text(json.dumps(record, indent=2))
print(json.dumps(record))
