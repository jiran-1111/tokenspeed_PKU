#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Strict CPU/native output pairing for the separately frozen eight-input cohort."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import struct
import sys
from pathlib import Path, PureWindowsPath

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
FROZEN_MANIFEST_SHA = "1e8e3ae38444191c7dd9d90ffa97b30f730e9e7ab98a2a7fc7a9e17b2d7ef774"
SOURCE_FILE_COUNT = 1531
MODELS = ("0.8b", "4b", "9b", "27b")
RUNTIME_MODULES = (
    "tokenspeed.runtime.entrypoints.engine",
    "tokenspeed_kernel",
    "tokenspeed_kernel_npu",
    "tokenspeed_scheduler",
    "tokenspeed_scheduler.tokenspeed_scheduler_ext",
)
EVIDENCE = "docs/evidence/homework2_20261023"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(
        Path(path).read_text(encoding="utf-8"),
        parse_constant=lambda value: require(False, "nonfinite JSON value"),
    )


def relative(root, name):
    require(
        isinstance(name, str) and bool(name), "nonempty relative evidence path required"
    )
    value = Path(name)
    require(
        not value.is_absolute()
        and not PureWindowsPath(name).drive
        and not PureWindowsPath(name).root,
        "evidence path must be relative",
    )
    root = Path(root).resolve()
    result = (root / value).resolve()
    require(
        result != root and result.is_relative_to(root), "evidence path escapes root"
    )
    return result


def file_record(path):
    return {"path": str(path), "sha256": sha(path)}


def ids(value, *, empty_allowed):
    require(
        isinstance(value, list)
        and (empty_allowed or bool(value))
        and all(type(token) is int and 0 <= token < 248320 for token in value),
        "invalid output/input token IDs",
    )


def compare_outputs(left, right, stop_ids):
    def compare(a, b):
        first = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), None)
        if first is None and len(a) != len(b):
            first = min(len(a), len(b))
        return {
            "exact_match": first is None,
            "engine_token_count": len(a),
            "reference_token_count": len(b),
            "first_mismatch_index": first,
            "matching_prefix_tokens": min(len(a), len(b)) if first is None else first,
            "matching_id_positions": sum(x == y for x, y in zip(a, b)),
            "first_mismatch": (
                None
                if first is None
                else {
                    "index": first,
                    "engine_id": a[first] if first < len(a) else None,
                    "reference_id": b[first] if first < len(b) else None,
                }
            ),
        }

    def trim(values):
        return values[
            : next(
                (i for i, token in enumerate(values) if token in stop_ids), len(values)
            )
        ]

    raw, aligned = compare(left, right), compare(trim(left), trim(right))
    return raw | {"stop_aligned_" + key: value for key, value in aligned.items()}


def expected_sampling(stops, maximum):
    return {
        "temperature": 0,
        "top_p": 1,
        "top_k": 1,
        "ignore_eos": False,
        "stop_token_ids": list(stops),
        "max_new_tokens": maximum,
        "skip_special_tokens": True,
        "no_stop_trim": False,
    }


def indexed(records, request_ids):
    require(
        isinstance(records, list) and len(records) == 8,
        "all eight request records are required",
    )
    result = {}
    for record in records:
        key = record["request_id"]
        require(
            key in request_ids and key not in result, "unknown or duplicate request ID"
        )
        result[key] = record
    require(set(result) == set(request_ids), "request coverage mismatch")
    return result


def validate_source(source, protocol):
    core_path = source / EVIDENCE / "source_manifest.json"
    require(
        sha(core_path) == protocol["source_manifest_sha256"] == CORE_SHA,
        "fixed core manifest SHA mismatch",
    )
    core = read(core_path)
    require(
        isinstance(core, dict) and len(core) == SOURCE_FILE_COUNT,
        "fixed source file count mismatch",
    )
    require(
        all(sha(relative(source, name)) == digest for name, digest in core.items()),
        "fixed source file SHA mismatch",
    )
    artifacts_path = source / EVIDENCE / "model_artifacts.json"
    require(
        sha(artifacts_path) == protocol["model_artifacts_sha256"],
        "certified model artifact list mismatch",
    )
    artifacts = read(artifacts_path)["models"]
    for model in MODELS:
        spec = protocol["models"][model]
        matches = [
            item
            for item in artifacts
            if (item["model_id"], item["model_revision"])
            == (spec["model_id"], spec["model_revision"])
        ]
        require(
            len(matches) == 1 and matches[0]["files"] == spec["expected_model_files"],
            "certified model identity differs from frozen cohort",
        )
        for tp in ("tp1", "tp2"):
            require(
                sha(relative(source, spec["config_paths"][tp]))
                == spec["config_sha256"][tp],
                "frozen model config SHA mismatch",
            )
    return core


def validate_cpu(directory, *, model, protocol, manifest_sha, source):
    spec = protocol["models"][model]
    state_path = directory / "state.json"
    state = read(state_path)
    require(
        state["status"] == "collected"
        and state["model"] == model
        and state["model_revision"] == spec["model_revision"]
        and state["manifest_sha256"] == manifest_sha
        and state["source_manifest_sha256"] == CORE_SHA,
        "CPU completion/model/manifest identity mismatch",
    )
    require(
        all(
            state[name] is True
            for name in (
                "source_unchanged",
                "model_files_unchanged",
                "reference_sources_unchanged",
                "npu_import_blocked",
            )
        ),
        "CPU completion verification flags failed",
    )
    require(
        state["cpu_threads"] == state["actual_threads"] == 8
        and state["compute_dtype"] == "float32"
        and state["actual_attention"] == "eager"
        and state["performance_eligible"] is False
        and state["new_pass_threshold"] is None
        and state["complete_logits_collected"] is False,
        "CPU reference contract mismatch",
    )
    require(
        set(state["verified_model_files"]) == set(spec["expected_model_files"]),
        "CPU certified model file coverage mismatch",
    )
    require(
        all(
            not state["loading"][name]
            for name in ("missing_keys", "mismatched_keys", "error_msgs")
        )
        and all(
            name.startswith(("model.visual.", "visual."))
            for name in state["loading"]["unexpected_keys"]
        ),
        "CPU loading information mismatch",
    )
    weight_path = directory / "weight_identity.json"
    require(
        sha(weight_path) == state["weight_identity_sha256"],
        "CPU weight identity file SHA mismatch",
    )
    weights = read(weight_path)
    require(
        weights["global_weight_sha256"] == state["global_weight_sha256"]
        and bool(weights["parameters"]),
        "CPU projected weight identity mismatch",
    )
    for parameter in weights["parameters"]:
        expected = (
            "float32"
            if parameter["name"].rsplit(".", 1)[-1] in ("A_log", "dt_bias")
            else "bfloat16"
        )
        require(
            parameter["actual_dtype"] == "torch.float32"
            and parameter["projection_dtype"] == expected,
            "CPU original projection policy mismatch",
        )
    refs = state["reference_source_sha256"]
    require(
        refs["collector"] == state["collector_sha256"]
        and refs["hf_model"] == state["hf_implementation_sha256"]
        and refs["weight_collector"] == state["reference_weight_collector_sha256"]
        and refs["weight_collector"]
        == sha(source / "scripts/collect_homework1_references.py")
        and refs["weight_contract"]
        == sha(source / "benchmarks/course_project/reference_contracts.py")
        and all(
            isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value)
            for value in refs.values()
        ),
        "CPU reference source SHA mismatch",
    )
    expected_rows = {row["request_id"]: row for row in protocol["requests"]}
    records, result = indexed(state["records"], expected_rows), {}
    for key, item in records.items():
        path = relative(directory, item["output_file"])
        require(
            path.name == key + ".json" and sha(path) == item["sha256"],
            "CPU request file SHA/name mismatch",
        )
        record = read(path)
        row = expected_rows[key]
        require(
            (record["request_id"], record["case"], record["turn_index"])
            == (key, row["case"], row["turn_index"])
            and record["input_ids"] == spec["input_ids"][key]
            and record["stop_token_ids"] == spec["stop_token_ids"]
            and record["complete_logits_collected"] is False,
            "CPU request/input identity mismatch",
        )
        tokens, stops = record["output_ids"], spec["stop_token_ids"]
        ids(tokens, empty_allowed=False)
        require(
            len(tokens) <= protocol["max_new_tokens"]
            and item["tokens"] == len(tokens)
            and item["stop_reason"] == record["stop_reason"]
            and isinstance(record["decoded_raw"], str)
            and isinstance(record["decoded_text"], str),
            "CPU output record mismatch",
        )
        if record["stop_reason"] == "eos":
            require(
                tokens[-1] in stops
                and not any(token in stops for token in tokens[:-1]),
                "CPU EOS placement mismatch",
            )
        else:
            require(
                record["stop_reason"] == "max_new_tokens"
                and len(tokens) == protocol["max_new_tokens"]
                and not any(token in stops for token in tokens),
                "CPU length stop mismatch",
            )
        margins = record["greedy_margins"]
        require(
            isinstance(margins, list) and len(margins) == len(tokens),
            "CPU margin coverage mismatch",
        )
        for index, margin in enumerate(margins):
            top_ids, logits = margin["top2_ids"], margin["top2_logits"]
            ids(top_ids, empty_allowed=False)
            require(
                len(top_ids) == len(logits) == 2
                and top_ids[0] != top_ids[1]
                and all(
                    isinstance(x, (float, int)) and math.isfinite(x) for x in logits
                )
                and logits[0] >= logits[1],
                "CPU top2 margin schema mismatch",
            )
            expected_margin = struct.unpack(
                "<f", struct.pack("<f", logits[0] - logits[1])
            )[0]
            require(
                margin["step"] == index
                and margin["token_id"] == tokens[index]
                and margin["margin"] == expected_margin
                and (expected_margin == 0 or top_ids[0] == tokens[index]),
                "CPU greedy margin/token mismatch",
            )
        result[key] = {"record": record, "file": file_record(path)}
    return {
        "state": state,
        "files": [file_record(state_path), file_record(weight_path)],
    }, result


def validate_guard(guard, kind):
    require(kind in ("shared", "exclusive"), "unknown explicit guard kind")
    require(
        guard["sources_sha"] == guard["sources_after_sha"] == CORE_SHA
        and guard["sources_unchanged"] is True,
        "native source guard failed",
    )
    if kind == "shared":
        require(
            guard["own_children_released"] is True and guard["violations"] == [],
            "native shared guard failed",
        )
    else:
        require(
            guard["engine_children_released"] is True, "native exclusive guard failed"
        )


def validate_native(
    directory, *, model, tp, kind, protocol, manifest_sha, source, core
):
    spec = protocol["models"][model]
    path = directory / "quality.json"
    quality = read(path)
    require(
        quality["status"] == "collected"
        and quality["model"] == model
        and quality["tp"] == tp
        and quality["model_revision"] == spec["model_revision"]
        and quality["input_manifest_sha256"] == manifest_sha,
        "native completion/model/manifest identity mismatch",
    )
    require(
        quality["runtime_origins_unchanged"] is True
        and quality["input_manifest_unchanged"] is True
        and quality["performance_eligible"] is False
        and quality["new_pass_threshold"] is None
        and quality["original_failures_replaced"] is False
        and quality["fixed_history_session_state_verified"] is False
        and quality["complete_logits_collected"] is False
        and quality["execution_mode_configured"] == "graph_enabled",
        "native runtime/input/scope verification mismatch",
    )
    validate_guard(quality["guard"], kind)
    config = read(relative(source, spec["config_paths"][f"tp{tp}"]))
    excluded = {"prometheus_port", "tokenspeed_metrics_port"}
    require(
        {k: v for k, v in quality["config"].items() if k not in excluded}
        == {k: v for k, v in config.items() if k not in excluded},
        "native effective config mismatch",
    )
    deps_path = source / EVIDENCE / "runtime_dependencies.json"
    require(
        sha(deps_path) == quality["runtime_dependencies_sha256"],
        "native dependency file SHA mismatch",
    )
    deps = read(deps_path)["external_extensions"]
    require(
        set(quality["runtime_origins"]) == set(RUNTIME_MODULES),
        "native runtime origin coverage mismatch",
    )
    for name, origin in quality["runtime_origins"].items():
        if "path" in origin:
            relative(source, origin["path"])
            if origin["path"] in core:
                require(
                    core[origin["path"]] == origin["sha256"],
                    "native runtime source SHA mismatch",
                )
                continue
            basename = Path(origin["path"]).name
        else:
            basename = origin["basename"]
        require(
            name == RUNTIME_MODULES[-1]
            and basename.startswith("tokenspeed_scheduler_ext.")
            and basename in deps
            and origin["sha256"] == deps[basename],
            "native extension identity mismatch",
        )
    expected_rows = {row["request_id"]: row for row in protocol["requests"]}
    records, result = indexed(quality["records"], expected_rows), {}
    for key, record in records.items():
        require(
            record["status"] == "collected"
            and record["input_ids"] == spec["input_ids"][key]
            and record["sampling_params"]
            == expected_sampling(spec["stop_token_ids"], protocol["max_new_tokens"]),
            "native request/input/sampling mismatch",
        )
        response_path = directory / (key + ".response.json")
        require(
            sha(response_path) == record["response_sha256"],
            "native response SHA mismatch",
        )
        response = read(response_path)
        require(
            response["output_ids"] == record["output_ids"]
            and response["text"] == record["decoded_text"]
            and response["meta_info"]["finish_reason"] == record["finish_reason"]
            and response["meta_info"]["prompt_tokens"] == len(spec["input_ids"][key]),
            "native response/record correspondence mismatch",
        )
        tokens, reason = record["output_ids"], record["finish_reason"]
        ids(tokens, empty_allowed=True)
        require(
            len(tokens) <= protocol["max_new_tokens"]
            and isinstance(record["decoded_text"], str),
            "native output bound/text mismatch",
        )
        if reason["type"] == "stop":
            require(
                type(reason["matched"]) is int
                and reason["matched"] in spec["stop_token_ids"],
                "native explicit EOS stop mismatch",
            )
        else:
            require(
                reason["type"] == "length"
                and len(tokens) == protocol["max_new_tokens"],
                "native length termination mismatch",
            )
        require(
            not any(token in spec["stop_token_ids"] for token in tokens[:-1]),
            "native tokens continue after EOS",
        )
        result[key] = {
            "record": record,
            "response": response,
            "file": file_record(response_path),
        }
    return {"record": quality, "guard_kind": kind, "file": file_record(path)}, result


def load_controllers(root, selection):
    items = selection["native_controllers"]
    require(isinstance(items, list) and bool(items), "native controllers required")
    controllers, paths = [], set()
    for item in items:
        path = relative(root, item["path"])
        require(path not in paths, "duplicate native controller file")
        paths.add(path)
        evidence = file_record(path)
        require(evidence["sha256"] == item["sha256"], "native controller SHA mismatch")
        controller = read(path)
        require(
            controller["source_manifest_sha256"] == CORE_SHA,
            "native controller source mismatch",
        )
        require(
            isinstance(controller["finished"], dict),
            "native controller finished mapping required",
        )
        for job, record in controller["finished"].items():
            require(record["job"] == job, "native controller job name mismatch")
        controllers.append({"file": evidence, "record": controller})
    return controllers


def validate_controller(controllers, *, job, quality_file):
    matches = [item for item in controllers if job in item["record"]["finished"]]
    require(len(matches) == 1, "native job requires exactly one controller completion")
    controller = matches[0]
    record = controller["record"]["finished"][job]
    require(
        record["job"] == job
        and type(record["exit_code"]) is int
        and record["exit_code"] == 0
        and record["own_contexts_released"] is True
        and record["quality_status"] == "collected"
        and type(record["requests"]) is int
        and record["requests"] == 8
        and record["guard_verified"] is True,
        "native driver completion or context release unverified",
    )
    return {
        "job": job,
        "controller_file": controller["file"],
        "finished": record,
        "quality_file": quality_file,
        "scope": "Driver exit and own-context release; separate from quality.guard child-process checks. The current quality file SHA is bound here, not asserted to exist in the historical controller record.",
    }


def analyze(*, root, manifest_path, selection_path, source_root):
    try:
        return _analyze(
            root=Path(root).resolve(),
            manifest_path=Path(manifest_path),
            selection_path=Path(selection_path),
            source=Path(source_root).resolve(),
        )
    except (KeyError, TypeError, OSError, IndexError) as error:
        raise ValueError(
            f"Incomplete or invalid semantic evidence ({type(error).__name__})"
        ) from error


def _analyze(*, root, manifest_path, selection_path, source):
    manifest_sha = sha(manifest_path)
    require(manifest_sha == FROZEN_MANIFEST_SHA, "frozen input manifest SHA mismatch")
    protocol, selection = read(manifest_path), read(selection_path)
    require(
        selection["manifest_sha256"] == manifest_sha
        and set(selection["models"]) == set(MODELS),
        "explicit four-model selection mismatch",
    )
    require(
        protocol["thinking_enabled"] is False
        and protocol["max_new_tokens"] == 128
        and protocol["greedy"] is True
        and protocol["stop_at_eos"] is True
        and protocol["complete_logits_collected"] is False
        and protocol["new_pass_threshold"] is None
        and protocol["replaces_original_failures"] is False
        and set(protocol["models"]) == set(MODELS)
        and len(protocol["requests"]) == 8,
        "frozen cohort scope mismatch",
    )
    request_ids = [row["request_id"] for row in protocol["requests"]]
    require(
        len(set(request_ids)) == 8
        and all(
            isinstance(key, str) and re.fullmatch("[a-z0-9_]+", key)
            for key in request_ids
        ),
        "frozen request ID coverage mismatch",
    )
    for spec in protocol["models"].values():
        require(
            set(spec["input_ids"]) == set(request_ids),
            "frozen input ID coverage mismatch",
        )
        ids(spec["stop_token_ids"], empty_allowed=False)
        for values in spec["input_ids"].values():
            ids(values, empty_allowed=False)
            require(
                len(values) + 128 <= spec["max_model_len"],
                "frozen context budget mismatch",
            )
    controllers = load_controllers(root, selection)
    core = validate_source(source, protocol)
    report = {
        "schema_version": 1,
        "analysis_kind": "finite_cohort_output_pairing",
        "manifest": file_record(manifest_path),
        "selection": file_record(selection_path) | {"record": selection},
        "source_manifest_sha256": CORE_SHA,
        "analyzer_sha256": sha(__file__),
        "native_controllers": controllers,
        "models": {},
        "historical_failures": [],
        "new_quality_threshold": None,
        "original_4b_9b_failures_resolved": False,
        "complete_logits_collected": False,
        "performance_eligible": False,
        "session_state_verified": False,
        "margin_scope": "Each CPU margin belongs to its own generated history. After output divergence it is not a common-frontier numerical comparison.",
        "scope": "Descriptive IDs and text for eight frozen requests per model; no general model-quality pass, no replacement of original failures.",
    }
    selected = set()
    for model in MODELS:
        choice = selection["models"][model]
        require(
            set(choice) == {"cpu", "tp1", "tp2"},
            "each model requires explicit CPU/TP1/TP2 selections",
        )
        cpu_dir = relative(root, choice["cpu"])
        require(cpu_dir not in selected, "duplicate selected run directory")
        selected.add(cpu_dir)
        evidence, outputs = {}, {}
        evidence["cpu"], outputs["cpu"] = validate_cpu(
            cpu_dir,
            model=model,
            protocol=protocol,
            manifest_sha=manifest_sha,
            source=source,
        )
        for tp in (1, 2):
            key = f"tp{tp}"
            directory = relative(root, choice[key]["directory"])
            require(directory not in selected, "duplicate selected run directory")
            selected.add(directory)
            evidence[key], outputs[key] = validate_native(
                directory,
                model=model,
                tp=tp,
                kind=choice[key]["guard_kind"],
                protocol=protocol,
                manifest_sha=manifest_sha,
                source=source,
                core=core,
            )
            evidence[key]["driver_closure"] = validate_controller(
                controllers, job=directory.name, quality_file=evidence[key]["file"]
            )
        pairs = {
            "tp2_vs_tp1": ("tp2", "tp1"),
            "tp1_vs_cpu": ("tp1", "cpu"),
            "tp2_vs_cpu": ("tp2", "cpu"),
        }
        rows = []
        for row in protocol["requests"]:
            key = row["request_id"]
            records = {role: values[key] for role, values in outputs.items()}
            comparisons = {
                name: compare_outputs(
                    records[left]["record"]["output_ids"],
                    records[right]["record"]["output_ids"],
                    protocol["models"][model]["stop_token_ids"],
                )
                for name, (left, right) in pairs.items()
            }
            rows.append(
                {
                    "request_id": key,
                    "case": row["case"],
                    "turn_index": row["turn_index"],
                    "messages": row["messages"],
                    "outputs": records,
                    "comparisons": comparisons,
                }
            )
        counts = {
            name: {
                "requests": 8,
                "raw_exact_matches": sum(
                    row["comparisons"][name]["exact_match"] for row in rows
                ),
                "stop_aligned_exact_matches": sum(
                    row["comparisons"][name]["stop_aligned_exact_match"] for row in rows
                ),
            }
            for name in pairs
        }
        report["models"][model] = {
            "model_revision": protocol["models"][model]["model_revision"],
            "evidence": evidence,
            "requests": rows,
            "comparison_counts": counts,
        }
    history = selection["historical_failures"]
    require(
        isinstance(history, list)
        and history
        and any(item["model"] == "27b" and item["tp"] == 1 for item in history),
        "original27BTP1 failure must remain explicitly selected",
    )
    for item in history:
        require(
            item["model"] in MODELS
            and item["tp"] in (1, 2)
            and item["guard_kind"] in ("shared", "exclusive"),
            "historical failure selection mismatch",
        )
        directory = relative(root, item["directory"])
        require(
            directory not in selected,
            "historical failure must not replace a successful selection",
        )
        selected.add(directory)
        path = directory / "quality.json"
        record = read(path)
        require(
            record["status"] == "failed"
            and record["model"] == item["model"]
            and record["tp"] == item["tp"]
            and record["model_revision"]
            == protocol["models"][item["model"]]["model_revision"]
            and record["input_manifest_sha256"] == manifest_sha
            and record["guard"]["sources_sha"] == CORE_SHA,
            "historical failed run identity mismatch",
        )
        report["historical_failures"].append(
            {
                "selection": item,
                "file": file_record(path),
                "record": record,
                "excluded_from_success_pairs": True,
                "original_status_preserved": True,
            }
        )
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "manifest", "selection", "source-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    args = parser.parse_args()
    report = analyze(
        root=args.root,
        manifest_path=args.manifest,
        selection_path=args.selection,
        source_root=args.source_root,
    )
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "models": 4,
                "requests_per_model": 8,
                "comparisons": 96,
                "historical_failures": len(report["historical_failures"]),
                "new_quality_threshold": None,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps({"status": "failed", "error_type": type(error).__name__}),
            file=sys.stderr,
        )
        sys.exit(1)
