#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""File-level pairing tests with fake eight-request runs; no model execution."""

import hashlib
import importlib.util
import json
from pathlib import Path

import pytest


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    script = Path(__file__).with_name("analyze_semantic_quality.py")
    assert script.exists(), "semantic pairing analyzer is not implemented"
    spec = importlib.util.spec_from_file_location("semantic_pairing_under_test", script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    root, source = tmp_path / "jobs", tmp_path / "source"
    root.mkdir()
    source.mkdir()
    models = ("0.8b", "4b", "9b", "27b")
    files = {}
    for index, name in enumerate(module.RUNTIME_MODULES[:-1]):
        path = source / f"runtime/{index}.py"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name, encoding="utf-8")
        files[path.relative_to(source).as_posix()] = module.sha(path)
    for name in (
        "benchmarks/course_project/reference_contracts.py",
        "scripts/collect_homework1_references.py",
    ):
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(name, encoding="utf-8")
        files[name] = module.sha(path)
    deps_path = source / "docs/evidence/homework2_20261023/runtime_dependencies.json"
    put(
        deps_path,
        {"external_extensions": {"tokenspeed_scheduler_ext.fixture.so": "e" * 64}},
    )
    requests = [
        {
            "request_id": f"request_{i}",
            "case": f"case_{i}",
            "turn_index": 1,
            "category": "fixture",
            "messages": [{"role": "user", "content": str(i)}],
        }
        for i in range(8)
    ]
    manifest = {
        "schema_version": 1,
        "protocol": "semantic_no_thinking_fixed_history_20261026",
        "source_manifest_sha256": None,
        "model_artifacts_sha256": None,
        "thinking_enabled": False,
        "max_new_tokens": 128,
        "greedy": True,
        "stop_at_eos": True,
        "requests": requests,
        "models": {},
        "complete_logits_collected": False,
        "new_pass_threshold": None,
        "replaces_original_failures": False,
    }
    artifacts = []
    for model in models:
        spec = {
            "model_id": f"fixture/{model}",
            "model_revision": "revision_" + model,
            "config_paths": {},
            "config_sha256": {},
            "stop_token_ids": [9],
            "expected_model_files": {"weights.bin": {"bytes": 3, "sha256": "a" * 64}},
            "input_ids": {r["request_id"]: [1, 2] for r in requests},
            "max_model_len": 4096,
        }
        for tp in (1, 2):
            config = {
                "model_id": spec["model_id"],
                "model_revision": spec["model_revision"],
                "tp_size": tp,
                "prefix_caching": False,
                "disable_kvstore": True,
                "overlap_schedule": False,
                "enforce_eager": False,
                "memory_utilization": 0.95 if model == "27b" else 0.9,
                "prometheus_port": 1,
                "tokenspeed_metrics_port": 2,
            }
            name = f"configs/{model}_tp{tp}.json"
            digest = put(source / name, config)
            files[name] = digest
            spec["config_paths"][f"tp{tp}"] = name
            spec["config_sha256"][f"tp{tp}"] = digest
        manifest["models"][model] = spec
        artifacts.append(
            {
                "model_id": spec["model_id"],
                "model_revision": spec["model_revision"],
                "files": spec["expected_model_files"],
            }
        )
    manifest["model_artifacts_sha256"] = put(
        source / "docs/evidence/homework2_20261023/model_artifacts.json",
        {"models": artifacts},
    )
    core_sha = put(
        source / "docs/evidence/homework2_20261023/source_manifest.json", files
    )
    manifest["source_manifest_sha256"] = core_sha
    monkeypatch.setattr(module, "CORE_SHA", core_sha)
    monkeypatch.setattr(module, "SOURCE_FILE_COUNT", len(files))
    manifest_path = tmp_path / "manifest.json"
    manifest_sha = put(manifest_path, manifest)
    monkeypatch.setattr(module, "FROZEN_MANIFEST_SHA", manifest_sha)
    selection = {
        "manifest_sha256": manifest_sha,
        "models": {},
        "historical_failures": [
            {
                "model": "27b",
                "tp": 1,
                "directory": "failed_27b_r1",
                "guard_kind": "shared",
            }
        ],
    }
    for model in models:
        spec = manifest["models"][model]
        cpu_dir = root / f"cpu_{model}"
        weights = {
            "parameters": [
                {
                    "name": "fixture.weight",
                    "shape": [1],
                    "projection_dtype": "bfloat16",
                    "actual_dtype": "torch.float32",
                    "sha256": "f" * 64,
                }
            ],
            "global_weight_sha256": "d" * 64,
        }
        weight_sha = put(cpu_dir / "weight_identity.json", weights)
        refs = {
            "hf_model": "b" * 64,
            "hf_cache": "c" * 64,
            "collector": "a" * 64,
            "weight_contract": files[
                "benchmarks/course_project/reference_contracts.py"
            ],
            "weight_collector": files["scripts/collect_homework1_references.py"],
        }
        state = {
            "status": "collected",
            "model": model,
            "model_revision": spec["model_revision"],
            "manifest_sha256": manifest_sha,
            "source_manifest_sha256": core_sha,
            "source_unchanged": True,
            "model_files_unchanged": True,
            "reference_sources_unchanged": True,
            "npu_import_blocked": True,
            "compute_dtype": "float32",
            "cpu_threads": 8,
            "actual_threads": 8,
            "actual_attention": "eager",
            "performance_eligible": False,
            "new_pass_threshold": None,
            "complete_logits_collected": False,
            "records": [],
            "weight_identity_sha256": weight_sha,
            "global_weight_sha256": weights["global_weight_sha256"],
            "reference_source_sha256": refs,
            "collector_sha256": refs["collector"],
            "hf_implementation_sha256": refs["hf_model"],
            "reference_weight_collector_sha256": refs["weight_collector"],
            "verified_model_files": ["weights.bin"],
            "loading": {
                "missing_keys": [],
                "mismatched_keys": [],
                "error_msgs": [],
                "unexpected_keys": [],
            },
        }
        for row in requests:
            record = {
                "request_id": row["request_id"],
                "case": row["case"],
                "turn_index": 1,
                "input_ids": [1, 2],
                "output_ids": [4, 9],
                "stop_reason": "eos",
                "stop_token_ids": [9],
                "decoded_raw": "fixture EOS",
                "decoded_text": "fixture",
                "complete_logits_collected": False,
                "greedy_margins": [
                    {
                        "step": i,
                        "token_id": token,
                        "top2_ids": [token, 8],
                        "top2_logits": [2.0, 1.0],
                        "margin": 1.0,
                    }
                    for i, token in enumerate([4, 9])
                ],
            }
            name = row["request_id"] + ".json"
            digest = put(cpu_dir / name, record)
            state["records"].append(
                {
                    "request_id": row["request_id"],
                    "output_file": name,
                    "sha256": digest,
                    "tokens": 2,
                    "stop_reason": "eos",
                }
            )
        put(cpu_dir / "state.json", state)
        selection["models"][model] = {"cpu": cpu_dir.name}
        for tp in (1, 2):
            directory = root / f"native_{model}_tp{tp}"
            kind = "exclusive" if model == "27b" and tp == 1 else "shared"
            config = json.loads(
                (source / spec["config_paths"][f"tp{tp}"]).read_text(encoding="utf-8")
            )
            config.update(prometheus_port=39781, tokenspeed_metrics_port=39782)
            origins = {
                name: {"path": f"runtime/{i}.py", "sha256": files[f"runtime/{i}.py"]}
                for i, name in enumerate(module.RUNTIME_MODULES[:-1])
            }
            origins[module.RUNTIME_MODULES[-1]] = {
                "basename": "tokenspeed_scheduler_ext.fixture.so",
                "sha256": "e" * 64,
            }
            guard = {
                "sources_sha": core_sha,
                "sources_after_sha": core_sha,
                "sources_unchanged": True,
            }
            guard.update(
                {"own_children_released": True, "violations": []}
                if kind == "shared"
                else {"engine_children_released": True}
            )
            native = {
                "status": "collected",
                "model": model,
                "model_revision": spec["model_revision"],
                "tp": tp,
                "config": config,
                "input_manifest_sha256": manifest_sha,
                "guard": guard,
                "runtime_origins_unchanged": True,
                "input_manifest_unchanged": True,
                "runtime_origins": origins,
                "runtime_dependencies_sha256": module.sha(deps_path),
                "performance_eligible": False,
                "new_pass_threshold": None,
                "complete_logits_collected": False,
                "original_failures_replaced": False,
                "fixed_history_session_state_verified": False,
                "execution_mode_configured": "graph_enabled",
                "records": [],
            }
            for row in requests:
                response = {
                    "output_ids": [4, 9],
                    "text": "fixture",
                    "meta_info": {
                        "prompt_tokens": 2,
                        "finish_reason": {"type": "stop", "matched": 9},
                    },
                }
                digest = put(
                    directory / (row["request_id"] + ".response.json"), response
                )
                native["records"].append(
                    {
                        "request_id": row["request_id"],
                        "status": "collected",
                        "input_ids": [1, 2],
                        "sampling_params": module.expected_sampling([9], 128),
                        "output_ids": [4, 9],
                        "decoded_text": "fixture",
                        "finish_reason": response["meta_info"]["finish_reason"],
                        "response_sha256": digest,
                    }
                )
            put(directory / "quality.json", native)
            selection["models"][model][f"tp{tp}"] = {
                "directory": directory.name,
                "guard_kind": kind,
            }
    put(
        root / "failed_27b_r1/quality.json",
        {
            "status": "failed",
            "model": "27b",
            "tp": 1,
            "model_revision": manifest["models"]["27b"]["model_revision"],
            "input_manifest_sha256": manifest_sha,
            "records": [],
            "guard": {"sources_sha": core_sha, "violations": ["reserve below8GB"]},
            "error_type": "ValueError",
        },
    )
    selection["native_controllers"] = []
    for name, models, status in (
        ("native_r1", ("0.8b", "4b", "9b"), "failed"),
        ("native_r2", ("27b",), "collected"),
    ):
        finished = {}
        for model in models:
            for tp in (1, 2):
                job = selection["models"][model][f"tp{tp}"]["directory"]
                finished[job] = {
                    "job": job,
                    "exit_code": 0,
                    "own_contexts_released": True,
                    "quality_status": "collected",
                    "requests": 8,
                    "guard_verified": True,
                }
        path = f"_controllers/{name}.json"
        digest = put(
            root / path,
            {
                "status": status,
                "source_manifest_sha256": core_sha,
                "finished": finished,
            },
        )
        selection["native_controllers"].append({"path": path, "sha256": digest})
    selection_path = tmp_path / "selection.json"
    put(selection_path, selection)
    return module, root, source, manifest_path, selection_path


def run(fixture):
    module, root, source, manifest, selection = fixture
    return module.analyze(
        root=root, manifest_path=manifest, selection_path=selection, source_root=source
    )


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def test_all_four_models_are_paired_and_failed_27_run_is_kept(fixture):
    report = run(fixture)
    assert set(report["models"]) == {"0.8b", "4b", "9b", "27b"}
    for model in report["models"].values():
        assert all(
            group["raw_exact_matches"]
            == group["stop_aligned_exact_matches"]
            == group["requests"]
            == 8
            for group in model["comparison_counts"].values()
        )
    assert report["historical_failures"][0]["record"]["status"] == "failed"
    assert report["historical_failures"][0]["record"]["records"] == []
    assert report["original_4b_9b_failures_resolved"] is False
    assert report["new_quality_threshold"] is None
    assert report["native_controllers"][0]["record"]["status"] == "failed"
    for model in report["models"].values():
        for tp in ("tp1", "tp2"):
            evidence = model["evidence"][tp]
            receipt = evidence["driver_closure"]
            assert receipt["quality_file"] == evidence["file"]
            assert receipt["finished"]["own_contexts_released"] is True
            assert receipt["job"] == receipt["finished"]["job"]
            assert receipt["controller_file"]["sha256"] in {
                item["file"]["sha256"] for item in report["native_controllers"]
            }


@pytest.mark.parametrize(
    "bad",
    [
        "missing_case",
        "wrong_response_sha",
        "changed_input",
        "changed_record_id",
        "runtime_sha",
        "guard_exit",
        "cpu_sha",
    ],
)
def test_missing_or_tampered_evidence_fails_instead_of_counting_partial_success(
    fixture, bad
):
    module, root, source, manifest, selection = fixture
    path = root / "native_4b_tp2/quality.json"
    data = read(path)
    if bad == "missing_case":
        data["records"].pop()
    elif bad == "wrong_response_sha":
        data["records"][0]["response_sha256"] = "0" * 64
    elif bad == "changed_input":
        data["records"][0]["input_ids"][0] = 999
    elif bad == "changed_record_id":
        data["records"][0]["request_id"] = "wrong_id"
    elif bad == "runtime_sha":
        data["runtime_origins"][module.RUNTIME_MODULES[0]]["sha256"] = "0" * 64
    elif bad == "guard_exit":
        data["guard"]["own_children_released"] = False
    elif bad == "cpu_sha":
        path = root / "cpu_9b/state.json"
        data = read(path)
        data["records"][0]["sha256"] = "0" * 64
    put(path, data)
    with pytest.raises(ValueError):
        run(fixture)


def test_response_ids_must_equal_quality_record_even_when_response_sha_is_updated(
    fixture,
):
    module, root, *_ = fixture
    path = root / "native_9b_tp1/request_0.response.json"
    response = read(path)
    response["output_ids"][0] = 7
    digest = put(path, response)
    quality = read(root / "native_9b_tp1/quality.json")
    quality["records"][0]["response_sha256"] = digest
    put(root / "native_9b_tp1/quality.json", quality)
    with pytest.raises(ValueError, match="response"):
        run(fixture)


def test_eos_at_token128_can_be_native_length_and_cpu_eos(fixture):
    module, root, *_ = fixture
    tokens = [4] * 127 + [9]
    cpu_path = root / "cpu_27b/request_0.json"
    record = read(cpu_path)
    record["output_ids"] = tokens
    record["greedy_margins"] = [
        {
            "step": i,
            "token_id": token,
            "top2_ids": [token, 8],
            "top2_logits": [2.0, 1.0],
            "margin": 1.0,
        }
        for i, token in enumerate(tokens)
    ]
    digest = put(cpu_path, record)
    state = read(root / "cpu_27b/state.json")
    state["records"][0].update(sha256=digest, tokens=128)
    put(root / "cpu_27b/state.json", state)
    for tp in (1, 2):
        directory = root / f"native_27b_tp{tp}"
        response = read(directory / "request_0.response.json")
        response["output_ids"] = tokens
        response["meta_info"]["finish_reason"] = {"type": "length", "length": 128}
        digest = put(directory / "request_0.response.json", response)
        quality = read(directory / "quality.json")
        quality["records"][0].update(
            output_ids=tokens,
            finish_reason=response["meta_info"]["finish_reason"],
            response_sha256=digest,
        )
        put(directory / "quality.json", quality)
    report = run(fixture)
    item = report["models"]["27b"]["requests"][0]
    assert item["comparisons"]["tp1_vs_cpu"]["exact_match"]
    assert item["outputs"]["cpu"]["record"]["stop_reason"] == "eos"
    assert item["outputs"]["tp1"]["record"]["finish_reason"]["type"] == "length"


def test_trimmed_eos_and_real_id_mismatch_are_distinct(fixture):
    module = fixture[0]
    aligned = module.compare_outputs([4], [4, 9], [9])
    assert not aligned["exact_match"] and aligned["stop_aligned_exact_match"]
    assert aligned["first_mismatch_index"] == 1
    different = module.compare_outputs([4, 7, 9], [4, 8, 9], [9])
    assert not different["stop_aligned_exact_match"]
    assert different["stop_aligned_first_mismatch_index"] == 1


def test_consistent_but_different_output_is_preserved_as_observation(fixture):
    module, root, *_ = fixture
    directory = root / "native_4b_tp1"
    response = read(directory / "request_0.response.json")
    response["output_ids"] = [7, 9]
    digest = put(directory / "request_0.response.json", response)
    quality = read(directory / "quality.json")
    quality["records"][0].update(output_ids=[7, 9], response_sha256=digest)
    put(directory / "quality.json", quality)
    report = run(fixture)
    group = report["models"]["4b"]
    assert group["comparison_counts"]["tp1_vs_cpu"]["stop_aligned_exact_matches"] == 7
    assert group["requests"][0]["outputs"]["tp1"]["record"]["output_ids"] == [7, 9]
    assert (
        group["requests"][0]["comparisons"]["tp1_vs_cpu"]["first_mismatch"]["engine_id"]
        == 7
    )
    assert report["new_quality_threshold"] is None


def test_trimmed_native_eos_is_valid_file_evidence(fixture):
    module, root, *_ = fixture
    directory = root / "native_0.8b_tp1"
    response = read(directory / "request_0.response.json")
    response["output_ids"] = [4]
    digest = put(directory / "request_0.response.json", response)
    quality = read(directory / "quality.json")
    quality["records"][0].update(output_ids=[4], response_sha256=digest)
    put(directory / "quality.json", quality)
    report = run(fixture)
    comparison = report["models"]["0.8b"]["requests"][0]["comparisons"]["tp1_vs_cpu"]
    assert not comparison["exact_match"]
    assert comparison["stop_aligned_exact_match"]


def test_path_escape_or_missing_selected_model_is_rejected(fixture):
    module, root, source, manifest, selection = fixture
    data = read(selection)
    data["models"]["27b"]["tp1"]["directory"] = "../escape"
    put(selection, data)
    with pytest.raises(ValueError, match="relative|escape"):
        run(fixture)
    data["models"].pop("27b")
    put(selection, data)
    with pytest.raises(ValueError):
        run(fixture)


@pytest.mark.parametrize(
    "bad",
    [
        "missing_controllers",
        "wrong_sha",
        "missing_job",
        "nonzero_exit",
        "not_released",
        "duplicate_job",
        "missing_guard_verified",
        "wrong_source",
        "wrong_job_name",
    ],
)
def test_driver_closure_requires_unique_complete_verified_record(fixture, bad):
    module, root, source, manifest, selection_path = fixture
    selection = read(selection_path)
    item = selection["native_controllers"][0]
    path = root / item["path"]
    controller = read(path)
    job = selection["models"]["0.8b"]["tp1"]["directory"]
    if bad == "missing_controllers":
        del selection["native_controllers"]
    elif bad == "wrong_sha":
        item["sha256"] = "0" * 64
    elif bad == "duplicate_job":
        other = selection["native_controllers"][1]
        other_path = root / other["path"]
        data = read(other_path)
        data["finished"][job] = controller["finished"][job]
        other["sha256"] = put(other_path, data)
    else:
        if bad == "missing_job":
            del controller["finished"][job]
        elif bad == "nonzero_exit":
            controller["finished"][job]["exit_code"] = 1
        elif bad == "not_released":
            controller["finished"][job]["own_contexts_released"] = False
        elif bad == "missing_guard_verified":
            del controller["finished"][job]["guard_verified"]
        elif bad == "wrong_source":
            controller["source_manifest_sha256"] = "0" * 64
        elif bad == "wrong_job_name":
            controller["finished"][job]["job"] = "another_job"
        item["sha256"] = put(path, controller)
    put(selection_path, selection)
    with pytest.raises(ValueError):
        run(fixture)
