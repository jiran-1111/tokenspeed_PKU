#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy

import numpy as np
import pytest
from export_frontier import validate_record, validate_run

CORE = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"


def records():
    case = {"input_ids": list(range(128)), "continuation_ids": [5]}
    vector = np.zeros(248320, dtype=np.float32)
    vector[5] = 1
    record = {
        "rank": 0,
        "input_ids": case["input_ids"],
        "positions": list(range(128)),
        "logits": vector,
        "original_dtype": "torch.bfloat16",
    }
    sample = {
        "rank": 0,
        "broadcast_sampled_id": 5,
        "raw_greedy_id": 5,
        "emitted_id": 5,
        "forced": True,
    }
    return case, record, sample


def test_original_record_contract():
    case, record, sample = records()
    assert validate_record(record, sample, case, step=0, rank=0).shape == (248320,)


@pytest.mark.parametrize("field", ["rank", "input_ids", "positions"])
def test_record_identity_mismatch_rejected(field):
    case, record, sample = records()
    record[field] = 99
    with pytest.raises(ValueError):
        validate_record(record, sample, case, step=0, rank=0)


@pytest.mark.parametrize(
    "field", ["rank", "raw_greedy_id", "broadcast_sampled_id", "emitted_id", "forced"]
)
def test_sampler_frontier_mismatch_rejected(field):
    case, record, sample = records()
    sample[field] = False if field == "forced" else 99
    with pytest.raises(ValueError):
        validate_record(record, sample, case, step=0, rank=0)


def test_nan_and_wrong_shape_rejected():
    case, record, sample = records()
    record["logits"][2] = np.nan
    with pytest.raises(ValueError):
        validate_record(record, sample, case, step=0, rank=0)
    record["logits"] = np.zeros(3)
    with pytest.raises(ValueError):
        validate_record(record, sample, case, step=0, rank=0)


def test_run_requires_outer_release_and_original_source():
    case, _, _ = records()
    run = {
        "status": "collected",
        "case": case,
        "case_sha256": "a" * 64,
        "vectors_per_rank": 2,
        "diagnostic_only": True,
        "execution_mode": "eager",
        "cached": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "config": {"model_revision": "revision", "tp_size": 1},
        "guard": {
            "sources_sha": CORE,
            "sources_after_sha": CORE,
            "sources_unchanged": True,
            "own_children_released": True,
            "violations": [],
        },
    }
    finished = {"job": "job", "exit_code": 0, "own_contexts_released": True}
    validate_run(
        run,
        finished,
        case,
        case_sha="a" * 64,
        model_revision="revision",
        tp=1,
        job="job",
    )
    for field, value in (("exit_code", 1), ("own_contexts_released", False)):
        broken = finished | {field: value}
        with pytest.raises(ValueError):
            validate_run(
                run,
                broken,
                case,
                case_sha="a" * 64,
                model_revision="revision",
                tp=1,
                job="job",
            )
    run["guard"]["sources_after_sha"] = "b" * 64
    with pytest.raises(ValueError):
        validate_run(
            run,
            finished,
            case,
            case_sha="a" * 64,
            model_revision="revision",
            tp=1,
            job="job",
        )
