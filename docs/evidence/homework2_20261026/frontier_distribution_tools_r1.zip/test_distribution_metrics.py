#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import numpy as np
import pytest
from distribution_metrics import compare_logits


def test_identity():
    result = compare_logits([1.0, 2.0, -1.0], [1.0, 2.0, -1.0], top_k=2)
    for key in (
        "raw_relative_l2",
        "raw_max_abs",
        "mean_delta",
        "centered_relative_l2",
        "tv",
        "kl_ref_actual",
        "kl_actual_ref",
        "js",
    ):
        assert result[key] == pytest.approx(0, abs=1e-15)
    assert result["centered_cosine"] == pytest.approx(1)
    assert result["delta_zero"] is True
    assert result["uniform_shift_energy_fraction"] is None
    assert result["actual"]["argmax"] == result["reference"]["argmax"] == 1
    assert result["top_k_overlap_count"] == 2


def test_uniform_shift_has_raw_error_but_same_distribution():
    result = compare_logits([101.0, 102.0, 103.0], [1.0, 2.0, 3.0], top_k=2)
    assert result["raw_relative_l2"] > 1
    assert result["raw_max_abs"] == 100
    assert result["mean_delta"] == 100
    assert result["uniform_shift_energy_fraction"] == pytest.approx(1)
    assert result["centered_relative_l2"] == pytest.approx(0)
    assert result["centered_cosine"] == pytest.approx(1)
    for key in ("tv", "kl_ref_actual", "kl_actual_ref", "js"):
        assert result[key] == pytest.approx(0, abs=1e-14)


def test_scale_changes_distribution_without_uniform_shift():
    result = compare_logits([-2.0, 0.0, 2.0], [-1.0, 0.0, 1.0], top_k=2)
    assert result["uniform_shift_energy_fraction"] == 0
    assert result["centered_relative_l2"] == pytest.approx(1)
    assert result["centered_cosine"] == pytest.approx(1)
    assert result["tv"] > 0
    assert result["kl_ref_actual"] > 0
    assert result["kl_actual_ref"] > 0
    assert result["js"] > 0
    assert (
        result["actual"]["top1_probability"] > result["reference"]["top1_probability"]
    )


def test_argmax_flip_and_known_divergences():
    result = compare_logits([0.0, np.log(3)], [np.log(3), 0.0], top_k=1)
    assert result["actual"]["argmax"] == 1
    assert result["reference"]["argmax"] == 0
    assert result["top_k_overlap_count"] == 0
    assert result["top_k_overlap_fraction"] == 0
    assert result["tv"] == pytest.approx(0.5)
    assert result["kl_ref_actual"] == pytest.approx(0.5 * np.log(3))
    assert result["kl_actual_ref"] == pytest.approx(0.5 * np.log(3))
    assert result["js"] == pytest.approx(0.75 * np.log(1.5) + 0.25 * np.log(0.5))
    assert result["actual"]["top1_logit_margin"] == pytest.approx(np.log(3))
    assert result["actual"]["top1_probability_margin"] == pytest.approx(0.5)


def test_asymmetric_kl_directions_and_shift_energy_formula():
    result = compare_logits([np.log(3), 0], [0, 0], top_k=2)
    assert result["kl_ref_actual"] == pytest.approx(0.5 * np.log(4 / 3))
    assert result["kl_actual_ref"] == pytest.approx(
        0.75 * np.log(1.5) + 0.25 * np.log(0.5)
    )
    expected_js = 0.5 * (
        0.5 * np.log(0.5 / 0.625)
        + 0.5 * np.log(0.5 / 0.375)
        + 0.75 * np.log(0.75 / 0.625)
        + 0.25 * np.log(0.25 / 0.375)
    )
    assert result["js"] == pytest.approx(expected_js)
    result = compare_logits([3, 2], [1, 2], top_k=1)
    assert result["raw_relative_l2"] == pytest.approx(2 / np.sqrt(5))
    assert result["mean_delta"] == 1
    assert result["uniform_shift_energy_fraction"] == 0.5
    assert result["centered_relative_l2"] == pytest.approx(2)
    assert result["centered_cosine"] == pytest.approx(-1)


def test_constant_actual_also_marks_cosine_undefined_without_mutating_inputs():
    actual = np.array([3, 3], dtype=np.float32)
    reference = np.array([1, 2], dtype=np.float32)
    result = compare_logits(actual, reference, top_k=1)
    assert result["actual_centered_zero"] is True
    assert result["reference_centered_zero"] is False
    assert result["centered_cosine"] is None
    assert result["centered_relative_l2"] == pytest.approx(1)
    np.testing.assert_array_equal(actual, [3, 3])
    np.testing.assert_array_equal(reference, [1, 2])


def test_ties_use_lowest_id_for_argmax_and_top_k():
    result = compare_logits([3, 1, 3, 3], [3, 3, 1, 3], top_k=2)
    assert result["actual"]["argmax"] == result["reference"]["argmax"] == 0
    assert result["actual"]["top_ids"] == [0, 2]
    assert result["reference"]["top_ids"] == [0, 1]
    assert (
        result["actual"]["top1_tie_count"] == result["reference"]["top1_tie_count"] == 3
    )
    assert result["actual"]["top1_logit_margin"] == 0
    assert result["top_k_overlap_count"] == 1


def test_extreme_logits_do_not_clip_probabilities_or_lose_log_kl():
    result = compare_logits([1e4, -1e4], [-1e4, 1e4], top_k=1)
    assert result["tv"] == 1
    assert result["kl_ref_actual"] == 2e4
    assert result["kl_actual_ref"] == 2e4
    assert result["js"] == pytest.approx(np.log(2))
    assert result["actual"]["top1_probability"] == 1


@pytest.mark.parametrize(
    "actual,reference", [([0, 0], [0, 0]), ([3, 3], [1, 1]), ([1, 2], [1, 1])]
)
def test_constant_reference_marks_undefined_centered_metrics(actual, reference):
    result = compare_logits(actual, reference, top_k=1)
    assert result["reference_centered_zero"] is True
    assert result["centered_relative_l2"] is None
    assert result["centered_cosine"] is None
    assert result["actual_centered_zero"] is (actual[0] == actual[1])
    assert result["reference_zero"] is (reference[0] == 0)
    if reference[0] == 0:
        assert result["raw_relative_l2"] is None


def test_single_token_has_no_top2():
    result = compare_logits([3], [2], top_k=1)
    assert result["actual"]["top1_probability"] == 1
    assert result["actual"]["top1_logit_margin"] is None
    assert result["actual"]["top1_probability_margin"] is None
    assert result["actual"]["has_top2"] is False
    assert result["tv"] == 0


@pytest.mark.parametrize(
    "actual,reference",
    [
        ([], []),
        ([[1, 2]], [[1, 2]]),
        ([1], [1, 2]),
        ([np.nan], [1]),
        ([1], [np.inf]),
        ([-np.inf], [1]),
        ([1j], [1]),
        (["bad"], [1]),
    ],
)
def test_invalid_logits_are_rejected(actual, reference):
    with pytest.raises(ValueError):
        compare_logits(actual, reference, top_k=1)


@pytest.mark.parametrize("top_k", [0, -1, 3, 1.0, True, None, "1"])
def test_invalid_top_k_is_rejected(top_k):
    with pytest.raises(ValueError):
        compare_logits([1, 2], [1, 2], top_k=top_k)


def test_top_k_is_explicit_and_numpy_integer_is_valid():
    with pytest.raises(TypeError):
        compare_logits([1], [1])
    assert compare_logits([1, 2], [1, 2], top_k=np.int64(1))["top_k_overlap_count"] == 1


def test_float64_metric_overflow_is_explicit():
    with pytest.raises(ValueError, match="metric overflow"):
        compare_logits([1e308, -1e308], [-1e308, 1e308], top_k=1)
