#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Describe probability changes in the original captured common-frontier logits."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from distribution_metrics import compare_logits


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "manifest", "baseline-analysis", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--top-k", type=int, required=True)
    args = parser.parse_args()
    manifest = read(args.manifest)
    receipt = read(args.root / "export_receipt.json")
    assert args.top_k == manifest["top_k"] == 10
    assert (
        receipt["input_manifest_sha256"] == sha(args.manifest)
        and receipt["original_files_unchanged"]
        and receipt["npu_import_blocked"]
        and receipt["npu_execution"] is False
    )
    assert receipt["source_manifest_sha256"] == manifest["source_manifest_sha256"]
    assert sha(args.root / "arrays.npz") == receipt["arrays_sha256"]
    assert (
        sha(args.baseline_analysis) == manifest["files"][manifest["baseline_analysis"]]
    )
    baseline = read(args.baseline_analysis)
    pairs = {
        "tp2_vs_tp1": ("tp2_rank0", "tp1_rank0"),
        "tp2_rank1_vs_rank0": ("tp2_rank1", "tp2_rank0"),
        "tp1_vs_cpu": ("tp1_rank0", "cpu"),
        "tp2_rank0_vs_cpu": ("tp2_rank0", "cpu"),
        "tp2_rank1_vs_cpu": ("tp2_rank1", "cpu"),
    }
    report = {
        "source_manifest_sha256": manifest["source_manifest_sha256"],
        "input_manifest_sha256": sha(args.manifest),
        "export_receipt_sha256": sha(args.root / "export_receipt.json"),
        "arrays_sha256": receipt["arrays_sha256"],
        "analyzer_sha256": sha(Path(__file__)),
        "metrics_sha256": sha(Path(__file__).with_name("distribution_metrics.py")),
        "new_threshold": None,
        "original_failures_preserved": True,
        "npu_execution": False,
        "top_k": args.top_k,
        "probability_temperature": 1,
        "logarithm": "natural",
        "models": {},
    }
    with np.load(args.root / "arrays.npz", allow_pickle=False) as arrays:
        assert set(arrays.files) == {
            f"{m}_{role}"
            for m in manifest["models"]
            for role in ("cpu", "tp1_rank0", "tp2_rank0", "tp2_rank1")
        }
        for model, spec in manifest["models"].items():
            assert all(
                arrays[f"{model}_{role}"].shape == (spec["count"], 248320)
                for role in ("cpu", "tp1_rank0", "tp2_rank0", "tp2_rank1")
            )
            values = {}
            for pair, (actual, ref) in pairs.items():
                rows = []
                for step in range(spec["count"]):
                    metrics = compare_logits(
                        arrays[f"{model}_{actual}"][step],
                        arrays[f"{model}_{ref}"][step],
                        top_k=args.top_k,
                    )
                    if pair == "tp2_vs_tp1":
                        old = baseline["models"][model]["tp1_vs_tp2_rank0"][step]
                        assert np.isclose(
                            metrics["raw_relative_l2"],
                            old["relative_l2"],
                            rtol=1e-12,
                            atol=1e-12,
                        )
                        assert metrics["raw_max_abs"] == old["max_abs"]
                        assert (
                            metrics["actual"]["argmax"]
                            == metrics["reference"]["argmax"]
                        ) == old["argmax_equal"]
                    rows.append({"step": step, "position": 127 + step, **metrics})
                numeric = (
                    "raw_relative_l2",
                    "raw_max_abs",
                    "centered_relative_l2",
                    "uniform_shift_energy_fraction",
                    "tv",
                    "kl_ref_actual",
                    "kl_actual_ref",
                    "js",
                    "top_k_overlap_fraction",
                )
                summary = {
                    name: {
                        "min": min(row[name] for row in rows if row[name] is not None),
                        "max": max(row[name] for row in rows if row[name] is not None),
                    }
                    for name in numeric
                    if any(row[name] is not None for row in rows)
                }
                values[pair] = {"summary": summary, "rows": rows}
            report["models"][model] = {"count": spec["count"], "comparisons": values}
    assert sha(args.root / "arrays.npz") == receipt["arrays_sha256"]
    with args.output.open("x", encoding="utf-8") as f:
        json.dump(report, f, indent=2, allow_nan=False)
        f.write("\n")
    print(
        json.dumps(
            {"models": 2, "vectors": 112, "comparisons": 140, "new_threshold": None}
        )
    )


if __name__ == "__main__":
    main()
