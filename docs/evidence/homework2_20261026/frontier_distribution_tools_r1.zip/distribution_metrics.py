#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Descriptive full-vocabulary logit metrics, with no acceptance threshold.

All computation uses float64; divergences use natural logarithms. Relative L2
with a zero reference denominator and cosine with either zero centered vector
are None, with explicit flags. Zero delta has no defined shift energy fraction.
Top1 tie counts include the winning token. Top2 margins are None for vocab=1.
Finite inputs whose metrics overflow float64 raise ValueError('metric overflow').
"""

import numpy as np


def _mean(values: np.ndarray) -> float:
    scale = float(np.max(np.abs(values)))
    return float(np.mean(values / scale) * scale) if scale else 0.0


def _relative_l2(error: np.ndarray, reference: np.ndarray) -> float | None:
    scale = float(max(np.max(np.abs(error)), np.max(np.abs(reference))))
    if not np.any(reference):
        return None
    return float(np.linalg.norm(error / scale) / np.linalg.norm(reference / scale))


def _log_softmax(values: np.ndarray) -> np.ndarray:
    shifted = values - np.max(values)
    return shifted - np.log(np.sum(np.exp(shifted)))


def _kl(log_p: np.ndarray, log_q: np.ndarray) -> float:
    p = np.exp(log_p)
    nonzero = p > 0
    return float(np.sum(p[nonzero] * (log_p[nonzero] - log_q[nonzero])))


def _top(values: np.ndarray, log_p: np.ndarray, top_k: int) -> dict:
    order = np.lexsort((np.arange(values.size), -values))
    first = int(order[0])
    has_top2 = values.size > 1
    return {
        "argmax": first,
        "top_ids": [int(index) for index in order[:top_k]],
        "top1_tie_count": int(np.count_nonzero(values == values[first])),
        "top1_probability": float(np.exp(log_p[first])),
        "has_top2": has_top2,
        "top1_logit_margin": (
            float(values[first] - values[order[1]]) if has_top2 else None
        ),
        "top1_probability_margin": (
            float(np.exp(log_p[first]) - np.exp(log_p[order[1]])) if has_top2 else None
        ),
    }


def _finite_result(value: object) -> None:
    if isinstance(value, dict):
        for item in value.values():
            _finite_result(item)
    elif isinstance(value, list):
        for item in value:
            _finite_result(item)
    elif isinstance(value, float) and not np.isfinite(value):
        raise ValueError("metric overflow")


def compare_logits(actual: object, reference: object, *, top_k: int) -> dict:
    """Compare two finite 1D vectors; ties sort by logit descending, ID ascending.

    raw_relative_l2 = ||actual-reference|| / ||reference||. The centered
    counterpart uses each vector minus its own mean. Probability metrics include
    TV, both directed KLs, and JS; no probabilities are clipped or renormalized
    after underflow. Top1 margins include both logit and probability differences.
    """
    arrays = []
    for value in (actual, reference):
        try:
            array = np.asarray(value)
            if array.dtype.kind not in "biuf":
                raise ValueError("real numeric logits required")
            with np.errstate(over="raise", invalid="raise"):
                array = array.astype(np.float64)
        except (TypeError, FloatingPointError, OverflowError) as error:
            raise ValueError("invalid logits") from error
        if array.ndim != 1 or not array.size or not np.all(np.isfinite(array)):
            raise ValueError("nonempty finite 1D logits required")
        arrays.append(array)
    actual, reference = arrays
    if actual.shape != reference.shape:
        raise ValueError("logit shape mismatch")
    if (
        isinstance(top_k, (bool, np.bool_))
        or not isinstance(top_k, (int, np.integer))
        or not 1 <= top_k <= actual.size
    ):
        raise ValueError("top_k must be an integer in [1, vocab]")
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
            delta = actual - reference
            mean_delta = _mean(delta)
            delta_scale = float(np.max(np.abs(delta)))
            actual_center = actual - _mean(actual)
            ref_center = reference - _mean(reference)
            actual_zero, ref_zero = not np.any(actual_center), not np.any(ref_center)
            cosine = None
            if not actual_zero and not ref_zero:
                a = actual_center / np.max(np.abs(actual_center))
                r = ref_center / np.max(np.abs(ref_center))
                cosine = float(np.dot(a / np.linalg.norm(a), r / np.linalg.norm(r)))
            log_a, log_r = _log_softmax(actual), _log_softmax(reference)
            log_mix = np.logaddexp(log_a, log_r) - np.log(2.0)
            top_a, top_r = _top(actual, log_a, top_k), _top(reference, log_r, top_k)
            overlap = len(set(top_a["top_ids"]) & set(top_r["top_ids"]))
            result = {
                "vocab_size": int(actual.size),
                "top_k": int(top_k),
                "raw_relative_l2": _relative_l2(delta, reference),
                "raw_max_abs": delta_scale,
                "reference_zero": bool(not np.any(reference)),
                "mean_delta": mean_delta,
                "delta_zero": delta_scale == 0,
                "uniform_shift_energy_fraction": (
                    float(
                        actual.size
                        * (mean_delta / delta_scale) ** 2
                        / np.sum((delta / delta_scale) ** 2)
                    )
                    if delta_scale
                    else None
                ),
                "centered_relative_l2": _relative_l2(
                    actual_center - ref_center, ref_center
                ),
                "centered_cosine": cosine,
                "actual_centered_zero": bool(actual_zero),
                "reference_centered_zero": bool(ref_zero),
                "tv": float(0.5 * np.sum(np.abs(np.exp(log_a) - np.exp(log_r)))),
                "kl_ref_actual": _kl(log_r, log_a),
                "kl_actual_ref": _kl(log_a, log_r),
                "js": 0.5 * (_kl(log_r, log_mix) + _kl(log_a, log_mix)),
                "top_k_overlap_count": overlap,
                "top_k_overlap_fraction": overlap / int(top_k),
                "actual": top_a,
                "reference": top_r,
            }
    except FloatingPointError as error:
        raise ValueError("metric overflow") from error
    _finite_result(result)
    return result
