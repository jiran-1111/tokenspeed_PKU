#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read SHA-bound original frontier tensors on CPU; never replay the model."""

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import numpy as np

CORE = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def validate_record(record, sample, case, *, step, rank):
    ids = case["input_ids"] if step == 0 else [case["continuation_ids"][step - 1]]
    positions = list(range(128)) if step == 0 else [128 + step - 1]
    require(
        record["rank"] == rank
        and record["input_ids"] == ids
        and record["positions"] == positions,
        "tensor identity mismatch",
    )
    vector = np.asarray(record["logits"])
    require(
        vector.shape == (248320,) and np.isfinite(vector).all(), "invalid logits vector"
    )
    greedy = int(vector.argmax())
    forced = step < len(case["continuation_ids"])
    require(
        sample["rank"] == rank
        and sample["raw_greedy_id"] == greedy
        and sample["broadcast_sampled_id"] == greedy,
        "sampler identity mismatch",
    )
    expected = case["continuation_ids"][step] if forced else greedy
    require(
        sample["forced"] is forced and sample["emitted_id"] == expected,
        "forced frontier mismatch",
    )
    return vector


def validate_run(run, finished, case, *, case_sha, model_revision, tp, job):
    require(
        run["status"] == "collected"
        and run["case"] == case
        and run["case_sha256"] == case_sha
        and run["vectors_per_rank"] == len(case["continuation_ids"]) + 1,
        "original run identity mismatch",
    )
    require(
        run["diagnostic_only"] is True
        and run["execution_mode"] == "eager"
        and run["cached"] is True
        and run["performance_eligible"] is False
        and run["original_graph_failures_preserved"] is True,
        "original diagnostic scope mismatch",
    )
    require(
        run["config"]["model_revision"] == model_revision
        and run["config"]["tp_size"] == tp,
        "model revision or TP mismatch",
    )
    guard = run["guard"]
    require(
        guard["sources_sha"] == guard["sources_after_sha"] == CORE
        and guard["sources_unchanged"] is True
        and guard["own_children_released"] is True
        and guard["violations"] == [],
        "source or child guard mismatch",
    )
    require(
        finished["job"] == job
        and finished["exit_code"] == 0
        and finished["own_contexts_released"] is True,
        "outer driver completion mismatch",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("task-root", "manifest", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    require(args.threads > 0, "positive CPU thread count required")
    require(
        os.environ.get("TORCH_DEVICE_BACKEND_AUTOLOAD") == "0",
        "disable NPU autoload explicitly",
    )
    import torch

    require("torch_npu" not in sys.modules, "NPU must not load")
    sys.modules["torch_npu"] = None
    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    root = args.task_root.resolve()
    manifest = read(args.manifest)
    source = root / "source_final"
    core_path = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(sha(core_path) == CORE, "original core manifest mismatch")
    core = read(core_path)
    require(len(core) == 1531, "core count mismatch")
    require(all(sha(source / n) == s for n, s in core.items()), "source file mismatch")

    def path(name):
        value = (root / name).resolve()
        require(value.is_relative_to(root), "evidence path escapes task")
        return value

    require(
        all(sha(path(n)) == s for n, s in manifest["files"].items()),
        "selected original evidence SHA mismatch",
    )
    old = read(path(manifest["baseline_analysis"]))
    controller = read(path(manifest["controller"]))
    require(controller["status"] == "collected", "original controller incomplete")
    arrays = {}
    records = {}
    for model, spec in manifest["models"].items():
        case_path = path(spec["case"])
        case = read(case_path)
        count = len(case["continuation_ids"]) + 1
        require(
            case == old["models"][model]["case"]
            and len(case["input_ids"]) == 128
            and count == spec["count"],
            "original case mismatch",
        )
        cpu_dir = path(spec["cpu"])
        state = read(cpu_dir / "reference_state.json")
        require(
            state["status"] == "collected"
            and state["source_unchanged"] is True
            and state["source_manifest_sha256"] == CORE
            and state["npu_import_blocked"] is True
            and state["model_revision"] == spec["revision"],
            "CPU identity mismatch",
        )
        cpu_path = cpu_dir / "input_128_greedy_logits.pt"
        require(
            sha(cpu_path) == old["models"][model]["reference_sha256"],
            "original CPU reference differs",
        )
        cpu = torch.load(cpu_path, map_location="cpu", weights_only=True)
        require(cpu["input_ids"] == case["input_ids"], "CPU input mismatch")
        if model == "4b":
            require(
                cpu["generated_ids"][: count - 1] == case["continuation_ids"],
                "CPU4 frontier mismatch",
            )
        else:
            require(state["case"] == case, "CPU9 forced case mismatch")
        vectors = cpu["logits"][:count].float().numpy()
        require(
            vectors.shape == (count, 248320) and np.isfinite(vectors).all(),
            "CPU vector coverage mismatch",
        )
        arrays[f"{model}_cpu"] = vectors
        records[model] = {
            "case_sha256": sha(case_path),
            "cpu_sha256": sha(cpu_path),
            "global_projected_weight_sha256": state["global_weight_sha256"],
            "captures": {},
        }
        for tp in (1, 2):
            name = spec[f"tp{tp}"]
            directory = path(name)
            run = read(directory / "diagnostic.json")
            validate_run(
                run,
                controller["finished"][directory.name],
                case,
                case_sha=sha(case_path),
                model_revision=spec["revision"],
                tp=tp,
                job=directory.name,
            )
            for rank in range(tp):
                role = f"tp{tp}_rank{rank}"
                values = []
                raw_hashes = []
                for step in range(count):
                    p = directory / f"rank_{rank}/step_{step:02d}.pt"
                    require(
                        sha(p)
                        == old["models"][model]["captures"][role]["vectors"][step][
                            "capture_sha256"
                        ],
                        "original captured tensor differs",
                    )
                    record = torch.load(p, map_location="cpu", weights_only=True)
                    record["logits"] = record["logits"].float().numpy()
                    values.append(
                        validate_record(
                            record,
                            read(p.with_suffix(".json")),
                            case,
                            step=step,
                            rank=rank,
                        )
                    )
                    raw_hashes.append(sha(p))
                arrays[f"{model}_{role}"] = np.stack(values)
                records[model]["captures"][role] = {
                    "raw_sha256": raw_hashes,
                    "original_dtype": record["original_dtype"],
                }
    require(
        all(sha(path(n)) == s for n, s in manifest["files"].items()),
        "original evidence changed",
    )
    require(all(sha(source / n) == s for n, s in core.items()), "core changed")
    args.output.mkdir(exist_ok=False)
    array_path = args.output / "arrays.npz"
    with array_path.open("xb") as f:
        np.savez_compressed(f, **arrays)
    receipt = {
        "status": "collected",
        "models": records,
        "input_manifest_sha256": sha(args.manifest),
        "exporter_sha256": sha(Path(__file__)),
        "source_manifest_sha256": CORE,
        "source_files": 1531,
        "original_files_unchanged": True,
        "original_files": len(manifest["files"]),
        "arrays_sha256": sha(array_path),
        "arrays": {k: list(v.shape) for k, v in arrays.items()},
        "npu_import_blocked": True,
        "npu_execution": False,
        "new_threshold": None,
        "original_failures_preserved": True,
        "original_outer_release_verified": True,
    }
    (args.output / "export_receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "status": "collected",
                "original_files": len(manifest["files"]),
                "vectors": sum(v.shape[0] for v in arrays.values()),
                "npu_execution": False,
            }
        )
    )


if __name__ == "__main__":
    main()
