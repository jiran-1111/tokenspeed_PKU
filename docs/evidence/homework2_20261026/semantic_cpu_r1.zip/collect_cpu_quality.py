#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent same-projection FP32/eager output reference; no NPU execution."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "manifest", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--manifest-sha", required=True)
    parser.add_argument("--model", choices=("0.8b", "4b", "9b", "27b"), required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    if args.threads < 1 or sha(args.manifest) != args.manifest_sha:
        raise ValueError("invalid reference protocol")
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if (
        manifest["thinking_enabled"]
        or manifest["max_new_tokens"] != 128
        or len(manifest["requests"]) != 8
        or manifest["complete_logits_collected"]
    ):
        raise ValueError("wrong frozen quality cohort")
    source = args.source_root.resolve()
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    if sha(core) != manifest["source_manifest_sha256"]:
        raise ValueError("source manifest mismatch")
    files = json.loads(core.read_text(encoding="utf-8"))
    if len(files) != 1531 or not all(sha(source / n) == s for n, s in files.items()):
        raise ValueError("source file mismatch")
    spec = manifest["models"][args.model]
    config_path = source / spec["config_paths"]["tp1"]
    if sha(config_path) != spec["config_sha256"]["tp1"]:
        raise ValueError("model config mismatch")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    checkpoint = source / config["local_model_path"]
    if config["model_revision"] != spec["model_revision"]:
        raise ValueError("revision mismatch")
    if not all(
        sha(checkpoint / n) == s for n, s in spec["tokenizer_and_config_sha256"].items()
    ):
        raise ValueError("tokenizer/config changed")
    output = args.output.resolve()
    if not output.is_relative_to(source):
        raise ValueError("reference output must stay in source workspace")
    output.mkdir(parents=True, exist_ok=False)
    state = {
        "status": "loading",
        "model": args.model,
        "model_revision": spec["model_revision"],
        "manifest_sha256": args.manifest_sha,
        "collector_sha256": sha(Path(__file__)),
        "source_manifest_sha256": sha(core),
        "cpu_threads": args.threads,
        "compute_dtype": "float32",
        "projection_policy": "original parameter -> BF16 -> FP32, except A_log/dt_bias remain FP32",
        "performance_eligible": False,
        "new_pass_threshold": None,
        "complete_logits_collected": False,
        "records": [],
    }

    def save():
        temporary = output / "state.tmp"
        temporary.write_text(json.dumps(state, indent=2))
        temporary.replace(output / "state.json")

    save()
    started = time.perf_counter()
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    if "torch_npu" in sys.modules:
        raise ValueError("reference cannot start with torch_npu loaded")
    sys.modules["torch_npu"] = None
    import torch
    import transformers
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from transformers.models.qwen3_5 import modeling_qwen3_5 as hf

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    sys.path.insert(0, str(source / "scripts"))
    sys.path.insert(0, str(source))
    from collect_homework1_references import normalize_loading_info, project_weights

    hf.causal_conv1d_fn = None
    hf.causal_conv1d_update = None
    hf.chunk_gated_delta_rule = None
    hf.fused_recurrent_gated_delta_rule = None
    hf.FusedRMSNormGated = None
    hf.is_fast_path_available = False
    model, loading_raw = AutoModelForCausalLM.from_pretrained(
        checkpoint,
        revision=spec["model_revision"],
        local_files_only=True,
        dtype=torch.float32,
        attn_implementation="eager",
        output_loading_info=True,
    )
    loading = normalize_loading_info(loading_raw)
    if any(
        loading[n] for n in ("missing_keys", "mismatched_keys", "error_msgs")
    ) or not all(
        n.startswith(("model.visual.", "visual.")) for n in loading["unexpected_keys"]
    ):
        raise ValueError("reference checkpoint loading mismatch")
    weights = project_weights(model, compute_dtype="float32", torch=torch)
    with (output / "weight_identity.json").open("x") as f:
        json.dump(weights, f, indent=2)
    model.to("cpu").eval()
    if any(
        p.device.type != "cpu" or p.dtype != torch.float32 for p in model.parameters()
    ):
        raise ValueError("reference must remain CPU FP32")
    tokenizer = AutoTokenizer.from_pretrained(
        checkpoint,
        revision=spec["model_revision"],
        local_files_only=True,
        trust_remote_code=False,
    )
    state.update(
        status="collecting",
        torch_version=str(torch.__version__),
        transformers_version=str(transformers.__version__),
        loading=loading,
        global_weight_sha256=weights["global_weight_sha256"],
        weight_identity_sha256=sha(output / "weight_identity.json"),
        hf_implementation_sha256=sha(Path(hf.__file__)),
        reference_weight_collector_sha256=sha(
            source / "scripts/collect_homework1_references.py"
        ),
        load_and_project_seconds=time.perf_counter() - started,
    )
    save()
    with torch.inference_mode():
        for row in manifest["requests"]:
            ids = spec["input_ids"][row["request_id"]]
            past = None
            generated = []
            margins = []
            case_start = time.perf_counter()
            stop_reason = "max_new_tokens"
            for step in range(manifest["max_new_tokens"]):
                feed = ids if step == 0 else [generated[-1]]
                positions = (
                    list(range(len(ids))) if step == 0 else [len(ids) + step - 1]
                )
                result = model(
                    input_ids=torch.tensor([feed], dtype=torch.long),
                    position_ids=torch.tensor([positions], dtype=torch.long),
                    attention_mask=torch.ones((1, len(ids) + step), dtype=torch.long),
                    past_key_values=past,
                    use_cache=True,
                    logits_to_keep=1,
                )
                vector = result.logits[0, -1].detach().float()
                if vector.shape != (248320,) or not bool(torch.isfinite(vector).all()):
                    raise ValueError("reference logits invalid")
                top = torch.topk(vector, 2)
                chosen = int(vector.argmax())
                generated.append(chosen)
                margins.append(
                    {
                        "step": step,
                        "token_id": chosen,
                        "top2_ids": [int(x) for x in top.indices.tolist()],
                        "top2_logits": [float(x) for x in top.values.tolist()],
                        "margin": float(top.values[0] - top.values[1]),
                    }
                )
                past = result.past_key_values
                if past.get_seq_length() != len(ids) + step:
                    raise ValueError("cached reference prefix mismatch")
                if chosen in spec["stop_token_ids"]:
                    stop_reason = "eos"
                    break
                if step % 16 == 0:
                    state["current"] = {
                        "request_id": row["request_id"],
                        "generated_tokens": len(generated),
                        "wall_seconds": time.perf_counter() - case_start,
                    }
                    save()
            record = {
                "request_id": row["request_id"],
                "case": row["case"],
                "turn_index": row["turn_index"],
                "input_ids": ids,
                "output_ids": generated,
                "stop_reason": stop_reason,
                "stop_token_ids": spec["stop_token_ids"],
                "decoded_raw": tokenizer.decode(generated, skip_special_tokens=False),
                "decoded_text": tokenizer.decode(generated, skip_special_tokens=True),
                "greedy_margins": margins,
                "wall_seconds": time.perf_counter() - case_start,
                "complete_logits_collected": False,
            }
            path = output / (row["request_id"] + ".json")
            with path.open("x", encoding="utf-8") as f:
                json.dump(record, f, indent=2, ensure_ascii=False)
            state["records"].append(
                {
                    "request_id": row["request_id"],
                    "output_file": path.name,
                    "sha256": sha(path),
                    "tokens": len(generated),
                    "stop_reason": stop_reason,
                    "wall_seconds": record["wall_seconds"],
                }
            )
            state["current"] = None
            save()
            print(
                json.dumps(
                    {
                        "request_id": row["request_id"],
                        "tokens": len(generated),
                        "stop_reason": stop_reason,
                        "wall_seconds": record["wall_seconds"],
                    }
                ),
                flush=True,
            )
    state.update(
        status="collected",
        total_wall_seconds=time.perf_counter() - started,
        source_unchanged=all(sha(source / n) == s for n, s in files.items()),
        npu_import_blocked=sys.modules["torch_npu"] is None,
    )
    save()
    if (
        len(state["records"]) != 8
        or not state["source_unchanged"]
        or not state["npu_import_blocked"]
    ):
        raise ValueError("reference incomplete")
    print(
        json.dumps(
            {
                "status": "collected",
                "model": args.model,
                "records": 8,
                "total_wall_seconds": state["total_wall_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
