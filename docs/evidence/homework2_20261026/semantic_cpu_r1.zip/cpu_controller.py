#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Retain CPU reference exit and logs without importing an NPU backend."""

import argparse
import json
import os
import subprocess
from pathlib import Path


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "manifest", "output"):
        p.add_argument("--" + name, type=Path, required=True)
    p.add_argument("--manifest-sha", required=True)
    p.add_argument("--model", choices=("0.8b", "4b", "9b", "27b"), required=True)
    p.add_argument("--threads", type=int, required=True)
    args = p.parse_args()
    source = args.source_root.resolve()
    tools = Path(__file__).resolve().parent
    if args.threads < 1 or args.output.exists():
        raise ValueError("invalid CPU reference output or threads")
    env = dict(os.environ)
    env.update(
        TORCH_DEVICE_BACKEND_AUTOLOAD="0",
        ASCEND_RT_VISIBLE_DEVICES="",
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS=str(args.threads),
        PYTHONPATH=str(tools),
    )
    with (tools / f"cpu_{args.model}.log").open("x") as log:
        result = subprocess.run(
            [
                str(source / ".conda-env/bin/python"),
                "-B",
                str(tools / "collect_cpu_quality.py"),
                "--source-root",
                str(source),
                "--manifest",
                str(args.manifest),
                "--manifest-sha",
                args.manifest_sha,
                "--model",
                args.model,
                "--output",
                str(args.output),
                "--threads",
                str(args.threads),
            ],
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            timeout=7200,
        )
    record = {
        "status": "completed" if result.returncode == 0 else "failed",
        "exit_code": result.returncode,
        "npu_execution": False,
        "model": args.model,
        "manifest_sha256": args.manifest_sha,
    }
    with (tools / f"cpu_{args.model}.controller.json").open("x") as f:
        json.dump(record, f, indent=2)
    print(json.dumps(record))


if __name__ == "__main__":
    main()
