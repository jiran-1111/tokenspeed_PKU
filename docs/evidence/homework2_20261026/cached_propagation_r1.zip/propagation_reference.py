#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU FP32 counterfactuals for actual GDN8/9/10 cached-step8 operands.

State/input swaps are observations, not additive error contributions. No prefix
is recomputed, no thresholds are added, and original graph failures remain.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import analyze_cached as cached


def slice_scan(scan, *, rank, tp_size):
    """Slice global Q/K heads separately from V/a/b/constant heads."""
    import numpy as np

    q, k, v = (np.asarray(scan[name]) for name in ("q", "k", "v"))
    cached.require(
        q.ndim == k.ndim == v.ndim == 4
        and q.shape == k.shape
        and q.shape[:2] == v.shape[:2] == (1, 1),
        "single-token scan shape mismatch",
    )
    hk, hv = q.shape[2], v.shape[2]
    cached.require(
        tp_size > 0
        and 0 <= rank < tp_size
        and hk % tp_size == hv % tp_size == 0
        and hk > 0
        and hv % hk == 0,
        "scan head partition mismatch",
    )
    key = slice(rank * (hk // tp_size), (rank + 1) * (hk // tp_size))
    value = slice(rank * (hv // tp_size), (rank + 1) * (hv // tp_size))
    result = {
        "q": q[:, :, key].copy(),
        "k": k[:, :, key].copy(),
        "v": v[:, :, value].copy(),
    }
    for name in ("a", "b"):
        cached.require(
            scan[name].shape == (1, hv), "scan gate partition shape mismatch"
        )
        result[name] = scan[name][:, value].copy()
    for name in ("A_log", "dt_bias"):
        cached.require(
            scan[name].shape == (hv,), "scan constant partition shape mismatch"
        )
        result[name] = scan[name][value].copy()
    if "output" in scan:
        result["output"] = scan["output"][:, :, value].copy()
    return result


def slice_conv_weights(weights, *, widths, rank, tp_size):
    """Inverse logical-Q/K/V reassembly; never split the packed matrix whole."""
    import numpy as np

    weights = np.asarray(weights)
    cached.require(
        weights.ndim == 2
        and weights.shape == (sum(widths), 4)
        and len(widths) == 3
        and tp_size > 0
        and 0 <= rank < tp_size
        and all(width > 0 and width % tp_size == 0 for width in widths),
        "conv weight partition mismatch",
    )
    segments = np.split(weights, np.cumsum(widths)[:-1], axis=0)
    return np.concatenate(
        [
            part[rank * (width // tp_size) : (rank + 1) * (width // tp_size)]
            for part, width in zip(segments, widths)
        ],
        axis=0,
    )


def _constant_checks(one, two):
    checks = {}
    for rank, actual in enumerate(two):
        expected = slice_scan(one, rank=rank, tp_size=len(two))
        checks[str(rank)] = {}
        for name in ("A_log", "dt_bias"):
            metric = cached.compare(actual[name], expected[name])
            cached.require(
                metric["value_bits_equal"], f"cross-TP constant mismatch: {name}"
            )
            checks[str(rank)][name] = metric
    return checks


def _reference_output(scan, state):
    import gdn_reference

    return gdn_reference.gdn_decode_reference(
        scan["q"][0, 0],
        scan["k"][0, 0],
        scan["v"][0, 0],
        state,
        A_log=scan["A_log"],
        a=scan["a"][0],
        dt_bias=scan["dt_bias"],
        b=scan["b"][0],
        use_qk_l2norm=True,
    )["output"]


def counterfactual_outputs(one_scan, one_state, two_scans, two_states):
    """Y1/Y2 plus isolated history/current-input swaps, all raw FP32 outputs.

    state_only: sliced TP1 q/k/v/a/b + TP2 before SSM.
    inputs_only: actual TP2 q/k/v/a/b + sliced TP1 before SSM.
    A_log/dt_bias are first required to match bitwise at global value-head IDs.
    """
    import numpy as np

    cached.require(len(two_scans) == len(two_states) == 2, "requires both TP2 ranks")
    checks = _constant_checks(one_scan, two_scans)
    baseline = _reference_output(one_scan, one_state)
    cached.require(one_state.shape[0] % 2 == 0, "SSM head partition mismatch")
    baseline_states = np.split(one_state, 2, axis=0)
    own, state_only, inputs_only = [], [], []
    for rank, (scan, state) in enumerate(zip(two_scans, two_states)):
        baseline_scan = slice_scan(one_scan, rank=rank, tp_size=2)
        own.append(_reference_output(scan, state))
        state_only.append(_reference_output(baseline_scan, state))
        inputs_only.append(_reference_output(scan, baseline_states[rank]))
    return {
        "Y1": baseline,
        "Y2": np.concatenate(own, axis=0),
        "state_only": np.concatenate(state_only, axis=0),
        "inputs_only": np.concatenate(inputs_only, axis=0),
        "per_rank_Y2": own,
        "constant_checks": checks,
    }


def analyze_layer(
    one_scan, one_state, two_scans, two_states, *, tp1_weights, tp2_weights
):
    """Check captured constants/conv weights before reporting counterfactuals."""
    import numpy as np

    hk, key_dim = one_scan["q"].shape[2:]
    hv, value_dim = one_scan["v"].shape[2:]
    widths = (hk * key_dim, hk * key_dim, hv * value_dim)
    cached.require(len(tp2_weights) == 2, "requires both TP2 conv weights")
    conv_checks = {}
    for rank, weight in enumerate(tp2_weights):
        expected = slice_conv_weights(tp1_weights, widths=widths, rank=rank, tp_size=2)
        metric = cached.compare(weight, expected)
        cached.require(
            metric["value_bits_equal"], "cross-TP conv weight shard mismatch"
        )
        conv_checks[str(rank)] = metric
    joined = cached.join_packed(
        tp2_weights, widths=[width // 2 for width in widths], axis=0
    )
    conv_checks["logical_reassembly"] = cached.compare(joined, tp1_weights)
    cached.require(
        conv_checks["logical_reassembly"]["value_bits_equal"],
        "cross-TP conv weight reassembly mismatch",
    )
    values = counterfactual_outputs(one_scan, one_state, two_scans, two_states)
    actual1 = one_scan["output"][0, 0]
    actual2 = np.concatenate([scan["output"][0, 0] for scan in two_scans], axis=0)
    compare = lambda actual, reference: cached.compare(actual, reference, head_axis=0)
    return {
        "parameter_checks": {
            "A_log_dt_bias": values["constant_checks"],
            "conv_weights": conv_checks,
        },
        "cpu_Y2_vs_Y1": compare(values["Y2"], values["Y1"]),
        "actual_npu_TP2_vs_TP1": compare(actual2, actual1),
        "TP1_npu_vs_own_fp32": compare(actual1, values["Y1"]),
        "TP2_npu_vs_own_fp32_reassembled": compare(actual2, values["Y2"]),
        "TP2_npu_vs_own_fp32_per_rank": [
            compare(scan["output"][0, 0], reference)
            for scan, reference in zip(two_scans, values["per_rank_Y2"])
        ],
        "state_only_vs_Y1": compare(values["state_only"], values["Y1"]),
        "inputs_only_vs_Y1": compare(values["inputs_only"], values["Y1"]),
        "Y2_vs_state_only": compare(values["Y2"], values["state_only"]),
        "Y2_vs_inputs_only": compare(values["Y2"], values["inputs_only"]),
        "reference_inputs": "Actual captured _decode_scan q/k/v/a/b and before SSM; no recomputed prefix.",
        "interpretation": "FP32 counterfactual observations with nonlinear interactions, not additive contributions or a whole-model fix. Cross-TP parameter equality is not independent checkpoint certification.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--jobs-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    cached.require(args.threads > 0, "threads must be positive")
    manifest = json.loads(args.jobs_manifest.read_text())
    jobs = cached.select_jobs(args.root, manifest)
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    cached.require(
        "torch_npu" not in sys.modules, "CPU analysis must start without torch_npu"
    )
    sys.modules["torch_npu"] = None
    import torch

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "thresholds_added": False,
        "core_source_sha256": cached.CORE_SHA,
        "cpu_threads": args.threads,
        "analyzer_sha256": cached.sha(__file__),
        "dependencies": {
            name: cached.sha(Path(__file__).with_name(name))
            for name in ("analyze_cached.py", "gdn_reference.py")
        },
        "selection": {
            "path": str(args.jobs_manifest),
            "sha256": cached.sha(args.jobs_manifest),
            "jobs": manifest,
        },
        "runs": {},
        "ranks": {},
        "gdn_layers": {},
        "definitions": {
            "Y1": "TP1 actual current scan inputs + TP1 before SSM, FP32 reference",
            "Y2": "Each TP2 rank actual current scan inputs + its before SSM, FP32 reference, joined by value heads",
            "state_only": "TP1 sliced current q/k/v/a/b + TP2 before SSM",
            "inputs_only": "TP2 current q/k/v/a/b + TP1 sliced before SSM",
        },
        "scope": "Actual cached step8 of one fixed input; nonlinear FP32 counterfactuals are not additive error contributions, new thresholds, or a whole-model correction.",
    }
    captures, cases = [], []
    for tp in (1, 2):
        directory = jobs[f"tp{tp}"]
        run_path = directory / "diagnostic.json"
        run = json.loads(run_path.read_text())
        cached.validate_run(run)
        case = run["case"]
        cached.require(
            "_9b_" in case["case_id"]
            and len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) == 9
            and case["vector_count"] == 10,
            "original 9B case coverage mismatch",
        )
        cases.append(case)
        report["runs"][f"tp{tp}"] = {
            "path": str(run_path),
            "sha256": cached.sha(run_path),
            "guard_verified": True,
        }
        for rank in range(tp):
            path = directory / f"rank_{rank}" / "cached_step8.pt"
            metadata_path = path.with_name("cached_step8_metadata.json")
            loaded = torch.load(path, map_location="cpu", weights_only=True)
            dtypes = {}
            data = cached.convert_tensors(loaded, torch=torch, dtypes=dtypes)
            cached.require(
                json.loads(json.dumps(data["metadata"], allow_nan=False))
                == json.loads(metadata_path.read_text()),
                "capture/sidecar metadata mismatch",
            )
            cached.require(
                data["metadata"]["case_id"] == case["case_id"],
                "capture/run case mismatch",
            )
            cached.validate_capture(data, dtypes, rank=rank, tp=tp)
            report["ranks"][f"tp{tp}_rank{rank}"] = {
                "capture_sha256": cached.sha(path),
                "metadata_sha256": cached.sha(metadata_path),
                "capture_validated": True,
            }
            captures.append(data)
    cached.require(
        cases[0]["input_ids"] == cases[1]["input_ids"]
        and cases[0]["continuation_ids"] == cases[1]["continuation_ids"],
        "cross-TP original inputs differ",
    )
    for layer in (8, 9, 10):
        backends = [data["observed"]["backend"][layer] for data in captures]
        states = [
            data["observed"]["states"][layer]["before"]["ssm_state"]
            for data in captures
        ]
        report["gdn_layers"][str(layer)] = analyze_layer(
            backends[0]["scan"],
            states[0],
            [item["scan"] for item in backends[1:]],
            states[1:],
            tp1_weights=backends[0]["decode"]["conv_weights"],
            tp2_weights=[item["decode"]["conv_weights"] for item in backends[1:]],
        )
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "status": "passed",
                "rank_captures": 3,
                "gdn_layers": 3,
                "step": 8,
                "diagnostic_only": True,
                "thresholds_added": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps({"status": "failed", "error_type": type(error).__name__}),
            file=sys.stderr,
        )
        sys.exit(1)
