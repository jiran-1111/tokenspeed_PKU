#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""NumPy examples for cached GDN counterfactuals; no Torch dependency."""

import subprocess
import sys
import unittest
from pathlib import Path

import numpy as np

try:
    import propagation_reference as ref
except ModuleNotFoundError as exc:
    if exc.name != "propagation_reference":
        raise
    ref = None


def example_scan():
    return {
        "q": np.array([[[[1, 2], [3, 1]]]], dtype=np.float32),
        "k": np.array([[[[1, 0], [0, 1]]]], dtype=np.float32),
        "v": np.arange(1, 9, dtype=np.float32).reshape(1, 1, 4, 2),
        "A_log": np.zeros(4, dtype=np.float32),
        "dt_bias": np.zeros(4, dtype=np.float32),
        "a": np.zeros((1, 4), dtype=np.float32),
        "b": np.zeros((1, 4), dtype=np.float32),
        "output": np.zeros((1, 1, 4, 2), dtype=np.float32),
    }


class PropagationReferenceTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(ref, "counterfactual analysis has not been implemented")
        self.one = example_scan()
        self.state = np.arange(16, dtype=np.float32).reshape(4, 2, 2) / 10

    def locals(self):
        scans = [ref.slice_scan(self.one, rank=rank, tp_size=2) for rank in (0, 1)]
        states = [self.state[:2].copy(), self.state[2:].copy()]
        return scans, states

    def test_scan_slices_qk_heads_separately_from_value_gate_heads(self):
        self.one["a"][:] = [[10, 11, 12, 13]]
        self.one["b"][:] = [[20, 21, 22, 23]]
        self.one["A_log"][:] = [30, 31, 32, 33]
        result = ref.slice_scan(self.one, rank=1, tp_size=2)
        np.testing.assert_array_equal(result["q"], self.one["q"][:, :, 1:])
        np.testing.assert_array_equal(result["k"], self.one["k"][:, :, 1:])
        np.testing.assert_array_equal(result["v"], self.one["v"][:, :, 2:])
        np.testing.assert_array_equal(result["a"], [[12, 13]])
        np.testing.assert_array_equal(result["b"], [[22, 23]])
        np.testing.assert_array_equal(result["A_log"], [32, 33])

    def test_conv_weights_slice_each_qkv_segment_before_concatenating(self):
        weight = np.arange(64, dtype=np.float32).reshape(16, 4)
        result = ref.slice_conv_weights(weight, widths=(4, 4, 8), rank=1, tp_size=2)
        expected = np.concatenate((weight[2:4], weight[6:8], weight[12:16]))
        np.testing.assert_array_equal(result, expected)
        self.assertFalse(np.array_equal(result, weight[8:]))

    def test_zero_perturbation_keeps_all_four_fp32_outputs_equal(self):
        scans, states = self.locals()
        result = ref.counterfactual_outputs(self.one, self.state, scans, states)
        for name in ("Y2", "state_only", "inputs_only"):
            np.testing.assert_array_equal(result[name], result["Y1"])

    def test_only_state_perturbation_changes_state_only_and_full_tp2(self):
        scans, states = self.locals()
        states[0] += np.float32(0.25)
        result = ref.counterfactual_outputs(self.one, self.state, scans, states)
        np.testing.assert_array_equal(result["Y2"], result["state_only"])
        np.testing.assert_array_equal(result["inputs_only"], result["Y1"])
        self.assertFalse(np.array_equal(result["Y2"], result["Y1"]))

    def test_only_current_input_perturbation_changes_inputs_only_and_tp2(self):
        scans, states = self.locals()
        scans[1]["v"] = scans[1]["v"] + np.float32(1)
        scans[1]["a"] = scans[1]["a"] + np.float32(0.5)
        result = ref.counterfactual_outputs(self.one, self.state, scans, states)
        np.testing.assert_array_equal(result["Y2"], result["inputs_only"])
        np.testing.assert_array_equal(result["state_only"], result["Y1"])
        self.assertFalse(np.array_equal(result["Y2"], result["Y1"]))

    def test_constant_parameter_difference_stops_counterfactual(self):
        scans, states = self.locals()
        scans[0]["A_log"] = scans[0]["A_log"].copy()
        scans[0]["A_log"][0] += np.float32(1e-4)
        with self.assertRaisesRegex(ValueError, "constant"):
            ref.counterfactual_outputs(self.one, self.state, scans, states)

    def test_mismatched_conv_weights_stop_layer_analysis(self):
        scans, states = self.locals()
        weight = np.arange(64, dtype=np.float32).reshape(16, 4)
        local = [
            ref.slice_conv_weights(weight, widths=(4, 4, 8), rank=r, tp_size=2)
            for r in (0, 1)
        ]
        local[1][0, 0] += 1
        with self.assertRaisesRegex(ValueError, "conv"):
            ref.analyze_layer(
                self.one,
                self.state,
                scans,
                states,
                tp1_weights=weight,
                tp2_weights=local,
            )

    def test_cli_advertises_all_required_flags_without_importing_torch(self):
        script = Path(__file__).with_name("propagation_reference.py")
        result = subprocess.run(
            [sys.executable, "-B", str(script), "--help"],
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        for flag in ("--root", "--jobs-manifest", "--output", "--threads"):
            self.assertIn(flag, result.stdout)


if __name__ == "__main__":
    unittest.main()
