import hashlib,json,tarfile
from pathlib import Path
task=Path.home()/'tokenspeed/.tmp/hw2-20261023';source=task/'source_final'
ref=task/'independent_e2e_reference_r1_20261028';folder=task/'independent_e2e_comparison_r1_20261028'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for data in iter(lambda:f.read(8*1024*1024),b''):h.update(data)
 return h.hexdigest()
manifest=folder/'tool_manifest.json'
assert sha(manifest)=='8976fe1f432691c47bca9a4e6097c255d3ebee07a233b79fff9fc8f9ee5ff261'
tools=json.loads(manifest.read_text());assert len(tools)==5 and all(sha(folder/n)==v for n,v in tools.items())
assert sha(ref/'tool_manifest.json')=='cf09ecac218c32702b757b6010f70b3f80125cc18ffec19290827c9bf1e534af'
assert all(sha(ref/n)==v for n,v in json.loads((ref/'tool_manifest.json').read_text()).items())
complete=json.loads((ref/'reference_complete.json').read_text());assert complete['status']=='collected' and len(complete['finished'])==8
summary=folder/'output/summary.json';result=json.loads(summary.read_text())
assert result['reference_complete_sha256']==sha(ref/'reference_complete.json') and result['reference_files_unchanged_after']
assert set(result['models'])=={'4b','9b'}
for model,item in result['models'].items():
 assert sha(folder/f'output/{model}_comparison.json')==item['analysis_sha256']
 assert sha(folder/f'output/{model}_comparison_arrays.npz')==item['arrays_sha256']
core=source/'docs/evidence/homework2_20261023/source_manifest.json'
assert sha(core)=='2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3'
core_files=json.loads(core.read_text());assert len(core_files)==1531 and all(sha(source/n)==v for n,v in core_files.items())
identity={'launch_source_sha256': '3bb2f57dc4422e44c116e15bb6c824092fcffb3be6917eb26ba40837aa9389de', 'client_launch_receipt_sha256': 'aeeecc2289884e3cf1b7b871491c5aa2548fa80cacff9984213073bc31cbe79c'}
audit={'passed':True,'comparison_manifest_before_launch_and_after_matches':True,'comparison_tool_manifest_sha256':sha(manifest),'comparison_tool_files_rehashed':5,
       'reference_manifest_rehashed':True,'reference_cases_unchanged':True,'complete_eight_references':True,'summary_sha256':sha(summary),'core_files_rehashed':1531,
       'launch_binding':identity,'runtime_changed':False,'original_greedy_failures_repaired':False,'npu_experiments_started':0}
audit_path=folder/'execution_audit.json';audit_path.write_text(json.dumps(audit,indent=2)+'\n')
files={n:folder/n for n in tools}
for name in ('tool_manifest.json','tests.log','preparation.json','analysis.log','analysis.pid','execution_audit.json'):
 files[name]=folder/name
for name in ('summary.json','4b_comparison.json','9b_comparison.json','4b_comparison_arrays.npz','9b_comparison_arrays.npz'):
 files['output/'+name]=folder/'output'/name
hashes={n:sha(p) for n,p in files.items()}
name='supplement_export_independent_e2e_comparison_r1_20261028'
metadata=task/(name+'_manifest.json');metadata.write_text(json.dumps(hashes,indent=2)+'\n')
archive=task/(name+'.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=1) as target:
 for n,p in sorted(files.items()):target.add(p,arcname=n,recursive=False)
 target.add(metadata,arcname='export_manifest.json',recursive=False)
receipt={'files':len(files),'bytes':archive.stat().st_size,'archive_sha256':sha(archive),'models':2,'cpu_only':True,'execution_audit_passed':True,'original_failures_preserved':True}
(task/(name+'_receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'audit':audit,'archive':receipt}))
