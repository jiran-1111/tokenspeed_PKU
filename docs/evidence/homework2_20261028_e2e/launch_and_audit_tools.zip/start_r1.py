import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

task = Path.home()/"tokenspeed/.tmp/hw2-20261023"
source = task/"source_final"
folder = task/"independent_e2e_reference_r1_20261028"
manifest = folder/"tool_manifest.json"
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == "cf09ecac218c32702b757b6010f70b3f80125cc18ffec19290827c9bf1e534af"
assert all(hashlib.sha256((folder/name).read_bytes()).hexdigest()==value for name,value in json.loads(manifest.read_text()).items())
preparation = json.loads((folder/"preparation.json").read_text())
assert preparation["passed"] and preparation["tests"] == 31 and preparation["zero_skips"]
assert not (folder/"state.json").exists() and not (folder/"controller.pid").exists()
memory = {line.split(':')[0]:int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:','MemTotal:'))}
assert memory['MemAvailable'] > 12*1024*1024 and shutil.disk_usage(task).free > 10*1024**3
env = dict(os.environ)
env.update(TORCH_DEVICE_BACKEND_AUTOLOAD="0",ASCEND_RT_VISIBLE_DEVICES="",CUDA_VISIBLE_DEVICES="",PYTHONDONTWRITEBYTECODE="1")
with (folder/"controller.log").open("x") as log:
    child = subprocess.Popen(["python3",str(folder/"reference_controller.py")],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(folder/"controller.pid").write_text(str(child.pid))
print(json.dumps({"started":True,"tasks":8,"serial_cpu_only":True,"threads_per_process":8,"memory_available_gib":round(memory['MemAvailable']/1024**2,1),"npu_experiments_started":0}))
