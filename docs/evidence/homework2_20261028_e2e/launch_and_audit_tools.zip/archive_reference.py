import hashlib
import json
import tarfile
from pathlib import Path

task=Path.home()/"tokenspeed/.tmp/hw2-20261023"
folder=task/"independent_e2e_reference_r1_20261028"
state=json.loads((folder/"reference_complete.json").read_text())
assert state["status"]=="collected" and len(state["finished"])==8
name="supplement_export_independent_e2e_reference_r1_20261028"
archive=task/(name+".tar.gz")
assert not archive.exists()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((folder/"tool_manifest.json").read_text())
files={name:folder/name for name in manifest}
for file in ("tool_manifest.json","preparation.json","tests.log","state.json","reference_complete.json","controller.log","controller.pid"):
    files[file]=folder/file
for job in state["finished"]:
    files[job+".log"]=folder/(job+".log")
    for file in ("reference_state.json","reference_arrays.npz","parameter_reads.json"):
        files[f"output/{job}/{file}"]=folder/"output"/job/file
hashes={name:sha(path) for name,path in files.items()}
metadata=task/(name+"_manifest.json")
metadata.write_text(json.dumps(hashes,indent=2)+"\n")
with tarfile.open(archive,"w:gz",compresslevel=1) as target:
    for name,path in sorted(files.items()):target.add(path,arcname=name,recursive=False)
    target.add(metadata,arcname="export_manifest.json",recursive=False)
receipt={"files":len(files),"bytes":archive.stat().st_size,"archive_sha256":sha(archive),"references":8,"cpu_only":True,
         "reference_tool_manifest_sha256":sha(folder/"tool_manifest.json"),"core_runtime_unchanged":True,"original_failure_cases_unchanged":True}
(task/("supplement_export_independent_e2e_reference_r1_20261028_receipt.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
