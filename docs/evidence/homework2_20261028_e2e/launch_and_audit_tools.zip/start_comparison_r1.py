import hashlib
import json
import os
import subprocess
from pathlib import Path

task=Path.home()/"tokenspeed/.tmp/hw2-20261023"
source=task/"source_final"
reference=task/"independent_e2e_reference_r1_20261028"
folder=task/"independent_e2e_comparison_r1_20261028"
assert json.loads((reference/"state.json").read_text())["status"]=="collected"
assert len(json.loads((reference/"reference_complete.json").read_text())["finished"])==8
assert not (folder/"output").exists() and not (folder/"analysis.pid").exists()
assert hashlib.sha256((folder/"tool_manifest.json").read_bytes()).hexdigest()=="8976fe1f432691c47bca9a4e6097c255d3ebee07a233b79fff9fc8f9ee5ff261"
assert all(hashlib.sha256((folder/name).read_bytes()).hexdigest()==value for name,value in json.loads((folder/"tool_manifest.json").read_text()).items())
assert json.loads((folder/"preparation.json").read_text())["passed"]
env=dict(os.environ)
env.update(TORCH_DEVICE_BACKEND_AUTOLOAD="0",ASCEND_RT_VISIBLE_DEVICES="",CUDA_VISIBLE_DEVICES="",PYTHONDONTWRITEBYTECODE="1",OMP_NUM_THREADS="8",OPENBLAS_NUM_THREADS="8",MKL_NUM_THREADS="8",PYTHONPATH=str(folder))
with (folder/"analysis.log").open("x") as log:
    child=subprocess.Popen([str(source/".conda-env/bin/python"),"-B",str(folder/"compare_reference.py")],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(folder/"analysis.pid").write_text(str(child.pid))
print(json.dumps({"comparison_started":True,"eight_references_complete":True,"cpu_only":True,"npu_experiments_started":0}))
