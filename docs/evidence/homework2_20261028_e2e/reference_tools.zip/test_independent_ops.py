# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib
import importlib.util

import numpy as np
import pytest


def api():
    assert (
        importlib.util.find_spec("independent_ops") is not None
    ), "Independent end-to-end operations not implemented"
    return importlib.import_module("independent_ops")


def test_bf16_partition_storage_can_change_cancelling_row_projection():
    ops = api()
    x = np.array([[1.0078125, 1.0]], np.float32)
    weight = np.array([[1.0078125, -1.015625]], np.float32)
    one = ops.row_linear([x], weight, storage_policy="bf16_contract")
    two = ops.row_linear(
        list(np.split(x, 2, axis=1)), weight, storage_policy="bf16_contract"
    )
    np.testing.assert_array_equal(one, [[2**-14]])
    np.testing.assert_array_equal(two, [[0.0]])


def test_fp32_control_does_not_inherit_bf16_partial_storage():
    ops = api()
    x = np.array([[1.0078125, 1.0]], np.float32)
    weight = np.array([[1.0078125, -1.015625]], np.float32)
    two = ops.row_linear(
        list(np.split(x, 2, axis=1)), weight, storage_policy="fp32_control"
    )
    np.testing.assert_array_equal(two, [[2**-14]])


def test_column_partition_slices_each_logical_segment():
    ops = api()
    x = np.array([[1.0, 2.0]], np.float32)
    q = np.arange(8, dtype=np.float32).reshape(4, 2)
    kv = np.arange(12, 16, dtype=np.float32).reshape(2, 2)
    out = ops.column_linear(x, [q, kv], tp=2, storage_policy="fp32_control")
    np.testing.assert_array_equal(out[0], x @ np.concatenate([q[:2], kv[:1]]).T)
    np.testing.assert_array_equal(out[1], x @ np.concatenate([q[2:], kv[1:]]).T)


def test_gemma_gamma_addition_remains_float32():
    ops = api()
    raw = np.array([0.00390625, -0.5], np.float32)
    expected = raw + np.float32(1)
    gamma = ops.effective_gamma(raw)
    np.testing.assert_array_equal(gamma, expected)
    assert gamma[0] == 1.00390625


def test_rope_table_is_generated_from_positions_and_configuration():
    ops = api()
    table = ops.rope_table(3, rotary_dim=4, base=100.0, storage_policy="fp32_control")
    freq = np.arange(3, dtype=np.float32)[:, None] * np.array([1, 0.1], np.float32)
    np.testing.assert_allclose(
        table,
        np.concatenate([np.cos(freq), np.sin(freq)], axis=1),
        rtol=1e-6,
        atol=1e-7,
    )


def test_mrope_preserves_bf16_storage_of_each_torch_product():
    ops = api()
    value = np.array([[[1.0078125, 1.0]]], np.float32)
    table = np.array([[0.7109375, 0.703125]], np.float32)
    out = ops.rotary(
        value, np.array([0]), table, rotary_dim=2, storage_policy="bf16_contract"
    )
    assert out[0, 0, 0] == 0.01171875
    fused = ops.stored(
        value[0, 0, 0] * table[0, 0] - value[0, 0, 1] * table[0, 1],
        storage_policy="bf16_contract",
    )
    assert out[0, 0, 0] != fused


def test_residual_add_is_stored_before_normalization():
    ops = api()
    x = np.array([[1.0, 2.0]], np.float32)
    residual = np.array([[2**-8, 2**-7]], np.float32)
    out, updated = ops.reduce_norm(
        x,
        residual,
        np.ones(2, np.float32),
        epsilon=1e-6,
        storage_policy="bf16_contract",
    )
    np.testing.assert_array_equal(updated, [[1.0, 2.0]])
    expected = np.array([[1.0, 2.0]], np.float32) / np.sqrt(np.float32(2.5 + 1e-6))
    np.testing.assert_array_equal(
        out, ops.stored(expected, storage_policy="bf16_contract")
    )


def test_gdn_state_is_fresh_owned_float32_and_segmented_history_agrees():
    ops = api()
    rng = np.random.default_rng(741)
    t, hk, hv, dim = 5, 2, 4, 2
    packed = (rng.normal(size=(t, 2 * hk * dim + 2 * hv * dim + 2 * hv)) * 0.2).astype(
        np.float32
    )
    conv = np.full((2 * hk * dim + hv * dim, 4), 0.25, np.float32)
    args = dict(
        hk=hk,
        hv=hv,
        key_dim=dim,
        value_dim=dim,
        epsilon=1e-6,
        A_log=np.zeros(hv, np.float32),
        dt_bias=np.zeros(hv, np.float32),
        conv_weight=conv,
        norm_weight=np.ones(dim, np.float32),
        storage_policy="fp32_control",
    )
    whole, state_a = ops.gdn_sequence([packed], **args)
    split, state_b = ops.gdn_sequence([packed[:3], packed[3:4], packed[4:]], **args)
    np.testing.assert_allclose(np.concatenate(split), whole[0], rtol=2e-6, atol=2e-7)
    np.testing.assert_array_equal(state_a["ssm"], state_b["ssm"])
    assert state_b["ssm"].dtype == np.float32 and state_b["conv"].dtype == np.float32
    copied = state_b["ssm"].copy()
    ops.gdn_sequence([packed], **args)
    np.testing.assert_array_equal(state_b["ssm"], copied)


def test_fa_causal_prefill_and_own_kv_decode_match_unsegmented_reference():
    ops = api()
    rng = np.random.default_rng(317)
    packed = (rng.normal(size=(5, (2 * 4 + 2 * 2) * 2)) * 0.25).astype(np.float32)
    args = dict(
        heads=4,
        kv_heads=2,
        head_dim=2,
        rotary_dim=2,
        rope_base=100.0,
        epsilon=1e-6,
        q_gamma=np.ones(2, np.float32),
        k_gamma=np.ones(2, np.float32),
        storage_policy="fp32_control",
    )
    whole, state_a = ops.fa_sequence([packed], **args)
    split, state_b = ops.fa_sequence([packed[:3], packed[3:4], packed[4:]], **args)
    np.testing.assert_allclose(np.concatenate(split), whole[0], rtol=3e-6, atol=2e-7)
    np.testing.assert_array_equal(state_a["k"], state_b["k"])
    np.testing.assert_array_equal(state_a["v"], state_b["v"])


def test_gdn_matches_separate_scalar_recurrence_with_unequal_key_value_dims():
    ops = api()
    rng = np.random.default_rng(441)
    t, hk, hv, kd, vd = 5, 2, 4, 2, 3
    widths = [hk * kd, hk * kd, hv * vd, hv * vd, hv, hv]
    packed = (rng.normal(size=(t, sum(widths))) * 0.15).astype(np.float32)
    channels = 2 * hk * kd + hv * vd
    conv = np.tile(np.array([0.03, 0.07, 0.11, 0.19], np.float32), (channels, 1))
    A_log = np.array([-0.2, -0.1, 0.1, 0.2], np.float32)
    dt_bias = np.array([0.03, -0.07, 0.1, -0.2], np.float32)
    weight = np.array([0.75, 1.0, 1.25], np.float32)
    outputs, state = ops.gdn_sequence(
        [packed[:3], packed[3:4], packed[4:]],
        hk=hk,
        hv=hv,
        key_dim=kd,
        value_dim=vd,
        epsilon=1e-6,
        A_log=A_log,
        dt_bias=dt_bias,
        conv_weight=conv,
        norm_weight=weight,
        storage_policy="fp32_control",
    )
    q, k, v, z, b, a = np.split(packed, np.cumsum(widths)[:-1], axis=1)
    raw = np.concatenate([q, k, v], axis=1)
    memory = np.zeros((hv, kd, vd), np.float32)
    expected = []
    for token in range(t):
        linear = np.zeros(channels, np.float32)
        for tap in range(4):
            source = token - 3 + tap
            if source >= 0:
                linear += raw[source] * conv[:, tap]
        mixed = linear / (1 + np.exp(-linear))
        qv, kv, vv = np.split(mixed, [hk * kd, 2 * hk * kd])
        qv, kv, vv = qv.reshape(hk, kd), kv.reshape(hk, kd), vv.reshape(hv, vd)
        qv /= np.sqrt(np.sum(qv * qv, axis=1, keepdims=True) + 1e-6)
        kv /= np.sqrt(np.sum(kv * kv, axis=1, keepdims=True) + 1e-6)
        core = np.empty((hv, vd), np.float32)
        for head in range(hv):
            key_head = head // (hv // hk)
            decay = np.exp(
                -np.exp(A_log[head])
                * np.log(1 + np.exp(a[token, head] + dt_bias[head]))
            )
            memory[head] *= decay
            prediction = kv[key_head] @ memory[head]
            change = (vv[head] - prediction) / (1 + np.exp(-b[token, head]))
            memory[head] += np.outer(kv[key_head], change)
            core[head] = (qv[key_head] / np.sqrt(np.float32(kd))) @ memory[head]
        core = core / np.sqrt(np.mean(core * core, axis=-1, keepdims=True) + 1e-6)
        gate = z[token].reshape(hv, vd)
        expected.append((core * weight * (gate / (1 + np.exp(-gate)))).reshape(-1))
    np.testing.assert_allclose(
        np.concatenate(outputs), np.stack(expected), rtol=2e-5, atol=1e-7
    )
    np.testing.assert_allclose(
        state["ssm"], memory.transpose(0, 2, 1), rtol=2e-5, atol=1e-8
    )


@pytest.mark.parametrize("policy", ["bf16_contract", "fp32_control"])
def test_storage_policy_is_explicit_and_rejects_nonfinite_values(policy):
    ops = api()
    with pytest.raises(ValueError):
        ops.stored(np.array([np.nan]), storage_policy=policy)
    with pytest.raises(ValueError):
        ops.stored(np.array([1]), storage_policy="unknown")
