# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU safetensors reader; reference values never come from runtime captures."""

import hashlib
import json
from pathlib import Path

import numpy as np
import torch
from independent_ops import require
from safetensors import safe_open


class CheckpointReader:
    def __init__(self, checkpoint: Path) -> None:
        self.checkpoint = checkpoint
        self.index = json.loads(
            (checkpoint / "model.safetensors.index.json").read_text()
        )["weight_map"]
        self.records: dict[str, dict] = {}

    def read(
        self, name: str, *, rows: tuple[int, int] | np.ndarray | None, mode: str
    ) -> np.ndarray:
        require(
            name.startswith("model.language_model.") or name == "lm_head.weight",
            "Only text checkpoint names allowed",
        )
        require(
            name in self.index and mode in ("float32", "bfloat16"),
            "Unknown parameter or precision",
        )
        with safe_open(
            self.checkpoint / self.index[name], framework="pt", device="cpu"
        ) as handle:
            sliced = handle.get_slice(name)
            shape = sliced.get_shape()
            if isinstance(rows, tuple):
                start, stop = rows
                require(
                    type(start) is int
                    and type(stop) is int
                    and 0 <= start < stop <= shape[0],
                    "Invalid row bounds",
                )
                tensor, selection = sliced[start:stop], [start, stop]
            elif rows is None:
                tensor, selection = handle.get_tensor(name), "all"
            else:
                require(
                    isinstance(rows, np.ndarray)
                    and rows.ndim == 1
                    and rows.dtype.kind in "iu"
                    and rows.size > 0,
                    "Integer row IDs required",
                )
                require(
                    bool(np.all(rows >= 0) and np.all(rows < shape[0])),
                    "Row IDs outside checkpoint",
                )
                tensor = handle.get_tensor(name)[
                    torch.from_numpy(rows.astype(np.int64))
                ]
                selection = {"ids": rows.tolist()}
            require(tensor.device.type == "cpu", "CPU checkpoint storage required")
            projected = (
                tensor.to(torch.bfloat16).float()
                if mode == "bfloat16"
                else tensor.float()
            )
            result = np.array(projected.numpy(), dtype=np.float32, copy=True, order="C")
        require(bool(np.isfinite(result).all()), "Nonfinite checkpoint parameter")
        key = json.dumps([name, mode, selection], sort_keys=True)
        record = {
            "name": name,
            "mode": mode,
            "rows": selection,
            "shape": list(result.shape),
            "float32_representation_sha256": hashlib.sha256(
                result.tobytes()
            ).hexdigest(),
        }
        require(
            key not in self.records or self.records[key] == record,
            "Checkpoint parameter changed during reference",
        )
        self.records[key] = record
        return result
