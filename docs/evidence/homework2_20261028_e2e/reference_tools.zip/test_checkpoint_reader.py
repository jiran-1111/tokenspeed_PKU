# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib
import importlib.util
import json

import numpy as np
import pytest

torch = pytest.importorskip("torch")
from safetensors.torch import save_file


def reader(tmp_path):
    assert (
        importlib.util.find_spec("checkpoint_reader") is not None
    ), "Independent checkpoint reader missing"
    values = torch.tensor(
        [[1.00390625, 2.0], [3.0, 4.0], [5.0, 6.0]], dtype=torch.float32
    )
    name = "model.language_model.embed_tokens.weight"
    save_file({name: values}, tmp_path / "weights.safetensors")
    (tmp_path / "model.safetensors.index.json").write_text(
        json.dumps({"weight_map": {name: "weights.safetensors"}})
    )
    return (
        importlib.import_module("checkpoint_reader").CheckpointReader(tmp_path),
        name,
        values,
    )


def test_loader_projects_checkpoint_values_and_slices_requested_ids(tmp_path):
    source, name, values = reader(tmp_path)
    result = source.read(name, rows=np.array([2, 0, 2]), mode="bfloat16")
    np.testing.assert_array_equal(result, values[[2, 0, 2]].bfloat16().float().numpy())
    assert result[1, 0] == 1.0


def test_ssm_parameters_keep_checkpoint_float32(tmp_path):
    source, name, values = reader(tmp_path)
    result = source.read(name, rows=None, mode="float32")
    np.testing.assert_array_equal(result, values.numpy())
    assert result[0, 0] == 1.00390625


def test_loader_owns_output_and_records_repeatable_parameter_values(tmp_path):
    source, name, values = reader(tmp_path)
    one = source.read(name, rows=(0, 2), mode="float32")
    one[:] = 0
    two = source.read(name, rows=(0, 2), mode="float32")
    np.testing.assert_array_equal(two, values[:2].numpy())
    assert len(source.records) == 1


@pytest.mark.parametrize("rows", [(1, 5), np.array([-1]), np.array([1.0])])
def test_loader_rejects_invalid_row_selection(tmp_path, rows):
    source, name, _ = reader(tmp_path)
    with pytest.raises(ValueError):
        source.read(name, rows=rows, mode="bfloat16")


def test_loader_rejects_unsupported_precision_and_nontext_parameters(tmp_path):
    source, name, _ = reader(tmp_path)
    with pytest.raises(ValueError):
        source.read(name, rows=None, mode="guess")
    with pytest.raises(ValueError):
        source.read("model.visual.weights", rows=None, mode="bfloat16")
