# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Execute one independent checkpoint/IDs CPU reference before comparison."""

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

assert os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0"
assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
sys.modules["torch_npu"] = None

import numpy as np
import torch
from checkpoint_reader import CheckpointReader
from independent_model import run_model
from independent_ops import require


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read(path: Path):
    return json.loads(path.read_text())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--model", choices=("4b", "9b"), required=True)
    parser.add_argument("--tp", type=int, choices=(1, 2), required=True)
    parser.add_argument(
        "--storage-policy", choices=("bf16_contract", "fp32_control"), required=True
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    protocol = read(here / "reference_protocol.json")
    tool_path = here / "tool_manifest.json"
    tool_files = read(tool_path)
    require(
        all(sha(here / name) == digest for name, digest in tool_files.items()),
        "Frozen reference tool mismatch",
    )
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    core = args.source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(
        sha(core) == protocol["core_manifest_sha256"], "Frozen core identity mismatch"
    )
    core_files = read(core)
    require(
        len(core_files) == 1531
        and all(
            sha(args.source / name) == digest for name, digest in core_files.items()
        ),
        "Core files changed",
    )
    config_path = args.source / f"configs/homework2/qwen35_{args.model}_tp1.yaml"
    engine_config = read(config_path)
    identity = protocol["models"][args.model]
    require(
        engine_config["model_revision"] == identity["revision"]
        and engine_config["tp_size"] == 1
        and engine_config["dtype"] == "bfloat16",
        "Original model configuration mismatch",
    )
    checkpoint = args.source / engine_config["local_model_path"]
    artifact_path = (
        args.source / "docs/evidence/homework2_20261023/model_artifacts.json"
    )
    require(
        sha(artifact_path) == protocol["model_artifacts_sha256"],
        "Model artifact manifest changed",
    )
    artifacts = [
        item
        for item in read(artifact_path)["models"]
        if item["model_id"] == engine_config["model_id"]
        and item["model_revision"] == identity["revision"]
    ]
    require(len(artifacts) == 1, "Ambiguous model artifact")
    artifact = artifacts[0]["files"]
    index = read(checkpoint / "model.safetensors.index.json")["weight_map"]
    files = {"config.json", "model.safetensors.index.json"} | {
        filename
        for name, filename in index.items()
        if name.startswith("model.language_model.") or name == "lm_head.weight"
    }
    fingerprints = {name: sha(checkpoint / name) for name in sorted(files)}
    require(
        all(
            value == artifact[name]["sha256"]
            and (checkpoint / name).stat().st_size == artifact[name]["bytes"]
            for name, value in fingerprints.items()
        ),
        "Original checkpoint file mismatch",
    )
    checkpoint_config = read(checkpoint / "config.json")
    config = checkpoint_config["text_config"]
    require(
        config["num_hidden_layers"] == 32 and config["mamba_ssm_dtype"] == "float32",
        "Original layer/state contract mismatch",
    )
    require(
        config.get("tie_word_embeddings", identity["tied"]) == identity["tied"],
        "Embedding/head tie mismatch",
    )
    config["tie_word_embeddings"] = identity["tied"]
    case_path = here / f"case_{args.model}.json"
    require(sha(case_path) == identity["case_sha256"], "Original failure case changed")
    case = read(case_path)
    require(
        len(case["input_ids"]) == 128
        and len(case["continuation_ids"]) + 1 == identity["vectors"],
        "Original frontier extent mismatch",
    )
    args.output.mkdir(exist_ok=False)
    record = {
        "status": "running",
        "model": args.model,
        "tp": args.tp,
        "storage_policy": args.storage_policy,
        "case_sha256": sha(case_path),
        "model_revision": identity["revision"],
        "vectors": identity["vectors"],
        "original_ids": case,
        "core_manifest_sha256": sha(core),
        "tool_manifest_sha256": sha(tool_path),
        "protocol_sha256": sha(here / "reference_protocol.json"),
        "checkpoint_files_before": fingerprints,
        "actual_runtime_intermediates_read": False,
        "runtime_modified": False,
        "model_threshold_added": False,
        "numpy_version": np.__version__,
        "torch_version": torch.__version__,
        "cpu_threads": 8,
        "head_precision": identity["head_precision"],
        "scope": "CPU FP32 math and explicit storage; own complete hidden/state propagation; not NPU instruction emulation or real HCCL",
        "performance_eligible": False,
    }

    def save():
        temporary = args.output / "reference_state.tmp"
        temporary.write_text(json.dumps(record, indent=2) + "\n")
        temporary.replace(args.output / "reference_state.json")

    def progress(layer):
        record["last_completed_layer"] = layer
        save()
        print(
            f"{args.model} {args.storage_policy} tp{args.tp}: layer{layer} complete",
            flush=True,
        )

    save()
    try:
        started = time.monotonic()
        reader = CheckpointReader(checkpoint)
        result = run_model(
            config,
            case,
            reader.read,
            tp=args.tp,
            storage_policy=args.storage_policy,
            head_precision=identity["head_precision"],
            progress=progress,
        )
        require(
            result["logits"].shape == (identity["vectors"], 248320)
            and result["norms"].shape
            == (65, 127 + identity["vectors"], config["hidden_size"]),
            "Incomplete reference output",
        )
        arrays = {name: result[name] for name in ("logits", "norms", "head_input")}
        state_metadata = {}
        for label, group in result["states"].items():
            state_metadata[label] = {}
            for name, array in group.items():
                arrays[f"state_{label}_{name}"] = array
                state_metadata[label][name] = {
                    "shape": list(array.shape),
                    "dtype": str(array.dtype),
                    "sha256": hashlib.sha256(array.tobytes()).hexdigest(),
                }
        np.savez_compressed(args.output / "reference_arrays.npz", **arrays)
        (args.output / "parameter_reads.json").write_text(
            json.dumps(list(reader.records.values()), indent=2) + "\n"
        )
        require(
            all(
                sha(checkpoint / name) == value for name, value in fingerprints.items()
            ),
            "Checkpoint changed during reference",
        )
        require(
            all(
                sha(args.source / name) == digest for name, digest in core_files.items()
            ),
            "Core changed during reference",
        )
        require(
            not any(name.startswith("tokenspeed.runtime") for name in sys.modules),
            "Production runtime unexpectedly imported",
        )
        require(
            not any(
                name.startswith("torch_npu") and module is not None
                for name, module in sys.modules.items()
            ),
            "NPU unexpectedly imported",
        )
        record.update(
            status="collected",
            arrays_sha256=sha(args.output / "reference_arrays.npz"),
            parameter_reads_sha256=sha(args.output / "parameter_reads.json"),
            norm_names=result["norm_names"],
            step_offsets=result["step_offsets"],
            states=state_metadata,
            raw_argmax_ids=result["logits"].argmax(axis=1).tolist(),
            elapsed_cpu_reference_seconds=time.monotonic() - started,
            checkpoint_unchanged=True,
            core_unchanged=True,
            only_cpu_imports=True,
        )
    except BaseException as error:
        record.update(
            status="failed", error_type=type(error).__name__, error=str(error)
        )
        raise
    finally:
        save()
    print(
        json.dumps(
            {
                "model": args.model,
                "tp": args.tp,
                "storage_policy": args.storage_policy,
                "status": record["status"],
                "seconds": record["elapsed_cpu_reference_seconds"],
                "argmax": record["raw_argmax_ids"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
