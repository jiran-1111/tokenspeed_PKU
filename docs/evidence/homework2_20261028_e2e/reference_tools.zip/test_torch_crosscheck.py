# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import numpy as np
import pytest

torch = pytest.importorskip("torch")

from independent_ops import rotary


def test_bf16_mrope_matches_separate_eager_torch_cpu_operations():
    rng = np.random.default_rng(887)
    source = torch.from_numpy(rng.normal(size=(7, 4, 8)).astype(np.float32)).bfloat16()
    table = torch.from_numpy(rng.normal(size=(9, 4)).astype(np.float32)).bfloat16()
    positions = np.array([0, 1, 2, 4, 5, 6, 8], np.int64)
    selected = table[torch.from_numpy(positions)]
    cos, sin = selected.chunk(2, dim=-1)
    first, second = source[..., :4].chunk(2, dim=-1)
    expected = torch.cat(
        [
            first * cos[:, None] - second * sin[:, None],
            second * cos[:, None] + first * sin[:, None],
            source[..., 4:],
        ],
        dim=-1,
    )
    actual = rotary(
        source.float().numpy(),
        positions,
        table.float().numpy(),
        rotary_dim=4,
        storage_policy="bf16_contract",
    )
    np.testing.assert_array_equal(actual, expected.float().numpy())


@pytest.mark.parametrize("tp", [1, 2])
def test_complete_fp32_reference_matches_independent_hf_tiny_model(monkeypatch, tp):
    from independent_model import run_model
    from test_independent_model import fixture
    from transformers import Qwen3_5TextConfig
    from transformers.models.qwen3_5 import modeling_qwen3_5 as hf

    for name in (
        "causal_conv1d_fn",
        "causal_conv1d_update",
        "chunk_gated_delta_rule",
        "fused_recurrent_gated_delta_rule",
        "FusedRMSNormGated",
    ):
        monkeypatch.setattr(hf, name, None)
    monkeypatch.setattr(hf, "is_fast_path_available", False)
    config, read, _ = fixture()
    settings = dict(config)
    settings["rope_parameters"] = dict(
        config["rope_parameters"], mrope_section=[1, 0, 0], mrope_interleaved=True
    )
    cfg = Qwen3_5TextConfig(
        **settings,
        attn_implementation="eager",
        dtype="float32",
        max_position_embeddings=64
    )
    model = hf.Qwen3_5TextModel(cfg).float().eval()
    values = {}
    for name in model.state_dict():
        mode = "float32" if name.endswith(("A_log", "dt_bias")) else "bfloat16"
        values[name] = torch.from_numpy(
            read("model.language_model." + name, rows=None, mode=mode)
        )
    model.load_state_dict(values, strict=True)
    case = dict(input_ids=[1, 2, 3], continuation_ids=[4, 5])
    reference = run_model(
        config,
        case,
        read,
        tp=tp,
        storage_policy="fp32_control",
        head_precision="float32",
        progress=None,
    )
    previous, hidden = None, []
    with torch.inference_mode():
        for feed in (case["input_ids"], [4], [5]):
            output = model(
                input_ids=torch.tensor([feed]), past_key_values=previous, use_cache=True
            )
            previous = output.past_key_values
            hidden.append(output.last_hidden_state[0, -1].numpy())
    hidden = np.stack(hidden)
    np.testing.assert_allclose(reference["head_input"], hidden, rtol=2e-5, atol=2e-6)
    expected_logits = hidden @ read("lm_head.weight", rows=None, mode="bfloat16").T
    np.testing.assert_allclose(
        reference["logits"], expected_logits, rtol=2e-5, atol=2e-6
    )
