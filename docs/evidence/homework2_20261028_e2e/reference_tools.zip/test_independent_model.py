# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib
import importlib.util

import numpy as np
import pytest


def api():
    assert (
        importlib.util.find_spec("independent_model") is not None
    ), "Independent full-model propagation not implemented"
    return importlib.import_module("independent_model")


def fixture():
    rng = np.random.default_rng(1028)
    config = dict(
        hidden_size=8,
        intermediate_size=12,
        num_hidden_layers=2,
        layer_types=["linear_attention", "full_attention"],
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=2,
        linear_num_key_heads=2,
        linear_num_value_heads=4,
        linear_key_head_dim=2,
        linear_value_head_dim=2,
        linear_conv_kernel_dim=4,
        rms_norm_eps=1e-6,
        vocab_size=16,
        rope_parameters=dict(
            rope_type="default", rope_theta=100.0, partial_rotary_factor=1.0
        ),
        hidden_act="silu",
        attention_bias=False,
        attn_output_gate=True,
        tie_word_embeddings=False,
    )
    weights = {}
    prefix = "model.language_model."

    def random(shape):
        return (rng.normal(size=shape) * 0.2).astype(np.float32)

    weights[prefix + "embed_tokens.weight"] = random((16, 8))
    weights["lm_head.weight"] = random((16, 8))
    weights[prefix + "norm.weight"] = random((8,))
    for layer in range(2):
        p = f"{prefix}layers.{layer}."
        for name in ("input_layernorm.weight", "post_attention_layernorm.weight"):
            weights[p + name] = random((8,))
        weights[p + "mlp.gate_proj.weight"] = random((12, 8))
        weights[p + "mlp.up_proj.weight"] = random((12, 8))
        weights[p + "mlp.down_proj.weight"] = random((8, 12))
        if layer == 0:
            for name, shape in {
                "in_proj_qkv.weight": (16, 8),
                "in_proj_z.weight": (8, 8),
                "in_proj_b.weight": (4, 8),
                "in_proj_a.weight": (4, 8),
                "out_proj.weight": (8, 8),
                "conv1d.weight": (16, 1, 4),
                "A_log": (4,),
                "dt_bias": (4,),
                "norm.weight": (2,),
            }.items():
                weights[p + "linear_attn." + name] = random(shape)
        else:
            for name, shape in {
                "q_proj.weight": (16, 8),
                "k_proj.weight": (4, 8),
                "v_proj.weight": (4, 8),
                "o_proj.weight": (8, 8),
                "q_norm.weight": (2,),
                "k_norm.weight": (2,),
            }.items():
                weights[p + "self_attn." + name] = random(shape)
    from prefill_oracle import bf16_storage

    calls = []

    def read(name, *, rows, mode):
        assert (
            name in weights
        ), "Reference requested something other than a checkpoint parameter"
        calls.append((name, mode))
        value = weights[name]
        if isinstance(rows, tuple):
            value = value[rows[0] : rows[1]]
        elif rows is not None:
            value = value[rows]
        return value.copy() if mode == "float32" else bf16_storage(value)

    return config, read, calls


@pytest.mark.parametrize("tp", [1, 2])
@pytest.mark.parametrize("policy", ["bf16_contract", "fp32_control"])
def test_full_model_owns_history_and_propagates_both_layer_types(tp, policy):
    model = api()
    config, read, calls = fixture()
    case = dict(input_ids=[1, 2, 3], continuation_ids=[4, 5])
    result = model.run_model(
        config,
        case,
        read,
        tp=tp,
        storage_policy=policy,
        head_precision="float32",
        progress=None,
    )
    assert result["logits"].shape == (3, 16)
    assert result["norms"].shape == (5, 5, 8)
    assert result["step_offsets"] == [[0, 3], [3, 4], [4, 5]]
    assert np.isfinite(result["logits"]).all()
    assert len(result["states"]) == 2 * tp
    assert all("observed" not in name and "capture" not in name for name, _ in calls)
    again = model.run_model(
        config,
        case,
        read,
        tp=tp,
        storage_policy=policy,
        head_precision="float32",
        progress=None,
    )
    np.testing.assert_array_equal(result["logits"], again["logits"])


@pytest.mark.parametrize("policy", ["bf16_contract", "fp32_control"])
def test_changing_future_continuation_cannot_change_earlier_logits(policy):
    model = api()
    config, read, _ = fixture()
    a = model.run_model(
        config,
        dict(input_ids=[1, 2, 3], continuation_ids=[4, 5]),
        read,
        tp=2,
        storage_policy=policy,
        head_precision="float32",
        progress=None,
    )
    b = model.run_model(
        config,
        dict(input_ids=[1, 2, 3], continuation_ids=[4, 6]),
        read,
        tp=2,
        storage_policy=policy,
        head_precision="float32",
        progress=None,
    )
    np.testing.assert_array_equal(a["logits"][:2], b["logits"][:2])
    assert np.any(a["logits"][-1] != b["logits"][-1])


def test_fp32_partition_control_preserves_complete_model_algebra():
    model = api()
    config, read, _ = fixture()
    case = dict(input_ids=[1, 2, 3], continuation_ids=[4, 5])
    a = model.run_model(
        config,
        case,
        read,
        tp=1,
        storage_policy="fp32_control",
        head_precision="float32",
        progress=None,
    )
    b = model.run_model(
        config,
        case,
        read,
        tp=2,
        storage_policy="fp32_control",
        head_precision="float32",
        progress=None,
    )
    np.testing.assert_allclose(a["logits"], b["logits"], rtol=2e-5, atol=2e-6)


def test_head_precision_and_tied_embeddings_are_explicit():
    model = api()
    config, read, calls = fixture()
    config["tie_word_embeddings"] = True
    result = model.run_model(
        config,
        dict(input_ids=[1, 2, 3], continuation_ids=[]),
        read,
        tp=1,
        storage_policy="bf16_contract",
        head_precision="bfloat16",
        progress=None,
    )
    assert not any(name == "lm_head.weight" for name, _ in calls)
    bits = result["logits"].view(np.uint32)
    assert np.all((bits & 65535) == 0)


def test_rejects_out_of_vocab_and_unsupported_model_rules():
    model = api()
    config, read, _ = fixture()
    with pytest.raises(ValueError):
        model.run_model(
            config,
            dict(input_ids=[17], continuation_ids=[]),
            read,
            tp=1,
            storage_policy="bf16_contract",
            head_precision="bfloat16",
            progress=None,
        )
    config["hidden_act"] = "gelu"
    with pytest.raises(ValueError):
        model.run_model(
            config,
            dict(input_ids=[1], continuation_ids=[]),
            read,
            tp=1,
            storage_policy="bf16_contract",
            head_precision="bfloat16",
            progress=None,
        )
