# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent CPU mathematics with explicit storage and fresh owned histories.

Inputs are reference-computed arrays and checkpoint values. No capture loader,
runtime module, actual state, hidden operand, or NPU package is imported here.
"""

import numpy as np
from prefill_oracle import causal_conv_prefill, delta_scan, gate_terms, gated_norm
from reference_math import (
    bf16_storage,
    decode_gqa,
    prefill_gqa,
    rmsnorm,
    sigmoid_gate,
    split_qkv,
)


def require(value: bool, message: str) -> None:
    if not value:
        raise ValueError(message)


def stored(value: np.ndarray, *, storage_policy: str) -> np.ndarray:
    require(
        storage_policy in ("bf16_contract", "fp32_control"),
        "Unknown explicit storage policy",
    )
    require(bool(np.isfinite(value).all()), "Nonfinite reference operand")
    array = np.asarray(value, dtype=np.float32)
    result = (
        bf16_storage(array.reshape(-1)).reshape(array.shape)
        if storage_policy == "bf16_contract"
        else array.copy()
    )
    require(bool(np.isfinite(result).all()), "Nonfinite stored reference result")
    return result


def effective_gamma(raw: np.ndarray) -> np.ndarray:
    return bf16_storage(raw) + np.float32(1)


def column_linear(
    x: np.ndarray, weights: list[np.ndarray], *, tp: int, storage_policy: str
) -> list[np.ndarray]:
    return [
        rank[0]
        for rank in column_sequence([x], weights, tp=tp, storage_policy=storage_policy)
    ]


def column_sequence(
    chunks: list[np.ndarray], weights: list[np.ndarray], *, tp: int, storage_policy: str
) -> list[list[np.ndarray]]:
    x = chunks[0]
    require(tp in (1, 2) and bool(weights), "Explicit TP and logical segments required")
    require(
        all(
            w.ndim == 2 and w.shape[1] == x.shape[1] and w.shape[0] % tp == 0
            for w in weights
        ),
        "Column partition shape mismatch",
    )
    result = []
    for rank in range(tp):
        local = np.concatenate(
            [
                w[rank * (w.shape[0] // tp) : (rank + 1) * (w.shape[0] // tp)]
                for w in weights
            ],
            axis=0,
        )
        result.append(
            [stored(x @ local.T, storage_policy=storage_policy) for x in chunks]
        )
    return result


def row_linear(
    values: list[np.ndarray], weight: np.ndarray, *, storage_policy: str
) -> np.ndarray:
    return row_sequence(
        [[value] for value in values], weight, storage_policy=storage_policy
    )[0]


def row_sequence(
    values: list[list[np.ndarray]], weight: np.ndarray, *, storage_policy: str
) -> list[np.ndarray]:
    tp = len(values)
    require(tp in (1, 2) and weight.shape[1] % tp == 0, "Row partition shape mismatch")
    width = weight.shape[1] // tp
    require(
        all(len(rank) == len(values[0]) for rank in values),
        "Rank sequence count mismatch",
    )
    local_weights = [
        np.ascontiguousarray(weight[:, rank * width : (rank + 1) * width])
        for rank in range(tp)
    ]
    result = []
    for step in range(len(values[0])):
        xs = [rank[step] for rank in values]
        require(
            all(x.ndim == 2 and x.shape == (xs[0].shape[0], width) for x in xs),
            "Local row input shape mismatch",
        )
        partials = [
            stored(x @ w.T, storage_policy=storage_policy)
            for x, w in zip(xs, local_weights)
        ]
        total = partials[0].copy()
        for partial in partials[1:]:
            total = total + partial
        result.append(stored(total, storage_policy=storage_policy))
    return result


def reduce_norm(
    x: np.ndarray,
    residual: np.ndarray | None,
    gamma: np.ndarray,
    *,
    epsilon: float,
    storage_policy: str
) -> tuple[np.ndarray, np.ndarray]:
    updated = (
        x.copy()
        if residual is None
        else stored(x + residual, storage_policy=storage_policy)
    )
    normalized = rmsnorm(
        updated,
        gamma,
        epsilon=epsilon,
        compute_dtype="float32",
        output_storage="float32",
    )["output"]
    return stored(normalized, storage_policy=storage_policy), updated


def silu_mul(gate: np.ndarray, up: np.ndarray, *, storage_policy: str) -> np.ndarray:
    exponential = np.exp(-np.abs(gate))
    sigmoid = np.where(
        gate >= 0, 1 / (1 + exponential), exponential / (1 + exponential)
    )
    return stored((gate * sigmoid) * up, storage_policy=storage_policy)


def rope_table(
    length: int, *, rotary_dim: int, base: float, storage_policy: str
) -> np.ndarray:
    require(
        type(length) is int
        and length > 0
        and rotary_dim > 0
        and rotary_dim % 2 == 0
        and base > 0,
        "Invalid RoPE configuration",
    )
    exponent = np.arange(0, rotary_dim, 2, dtype=np.float32) / np.float32(rotary_dim)
    inverse = np.float32(1) / np.power(np.float32(base), exponent)
    frequency = np.arange(length, dtype=np.float32)[:, None] * inverse[None]
    return stored(
        np.concatenate([np.cos(frequency), np.sin(frequency)], axis=-1),
        storage_policy=storage_policy,
    )


def rotary(
    value: np.ndarray,
    positions: np.ndarray,
    table: np.ndarray,
    *,
    rotary_dim: int,
    storage_policy: str
) -> np.ndarray:
    require(
        value.ndim == 3
        and rotary_dim > 0
        and rotary_dim % 2 == 0
        and rotary_dim <= value.shape[-1],
        "Invalid partial rotation",
    )
    cos, sin = np.split(table[positions], 2, axis=-1)
    first, second = np.split(value[..., :rotary_dim], 2, axis=-1)
    # MRotaryEmbedding calls eager Torch mul/mul/sub and mul/mul/add.
    # Each product is returned in input dtype before the add/sub operation.
    p1 = stored(first * cos[:, None], storage_policy=storage_policy)
    p2 = stored(second * sin[:, None], storage_policy=storage_policy)
    p3 = stored(second * cos[:, None], storage_policy=storage_policy)
    p4 = stored(first * sin[:, None], storage_policy=storage_policy)
    rotated = np.concatenate(
        [
            stored(p1 - p2, storage_policy=storage_policy),
            stored(p3 + p4, storage_policy=storage_policy),
        ],
        axis=-1,
    )
    return np.concatenate([rotated, value[..., rotary_dim:]], axis=-1)


def fa_sequence(
    chunks: list[np.ndarray],
    *,
    heads: int,
    kv_heads: int,
    head_dim: int,
    rotary_dim: int,
    rope_base: float,
    epsilon: float,
    q_gamma: np.ndarray,
    k_gamma: np.ndarray,
    storage_policy: str
) -> tuple[list[np.ndarray], dict[str, np.ndarray]]:
    require(
        bool(chunks) and all(x.shape[0] == 1 for x in chunks[1:]),
        "One Prefill followed by single-token Decode required",
    )
    table = rope_table(
        sum(x.shape[0] for x in chunks),
        rotary_dim=rotary_dim,
        base=rope_base,
        storage_policy=storage_policy,
    )
    keys, values, outputs = [], [], []
    offset = 0
    for step, packed in enumerate(chunks):
        parts = split_qkv(
            packed,
            heads=heads,
            kv_heads=kv_heads,
            head_dim=head_dim,
            compute_dtype="float32",
        )
        positions = np.arange(offset, offset + packed.shape[0], dtype=np.int64)
        rotated = {}
        for name, gamma in (("q", q_gamma), ("k", k_gamma)):
            normalized = stored(
                rmsnorm(
                    parts[name],
                    gamma,
                    epsilon=epsilon,
                    compute_dtype="float32",
                    output_storage="float32",
                )["output"],
                storage_policy=storage_policy,
            )
            rotated[name] = rotary(
                normalized,
                positions,
                table,
                rotary_dim=rotary_dim,
                storage_policy=storage_policy,
            )
        keys.append(rotated["k"].copy())
        values.append(parts["v"].copy())
        query, key, value = rotated["q"], np.concatenate(keys), np.concatenate(values)
        attention = (prefill_gqa if step == 0 else decode_gqa)(
            query,
            key,
            value,
            scale=head_dim**-0.5,
            compute_dtype="float32",
            output_storage="float32",
        )["output"]
        attention = stored(attention, storage_policy=storage_policy)
        gated = sigmoid_gate(
            attention, parts["gate"], compute_dtype="float32", output_storage="float32"
        )["output"]
        outputs.append(
            stored(gated, storage_policy=storage_policy).reshape(packed.shape[0], -1)
        )
        offset += packed.shape[0]
    return outputs, {"k": np.concatenate(keys), "v": np.concatenate(values)}


def gdn_sequence(
    chunks: list[np.ndarray],
    *,
    hk: int,
    hv: int,
    key_dim: int,
    value_dim: int,
    epsilon: float,
    A_log: np.ndarray,
    dt_bias: np.ndarray,
    conv_weight: np.ndarray,
    norm_weight: np.ndarray,
    storage_policy: str
) -> tuple[list[np.ndarray], dict[str, np.ndarray]]:
    require(
        bool(chunks) and all(x.shape[0] == 1 for x in chunks[1:]),
        "One Prefill followed by single-token Decode required",
    )
    channels = 2 * hk * key_dim + hv * value_dim
    history = np.zeros((channels, 3), np.float32)
    state = np.zeros((hv, value_dim, key_dim), np.float32)
    widths = [hk * key_dim, hk * key_dim, hv * value_dim, hv * value_dim, hv, hv]
    outputs = []
    for packed in chunks:
        require(packed.shape[1] == sum(widths), "GDN packed width mismatch")
        q, k, v, z, b, a = np.split(packed, np.cumsum(widths)[:-1], axis=1)
        mixed = np.concatenate([q, k, v], axis=1)
        conv = causal_conv_prefill(mixed, conv_weight, history, compute_dtype="float32")
        history = conv["history"].copy()
        convolved = stored(conv["output"], storage_policy=storage_policy)
        q, k, v = np.split(convolved, [hk * key_dim, 2 * hk * key_dim], axis=1)
        gates = gate_terms(
            a, b, A_log, dt_bias, compute_dtype="float32", softplus_policy="naive"
        )
        scan = delta_scan(
            q.reshape(-1, hk, key_dim),
            k.reshape(-1, hk, key_dim),
            v.reshape(-1, hv, value_dim),
            gates["g"],
            gates["beta"],
            state,
            qk_epsilon=1e-6,
            scale=key_dim**-0.5,
            compute_dtype="float32",
        )
        state = scan["state"].copy()
        core = stored(scan["core"], storage_policy=storage_policy)
        norm = gated_norm(
            core,
            z.reshape(-1, hv, value_dim),
            norm_weight,
            norm_epsilon=epsilon,
            compute_dtype="float32",
        )
        outputs.append(
            stored(norm["output"], storage_policy=storage_policy).reshape(
                packed.shape[0], -1
            )
        )
    return outputs, {"conv": history, "ssm": state}
