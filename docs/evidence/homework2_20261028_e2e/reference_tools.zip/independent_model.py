# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Full CPU reference from token IDs/checkpoint values; no observed intermediates."""

from collections.abc import Callable

import numpy as np
from independent_ops import (
    column_sequence,
    effective_gamma,
    fa_sequence,
    gdn_sequence,
    reduce_norm,
    require,
    row_sequence,
    silu_mul,
    stored,
)


def run_model(
    config: dict,
    case: dict,
    read: Callable,
    *,
    tp: int,
    storage_policy: str,
    head_precision: str,
    progress: Callable | None,
) -> dict:
    require(
        tp in (1, 2) and head_precision in ("float32", "bfloat16"),
        "Explicit TP/head policy required",
    )
    require(
        config["hidden_act"] == "silu"
        and not config["attention_bias"]
        and config["attn_output_gate"],
        "Unsupported decoder math",
    )
    require(
        config["linear_conv_kernel_dim"] == 4
        and config["rope_parameters"]["rope_type"] == "default",
        "Unsupported state/RoPE rule",
    )
    require(
        len(config["layer_types"]) == config["num_hidden_layers"],
        "Layer coverage mismatch",
    )
    ids = case["input_ids"] + case["continuation_ids"]
    require(
        bool(case["input_ids"])
        and all(type(i) is int and 0 <= i < config["vocab_size"] for i in ids),
        "Invalid original token IDs",
    )
    count = len(case["input_ids"])
    offsets = [[0, count]] + [[i, i + 1] for i in range(count, len(ids))]
    prefix = "model.language_model."
    embedding = read(
        prefix + "embed_tokens.weight", rows=np.array(ids, np.int64), mode="bfloat16"
    )
    require(
        embedding.shape == (len(ids), config["hidden_size"]),
        "Embedding geometry mismatch",
    )
    hidden = [embedding[start:stop].copy() for start, stop in offsets]
    residual = [None] * len(hidden)
    boundaries, names, states = [], [], {}
    epsilon = config["rms_norm_eps"]

    def parameter(name):
        return read(name, rows=None, mode="bfloat16")

    for layer, family in enumerate(config["layer_types"]):
        base = f"{prefix}layers.{layer}."
        gamma = effective_gamma(parameter(base + "input_layernorm.weight"))
        pairs = [
            reduce_norm(x, r, gamma, epsilon=epsilon, storage_policy=storage_policy)
            for x, r in zip(hidden, residual)
        ]
        normalized, residual = [p[0] for p in pairs], [p[1] for p in pairs]
        boundaries.append(np.concatenate(normalized))
        names.append(f"layers.{layer}.input_layernorm")
        local_outputs = []
        if family == "linear_attention":
            p = base + "linear_attn."
            hk, hv, kd, vd = (
                config[k]
                for k in (
                    "linear_num_key_heads",
                    "linear_num_value_heads",
                    "linear_key_head_dim",
                    "linear_value_head_dim",
                )
            )
            key_width, value_width = hk * kd, hv * vd
            qkv = parameter(p + "in_proj_qkv.weight")
            pieces = list(np.split(qkv, [key_width, 2 * key_width], axis=0))
            pieces += [
                parameter(p + "in_proj_z.weight"),
                parameter(p + "in_proj_b.weight"),
                parameter(p + "in_proj_a.weight"),
            ]
            projections = column_sequence(
                normalized, pieces, tp=tp, storage_policy=storage_policy
            )
            conv = parameter(p + "conv1d.weight").squeeze(1)
            conv_segments = np.split(conv, [key_width, 2 * key_width], axis=0)
            A_log = read(p + "A_log", rows=None, mode="float32")
            dt_bias = read(p + "dt_bias", rows=None, mode="float32")
            norm = parameter(p + "norm.weight")
            for rank in range(tp):
                cv = np.concatenate(
                    [
                        v[rank * (len(v) // tp) : (rank + 1) * (len(v) // tp)]
                        for v in conv_segments
                    ]
                )
                sl = slice(rank * (hv // tp), (rank + 1) * (hv // tp))
                out, state = gdn_sequence(
                    projections[rank],
                    hk=hk // tp,
                    hv=hv // tp,
                    key_dim=kd,
                    value_dim=vd,
                    epsilon=epsilon,
                    A_log=A_log[sl],
                    dt_bias=dt_bias[sl],
                    conv_weight=cv,
                    norm_weight=norm,
                    storage_policy=storage_policy,
                )
                local_outputs.append(out)
                states[f"layer{layer}_rank{rank}"] = state
            hidden = row_sequence(
                local_outputs,
                parameter(p + "out_proj.weight"),
                storage_policy=storage_policy,
            )
        elif family == "full_attention":
            p = base + "self_attn."
            projections = column_sequence(
                normalized,
                [parameter(p + n + "_proj.weight") for n in ("q", "k", "v")],
                tp=tp,
                storage_policy=storage_policy,
            )
            rope = config["rope_parameters"]
            q_gamma, k_gamma = [
                effective_gamma(parameter(p + n + "_norm.weight")) for n in ("q", "k")
            ]
            for rank in range(tp):
                out, state = fa_sequence(
                    projections[rank],
                    heads=config["num_attention_heads"] // tp,
                    kv_heads=config["num_key_value_heads"] // tp,
                    head_dim=config["head_dim"],
                    rotary_dim=int(config["head_dim"] * rope["partial_rotary_factor"]),
                    rope_base=rope["rope_theta"],
                    epsilon=epsilon,
                    q_gamma=q_gamma,
                    k_gamma=k_gamma,
                    storage_policy=storage_policy,
                )
                local_outputs.append(out)
                states[f"layer{layer}_rank{rank}"] = state
            hidden = row_sequence(
                local_outputs,
                parameter(p + "o_proj.weight"),
                storage_policy=storage_policy,
            )
        else:
            raise ValueError("Unsupported attention family")
        gamma = effective_gamma(parameter(base + "post_attention_layernorm.weight"))
        pairs = [
            reduce_norm(x, r, gamma, epsilon=epsilon, storage_policy=storage_policy)
            for x, r in zip(hidden, residual)
        ]
        normalized, residual = [p[0] for p in pairs], [p[1] for p in pairs]
        boundaries.append(np.concatenate(normalized))
        names.append(f"layers.{layer}.post_attention_layernorm")
        gate_up = column_sequence(
            normalized,
            [
                parameter(base + "mlp.gate_proj.weight"),
                parameter(base + "mlp.up_proj.weight"),
            ],
            tp=tp,
            storage_policy=storage_policy,
        )
        local = [
            [
                silu_mul(*np.split(value, 2, axis=1), storage_policy=storage_policy)
                for value in rank
            ]
            for rank in gate_up
        ]
        hidden = row_sequence(
            local,
            parameter(base + "mlp.down_proj.weight"),
            storage_policy=storage_policy,
        )
        if progress is not None:
            progress(layer)
    gamma = effective_gamma(parameter(prefix + "norm.weight"))
    normalized = [
        reduce_norm(x, r, gamma, epsilon=epsilon, storage_policy=storage_policy)[0]
        for x, r in zip(hidden, residual)
    ]
    boundaries.append(np.concatenate(normalized))
    names.append("final_norm")
    head_input = np.stack([x[-1] for x in normalized])
    head_key = (
        prefix + "embed_tokens.weight"
        if config["tie_word_embeddings"]
        else "lm_head.weight"
    )
    vocab = config["vocab_size"]
    require(vocab % tp == 0, "Vocabulary partition mismatch")
    output_policy = (
        "bf16_contract"
        if head_precision == "bfloat16" and storage_policy == "bf16_contract"
        else "fp32_control"
    )
    logits = np.empty((len(offsets), vocab), np.float32)
    # Chunk1280 divides the real half vocabulary124160; both TP paths use
    # the same CPU head GEMM shapes while holding disjoint output rows.
    for rank in range(tp):
        lo, hi = rank * (vocab // tp), (rank + 1) * (vocab // tp)
        for start in range(lo, hi, 1280):
            stop = min(start + 1280, hi)
            weight = read(head_key, rows=(start, stop), mode="bfloat16")
            logits[:, start:stop] = stored(
                head_input @ weight.T, storage_policy=output_policy
            )
    return {
        "logits": logits,
        "norms": np.stack(boundaries),
        "norm_names": names,
        "states": states,
        "step_offsets": offsets,
        "head_input": head_input,
        "scope": "Independent checkpoint/IDs only; own hidden and causal state histories; CPU partition simulation, not actual HCCL",
    }
