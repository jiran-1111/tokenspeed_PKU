# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Run all independent CPU references serially, before any capture comparison."""

import hashlib
import json
import os
import subprocess
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    here = Path(__file__).resolve().parent
    source = here.parent / "source_final"
    manifest = json.loads((here / "tool_manifest.json").read_text())
    assert all(sha(here / name) == digest for name, digest in manifest.items())
    preparation = json.loads((here / "preparation.json").read_text())
    assert preparation["passed"] and preparation["zero_skips"]
    task = here.parent
    queue = json.loads((task / "queue_state.json").read_text())
    assert (task / "stop-queue").exists() and not queue.get("current")
    state_path = here / "state.json"
    assert not state_path.exists()
    state = {
        "status": "running",
        "cpu_only": True,
        "serial": True,
        "actual_capture_inputs_read": False,
        "tool_manifest_sha256": sha(here / "tool_manifest.json"),
        "finished": {},
        "current": None,
        "runtime_modified": False,
        "old_queue_retained_paused": True,
    }

    def save():
        temporary = here / "state.tmp"
        temporary.write_text(json.dumps(state, indent=2) + "\n")
        temporary.replace(state_path)

    save()
    env = dict(os.environ)
    env.update(
        TORCH_DEVICE_BACKEND_AUTOLOAD="0",
        ASCEND_RT_VISIBLE_DEVICES="",
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS="8",
        OPENBLAS_NUM_THREADS="8",
        MKL_NUM_THREADS="8",
        NUMEXPR_NUM_THREADS="8",
        PYTHONPATH=str(here),
    )
    try:
        for model in ("9b", "4b"):
            for policy in ("bf16_contract", "fp32_control"):
                for tp in (1, 2):
                    name = f"{model}_{policy}_tp{tp}"
                    output = here / "output" / name
                    output.parent.mkdir(exist_ok=True)
                    assert not output.exists()
                    state["current"] = name
                    save()
                    with (here / f"{name}.log").open("x") as log:
                        result = subprocess.run(
                            [
                                str(source / ".conda-env/bin/python"),
                                "-B",
                                str(here / "run_reference.py"),
                                "--source",
                                str(source),
                                "--model",
                                model,
                                "--tp",
                                str(tp),
                                "--storage-policy",
                                policy,
                                "--output",
                                str(output),
                            ],
                            cwd=here,
                            env=env,
                            stdout=log,
                            stderr=subprocess.STDOUT,
                            timeout=7200,
                        )
                    assert (
                        result.returncode == 0
                    ), f"Independent CPU reference failed: {name}"
                    record = json.loads((output / "reference_state.json").read_text())
                    assert (
                        record["status"] == "collected"
                        and not record["actual_runtime_intermediates_read"]
                    )
                    state["finished"][name] = {
                        "state_sha256": sha(output / "reference_state.json"),
                        "arrays_sha256": record["arrays_sha256"],
                        "vectors": record["vectors"],
                        "argmax": record["raw_argmax_ids"],
                        "seconds": record["elapsed_cpu_reference_seconds"],
                    }
                    save()
        assert len(state["finished"]) == 8
        state.update(status="collected", current=None)
        save()
        (here / "reference_complete.json").write_text(
            json.dumps(state, indent=2) + "\n"
        )
    except BaseException as error:
        state.update(status="failed", error_type=type(error).__name__, error=str(error))
        save()
        raise


if __name__ == "__main__":
    main()
