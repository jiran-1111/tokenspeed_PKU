# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Recompute exported comparisons independently, without Torch or NPU access."""

import hashlib
import json
import os
from pathlib import Path

os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np

here=Path(__file__).resolve().parent
workspace=here.parents[1]
base=workspace/'.tmp/hw2-20261023'
comparison=base/'supplement_export_independent_e2e_comparison_r1_20261028'
reference=base/'supplement_export_independent_e2e_reference_r1_20261028'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(8*1024*1024),b''):digest.update(data)
    return digest.hexdigest()


for folder in (comparison,reference):
    files=read(folder/'export_manifest.json')
    assert all(sha(folder/name)==digest for name,digest in files.items())
summary=read(comparison/'output/summary.json')
audit=read(comparison/'execution_audit.json')
assert audit['passed'] and audit['summary_sha256']==sha(comparison/'output/summary.json')
assert audit['comparison_tool_manifest_sha256']==sha(comparison/'tool_manifest.json')
assert all(sha(comparison/name)==digest for name,digest in read(comparison/'tool_manifest.json').items())
assert sha(reference/'tool_manifest.json')==summary['reference_manifest_sha256']
assert all(sha(reference/name)==digest for name,digest in read(reference/'tool_manifest.json').items())
assert sha(reference/'reference_complete.json')==summary['reference_complete_sha256']
complete=read(reference/'reference_complete.json')
assert complete['status']=='collected' and len(complete['finished'])==8
groups=0
max_error=0.0
state_arrays=0
tie_diagnostics={}


def metric(one,two,stored):
    global groups,max_error
    a,b=np.asarray(one,dtype=np.float64),np.asarray(two,dtype=np.float64)
    delta=a-b
    denominator=float(np.sqrt(np.sum(b*b,dtype=np.float64)))
    numerator=float(np.sqrt(np.sum(delta*delta,dtype=np.float64)))
    assert list(a.shape)==stored['shape'] and a.size==stored['elements']
    assert int(np.count_nonzero(a!=b))==stored['different_elements']
    assert float(np.max(np.abs(delta)))==stored['max_abs']
    assert (denominator==0)==stored['zero_reference']
    if denominator:
        value=numerator/denominator
        error=abs(value-stored['relative_l2'])
        assert error<=2e-13*max(1.0,abs(value))
        max_error=max(max_error,error)
    else:assert stored['relative_l2'] is None
    groups+=1


for model in ('4b','9b'):
    data=read(comparison/f'output/{model}_comparison.json')
    assert sha(comparison/f'output/{model}_comparison.json')==summary['models'][model]['analysis_sha256']
    assert sha(comparison/f'output/{model}_comparison_arrays.npz')==data['arrays_sha256']
    with np.load(comparison/f'output/{model}_comparison_arrays.npz',allow_pickle=False) as exported:
        for label,item in data['vectors'].items():
            a,b=label.split('_vs_')
            one,two=exported[a+'_logits'],exported[b+'_logits']
            for index,stored in enumerate(item['per_step']):
                metric(one[index],two[index],stored)
                assert int(one[index].argmax())==stored['actual_argmax']
                assert int(two[index].argmax())==stored['reference_argmax']
                assert (stored['actual_argmax']==stored['reference_argmax'])==stored['argmax_equal']
            assert sum(row['argmax_equal'] for row in item['per_step'])==item['argmax_matches']
            assert max(row['relative_l2'] for row in item['per_step'])==item['max_relative_l2']
            assert max(row['max_abs'] for row in item['per_step'])==item['max_abs']
        for label,group in data['norms'].items():
            a,b=label.split('_vs_')
            one,two=exported[a+'_norm_last_rows'],exported[b+'_norm_last_rows']
            for boundary,(name,item) in enumerate(group.items()):
                for step,stored in enumerate(item['per_step_last_row']):metric(one[boundary,step],two[boundary,step],stored)
        tie_diagnostics[model]={}
        for tp in (1,2):
            actual=exported[f'engine_tp{tp}_logits']
            oracle=exported[f'bf16_contract_tp{tp}_logits']
            rows=[]
            for step,(left,right) in enumerate(zip(actual,oracle)):
                index=int(left.argmax())
                rows.append({'step':step,'actual_argmax':index,'reference_canonical_argmax':int(right.argmax()),
                    'reference_exact_maximum_count':int(np.count_nonzero(right==right.max())),
                    'actual_choice_in_reference_exact_maximum_set':bool(right[index]==right.max())})
            tie_diagnostics[model][f'tp{tp}']=rows
    reference_arrays={}
    for policy in ('bf16_contract','fp32_control'):
        for tp in (1,2):
            name=f'{model}_{policy}_tp{tp}'
            folder=reference/'output'/name
            state=read(folder/'reference_state.json')
            assert sha(folder/'reference_state.json')==complete['finished'][name]['state_sha256']
            assert sha(folder/'reference_arrays.npz')==state['arrays_sha256']==complete['finished'][name]['arrays_sha256']
            assert sha(folder/'parameter_reads.json')==state['parameter_reads_sha256']
            with np.load(folder/'reference_arrays.npz',allow_pickle=False) as raw:
                reference_arrays[f'{policy}_tp{tp}']=raw['norms']
                for layer,values in state['states'].items():
                    for field,metadata in values.items():
                        array=raw[f'state_{layer}_{field}']
                        assert list(array.shape)==metadata['shape'] and str(array.dtype)==metadata['dtype']
                        assert hashlib.sha256(array.tobytes()).hexdigest()==metadata['sha256']
                        state_arrays+=1
    for label,group in data['norms'].items():
        a,b=label.split('_vs_')
        if a not in reference_arrays or b not in reference_arrays:continue
        for boundary,(name,item) in enumerate(group.items()):
            for step,(start,stop) in enumerate(state['step_offsets']):
                metric(reference_arrays[a][boundary,start:stop],reference_arrays[b][boundary,start:stop],item['per_step_all_rows'][step])
result={'passed':True,'metric_groups_recomputed':groups,'reference_state_array_payloads_rehashed':state_arrays,'maximum_float_metric_difference':max_error,
        'comparison_archive_files_rehashed':len(read(comparison/'export_manifest.json')),'reference_archive_files_rehashed':len(read(reference/'export_manifest.json')),
        'scope':'Exported actual logits/norm last rows; all independent-reference full-row norm comparisons and all independent state payload hashes; no local raw NPU PT extraction',
        'recomputation_tolerance_is_not_model_acceptance_threshold':True,'original_canonical_argmax_failures_replaced':False,'verifier_sha256':sha(Path(__file__))}
(here/'local_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
(here/'tie_diagnostics.json').write_text(json.dumps({'scope':'Exact reference max-value ties, no epsilon and no new acceptance gate','models':tie_diagnostics},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))
