import hashlib
import json
import zipfile
from pathlib import Path

here=Path(__file__).resolve().parent
workspace=here.parents[1]
repo=workspace/'delivery/homework2-20261023'
evidence=repo/'docs/evidence/homework2_20261028_e2e'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ledger=json.loads((evidence/'archives.json').read_text())


def pack(name,entries,source):
    with zipfile.ZipFile(evidence/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for member,path in sorted(entries.items()):
            info=zipfile.ZipInfo(member,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,path.read_bytes(),compresslevel=9)
    ledger[name]={'sha256':sha(evidence/name),'bytes':(evidence/name).stat().st_size,'source':source,
                  'members':{member:sha(path) for member,path in entries.items()}}


csv=evidence/'boundary_curves.csv'
assert csv.stat().st_size==572072 and sha(csv)==json.loads((evidence/'figure_identity.json').read_text())['csv_sha256']
pack('boundary_curves.zip',{'boundary_curves.csv':csv},'local boundary CSV generation')
target=here/'boundary_curves.csv'
assert not target.exists() and csv.resolve().is_relative_to(repo.resolve()) and target.resolve().is_relative_to(workspace.resolve())
csv.rename(target)
pack('publication_tools.zip',{name:here/name for name in ('build_publication.py','finalize_publication.py')},'local figure and package generation')
(evidence/'archives.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8',newline='\n')
p=evidence/'README.md';s=p.read_text(encoding='utf-8').replace('[boundary_curves.csv](boundary_curves.csv)','[boundary_curves.zip](boundary_curves.zip)').replace('三组跨分片比较全部5460个末行指标；','无损压缩CSV，含三组跨分片比较全部5460个末行指标；');p.write_text(s,encoding='utf-8',newline='\n')
assert all(p.stat().st_size<512000 for p in evidence.iterdir() if p.is_file())
print(json.dumps({'public_archives':len(ledger),'public_files':len(list(evidence.iterdir())),'all_files_under_500kib':True}))
