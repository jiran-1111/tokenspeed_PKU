import csv
import hashlib
import json
import os
import sys
import zipfile
from pathlib import Path

here=Path(__file__).resolve().parent
workspace=here.parents[1]
repo=workspace/'delivery/homework2-20261023'
base=workspace/'.tmp/hw2-20261023'
reference=base/'supplement_export_independent_e2e_reference_r1_20261028'
comparison=base/'supplement_export_independent_e2e_comparison_r1_20261028'
evidence=repo/'docs/evidence/homework2_20261028_e2e'
evidence.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ledger={}


def pack(name,entries,source):
    with zipfile.ZipFile(evidence/name,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for member,path in sorted(entries.items()):
            info=zipfile.ZipInfo(member,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,path.read_bytes(),compresslevel=9)
    assert (evidence/name).stat().st_size<512000
    with zipfile.ZipFile(evidence/name) as archive:
        assert all(archive.read(member)==path.read_bytes() for member,path in entries.items())
    ledger[name]={'sha256':sha(evidence/name),'bytes':(evidence/name).stat().st_size,'source':source,'members':{member:sha(path) for member,path in entries.items()}}


for name,folder,actual in [('reference_tools.zip',reference,'independent_e2e_reference_r1_20261028'),('comparison_tools.zip',comparison,'independent_e2e_comparison_r1_20261028')]:
    manifest=read(folder/'tool_manifest.json')
    assert all(sha(folder/n)==v for n,v in manifest.items())
    entries={n:folder/n for n in manifest};entries['tool_manifest.json']=folder/'tool_manifest.json'
    pack(name,entries,actual)
for model in ('4b','9b'):
    source=comparison/f'output/{model}_comparison.json'
    pack(f'{model}_comparison.zip',{source.name:source},'independent_e2e_comparison_r1_20261028/output')
pack('local_verifier.zip',{'verify_local.py':here/'verify_local.py'},'local NumPy verification')
pack('launch_and_audit_tools.zip',{name:here/name for name in ('start_r1.py','start_comparison_r1.py','archive_reference.py','server_audit_archive_comparison.py')},'local launch and final audit snapshots')
pack('publication_tools.zip',{'build_publication.py':here/'build_publication.py'},'local figure and package generation')
for source,name in [(comparison/'output/summary.json','summary.json'),(comparison/'execution_audit.json','execution_audit.json'),
                    (here/'local_verification.json','local_verification.json'),(here/'tie_diagnostics.json','tie_diagnostics.json')]:
    (evidence/name).write_bytes(source.read_bytes())
summary=read(comparison/'output/summary.json')
reference_receipt=read(base/'independent_e2e_reference_download_verified_20261028.json')
comparison_receipt=read(base/'independent_e2e_comparison_download_verified_20261028.json')
assert reference_receipt['all_file_hashes_match'] and comparison_receipt['all_file_hashes_match']
provenance={'date':'2026-10-28','core_files':1531,'core_manifest_sha256':summary['source_core_sha256'],
            'reference_manifest_sha256':sha(reference/'tool_manifest.json'),'comparison_manifest_sha256':sha(comparison/'tool_manifest.json'),
            'cases_byte_equal_to_original_r3':{model:sha(reference/f'case_{model}.json')==sha(here.parent/f'hw2-fullpath-20261028/tools_r3/case_{model}.json') for model in ('4b','9b')},
            'references':8,'unique_original_inputs':2,'logit_vectors':112,'reference_completed_before_captures_read':True,
            'server_tests':{'reference':{'passed':31,'skipped':0},'comparison_guard':{'passed':7,'skipped':0}},
            'local_tests':{'numpy_reference':21,'comparison_guard':7,'torch_modules_skipped_locally':2},
            'downloaded_archives':{'reference':reference_receipt,'comparison':comparison_receipt},'runtime_changed':False,
            'npu_experiments_started':0,'original_greedy_failures_repaired':False,'new_model_acceptance_threshold':False,
            'local_verifier_sha256':read(here/'local_verification.json')['verifier_sha256'],
            'launch_source_sha256':sha(here/'start_comparison_r1.py')}
assert provenance['launch_source_sha256']==read(comparison/'execution_audit.json')['launch_binding']['launch_source_sha256']
(evidence/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8',newline='\n')
(evidence/'archives.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8',newline='\n')

curves={};rows=[]
for model in ('4b','9b'):
    data=read(comparison/f'output/{model}_comparison.json')
    curves[model]={}
    for label in ('engine_tp2_vs_engine_tp1','bf16_contract_tp2_vs_bf16_contract_tp1','fp32_control_tp2_vs_fp32_control_tp1'):
        curves[model][label]=[]
        for boundary,(name,item) in enumerate(data['norms'][label].items()):
            curves[model][label].append(item['per_step_last_row'][0]['relative_l2'])
            for step,metric in enumerate(item['per_step_last_row']):
                rows.append({'model':model,'pair':label,'boundary_index':boundary,'boundary':name,'step':step,'relative_l2':metric['relative_l2'],'max_abs':metric['max_abs']})
with (evidence/'boundary_curves.csv').open('w',encoding='utf-8',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
assert len(rows)==5460
sys.path.insert(0,str(workspace/'.deps/hw2-publication'))
os.environ['MPLCONFIGDIR']=str(here/'matplotlib-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties
font=FontProperties(fname='C:/Windows/Fonts/msyh.ttc')
plt.rcParams.update({'font.family':font.get_name(),'font.size':9,'axes.unicode_minus':False})
figure,axes=plt.subplots(1,2,figsize=(9,3.35),layout='constrained')
for axis,model in zip(axes,('4b','9b')):
    for label,title,color in [('engine_tp2_vs_engine_tp1','原部署 BF16','#62686f'),('bf16_contract_tp2_vs_bf16_contract_tp1','独立CPU BF16存储','#b65b35'),('fp32_control_tp2_vs_fp32_control_tp1','独立CPU FP32控制','#1c7581')]:
        values=np.array(curves[model][label]);axis.plot(np.arange(65),np.where(values==0,np.nan,values),label=title,color=color,linewidth=1.5)
    axis.set_yscale('log');axis.set_ylim(1e-8,2)
    axis.set_xticks([0,16,32,48,64],['输入','层8前','层16前','层24前','末归一化'])
    axis.set_ylabel('TP2 相对 TP1 的 relative-L2')
    axis.set_title(f'Qwen3.5-{model.upper()}：Prefill末行')
    axis.grid(axis='y',alpha=.18);axis.legend(fontsize=7.5,loc='center left')
    axis.text(.02,.97,'零差异不在对数轴上绘制',transform=axis.transAxes,va='top',fontsize=8)
path=repo/'docs/report/hw2_figures/homework2_independent_reference_20261028.png'
figure.savefig(path,dpi=180,facecolor='white');plt.close(figure)
(workspace/'hw2_figures'/path.name).write_bytes(path.read_bytes())
(evidence/'figure_identity.json').write_text(json.dumps({'figure_sha256':sha(path),'csv_sha256':sha(evidence/'boundary_curves.csv'),'csv_metrics':len(rows),'scope':'Prefill last rows, cross-partition differences, not CPU-vs-engine error or additive causal fractions','zeros_not_replaced_with_epsilon':True},indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'evidence_files':len(list(evidence.iterdir())),'archives':len(ledger),'figure_bytes':path.stat().st_size}))
