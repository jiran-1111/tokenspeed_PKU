"""Normalize input-diversity metadata without changing any numerical result."""

import hashlib
import json
import zipfile
from pathlib import Path

here=Path(__file__).resolve().parent
workspace=here.parents[1]
repo=workspace/'delivery/homework2-20261023'
evidence=repo/'docs/evidence/homework2_20261028_e2e'
cases=[json.loads((here/'tools_r1'/f'case_{model}.json').read_text()) for model in ('4b','9b')]
canonical=lambda ids:json.dumps(ids,separators=(',',':')).encode()
prefills={canonical(case['input_ids']) for case in cases}
assert len(prefills)==1
p=evidence/'provenance.json';provenance=json.loads(p.read_text())
provenance.pop('unique_original_inputs')
provenance.update(model_trajectory_cases=2,unique_prefill_inputs=1,
                  prefill_token_ids_canonical_sha256=hashlib.sha256(next(iter(prefills))).hexdigest(),
                  coverage_note='Two model/continuation trajectories share exactly one unique 128-token Prefill input; no sample added or removed')
p.write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8',newline='\n')
changes={
 evidence/'README.md':('它们只覆盖两个原始输入','它们对应两模型各一条固定轨迹，共用同一个独特128-token Prefill输入'),
 repo/'docs/project/homework2_independent_reference_20261028.md':('只覆盖两个不同输入','对应两模型各一条固定轨迹，共用同一个独特128-token Prefill输入'),
 repo/'docs/report/homework2_communication_subsystem.md':('只覆盖两个原始输入','对应两模型各一条固定轨迹，共用一个独特128-token提示')}
for path,(old,new) in changes.items():
    text=path.read_text(encoding='utf-8');assert old in text
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')
(workspace/'作业2实验报告.md').write_bytes((repo/'docs/report/homework2_communication_subsystem.md').read_bytes())
ledger=json.loads((evidence/'archives.json').read_text())
name='publication_tools.zip'
entries={name:here/name for name in ('build_publication.py','finalize_publication.py','fix_input_counts.py')}
with zipfile.ZipFile(evidence/name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for member,path in sorted(entries.items()):
        info=zipfile.ZipInfo(member,date_time=(2026,10,28,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,path.read_bytes(),compresslevel=9)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ledger[name]={'sha256':sha(evidence/name),'bytes':(evidence/name).stat().st_size,'source':'local figure and package generation',
              'members':{member:sha(path) for member,path in entries.items()}}
(evidence/'archives.json').write_text(json.dumps(ledger,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'model_trajectory_cases':2,'unique_prefill_inputs':1,'numeric_arrays_unchanged':True}))
