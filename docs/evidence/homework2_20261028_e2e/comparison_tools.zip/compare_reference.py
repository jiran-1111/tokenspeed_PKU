# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Compare completed independent paths with fixed original actual captures."""

import hashlib
import json
import os
import sys
from pathlib import Path

assert os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] == "0"
assert os.environ["ASCEND_RT_VISIBLE_DEVICES"] == ""
sys.modules["torch_npu"] = None

import numpy as np
import torch
from analysis_binding import (
    CORE,
    compare,
    load_model,
    read,
    require,
    sha,
    verify_unchanged,
)
from comparison_contract import validate_complete


def vectors(one: np.ndarray, two: np.ndarray) -> dict:
    require(
        one.shape == two.shape and one.ndim == 2 and one.shape[1] == 248320,
        "Complete logits geometry mismatch",
    )
    rows = []
    for index, (a, b) in enumerate(zip(one, two)):
        metric = compare(a, b)
        a_id, b_id = int(a.argmax()), int(b.argmax())
        metric.update(
            step=index,
            actual_argmax=a_id,
            reference_argmax=b_id,
            argmax_equal=a_id == b_id,
        )
        rows.append(metric)
    return {
        "per_step": rows,
        "max_relative_l2": max(r["relative_l2"] for r in rows),
        "max_abs": max(r["max_abs"] for r in rows),
        "argmax_matches": sum(r["argmax_equal"] for r in rows),
        "vectors": len(rows),
    }


def boundary_metrics(
    one: np.ndarray, two: np.ndarray, *, names: list, offsets: list
) -> dict:
    require(
        one.shape == two.shape and one.ndim == 3 and one.shape[0] == 65,
        "Complete norm boundary geometry mismatch",
    )
    result = {}
    for index, name in enumerate(names):
        result[name] = {
            "per_step_all_rows": [
                compare(one[index, start:stop], two[index, start:stop])
                for start, stop in offsets
            ],
            "per_step_last_row": [
                compare(one[index, stop - 1], two[index, stop - 1])
                for start, stop in offsets
            ],
        }
    return result


def main() -> None:
    torch.set_num_threads(8)
    torch.set_num_interop_threads(1)
    here = Path(__file__).resolve().parent
    task = here.parent
    reference = task / "independent_e2e_reference_r1_20261028"
    frozen = "cf09ecac218c32702b757b6010f70b3f80125cc18ffec19290827c9bf1e534af"
    complete_path = reference / "reference_complete.json"
    complete = read(complete_path)
    validate_complete(complete, expected_manifest=frozen)
    require(
        read(reference / "state.json") == complete,
        "Reference completion/state disagreement",
    )
    require(
        sha(reference / "tool_manifest.json") == frozen,
        "Reference tool identity mismatch",
    )
    reference_manifest = read(reference / "tool_manifest.json")
    require(
        all(
            sha(reference / name) == digest
            for name, digest in reference_manifest.items()
        ),
        "Reference files changed",
    )
    protocol = read(reference / "reference_protocol.json")
    states = {}
    bindings = {
        complete_path: sha(complete_path),
        reference / "state.json": sha(reference / "state.json"),
    }
    # Validate every path and its payload digest BEFORE opening any capture.
    for name, item in complete["finished"].items():
        directory = reference / "output" / name
        state_path = directory / "reference_state.json"
        require(
            sha(state_path) == item["state_sha256"], "Completed reference state changed"
        )
        state = read(state_path)
        model, policy, tp_text = (
            name.split("_", 1)[0],
            state["storage_policy"],
            f"tp{state['tp']}",
        )
        require(
            name == f"{model}_{policy}_{tp_text}"
            and state["model"] == model
            and state["status"] == "collected",
            "Reference path metadata mismatch",
        )
        identity = protocol["models"][model]
        require(
            state["core_manifest_sha256"] == CORE
            and state["tool_manifest_sha256"] == frozen
            and state["protocol_sha256"] == sha(reference / "reference_protocol.json"),
            "Reference source/protocol mismatch",
        )
        require(
            state["case_sha256"] == identity["case_sha256"]
            and state["model_revision"] == identity["revision"]
            and state["original_ids"] == read(reference / f"case_{model}.json"),
            "Reference input/weight identity mismatch",
        )
        require(
            not state["actual_runtime_intermediates_read"]
            and not state["runtime_modified"]
            and not state["model_threshold_added"]
            and state["only_cpu_imports"]
            and state["checkpoint_unchanged"]
            and state["core_unchanged"],
            "Independent reference scope failed",
        )
        require(
            item["arrays_sha256"]
            == state["arrays_sha256"]
            == sha(directory / "reference_arrays.npz"),
            "Reference numerical payload changed",
        )
        require(
            state["parameter_reads_sha256"] == sha(directory / "parameter_reads.json"),
            "Reference parameter read ledger changed",
        )
        states[name] = state
        for file in (
            "reference_state.json",
            "reference_arrays.npz",
            "parameter_reads.json",
        ):
            bindings[directory / file] = sha(directory / file)
    output = here / "output"
    output.mkdir(exist_ok=False)
    summary = {
        "source_core_sha256": CORE,
        "reference_manifest_sha256": frozen,
        "reference_complete_sha256": sha(complete_path),
        "actual_captures_read_only_after_eight_references_complete": True,
        "runtime_modified": False,
        "model_acceptance_threshold_added": False,
        "original_greedy_failures_repaired": False,
        "models": {},
    }
    for model in ("9b", "4b"):
        print(
            f"Binding completed {model} references to original R3 captures", flush=True
        )
        data = load_model(task, model=model, torch=torch)
        identity = protocol["models"][model]
        case = data["case"]
        require(
            case == read(reference / f"case_{model}.json"),
            "Original capture/reference case mismatch",
        )
        arrays, records = {}, {}
        for policy in ("bf16_contract", "fp32_control"):
            for tp in (1, 2):
                label = f"{policy}_tp{tp}"
                path = (
                    reference / "output" / f"{model}_{label}" / "reference_arrays.npz"
                )
                with np.load(path, allow_pickle=False) as archive:
                    arrays[label] = {name: archive[name] for name in archive.files}
                record = states[f"{model}_{label}"]
                require(
                    record["original_ids"] == case
                    and record["vectors"] == data["steps"],
                    "Reference/capture geometry mismatch",
                )
                require(
                    all(
                        data["files"].get(data["checkpoint"] / name) == digest
                        for name, digest in record["checkpoint_files_before"].items()
                    ),
                    "Reference checkpoint differs from actual capture binding",
                )
                records[label] = record
        names, offsets = (
            records["bf16_contract_tp1"]["norm_names"],
            records["bf16_contract_tp1"]["step_offsets"],
        )
        require(
            len(names) == 65
            and all(
                r["norm_names"] == names and r["step_offsets"] == offsets
                for r in records.values()
            ),
            "Reference boundaries disagree",
        )
        actual = {
            f"engine_tp{tp}": np.stack(data["logits"][f"tp{tp}_rank0"]) for tp in (1, 2)
        }
        actual_norms = {}
        for tp in (1, 2):
            captures = data["records"][f"tp{tp}_rank0"]
            actual_norms[f"engine_tp{tp}"] = np.stack(
                [
                    np.concatenate(
                        [
                            entry["observed"]["norm_boundaries"][name]["outputs"][0]
                            for entry in captures
                        ]
                    )
                    for name in names
                ]
            )
        vector_sets = dict(actual)
        norm_sets = dict(actual_norms)
        for label, item in arrays.items():
            vector_sets[label] = item["logits"]
            norm_sets[label] = item["norms"]
            require(
                item["logits"].shape == (data["steps"], 248320)
                and item["norms"].shape == actual_norms["engine_tp1"].shape,
                "Reference array dimensions changed",
            )
        cpu_name = (
            "auxiliary_cpu_fp32_eager_4b"
            if model == "4b"
            else "auxiliary_cpu_fp32_eager_frontier_9b"
        )
        cpu_dir = task / "source_final/results/raw/homework2_20261024" / cpu_name
        cpu_state_path = cpu_dir / "reference_state.json"
        cpu_path = cpu_dir / "input_128_greedy_logits.pt"
        cpu_state = read(cpu_state_path)
        cpu_case = next(row for row in cpu_state["cases"] if row["input_length"] == 128)
        require(
            cpu_state["status"] == "collected"
            and cpu_state["source_unchanged"]
            and cpu_state["source_manifest_sha256"] == CORE
            and cpu_state["model_revision"] == identity["revision"]
            and sha(cpu_path) == cpu_case["logits_sha256"],
            "Frozen complete HF CPU reference mismatch",
        )
        expected_weights = {
            "4b": "d898725257384a457fdfc35781f6e969e58f9c204254fe2a2542069f4194dd38",
            "9b": "3fb5b1bfbf1fe8817ecafdbe4b0fc0bf58447cd6b6b4a9738f73670578b86834",
        }
        require(
            cpu_state["global_weight_sha256"] == expected_weights[model],
            "HF projected weights changed",
        )
        cpu = torch.load(cpu_path, map_location="cpu", weights_only=True)
        require(cpu["input_ids"] == case["input_ids"], "HF original Prefill IDs differ")
        if model == "4b":
            require(
                cpu["generated_ids"][: data["steps"] - 1] == case["continuation_ids"],
                "HF original greedy prefix differs",
            )
        else:
            require(
                cpu_state["case"]["continuation_ids"] == case["continuation_ids"],
                "HF fixed original continuation differs",
            )
        vector_sets["hf_cpu_fp32"] = (
            cpu["logits"][: data["steps"]].float().numpy().copy()
        )
        bindings[cpu_path], bindings[cpu_state_path] = sha(cpu_path), sha(
            cpu_state_path
        )
        pairs = [
            ("engine_tp1", "bf16_contract_tp1"),
            ("engine_tp2", "bf16_contract_tp2"),
            ("bf16_contract_tp2", "bf16_contract_tp1"),
            ("fp32_control_tp2", "fp32_control_tp1"),
            ("engine_tp2", "engine_tp1"),
            ("bf16_contract_tp1", "fp32_control_tp1"),
            ("bf16_contract_tp2", "fp32_control_tp2"),
            ("fp32_control_tp1", "hf_cpu_fp32"),
            ("fp32_control_tp2", "hf_cpu_fp32"),
        ]
        result = {
            "model": model,
            "case": case,
            "vectors": {},
            "norms": {},
            "states": {},
            "first_embedding": {},
            "reference_final_scores": {},
            "scope": "Fully independent CPU hidden/state propagation versus actual original frontier; no adaptive model tolerance",
        }
        from safetensors import safe_open

        embedding_key = "model.language_model.embed_tokens.weight"
        all_ids = np.array(case["input_ids"] + case["continuation_ids"], np.int64)
        with safe_open(
            data["checkpoint"] / data["index"][embedding_key],
            framework="pt",
            device="cpu",
        ) as handle:
            embedding = (
                handle.get_tensor(embedding_key)[torch.from_numpy(all_ids)]
                .to(torch.bfloat16)
                .float()
                .numpy()
                .copy()
            )
        for label, captures in data["records"].items():
            observed = np.concatenate(
                [
                    entry["observed"]["norm_boundaries"][names[0]]["inputs"][0]
                    for entry in captures
                ]
            )
            result["first_embedding"][label] = {
                "actual_input_equals_checkpoint_embedding": bool(
                    np.array_equal(observed, embedding)
                ),
                "metric": compare(observed, embedding),
            }
        exports = {}
        for a, b in pairs:
            label = f"{a}_vs_{b}"
            result["vectors"][label] = vectors(vector_sets[a], vector_sets[b])
            if a in norm_sets and b in norm_sets:
                result["norms"][label] = boundary_metrics(
                    norm_sets[a], norm_sets[b], names=names, offsets=offsets
                )
        for label, values in vector_sets.items():
            exports[f"{label}_logits"] = values
            competing = [
                case["original_graph_tp1_next"],
                case["original_graph_tp2_next"],
            ]
            row = values[-1]
            order = np.argsort(row)[-2:][::-1]
            result["reference_final_scores"][label] = {
                "argmax": int(row.argmax()),
                "top1_minus_top2": float(row[order[0]] - row[order[1]]),
                "competing_scores": {str(i): float(row[i]) for i in competing},
            }
        for label, values in norm_sets.items():
            exports[f"{label}_norm_last_rows"] = values[
                :, [stop - 1 for start, stop in offsets]
            ]
        for label, records_actual in data["records"].items():
            tp = records_actual[0]["metadata"]["tp"]
            rank = records_actual[0]["metadata"]["rank"]
            result["states"][label] = {}
            ref_arrays = arrays[f"bf16_contract_tp{tp}"]
            last = records_actual[-1]["observed"]
            for layer in range(32):
                prefix = f"state_layer{layer}_rank{rank}_"
                if layer % 4 == 3:
                    actual_state = last["kv"][layer]["after"]
                    result["states"][label][layer] = {
                        name: compare(actual_state[name], ref_arrays[prefix + name])
                        for name in ("k", "v")
                    }
                else:
                    actual_state = last["states"][layer]["after"]
                    result["states"][label][layer] = {
                        "ssm": compare(
                            actual_state["ssm_state"], ref_arrays[prefix + "ssm"]
                        ),
                        "conv": compare(
                            actual_state["conv_state"], ref_arrays[prefix + "conv"]
                        ),
                    }
        verify_unchanged(data)
        result["input_manifest"] = {
            path.relative_to(task).as_posix(): digest
            for path, digest in data["files"].items()
        }
        result["reference_payloads"] = {
            label: {
                k: record[k]
                for k in (
                    "arrays_sha256",
                    "case_sha256",
                    "tool_manifest_sha256",
                    "checkpoint_files_before",
                )
            }
            for label, record in records.items()
        }
        arrays_path = output / f"{model}_comparison_arrays.npz"
        np.savez_compressed(arrays_path, **exports)
        result["arrays_sha256"] = sha(arrays_path)
        destination = output / f"{model}_comparison.json"
        destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        summary["models"][model] = {
            "analysis_sha256": sha(destination),
            "arrays_sha256": sha(arrays_path),
            "logits": {
                name: {key: value for key, value in entry.items() if key != "per_step"}
                for name, entry in result["vectors"].items()
            },
            "final_scores": result["reference_final_scores"],
            "first_embedding": result["first_embedding"],
        }
        print(
            json.dumps({"model": model, "logits": summary["models"][model]["logits"]}),
            flush=True,
        )
        del (
            data,
            arrays,
            records,
            vector_sets,
            norm_sets,
            actual,
            actual_norms,
            exports,
            result,
        )
    require(
        all(sha(path) == digest for path, digest in bindings.items()),
        "Independent reference or HF input changed during comparison",
    )
    summary["reference_files_unchanged_after"] = True
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    print("ALL INDEPENDENT END-TO-END COMPARISONS COMPLETE", flush=True)


if __name__ == "__main__":
    main()
