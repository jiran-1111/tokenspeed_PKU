# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Require all independent reference paths before reading actual captures."""


def validate_complete(state: dict, *, expected_manifest: str) -> None:
    names = {
        f"{model}_{policy}_tp{tp}"
        for model in ("4b", "9b")
        for policy in ("bf16_contract", "fp32_control")
        for tp in (1, 2)
    }
    conditions = (
        state["status"] == "collected",
        state["cpu_only"] is True,
        state["actual_capture_inputs_read"] is False,
        state["current"] is None,
        state["tool_manifest_sha256"] == expected_manifest,
        set(state["finished"]) == names,
    )
    if not all(conditions):
        raise ValueError(
            "All exact eight independent CPU references must complete before capture comparison"
        )
