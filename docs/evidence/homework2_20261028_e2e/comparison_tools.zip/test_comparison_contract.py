# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import importlib
import importlib.util

import pytest


def api():
    assert (
        importlib.util.find_spec("comparison_contract") is not None
    ), "Complete reference comparison guard missing"
    return importlib.import_module("comparison_contract")


def complete():
    names = {
        f"{m}_{p}_tp{t}"
        for m in ("4b", "9b")
        for p in ("bf16_contract", "fp32_control")
        for t in (1, 2)
    }
    return dict(
        status="collected",
        cpu_only=True,
        actual_capture_inputs_read=False,
        current=None,
        tool_manifest_sha256="frozen",
        finished={n: {"state_sha256": "s", "arrays_sha256": "a"} for n in names},
    )


def test_accepts_only_complete_exact_eight_cpu_references():
    api().validate_complete(complete(), expected_manifest="frozen")


@pytest.mark.parametrize(
    "change",
    [
        "missing_job",
        "extra_job",
        "running",
        "wrong_manifest",
        "capture_input",
        "not_cpu",
    ],
)
def test_rejects_partial_tampered_or_nonindependent_cohort(change):
    contract = api()
    state = complete()
    if change == "missing_job":
        state["finished"].pop(next(iter(state["finished"])))
    elif change == "extra_job":
        state["finished"]["substituted_sample"] = {}
    elif change == "running":
        state["status"] = "running"
    elif change == "wrong_manifest":
        state["tool_manifest_sha256"] = "other"
    elif change == "capture_input":
        state["actual_capture_inputs_read"] = True
    elif change == "not_cpu":
        state["cpu_only"] = False
    with pytest.raises(ValueError):
        contract.validate_complete(state, expected_manifest="frozen")
