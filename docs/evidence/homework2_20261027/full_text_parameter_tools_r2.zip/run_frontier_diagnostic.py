# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Collect actual cached eager logits for a predeclared common frontier."""

import argparse
import hashlib
import json
import os
from pathlib import Path

from benchmarks.course_project.core import build_serve_command
from benchmarks.course_project.tp_devices import hardware_lease
from scripts.run_session_kv import _engine_cli_args
from shared_guard import shared_hardware_lease, stop_shared_monitor


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--npu-id", type=int, required=True)
    parser.add_argument("--chips", required=True)
    args = parser.parse_args()
    source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
    manifest = source / "docs/evidence/homework2_20261023/source_manifest.json"
    config = json.loads(args.config.read_text())
    config.update(
        enforce_eager=True,
        overlap_schedule=False,
        prefix_caching=False,
        disable_kvstore=True,
        prometheus_port=39581,
        tokenspeed_metrics_port=39582,
    )
    tp = config["tp_size"]
    chips = {
        int(pair.split(":")[0]): int(pair.split(":")[1])
        for pair in args.chips.split(",")
    }
    case = json.loads(args.case.read_text())
    assert len(case["input_ids"]) == 128 and 0 < len(case["continuation_ids"]) < 32
    args.output.mkdir(parents=True, exist_ok=False)
    arm = Path(os.environ["TOKENSPEED_HW2_DIAGNOSTIC_ARM"])
    assert not arm.exists()
    record = {
        "status": "starting",
        "config": config,
        "case": case,
        "diagnostic_only": True,
        "execution_mode": "eager",
        "cached": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "runtime_math_changed_by_external_override": False,
        "observational_full_parameter_identity": True,
        "large_matrices_saved": False,
        "case_sha256": hashlib.sha256(args.case.read_bytes()).hexdigest(),
    }
    lease = shared_hardware_lease
    try:
        with lease(
            source,
            npu_id=args.npu_id,
            chip_logic_ids=chips,
            tp_size=tp,
            output_dir=args.output,
            source_manifest=manifest,
        ) as guard:
            record["guard"] = guard
            from tokenspeed.runtime.entrypoints.engine import Engine
            from tokenspeed.runtime.utils.server_args import prepare_server_args

            cli = _engine_cli_args(
                build_serve_command(config, host="127.0.0.1", port=18580)
            )
            with Engine(server_args=prepare_server_args(cli)) as engine:
                arm.write_text(
                    json.dumps(
                        {
                            **case,
                            "output": str(args.output),
                            "config_path": str(args.config),
                        }
                    )
                )
                try:
                    response = engine.generate(
                        input_ids=case["input_ids"],
                        sampling_params={
                            "temperature": 0,
                            "ignore_eos": True,
                            "max_new_tokens": len(case["continuation_ids"]) + 1,
                        },
                    )
                    (args.output / "response.json").write_text(
                        json.dumps(response, indent=2)
                    )
                    assert response["output_ids"][:-1] == case["continuation_ids"]
                    assert (
                        len(response["output_ids"]) == len(case["continuation_ids"]) + 1
                    )
                finally:
                    arm.unlink(missing_ok=True)
                    stop_shared_monitor()
            count = len(case["continuation_ids"]) + 1
            for rank in range(tp):
                directory = args.output / f"rank_{rank}"
                assert len(list(directory.glob("step_*.pt"))) == count
                assert len(list(directory.glob("step_*.json"))) == count
            import torch

            protocol = json.loads(
                (Path(__file__).parent / "identity_protocol.json").read_text()
            )
            baseline_analysis = source.parent / "frontier_analysis_r2.json"
            assert (
                hashlib.sha256(baseline_analysis.read_bytes()).hexdigest()
                == protocol["baseline_analysis_sha256"]
            )
            model_tag = {"Qwen/Qwen3.5-4B": "4b", "Qwen/Qwen3.5-9B": "9b"}[
                config["model_id"]
            ]
            previous = json.loads(baseline_analysis.read_text())["models"][model_tag][
                "captures"
            ]
            baseline = (
                source
                / "results/raw/homework2_20261024"
                / f"frontier_diagnostic_{model_tag}_tp{tp}_20261024_r2"
            )
            for rank in range(tp):
                for step in range(count):
                    filename = f"rank_{rank}/step_{step:02d}.pt"
                    old_path = baseline / filename
                    assert (
                        hashlib.sha256(old_path.read_bytes()).hexdigest()
                        == previous[f"tp{tp}_rank{rank}"]["vectors"][step][
                            "capture_sha256"
                        ]
                    )
                    actual = torch.load(
                        args.output / filename, map_location="cpu", weights_only=True
                    )
                    old = torch.load(old_path, map_location="cpu", weights_only=True)
                    assert torch.equal(
                        actual["logits"].contiguous().view(torch.uint8),
                        old["logits"].contiguous().view(torch.uint8),
                    ), "observation changed original logits"
                    for field in (
                        "case_id",
                        "step",
                        "rank",
                        "input_ids",
                        "positions",
                        "prefix_length",
                        "original_dtype",
                        "raw_greedy_id",
                    ):
                        assert actual[field] == old[field]
            record["original_full_logits_preserved"] = count * tp
            record.update(status="captured_pending_guard_exit", vectors_per_rank=count)
        record["status"] = "collected"
    finally:
        (args.output / "diagnostic.json").write_text(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
