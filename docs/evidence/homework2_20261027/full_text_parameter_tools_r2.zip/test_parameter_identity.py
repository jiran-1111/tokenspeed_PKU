# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import numpy as np
import pytest
from parameter_identity import (
    compare_numpy_chunks,
    intersect_parts,
    logical_ranges,
    row_range,
)


def test_logical_shards_preserve_each_packed_segment():
    weights = np.arange(12 * 3).reshape(12, 3)
    pieces = logical_ranges([4, 2, 6], rank=1, tp=2)
    assert pieces == [(2, 4), (5, 6), (9, 12)]
    actual = np.concatenate([weights[start:end] for start, end in pieces])
    np.testing.assert_array_equal(actual, weights[[2, 3, 5, 9, 10, 11]])


def test_tp1_logical_packing_retains_all_rows():
    assert logical_ranges([4, 2, 6], rank=0, tp=1) == [(0, 4), (4, 6), (6, 12)]
    assert row_range(12, rank=1, tp=2) == (6, 12)


@pytest.mark.parametrize(
    "widths,rank,tp",
    [([3, 2], 0, 2), ([4], 2, 2), ([4], 0, 0), ([0, 4], 0, 2), ([True, 4], 0, 1)],
)
def test_invalid_geometry_rejected(widths, rank, tp):
    with pytest.raises(ValueError):
        logical_ranges(widths, rank=rank, tp=tp)


def test_chunks_crossing_checkpoint_piece_boundaries():
    parts = [
        {"key": "q", "start": 2, "stop": 4, "columns": None},
        {"key": "k", "start": 1, "stop": 3, "columns": None},
    ]
    assert intersect_parts(parts, offset=1, length=3) == [
        ("q", 3, 4, None),
        ("k", 1, 3, None),
    ]


def test_byte_identity_requires_dtype_shape_and_all_chunks():
    a = np.arange(35, dtype=np.float32).reshape(7, 5)
    result = compare_numpy_chunks(a, a.copy(), rows=3)
    assert result["exact_match"] and result["chunks"] == 3
    b = a.copy()
    b[-1, -1] += 1
    assert not compare_numpy_chunks(a, b, rows=3)["exact_match"]
    assert not compare_numpy_chunks(a, a.astype(np.float64), rows=3)["exact_match"]


def test_gemma_effective_gamma_uses_projected_weight_before_addition():
    import importlib.util

    if importlib.util.find_spec("torch") is None:
        pytest.skip("real CPU Torch required")
    import torch
    from parameter_identity import expected_block

    original = torch.tensor([0.00391, 0.12345, -0.3], dtype=torch.float32)
    actual = expected_block(original, mode="gamma", torch=torch)
    assert actual.dtype == torch.float32
    assert torch.equal(actual, original.bfloat16().float() + 1)


def test_explicit_bf16_and_fp32_head_projection():
    import importlib.util

    if importlib.util.find_spec("torch") is None:
        pytest.skip("real CPU Torch required")
    import torch
    from parameter_identity import expected_block

    original = torch.tensor([[1.003, 3.125, 0.123456]], dtype=torch.float32)
    assert torch.equal(
        expected_block(original, mode="bfloat16", torch=torch), original.bfloat16()
    )
    assert torch.equal(
        expected_block(original, mode="head_float32", torch=torch),
        original.bfloat16().float(),
    )


def runtime_fixture(*, tied, rank, tp):
    import json
    from pathlib import Path
    from types import SimpleNamespace as NS

    geometry = Path(__file__).resolve().parent / "model_geometry_fixture.json"
    text = next(
        row["text_config"]
        for row in json.loads(geometry.read_text())["models"]
        if row["model"] == "Qwen/Qwen3.5-9B"
    ).copy()
    text["rms_norm_eps"] = 1e-6
    parameters = []

    def parameter():
        value = object()
        parameters.append(value)
        return value

    def norm():
        return NS(weight=parameter(), gemma_weight=object(), variance_epsilon=1e-6)

    layers = []
    for number, kind in enumerate(text["layer_types"]):
        layer = NS(
            input_layernorm=norm(),
            post_attention_layernorm=norm(),
            mlp=NS(
                gate_up_proj=NS(weight=parameter()), down_proj=NS(weight=parameter())
            ),
        )
        if kind == "linear_attention":
            layer.linear_attn = NS(
                layer_id=number,
                attn_tp_rank=rank,
                attn_tp_size=tp,
                in_proj_qkvzba=NS(weight=parameter()),
                out_proj=NS(weight=parameter()),
                conv1d=NS(weight=parameter()),
                conv_weights=object(),
                A_log=parameter(),
                dt_bias=parameter(),
                norm=NS(
                    weight=parameter(),
                    eps=1e-6,
                    group_size=None,
                    norm_before_gate=True,
                    sigmoid_gate=False,
                ),
            )
        else:
            layer.layer_id = number
            layer.attn_tp_rank = rank
            layer.attn_tp_size = tp
            layer.attn_output_gate = True
            layer.qkv_proj = NS(weight=parameter())
            layer.o_proj = NS(weight=parameter())
            layer.q_norm = norm()
            layer.k_norm = norm()
        layers.append(layer)
    embedding = NS(weight=parameter())
    head = embedding if tied else NS(weight=parameter())
    model = NS(
        model=NS(layers=layers, norm=norm(), embed_tokens=embedding),
        lm_head=head,
        named_parameters=lambda **kwargs: [
            (str(i), p) for i, p in enumerate(parameters)
        ],
    )
    return model, text, parameters


@pytest.mark.parametrize("tp,rank,tied", [(1, 0, True), (2, 0, False), (2, 1, False)])
def test_full_decoder_target_coverage_and_expected_shards(tp, rank, tied):
    from parameter_identity import build_targets

    model, text, parameters = runtime_fixture(tied=tied, rank=rank, tp=tp)
    targets, excluded = build_targets(
        model,
        text,
        rank=rank,
        tp=tp,
        head_mode="bfloat16" if tied else "head_float32",
        tied=tied,
    )
    assert len(targets) == 412
    assert excluded == []
    assert len(
        {
            id(t["tensor"])
            for t in targets
            if t["mode"] not in ("gamma", "conv_view_bfloat16")
        }
    ) == len(parameters)
    target = next(
        t
        for t in targets
        if t["name"] == "model.language_model.layers.3.self_attn.qkv_proj.weight"
    )
    assert target["shape"] == [10240 // tp, 4096]
    assert [(p["start"], p["stop"]) for p in target["parts"]] == [
        (rank * 8192 // tp, (rank + 1) * 8192 // tp),
        (rank * 1024 // tp, (rank + 1) * 1024 // tp),
        (rank * 1024 // tp, (rank + 1) * 1024 // tp),
    ]
    conv = next(
        t
        for t in targets
        if t["name"] == "model.language_model.layers.0.linear_attn.conv1d.weight"
    )
    assert conv["shape"] == [8192 // tp, 1, 4]


def test_uncovered_parameter_is_an_error():
    from parameter_identity import build_targets

    model, text, parameters = runtime_fixture(tied=False, rank=0, tp=1)
    parameters.append(object())
    with pytest.raises(ValueError, match="uncovered learned"):
        build_targets(model, text, rank=0, tp=1, head_mode="head_float32", tied=False)


def test_only_explicit_visual_prefix_is_excluded_and_recorded():
    from parameter_identity import build_targets

    model, text, parameters = runtime_fixture(tied=False, rank=0, tp=1)
    original = model.named_parameters
    model.named_parameters = lambda **kwargs: [
        *original(**kwargs),
        ("visual.patch_embed.proj.weight", object()),
    ]
    targets, excluded = build_targets(
        model, text, rank=0, tp=1, head_mode="head_float32", tied=False
    )
    assert len(targets) == 412 and excluded == ["visual.patch_embed.proj.weight"]


def test_visual_forward_guard_rejects_and_always_removes_hook():
    from types import SimpleNamespace

    from parameter_identity import text_forward_scope

    class Vision:
        def __init__(self):
            self.hook = None

        def register_forward_pre_hook(self, hook):
            self.hook = hook
            return self

        def remove(self):
            self.hook = None

        def named_modules(self):
            return [("", self)]

    visual = Vision()
    with pytest.raises(ValueError, match="outside the declared text"):
        with text_forward_scope(SimpleNamespace(visual=visual)):
            visual.hook(visual, ())
    assert visual.hook is None
    with text_forward_scope(SimpleNamespace(visual=None)):
        pass


def test_direct_visual_child_call_cannot_bypass_root_guard():
    from types import SimpleNamespace

    from parameter_identity import text_forward_scope

    class Node:
        def __init__(self):
            self.hook = None
            self.child = None

        def register_forward_pre_hook(self, hook):
            self.hook = hook
            return self

        def remove(self):
            self.hook = None

        def named_modules(self):
            return [("", self), ("child", self.child)]

        def forward(self):
            if self.hook is not None:
                self.hook(self, ())

    root = Node()
    child = Node()
    root.child = child
    with pytest.raises(ValueError, match="outside the declared text"):
        with text_forward_scope(SimpleNamespace(visual=root)):
            child.forward()
    assert root.hook is None and child.hook is None


def test_real_torch_safetensors_chunk_and_conv_view(tmp_path):
    import importlib.util

    if importlib.util.find_spec("torch") is None:
        pytest.skip("real CPU Torch required")
    import torch
    from parameter_identity import expected_block
    from safetensors import safe_open
    from safetensors.torch import save_file

    matrix = torch.arange(35, dtype=torch.float32).reshape(7, 5)
    conv = torch.arange(24, dtype=torch.float32).reshape(6, 1, 4)
    path = tmp_path / "small.safetensors"
    save_file({"matrix": matrix, "conv": conv}, str(path))
    with safe_open(path, framework="pt", device="cpu") as f:
        block = f.get_slice("matrix")[2:6, 1:4]
        view = f.get_slice("conv")[1:4]
    assert torch.equal(block, matrix[2:6, 1:4])
    assert torch.equal(
        expected_block(view, mode="conv_view_bfloat16", torch=torch),
        conv[1:4, 0].bfloat16(),
    )
