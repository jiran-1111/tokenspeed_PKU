# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import hashlib
import json
from contextlib import contextmanager
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


@contextmanager
def text_forward_scope(model):
    def reject_visual(module, args):
        raise ValueError("visual execution is outside the declared text identity scope")

    visual = model.visual
    if visual is None:
        yield
    else:
        handles = []
        try:
            for name, module in visual.named_modules():
                handles.append(module.register_forward_pre_hook(reject_visual))
            yield
        finally:
            for handle in reversed(handles):
                handle.remove()


def logical_ranges(widths, *, rank, tp):
    require(
        type(tp) is int and tp in (1, 2) and type(rank) is int and 0 <= rank < tp,
        "invalid TP/rank",
    )
    require(
        bool(widths) and all(type(n) is int and n > 0 and n % tp == 0 for n in widths),
        "invalid logical width",
    )
    offset = 0
    result = []
    for width in widths:
        result.append(
            (offset + rank * (width // tp), offset + (rank + 1) * (width // tp))
        )
        offset += width
    return result


def row_range(width, *, rank, tp):
    return logical_ranges([width], rank=rank, tp=tp)[0]


def intersect_parts(parts, *, offset, length):
    total = sum(p["stop"] - p["start"] for p in parts)
    require(
        type(offset) is int
        and type(length) is int
        and 0 <= offset < total
        and 0 < length <= total - offset,
        "invalid requested chunk",
    )
    result = []
    position = 0
    for part in parts:
        count = part["stop"] - part["start"]
        left = max(offset, position)
        right = min(offset + length, position + count)
        if left < right:
            result.append(
                (
                    part["key"],
                    part["start"] + left - position,
                    part["start"] + right - position,
                    part["columns"],
                )
            )
        position += count
    return result


def compare_numpy_chunks(actual, expected, *, rows):
    import numpy as np

    require(type(rows) is int and rows > 0, "positive chunk rows required")
    a, b = np.asarray(actual), np.asarray(expected)
    if a.shape != b.shape or a.dtype != b.dtype:
        return {"exact_match": False, "chunks": 0}
    h1, h2 = hashlib.sha256(), hashlib.sha256()
    chunks = 0
    for start in range(0, a.shape[0], rows):
        h1.update(np.ascontiguousarray(a[start : start + rows]).tobytes())
        h2.update(np.ascontiguousarray(b[start : start + rows]).tobytes())
        chunks += 1
    return {
        "exact_match": h1.digest() == h2.digest(),
        "chunks": chunks,
        "actual_sha256": h1.hexdigest(),
        "expected_sha256": h2.hexdigest(),
    }


def expected_block(raw, *, mode, torch):
    if mode == "bfloat16":
        return raw.to(torch.bfloat16)
    if mode == "float32":
        return raw.to(torch.float32)
    if mode == "head_float32":
        return raw.to(torch.bfloat16).float()
    if mode == "gamma":
        return raw.to(torch.bfloat16).float() + 1.0
    if mode == "conv_view_bfloat16":
        require(raw.ndim == 3 and raw.shape[1] == 1, "unexpected checkpoint conv shape")
        return raw.squeeze(1).to(torch.bfloat16)
    raise ValueError("unknown explicit parameter projection")


def build_targets(model, text, *, rank, tp, head_mode, tied):
    layers = model.model.layers
    require(
        len(layers) == text["num_hidden_layers"] == 32
        and len(text["layer_types"]) == 32,
        "expected complete 32-layer decoder",
    )
    require(
        head_mode in ("bfloat16", "head_float32") and type(tied) is bool,
        "explicit head/tie contract required",
    )
    hidden = text["hidden_size"]
    intermediate = text["intermediate_size"]
    k = text["linear_num_key_heads"] * text["linear_key_head_dim"]
    v = text["linear_num_value_heads"] * text["linear_value_head_dim"]
    heads = text["linear_num_value_heads"]
    conv = text["linear_conv_kernel_dim"]
    q = text["num_attention_heads"] * text["head_dim"]
    kv = text["num_key_value_heads"] * text["head_dim"]
    targets = []

    def add(name, tensor, shape, mode, parts):
        require(
            sum(p["stop"] - p["start"] for p in parts) == shape[0],
            "target row geometry mismatch",
        )
        targets.append(
            {
                "name": name,
                "tensor": tensor,
                "shape": shape,
                "mode": mode,
                "parts": parts,
            }
        )

    def part(key, start, stop, columns):
        return {"key": key, "start": start, "stop": stop, "columns": columns}

    def norm(name, module, width):
        require(
            module.variance_epsilon == text["rms_norm_eps"],
            "actual norm epsilon mismatch",
        )
        p = [part(name + ".weight", 0, width, None)]
        add(name + ".weight", module.weight, [width], "bfloat16", p)
        add(name + ".effective_gamma", module.gemma_weight, [width], "gamma", p)

    def row(name, tensor, output, width):
        add(
            name,
            tensor,
            [output, width // tp],
            "bfloat16",
            [part(name, 0, output, row_range(width, rank=rank, tp=tp))],
        )

    def columns(name, tensor, segments, width, tail):
        pieces = []
        for key, widths in segments:
            pieces.extend(
                part(key, start, stop, None)
                for start, stop in logical_ranges(widths, rank=rank, tp=tp)
            )
        add(
            name,
            tensor,
            [sum(p["stop"] - p["start"] for p in pieces), *tail],
            "bfloat16",
            pieces,
        )

    for number, kind in enumerate(text["layer_types"]):
        layer = layers[number]
        prefix = f"model.language_model.layers.{number}"
        norm(prefix + ".input_layernorm", layer.input_layernorm, hidden)
        norm(
            prefix + ".post_attention_layernorm", layer.post_attention_layernorm, hidden
        )
        columns(
            prefix + ".mlp.gate_up_proj.weight",
            layer.mlp.gate_up_proj.weight,
            [
                (prefix + ".mlp.gate_proj.weight", [intermediate]),
                (prefix + ".mlp.up_proj.weight", [intermediate]),
            ],
            hidden,
            [hidden],
        )
        row(
            prefix + ".mlp.down_proj.weight",
            layer.mlp.down_proj.weight,
            hidden,
            intermediate,
        )
        if kind == "linear_attention":
            gdn = layer.linear_attn
            require(
                (gdn.layer_id, gdn.attn_tp_rank, gdn.attn_tp_size)
                == (number, rank, tp),
                "actual GDN identity mismatch",
            )
            gp = prefix + ".linear_attn"
            columns(
                gp + ".in_proj_qkvzba.weight",
                gdn.in_proj_qkvzba.weight,
                [
                    (gp + ".in_proj_qkv.weight", [k, k, v]),
                    (gp + ".in_proj_z.weight", [v]),
                    (gp + ".in_proj_b.weight", [heads]),
                    (gp + ".in_proj_a.weight", [heads]),
                ],
                hidden,
                [hidden],
            )
            row(gp + ".out_proj.weight", gdn.out_proj.weight, hidden, v)
            columns(
                gp + ".conv1d.weight",
                gdn.conv1d.weight,
                [(gp + ".conv1d.weight", [k, k, v])],
                conv,
                [1, conv],
            )
            add(
                gp + ".actual_conv_weights_view",
                gdn.conv_weights,
                [(k + k + v) // tp, conv],
                "conv_view_bfloat16",
                [
                    part(gp + ".conv1d.weight", start, stop, None)
                    for start, stop in logical_ranges([k, k, v], rank=rank, tp=tp)
                ],
            )
            for suffix, tensor in [("A_log", gdn.A_log), ("dt_bias", gdn.dt_bias)]:
                start, stop = row_range(heads, rank=rank, tp=tp)
                add(
                    gp + "." + suffix,
                    tensor,
                    [heads // tp],
                    "float32",
                    [part(gp + "." + suffix, start, stop, None)],
                )
            require(
                gdn.norm.eps == text["rms_norm_eps"]
                and gdn.norm.group_size is None
                and gdn.norm.norm_before_gate is True
                and gdn.norm.sigmoid_gate is False,
                "actual GDN norm metadata mismatch",
            )
            add(
                gp + ".norm.weight",
                gdn.norm.weight,
                [text["linear_value_head_dim"]],
                "bfloat16",
                [part(gp + ".norm.weight", 0, text["linear_value_head_dim"], None)],
            )
        elif kind == "full_attention":
            require(
                (layer.layer_id, layer.attn_tp_rank, layer.attn_tp_size)
                == (number, rank, tp)
                and layer.attn_output_gate is True,
                "actual FA identity/gate mismatch",
            )
            fp = prefix + ".self_attn"
            columns(
                fp + ".qkv_proj.weight",
                layer.qkv_proj.weight,
                [
                    (fp + ".q_proj.weight", [q * 2]),
                    (fp + ".k_proj.weight", [kv]),
                    (fp + ".v_proj.weight", [kv]),
                ],
                hidden,
                [hidden],
            )
            row(fp + ".o_proj.weight", layer.o_proj.weight, hidden, q)
            norm(fp + ".q_norm", layer.q_norm, text["head_dim"])
            norm(fp + ".k_norm", layer.k_norm, text["head_dim"])
        else:
            raise ValueError("unsupported explicit decoder layer type")
    norm("model.language_model.norm", model.model.norm, hidden)
    start, stop = row_range(text["vocab_size"], rank=rank, tp=tp)
    embed = "model.language_model.embed_tokens.weight"
    add(
        embed,
        model.model.embed_tokens.weight,
        [text["vocab_size"] // tp, hidden],
        "bfloat16",
        [part(embed, start, stop, None)],
    )
    head_key = embed if tied else "lm_head.weight"
    add(
        "lm_head.weight",
        model.lm_head.weight,
        [text["vocab_size"] // tp, hidden],
        head_mode,
        [part(head_key, start, stop, None)],
    )
    require(
        (model.lm_head.weight is model.model.embed_tokens.weight) == tied,
        "actual embedding/head alias mismatch",
    )
    covered = {id(t["tensor"]) for t in targets}
    parameters = list(model.named_parameters(remove_duplicate=False))
    excluded_visual = [name for name, p in parameters if name.startswith("visual.")]
    uncovered = [
        name
        for name, p in parameters
        if id(p) not in covered and not name.startswith("visual.")
    ]
    require(not uncovered, f"uncovered learned parameters: {uncovered}")
    require(len(targets) == 412, "full target coverage mismatch")
    return targets, excluded_visual


def file_sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_model(model, *, torch, rank, tp, config_path, output, rows_per_chunk):
    import os

    from safetensors import safe_open

    require(
        type(rows_per_chunk) is int and rows_per_chunk > 0,
        "explicit positive chunk rows required",
    )
    source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
    config = json.loads(config_path.read_text())
    require(
        config["tp_size"] == tp and config["dtype"] == "bfloat16",
        "original TP/dtype config mismatch",
    )
    identities = {
        "Qwen/Qwen3.5-4B": (
            "851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a",
            True,
            "bfloat16",
        ),
        "Qwen/Qwen3.5-9B": (
            "c202236235762e1c871ad0ccb60c8ee5ba337b9a",
            False,
            "head_float32",
        ),
    }
    revision, tied, head_mode = identities[config["model_id"]]
    require(config["model_revision"] == revision, "frozen model revision mismatch")
    checkpoint = source / config["local_model_path"]
    index_path = checkpoint / "model.safetensors.index.json"
    index = json.loads(index_path.read_text())["weight_map"]
    model_config_path = checkpoint / "config.json"
    model_config = json.loads(model_config_path.read_text())
    text = model_config["text_config"]
    targets, excluded_visual = build_targets(
        model, text, rank=rank, tp=tp, head_mode=head_mode, tied=tied
    )
    artifacts = source / "docs/evidence/homework2_20261023/model_artifacts.json"
    require(
        file_sha(artifacts)
        == "169e3069d4fdb70e57aaaffdee9f1a84b3f0001aceb4fe4a007ed66f9eeda1c6",
        "frozen artifacts SHA mismatch",
    )
    entries = [
        x
        for x in json.loads(artifacts.read_text())["models"]
        if x["model_id"] == config["model_id"] and x["model_revision"] == revision
    ]
    require(len(entries) == 1, "checkpoint artifact ambiguity")
    artifact = entries[0]["files"]
    names = {"config.json", "model.safetensors.index.json"} | {
        index[p["key"]] for target in targets for p in target["parts"]
    }
    files = {name: file_sha(checkpoint / name) for name in sorted(names)}
    require(
        all(
            value == artifact[name]["sha256"]
            and (checkpoint / name).stat().st_size == artifact[name]["bytes"]
            for name, value in files.items()
        ),
        "checkpoint file identity mismatch",
    )
    result = {
        "status": "verifying",
        "rank": rank,
        "tp": tp,
        "model_id": config["model_id"],
        "model_revision": revision,
        "config_sha256": file_sha(config_path),
        "checkpoint_files_before": files,
        "parameter_checks": 412,
        "parameters": {},
        "all_exact": False,
        "diagnostic_only": True,
        "performance_eligible": False,
        "runtime_math_changed": False,
        "runtime_state_written": False,
        "rows_per_chunk": rows_per_chunk,
        "coverage": "All in-scope named text decoder/embedding/head parameters plus actual effective Gemma gamma and conv_weights view; visual parameters explicitly excluded; not cache/state/operation certification",
        "excluded_visual_parameters": excluded_visual,
        "visual_parameter_identity_certified": False,
        "armed_text_forward_visual_module_calls_blocked": True,
    }
    destination = output / "full_parameter_identity.json"
    require(not destination.exists(), "new parameter identity output required")
    try:
        for target in targets:
            actual = target["tensor"]
            mode = target["mode"]
            dtype = (
                torch.float32
                if mode in ("float32", "head_float32", "gamma")
                else torch.bfloat16
            )
            record = {
                "shape": list(actual.shape),
                "expected_shape": target["shape"],
                "dtype": str(actual.dtype),
                "expected_dtype": str(dtype),
                "projection": mode,
                "checkpoint_parts": target["parts"],
                "exact_match": False,
            }
            result["parameters"][target["name"]] = record
            require(
                list(actual.shape) == target["shape"] and actual.dtype == dtype,
                "actual parameter shape/dtype mismatch",
            )
            a_hash, e_hash = hashlib.sha256(), hashlib.sha256()
            equal = True
            chunks = 0
            for offset in range(0, actual.shape[0], rows_per_chunk):
                length = min(rows_per_chunk, actual.shape[0] - offset)
                blocks = []
                for key, start, stop, columns in intersect_parts(
                    target["parts"], offset=offset, length=length
                ):
                    with safe_open(
                        checkpoint / index[key], framework="pt", device="cpu"
                    ) as handle:
                        block = (
                            handle.get_slice(key)[start:stop]
                            if columns is None
                            else handle.get_slice(key)[
                                start:stop, columns[0] : columns[1]
                            ]
                        )
                    blocks.append(expected_block(block, mode=mode, torch=torch))
                expected = torch.cat(blocks, dim=0).contiguous()
                copied = actual.detach()[offset : offset + length].cpu().contiguous()
                equal = bool(torch.equal(copied, expected)) and equal
                a_hash.update(copied.view(torch.uint8).numpy().tobytes())
                e_hash.update(expected.view(torch.uint8).numpy().tobytes())
                chunks += 1
            record.update(
                actual_sha256=a_hash.hexdigest(),
                checkpoint_expected_sha256=e_hash.hexdigest(),
                chunks=chunks,
                exact_match=equal and a_hash.digest() == e_hash.digest(),
            )
            require(
                record["exact_match"],
                f'parameter checkpoint mismatch: {target["name"]}',
            )
        result["checkpoint_files_after"] = {
            name: file_sha(checkpoint / name) for name in files
        }
        require(
            result["checkpoint_files_after"] == files
            and file_sha(config_path) == result["config_sha256"],
            "checkpoint/config changed during parameter audit",
        )
        result["all_exact"] = True
        result["status"] = "verified"
    finally:
        with destination.open("x") as stream:
            json.dump(result, stream, indent=2)
    return result
