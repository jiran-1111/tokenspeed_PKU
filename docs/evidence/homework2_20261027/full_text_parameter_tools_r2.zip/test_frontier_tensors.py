# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import pytest

torch = pytest.importorskip(
    "torch", reason="real CPU Torch frontier checks require the server environment"
)

from frontier_capture import install


class CaptureTests(unittest.TestCase):
    def test_both_ranks_preserve_logits_and_broadcast(self):
        for rank in (0, 1):
            with self.subTest(rank=rank), tempfile.TemporaryDirectory(
                dir=Path(__file__).parent
            ) as temporary:
                root = Path(temporary)
                arm = root / "arm.json"
                logits = torch.zeros((1, 248320), dtype=torch.bfloat16)
                logits[0, 5 if rank == 0 else 4] = 3
                original = logits.clone()

                class Runner:
                    global_rank = rank

                    def __init__(self):
                        self.model = SimpleNamespace(
                            visual=None,
                            model=SimpleNamespace(
                                layers=[
                                    None,
                                    None,
                                    None,
                                    SimpleNamespace(attn_tp_size=2),
                                ]
                            ),
                        )

                    def forward(self, ctx, input_ids, positions):
                        return SimpleNamespace(next_token_logits=logits)

                class Executor:
                    def _run_sampling(self, output, info, ctx, candidates=None):
                        return torch.tensor([5]), torch.tensor([1])

                install(Runner, Executor, torch=torch, arm_path=arm)
                identity = self.enterContext(patch("parameter_identity.verify_model"))
                runner, executor = Runner(), Executor()
                # Installation is inert until explicitly armed.
                output = runner.forward(None, torch.tensor([3]), torch.tensor([0]))
                self.assertEqual(
                    int(executor._run_sampling(output, None, None)[0].item()), 5
                )
                arm.write_text(
                    json.dumps(
                        {
                            "case_id": "unit",
                            "input_ids": [3, 4],
                            "continuation_ids": [7, 8],
                            "output": str(root),
                            "config_path": str(root / "config.yaml"),
                        }
                    )
                )
                for step, (ids, pos, emitted) in enumerate(
                    (([3, 4], [0, 1], 7), ([7], [2], 8), ([8], [3], 5))
                ):
                    output = runner.forward(None, torch.tensor(ids), torch.tensor(pos))
                    result, _ = executor._run_sampling(output, None, None)
                    self.assertEqual(int(result.item()), emitted)
                    self.assertTrue(torch.equal(logits, original))
                    path = root / f"rank_{rank}/step_{step:02d}"
                    record = torch.load(path.with_suffix(".pt"), weights_only=True)
                    sample = json.loads(path.with_suffix(".json").read_text())
                    self.assertEqual(record["original_dtype"], "torch.bfloat16")
                    self.assertEqual(record["logits"].shape, (248320,))
                    self.assertEqual(sample["broadcast_sampled_id"], 5)
                    self.assertEqual(sample["raw_greedy_id"], 5 if rank == 0 else 4)
                identity.assert_called_once()
                self.assertEqual(identity.call_args.kwargs["rows_per_chunk"], 256)
                self.assertEqual(identity.call_args.kwargs["rank"], rank)


if __name__ == "__main__":
    unittest.main()
