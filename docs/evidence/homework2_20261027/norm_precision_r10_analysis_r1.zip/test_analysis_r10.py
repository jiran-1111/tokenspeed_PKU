# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy
import hashlib
import json

import numpy as np
import pytest

try:
    import analysis_math as math
except ModuleNotFoundError as error:
    if error.name != "analysis_math":
        raise
    math = None


def test_complete_vector_math_and_tie_order():
    assert math is not None, "R10 vector math has not been implemented"
    actual = np.array([3, 3, 0], dtype=np.float32)
    reference = np.array([2, 3, -1], dtype=np.float32)
    metrics = math.compare(actual, reference)
    assert metrics["max_abs"] == 1 and metrics["argmax_equal"] is False
    np.testing.assert_allclose(metrics["relative_l2"], np.sqrt(2 / 14))
    top = math.top(actual, count=3)
    assert top["ids"] == [0, 1, 2] and top["maximum_tie_count"] == 2
    assert top["margin"] == 0


def test_zero_denominator_and_no_threshold():
    zero = np.zeros(3, dtype=np.float32)
    same = math.compare(zero, zero)
    other = math.compare(zero + 1, zero)
    assert same["relative_l2"] == 0 and same["value_bits_equal"]
    assert other["relative_l2"] is None and other["reference_zero"]
    assert "passed" not in other and "threshold" not in other


@pytest.mark.parametrize(
    "bad",
    [
        np.array([np.inf, 0], dtype=np.float32),
        np.ones((1, 2), dtype=np.float32),
        np.array([], dtype=np.float32),
    ],
)
def test_bad_vector_inputs_rejected(bad):
    with pytest.raises(ValueError):
        math.compare(bad, bad)


def test_summary_and_npz_roundtrip_preserve_every_vector(tmp_path):
    one = np.array([[1, 2, 0], [3, 1, 0]], dtype=np.float32)
    two = np.array([[1, 3, 0], [3, 1, 0]], dtype=np.float32)
    rows = math.compare_steps(two, one)
    assert len(rows) == 2 and rows[0]["step"] == 0
    summary = math.summary(rows)
    np.testing.assert_allclose(summary["max_relative_l2"], 1 / np.sqrt(5))
    path = tmp_path / "vectors.npz"
    with path.open("xb") as stream:
        np.savez_compressed(stream, original=one, candidate=two)
    with np.load(path, allow_pickle=False) as restored:
        assert math.compare_steps(restored["candidate"], restored["original"]) == rows
        assert (
            math.array_sha(restored["candidate"])
            == hashlib.sha256(two.tobytes()).hexdigest()
        )


def jobs_fixture():
    return {
        model: {
            f"tp{tp}": f"results/raw/homework2_20261027/norm_precision_{model}_tp{tp}_20261027_r10r2"
            for tp in (1, 2)
        }
        for model in ("4b", "9b")
    }


def controller_fixture():
    import analyze_r10 as cli

    state = {
        "status": "collected",
        "source_manifest_sha256": cli.CORE_SHA,
        "original_queue_retained_paused": True,
        "performance_eligible": False,
        "runtime_math_changed_by_external_override": True,
        "not_final_source": True,
        "new_threshold": None,
        "finished": {},
    }
    for model in ("4b", "9b"):
        for tp in (1, 2):
            name = cli.job_name(model, tp, jobs=jobs_fixture())
            state["finished"][name] = {
                "job": name,
                "npu_id": 0,
                "chips": {str(rank): rank for rank in range(tp)},
                "exit_code": 0,
                "own_contexts_released": True,
                "all_dtype_boundaries_verified": True,
            }
    return state


def test_only_complete_four_job_controller_can_enter_analysis():
    import analyze_r10 as cli

    state = controller_fixture()
    cli.validate_controller(state, jobs=jobs_fixture())
    before = copy.deepcopy(state)
    for status in ("running", "failed", "starting", "captured_pending_guard_exit"):
        state["status"] = status
        with pytest.raises(ValueError, match="collected"):
            cli.validate_controller(state, jobs=jobs_fixture())
    state = before
    assert len(state["finished"]) == 4


@pytest.mark.parametrize(
    "failure", ["missing", "exit", "release", "dtype", "card", "queue", "source"]
)
def test_controller_rejects_unreleased_failed_or_unverified_cohort(failure):
    import analyze_r10 as cli

    state = controller_fixture()
    row = state["finished"][cli.job_name("4b", 2, jobs=jobs_fixture())]
    if failure == "missing":
        del state["finished"][cli.job_name("9b", 2, jobs=jobs_fixture())]
    elif failure == "exit":
        row["exit_code"] = 1
    elif failure == "release":
        row["own_contexts_released"] = False
    elif failure == "dtype":
        row["all_dtype_boundaries_verified"] = False
    elif failure == "card":
        row["npu_id"] = 1
    elif failure == "queue":
        state["original_queue_retained_paused"] = False
    else:
        state["source_manifest_sha256"] = "0" * 64
    with pytest.raises(ValueError):
        cli.validate_controller(state, jobs=jobs_fixture())


def frontier_fixture():
    case = {"case_id": "toy", "input_ids": [4, 5], "continuation_ids": [7]}
    record = {
        "case_id": "toy",
        "step": 1,
        "rank": 0,
        "input_ids": [7],
        "positions": [2],
        "prefix_length": 3,
        "original_dtype": "torch.float32",
        "raw_greedy_id": 1,
        "logits": np.array([1, 2, 0], dtype=np.float32),
    }
    sample = {
        "rank": 0,
        "raw_greedy_id": 1,
        "broadcast_sampled_id": 1,
        "emitted_id": 1,
        "forced": False,
    }
    return case, record, sample


def test_frontier_terminal_step_has_no_extra_forcing_and_keeps_original_dtype():
    import analyze_r10 as cli

    case, record, sample = frontier_fixture()
    cli.validate_record(
        record, sample, case, step=1, rank=0, original_dtype="torch.float32"
    )
    before = record["logits"].copy()
    np.testing.assert_array_equal(before, record["logits"])


@pytest.mark.parametrize(
    "failure",
    ["input", "position", "case", "rank", "step", "dtype", "argmax", "force", "sample"],
)
def test_wrong_frontier_or_sampling_is_rejected(failure):
    import analyze_r10 as cli

    case, record, sample = frontier_fixture()
    if failure == "input":
        record["input_ids"] = [8]
    elif failure == "position":
        record["positions"] = [3]
    elif failure == "case":
        record["case_id"] = "other"
    elif failure == "rank":
        sample["rank"] = 1
    elif failure == "step":
        record["step"] = 0
    elif failure == "dtype":
        record["original_dtype"] = "torch.bfloat16"
    elif failure == "argmax":
        record["raw_greedy_id"] = 0
    elif failure == "force":
        sample["forced"] = True
    else:
        sample["broadcast_sampled_id"] = 0
    with pytest.raises(ValueError):
        cli.validate_record(
            record, sample, case, step=1, rank=0, original_dtype="torch.float32"
        )


def test_cohort_requires_hash_for_every_read_and_rechecks_changed_content(tmp_path):
    import analyze_r10 as cli

    file = tmp_path / "plain.json"
    file.write_text('{"ok": true}')
    digest = hashlib.sha256(file.read_bytes()).hexdigest()
    roots = {name: tmp_path for name in ("source", "task", "tools", "reference")}
    cohort = {"schema_version": 1, "files": {name: {} for name in roots}}
    cohort["files"]["tools"]["plain.json"] = digest
    bound = cli.BoundFiles(roots, cohort)
    assert bound.json("tools", "plain.json") == {"ok": True}
    with pytest.raises(ValueError, match="cohort"):
        bound.path("tools", "unbound")
    file.write_text('{"ok": false}')
    with pytest.raises(ValueError, match="SHA"):
        bound.recheck()


@pytest.mark.parametrize("name", ["../outside", "/outside", "C:/outside"])
def test_cohort_rejects_traversal_paths(tmp_path, name):
    import analyze_r10 as cli

    with pytest.raises(ValueError):
        cli.relative(tmp_path, name)


def test_cli_requires_explicit_roots_cohort_output_and_threads():
    import analyze_r10 as cli

    with pytest.raises(SystemExit):
        cli.parser().parse_args([])
    args = cli.parser().parse_args(
        [
            "--source-root",
            "s",
            "--task-root",
            "t",
            "--tools-root",
            "u",
            "--reference-root",
            "r",
            "--input-cohort",
            "c",
            "--output",
            "o",
            "--threads",
            "1",
        ]
    )
    assert args.threads == 1


def test_explicit_retry2_paths_cannot_fall_back_to_old_r10_receipts():
    import analyze_r10 as cli

    jobs = jobs_fixture()
    assert cli.validate_jobs(jobs) == jobs
    state = controller_fixture()
    key = cli.job_name("4b", 1, jobs=jobs)
    state["finished"][key.removesuffix("r2")] = state["finished"].pop(key)
    with pytest.raises(ValueError):
        cli.validate_controller(state, jobs=jobs)


def test_dtype_evidence_normalizes_only_root_paths_not_hashes_or_values():
    import analyze_r10 as cli

    name = cli.job_name("4b", 1, jobs=jobs_fixture())
    one = {
        "passed": True,
        "ranks": {0: {"norm_count": 1170}},
        "evidence_files": {f"/original/{name}/rank_0/step_00.pt": "a" * 64},
    }
    two = {
        "passed": True,
        "ranks": {"0": {"norm_count": 1170}},
        "evidence_files": {f"/restored/{name}/rank_0/step_00.pt": "a" * 64},
    }
    assert cli.canonical_dtype_report(one, name) == cli.canonical_dtype_report(
        two, name
    )
    two["evidence_files"][next(iter(two["evidence_files"]))] = "b" * 64
    assert cli.canonical_dtype_report(one, name) != cli.canonical_dtype_report(
        two, name
    )


def test_cohort_preparation_refuses_running_without_waiting(tmp_path, monkeypatch):
    import prepare_cohort

    (tmp_path / "state.json").write_text(json.dumps({"status": "running"}))
    selection = {
        "jobs": jobs_fixture(),
        "tools_manifest_sha256": "a" * 64,
        "case_sha256": {},
        "reference_identities": {},
    }
    selected = tmp_path / "selection.json"
    selected.write_text(json.dumps(selection))
    output = tmp_path / "new_cohort.json"
    arguments = ["prepare_cohort.py"]
    for kind in ("source", "task", "tools", "reference"):
        arguments.extend([f"--{kind}-root", str(tmp_path)])
    arguments.extend(["--jobs-selection", str(selected), "--output", str(output)])
    monkeypatch.setattr("sys.argv", arguments)
    with pytest.raises(ValueError, match="collected"):
        prepare_cohort.main()
    assert not output.exists()
