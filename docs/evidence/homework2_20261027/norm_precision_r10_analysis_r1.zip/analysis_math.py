# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent full-vector NumPy comparisons; no acceptance thresholds."""

import hashlib


def require(condition, message):
    if not condition:
        raise ValueError(message)


def vector(value):
    import numpy as np

    value = np.asarray(value)
    require(
        value.ndim == 1
        and value.size > 0
        and value.dtype.kind == "f"
        and np.isfinite(value).all(),
        "comparison requires nonempty finite floating vectors",
    )
    return value


def array_sha(value):
    import numpy as np

    value = np.asarray(value)
    require(
        value.dtype.kind == "f" and np.isfinite(value).all(),
        "array hash requires finite floating values",
    )
    return hashlib.sha256(
        np.ascontiguousarray(
            value.astype(value.dtype.newbyteorder("<"), copy=False)
        ).tobytes()
    ).hexdigest()


def compare(actual, reference):
    import numpy as np

    actual, reference = vector(actual), vector(reference)
    require(actual.shape == reference.shape, "comparison shape mismatch")
    a, r = actual.astype(np.float64), reference.astype(np.float64)
    delta = a - r
    numerator, denominator = float(np.linalg.norm(delta)), float(np.linalg.norm(r))
    p, q = np.exp(a - a.max()), np.exp(r - r.max())
    p, q = p / p.sum(), q / q.sum()
    return {
        "relative_l2": (
            numerator / denominator
            if denominator
            else (0.0 if numerator == 0 else None)
        ),
        "reference_zero": denominator == 0,
        "max_abs": float(np.abs(delta).max()),
        "max_abs_token_id": int(np.abs(delta).argmax()),
        "mean_signed_difference": float(delta.mean()),
        "argmax_equal": bool(a.argmax() == r.argmax()),
        "value_bits_equal": actual.dtype == reference.dtype
        and array_sha(actual) == array_sha(reference),
        "offline_temperature1_tv": float(np.abs(p - q).sum() / 2),
    }


def top(value, *, count):
    import numpy as np

    value = vector(value)
    require(
        type(count) is int and 1 <= count <= value.size, "invalid explicit top count"
    )
    indices = np.lexsort((np.arange(value.size), -value))[:count]
    return {
        "ids": indices.tolist(),
        "values": value[indices].astype(np.float64).tolist(),
        "argmax": int(value.argmax()),
        "maximum_tie_count": int(np.count_nonzero(value == value.max())),
        "margin": (
            float(
                value[indices[0]].astype(np.float64)
                - value[indices[1]].astype(np.float64)
            )
            if count > 1
            else None
        ),
        "diagnostic_token_values": {
            str(token): float(value[token])
            for token in (198, 271, 25389, 35378)
            if token < value.size
        },
    }


def compare_steps(actual, reference):
    import numpy as np

    actual, reference = np.asarray(actual), np.asarray(reference)
    require(
        actual.ndim == reference.ndim == 2
        and actual.shape == reference.shape
        and actual.shape[0] > 0,
        "step matrix shape mismatch",
    )
    return [
        {"step": step, **compare(a, r)}
        for step, (a, r) in enumerate(zip(actual, reference))
    ]


def summary(rows):
    require(bool(rows), "summary requires comparisons")
    ratios = [row["relative_l2"] for row in rows if row["relative_l2"] is not None]
    return {
        "vectors": len(rows),
        "max_relative_l2": max(ratios) if ratios else None,
        "undefined_relative_l2_steps": [
            row["step"] for row in rows if row["relative_l2"] is None
        ],
        "max_abs": max(row["max_abs"] for row in rows),
        "argmax_matches": sum(row["argmax_equal"] for row in rows),
        "max_offline_temperature1_tv": max(
            row["offline_temperature1_tv"] for row in rows
        ),
    }
