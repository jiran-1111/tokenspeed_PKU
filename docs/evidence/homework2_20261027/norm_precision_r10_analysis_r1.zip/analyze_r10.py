# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Completed-cohort CPU analysis of R10, original R2 and R9; never waits.

NumPy/Torch imports occur only after backend autoload is blocked in main.
Pure helpers and cohort preparation need no Torch or device imports.
"""

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
from pathlib import Path, PureWindowsPath

from analysis_math import array_sha, compare, compare_steps, require, summary, top

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
ARTIFACT_SHA = "169e3069d4fdb70e57aaaffdee9f1a84b3f0001aceb4fe4a007ed66f9eeda1c6"
MODELS = {
    "4b": (
        18,
        "851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a",
        "auxiliary_cpu_fp32_eager_4b",
    ),
    "9b": (
        10,
        "c202236235762e1c871ad0ccb60c8ee5ba337b9a",
        "auxiliary_cpu_fp32_eager_frontier_9b",
    ),
}
ROOT_NAMES = {"source", "task", "tools", "reference"}
VOCAB = 248320


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def relative(root, name):
    require(
        isinstance(name, str)
        and bool(name)
        and not Path(name).anchor
        and not PureWindowsPath(name).anchor
        and ".." not in Path(name).parts
        and ".." not in PureWindowsPath(name).parts,
        "unsafe relative cohort path",
    )
    # Frozen model config/index files may be deployed as symlinks. All reads
    # require an expected SHA; this function never writes through a symlink.
    return Path(root) / name


class BoundFiles:
    """Read helpers requiring an expected SHA for every consumed input file."""

    def __init__(self, roots, cohort):
        require(
            set(roots) == ROOT_NAMES
            and cohort.get("schema_version") == 1
            and set(cohort["files"]) == ROOT_NAMES,
            "input cohort root/schema mismatch",
        )
        self.roots, self.files, self.used = roots, cohort["files"], {}

    def path(self, root, name):
        require(
            name in self.files[root], f"input cohort has no binding for {root}/{name}"
        )
        expected = self.files[root][name]
        require(
            isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected),
            "invalid cohort SHA",
        )
        path = relative(self.roots[root], name)
        require(sha(path) == expected, f"SHA mismatch for {root}/{name}")
        self.used[root, name] = expected
        return path

    def json(self, root, name):
        return json.loads(self.path(root, name).read_text(encoding="utf-8"))

    def recheck(self):
        for (root, name), expected in self.used.items():
            require(
                sha(relative(self.roots[root], name)) == expected,
                "consumed input SHA changed during analysis",
            )


def validate_jobs(jobs):
    require(set(jobs) == set(MODELS), "selected job model coverage mismatch")
    for model in MODELS:
        require(set(jobs[model]) == {"tp1", "tp2"}, "selected job TP coverage mismatch")
        for tp in (1, 2):
            value = jobs[model][f"tp{tp}"]
            relative(Path("."), value)
            path = Path(value)
            require(
                path.parent.as_posix() == "results/raw/homework2_20261027"
                and path.name.startswith(f"norm_precision_{model}_tp{tp}_20261027_r10"),
                "selected job path/model/TP mismatch",
            )
    return jobs


def job_name(model, tp, *, jobs):
    return Path(jobs[model][f"tp{tp}"]).name


def validate_controller(state, *, jobs):
    validate_jobs(jobs)
    require(
        state["status"] == "collected",
        "controller must already be collected; no waiting is performed",
    )
    names = {job_name(model, tp, jobs=jobs) for model in MODELS for tp in (1, 2)}
    require(
        set(state["finished"]) == names
        and state["source_manifest_sha256"] == CORE_SHA
        and state["original_queue_retained_paused"] is True
        and state["performance_eligible"] is False
        and state["runtime_math_changed_by_external_override"] is True
        and state["not_final_source"] is True
        and state["new_threshold"] is None,
        "completed controller source/scope/queue mismatch",
    )
    for model in MODELS:
        cards = []
        for tp in (1, 2):
            name = job_name(model, tp, jobs=jobs)
            row = state["finished"][name]
            require(
                row["job"] == name
                and row["exit_code"] == 0
                and row["own_contexts_released"] is True
                and row["all_dtype_boundaries_verified"] is True
                and len(row["chips"]) == tp,
                "job failed, unreleased or dtype validation missing",
            )
            cards.append(row["npu_id"])
        require(cards[0] == cards[1], "same-model TP1/TP2 physical card mismatch")


def validate_record(record, sample, case, *, step, rank, original_dtype):
    import numpy as np

    count = len(case["continuation_ids"]) + 1
    require(0 <= step < count, "frontier step out of range")
    ids = case["input_ids"] if step == 0 else [case["continuation_ids"][step - 1]]
    positions = (
        list(range(len(ids))) if step == 0 else [len(case["input_ids"]) + step - 1]
    )
    v = record["logits"]
    require(
        isinstance(v, np.ndarray)
        and v.ndim == 1
        and v.dtype == np.float32
        and v.size > 0
        and np.isfinite(v).all(),
        "logits must retain finite FP32 capture values",
    )
    greedy = int(v.argmax())
    require(
        record["case_id"] == case["case_id"]
        and record["step"] == step
        and record["rank"] == rank
        and record["input_ids"] == ids
        and record["positions"] == positions
        and record["prefix_length"] == len(case["input_ids"]) + step
        and record["original_dtype"] == original_dtype
        and record["raw_greedy_id"] == greedy,
        "original input/position/case/dtype frontier mismatch",
    )
    require(
        sample["rank"] == rank
        and sample["raw_greedy_id"] == greedy
        and sample["forced"] is (step < count - 1)
        and sample["emitted_id"]
        == (
            case["continuation_ids"][step]
            if step < count - 1
            else sample["broadcast_sampled_id"]
        )
        and (rank != 0 or sample["broadcast_sampled_id"] == greedy),
        "original greedy/broadcast/forcing mismatch",
    )


def verify_core(source):
    manifest_path = source / "docs/evidence/homework2_20261023/source_manifest.json"
    require(sha(manifest_path) == CORE_SHA, "core source manifest SHA mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(len(manifest) == 1531, "core source file coverage mismatch")
    for name, expected in manifest.items():
        require(
            sha(relative(source, name)) == expected, "frozen core source file mismatch"
        )


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    for name in (
        "source-root",
        "task-root",
        "tools-root",
        "reference-root",
        "input-cohort",
        "output",
    ):
        result.add_argument(f"--{name}", type=Path, required=True)
    result.add_argument("--threads", type=int, required=True)
    return result


def required_inputs(roots, *, jobs):
    """Enumerate the explicit completed cohort; used by prepare_cohort.py."""
    paths = {name: set() for name in ROOT_NAMES}
    state = json.loads((roots["tools"] / "state.json").read_text(encoding="utf-8"))
    validate_controller(state, jobs=jobs)
    paths["tools"].update(
        (
            "state.json",
            "tool_manifest.json",
            "preparation.json",
            "precision_protocol.json",
            "validate_r10_dtype.py",
        )
    )
    paths["tools"].update(
        json.loads((roots["tools"] / "tool_manifest.json").read_text(encoding="utf-8"))
    )
    paths["task"].update(("frontier_analysis_r2.json", "precision_analysis_r9.json"))
    paths["source"].update(
        (
            "docs/evidence/homework2_20261023/source_manifest.json",
            "docs/evidence/homework2_20261023/model_artifacts.json",
        )
    )
    for model, (count, _, ref_name) in MODELS.items():
        paths["tools"].add(f"case_{model}.json")
        paths["reference"].update(
            f"{ref_name}/{name}"
            for name in (
                "reference_state.json",
                "input_128_greedy_logits.pt",
                "inputs.json",
                "weight_identity.json",
            )
        )
        for tp in (1, 2):
            config_name = f"configs/homework2/qwen35_{model}_tp{tp}.yaml"
            paths["source"].add(config_name)
            config = json.loads(
                relative(roots["source"], config_name).read_text(encoding="utf-8")
            )
            paths["source"].update(
                f'{config["local_model_path"]}/{name}'
                for name in ("config.json", "model.safetensors.index.json")
            )
            paths["tools"].add(
                f"{job_name(model, tp, jobs=jobs)}.dtype_validation.json"
            )
            selected = [
                ("source", jobs[model][f"tp{tp}"]),
                ("reference", f"frontier_diagnostic_{model}_tp{tp}_20261024_r2"),
                ("reference", f"precision_diagnostic_{model}_tp{tp}_20261024_r9"),
            ]
            for root, directory in selected:
                paths[root].add(f"{directory}/diagnostic.json")
                for rank in range(tp):
                    for step in range(count):
                        paths[root].update(
                            f"{directory}/rank_{rank}/step_{step:02d}.{suffix}"
                            for suffix in ("pt", "json")
                        )
                    if root == "source":
                        paths[root].update(
                            f"{directory}/{stem}_rank{rank}.jsonl"
                            for stem in (
                                "precision_rows",
                                "precision_columns",
                                "precision_residual",
                            )
                        )
    return paths


def check_run(run, *, case, count, config, candidate):
    expected_config = {
        **config,
        "enforce_eager": True,
        "overlap_schedule": False,
        "prefix_caching": False,
        "disable_kvstore": True,
        "prometheus_port": 39581,
        "tokenspeed_metrics_port": 39582,
    }
    guard = run["guard"]
    require(
        run["status"] == "collected"
        and run["vectors_per_rank"] == count
        and run["case"] == case
        and run["execution_mode"] == "eager"
        and run["diagnostic_only"] is True
        and run["performance_eligible"] is False
        and run["original_graph_failures_preserved"] is True
        and run["config"] == expected_config,
        "run source/config/frontier mismatch",
    )
    require(
        guard["sources_sha"] == guard["sources_after_sha"] == CORE_SHA
        and guard["sources_unchanged"] is True
        and guard["own_children_released"] is True
        and guard["violations"] == [],
        "run source/own-release/background guard mismatch",
    )
    if candidate:
        require(
            run["runtime_math_changed_by_external_override"] is True,
            "candidate must declare changed runtime math",
        )


def canonical_dtype_report(report, job):
    """Ignore only absolute-root spelling while retaining every evidence SHA."""
    result = json.loads(json.dumps(report, allow_nan=False))
    files = {}
    for name, digest in result["evidence_files"].items():
        parts = PureWindowsPath(name).parts if "\\" in name else Path(name).parts
        require(parts.count(job) == 1, "dtype evidence file has wrong job binding")
        suffix = "/".join(parts[parts.index(job) + 1 :])
        require(suffix and suffix not in files, "dtype evidence paths collide")
        files[suffix] = digest
    result["evidence_files"] = files
    return result


def load_matrix(bound, root, directory, case, *, rank, model, torch):
    import numpy as np

    vectors, samples = [], []
    dtype = "torch.bfloat16" if model == "4b" else "torch.float32"
    for step in range(MODELS[model][0]):
        prefix = f"{directory}/rank_{rank}/step_{step:02d}"
        record = torch.load(
            bound.path(root, prefix + ".pt"), map_location="cpu", weights_only=True
        )
        v = record["logits"]
        require(
            isinstance(v, torch.Tensor)
            and v.device.type == "cpu"
            and v.dtype == torch.float32
            and tuple(v.shape) == (VOCAB,)
            and bool(torch.isfinite(v).all()),
            "captured tensor payload shape/dtype mismatch",
        )
        record["logits"] = v.numpy().copy()
        sample = bound.json(root, prefix + ".json")
        validate_record(
            record, sample, case, step=step, rank=rank, original_dtype=dtype
        )
        vectors.append(record["logits"])
        samples.append(sample)
    return np.stack(vectors), samples


def main():
    args = parser().parse_args()
    require(args.threads > 0, "positive threads required")
    roots = {
        name: getattr(args, f"{name}_root").resolve(strict=True) for name in ROOT_NAMES
    }
    output, npz_path = args.output.resolve(), args.output.resolve().with_suffix(
        ".vectors.npz"
    )
    require(
        output != npz_path
        and output.parent.is_dir()
        and not output.exists()
        and not npz_path.exists(),
        "new output paths required",
    )
    cohort_bytes = args.input_cohort.read_bytes()
    cohort_sha = hashlib.sha256(cohort_bytes).hexdigest()
    cohort = json.loads(cohort_bytes)
    jobs = validate_jobs(cohort["jobs"])
    bound = BoundFiles(roots, cohort)
    state = bound.json("tools", "state.json")
    validate_controller(state, jobs=jobs)
    verify_core(roots["source"])
    tools_manifest = bound.json("tools", "tool_manifest.json")
    require(
        sha(bound.path("tools", "tool_manifest.json"))
        == cohort["tools_manifest_sha256"],
        "selected hardware tool manifest SHA mismatch",
    )
    require(
        bound.json("tools", "preparation.json")["passed"] is True,
        "hardware tools preparation not passed",
    )
    for name, expected in tools_manifest.items():
        require(
            sha(bound.path("tools", name)) == expected,
            "hardware tool manifest mismatch",
        )
    protocol = bound.json("tools", "precision_protocol.json")
    require(
        protocol["experiment_id"] == "R10_norm_output_fp32"
        and protocol["reference_policy"] == "R9"
        and protocol["runtime_math_changed_by_external_override"] is True
        and protocol["not_final_source_validation"] is True
        and protocol["thresholds_added"] is False,
        "R10 mathematical factor protocol mismatch",
    )
    require(
        "torch" not in sys.modules and "torch_npu" not in sys.modules,
        "clean CPU analysis process required",
    )
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    sys.modules["torch_npu"] = None
    import numpy as np
    import torch

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    validator_path = bound.path("tools", "validate_r10_dtype.py")
    spec = importlib.util.spec_from_file_location(
        "bound_r10_dtype_validator", validator_path
    )
    validator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(validator)
    artifacts_path = bound.path(
        "source", "docs/evidence/homework2_20261023/model_artifacts.json"
    )
    require(
        sha(artifacts_path) == ARTIFACT_SHA, "frozen model artifacts manifest mismatch"
    )
    artifacts = json.loads(artifacts_path.read_text(encoding="utf-8"))["models"]
    old = {
        name: bound.json("task", filename)
        for name, filename in (
            ("r2", "frontier_analysis_r2.json"),
            ("r9", "precision_analysis_r9.json"),
        )
    }
    report = {
        "status": "analyzed",
        "diagnostic_only": True,
        "performance_eligible": False,
        "acceptance_threshold": None,
        "thresholds_added": False,
        "execution_mode": "eager",
        "runtime_math_changed_by_external_override": True,
        "candidate_policy": "R10 relative to R9",
        "not_final_source_validation": True,
        "original_graph_failures_preserved": True,
        "runtime_weight_identity_certified": False,
        "core_source_manifest_sha256": CORE_SHA,
        "core_files": 1531,
        "input_cohort_sha256": cohort_sha,
        "threads": args.threads,
        "analysis_sha256": sha(Path(__file__)),
        "math_sha256": sha(Path(__file__).with_name("analysis_math.py")),
        "offline_tv_definition": "Temperature1 softmax diagnostic, not the actual greedy sampler distribution.",
        "models": {},
    }
    arrays = {}
    for model, (count, revision, ref_name) in MODELS.items():
        case_path = bound.path("tools", f"case_{model}.json")
        case = json.loads(case_path.read_text(encoding="utf-8"))
        case_sha = sha(case_path)
        require(
            case_sha == cohort["case_sha256"][model],
            "selected original case SHA mismatch",
        )
        require(
            len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) + 1 == count
            and case["vector_count"] == count
            and case["case_id"] == f"hw2_{model}_short_first_divergence",
            "original case mismatch",
        )
        ref_state = bound.json("reference", f"{ref_name}/reference_state.json")
        expected_reference = cohort["reference_identities"][model]
        require(
            sha(bound.path("reference", f"{ref_name}/reference_state.json"))
            == expected_reference["reference_state_sha256"]
            and ref_state["global_weight_sha256"]
            == expected_reference["global_weight_sha256"],
            "selected CPU reference identity mismatch",
        )
        require(
            ref_state["status"] == "collected"
            and ref_state["source_unchanged"] is True
            and ref_state["source_manifest_sha256"] == CORE_SHA
            and ref_state["model_revision"] == revision
            and ref_state["npu_import_blocked"] is True,
            "CPU reference provenance mismatch",
        )
        inputs = bound.path("reference", f"{ref_name}/inputs.json")
        require(
            sha(inputs) == ref_state["input_sha256"], "CPU original inputs SHA mismatch"
        )
        identity = bound.json("reference", f"{ref_name}/weight_identity.json")
        require(
            identity["global_weight_sha256"] == ref_state["global_weight_sha256"],
            "CPU projected-weight identity mismatch",
        )
        ref_path = bound.path("reference", f"{ref_name}/input_128_greedy_logits.pt")
        entries = [row for row in ref_state["cases"] if row["input_length"] == 128]
        require(
            len(entries) == 1 and sha(ref_path) == entries[0]["logits_sha256"],
            "CPU reference vector SHA mismatch",
        )
        require(
            sha(ref_path) == expected_reference["logits_sha256"],
            "selected CPU vector SHA mismatch",
        )
        cpu = torch.load(ref_path, map_location="cpu", weights_only=True)
        require(
            cpu["input_ids"] == case["input_ids"]
            and cpu["logits"].dtype == torch.float32
            and cpu["logits"].device.type == "cpu"
            and cpu["logits"].shape[0] >= count
            and cpu["logits"].shape[1] == VOCAB
            and bool(torch.isfinite(cpu["logits"]).all()),
            "CPU reference tensor/frontier mismatch",
        )
        require(
            (
                model == "4b"
                and cpu["generated_ids"][: count - 1] == case["continuation_ids"]
            )
            or (model == "9b" and ref_state["case"] == case),
            "CPU reference continuation mismatch",
        )
        reference = cpu["logits"][:count].numpy().copy()
        arrays[f"{model}_cpu_reference"] = reference
        item = {
            "case": case,
            "case_sha256": case_sha,
            "model_revision": revision,
            "vocabulary_head_dtype": (
                "torch.bfloat16" if model == "4b" else "torch.float32"
            ),
            "reference_projected_weight_sha256": ref_state["global_weight_sha256"],
            "cpu_reference_sha256": sha(ref_path),
            "dtype_validation": {},
            "captures": {},
            "comparisons": {},
        }
        groups = {name: {} for name in ("r10", "r2", "r9")}
        for name in ("r2", "r9"):
            previous = old[name]["models"][model]
            require(
                previous["case"] == case
                and previous["case_sha256"] == case_sha
                and previous["reference_projected_weight_sha256"]
                == ref_state["global_weight_sha256"]
                and previous["reference_sha256"] == sha(ref_path),
                "previous analysis reference/case identity mismatch",
            )
            item[f"previous_{name}_summary"] = previous["summary"]
        for tp in (1, 2):
            config_name = f"configs/homework2/qwen35_{model}_tp{tp}.yaml"
            config = bound.json("source", config_name)
            require(
                config["model_revision"] == revision
                and config["dtype"] == "bfloat16"
                and config["tp_size"] == tp
                and config.get("hf_overrides", {}).get("npu_lm_head_dtype")
                == ("float32" if model == "9b" else None),
                "original per-model head/config mismatch",
            )
            artifact = [
                a
                for a in artifacts
                if a["model_id"] == config["model_id"]
                and a["model_revision"] == revision
            ]
            require(len(artifact) == 1, "model artifact revision ambiguity")
            model_config_name = f'{config["local_model_path"]}/config.json'
            model_config_path = bound.path("source", model_config_name)
            model_config = json.loads(model_config_path.read_text(encoding="utf-8"))
            for filename in ("config.json", "model.safetensors.index.json"):
                path = bound.path("source", f'{config["local_model_path"]}/{filename}')
                expected = artifact[0]["files"][filename]
                require(
                    path.stat().st_size == expected["bytes"]
                    and sha(path) == expected["sha256"],
                    "model config/index artifact SHA mismatch",
                )
            directory = jobs[model][f"tp{tp}"]
            job = job_name(model, tp, jobs=jobs)
            run = bound.json("source", directory + "/diagnostic.json")
            check_run(run, case=case, count=count, config=config, candidate=True)
            require(run["case_sha256"] == case_sha, "candidate case file SHA mismatch")
            for rank in range(tp):
                for stem in (
                    "precision_rows",
                    "precision_columns",
                    "precision_residual",
                ):
                    bound.path("source", f"{directory}/{stem}_rank{rank}.jsonl")
            fresh = validator.validate_job(
                relative(roots["source"], directory),
                case=case,
                config=config,
                model_config=model_config,
            )
            saved = bound.json("tools", f"{job}.dtype_validation.json")
            require(
                fresh["passed"] is True
                and canonical_dtype_report(fresh, job)
                == canonical_dtype_report(saved, job),
                "saved dtype validation differs from fresh validation",
            )
            item["dtype_validation"][f"tp{tp}"] = canonical_dtype_report(fresh, job)
            for name, root, folder in (
                ("r10", "source", directory),
                ("r2", "reference", f"frontier_diagnostic_{model}_tp{tp}_20261024_r2"),
                ("r9", "reference", f"precision_diagnostic_{model}_tp{tp}_20261024_r9"),
            ):
                old_run = bound.json(root, folder + "/diagnostic.json")
                check_run(
                    old_run,
                    case=case,
                    count=count,
                    config=config,
                    candidate=name != "r2",
                )
                require(old_run["case_sha256"] == case_sha, "run case SHA mismatch")
                for rank in range(tp):
                    key = f"tp{tp}_rank{rank}"
                    matrix, samples = load_matrix(
                        bound, root, folder, case, rank=rank, model=model, torch=torch
                    )
                    groups[name][key] = matrix
                    arrays[f"{model}_{name}_{key}"] = matrix
                    metrics = compare_steps(matrix, reference)
                    item["captures"][f"{name}_{key}"] = {
                        "vs_cpu": metrics,
                        "summary_vs_cpu": summary(metrics),
                        "sampling": samples,
                        "vector_sha256": [array_sha(v) for v in matrix],
                        "top10": [top(v, count=10) for v in matrix],
                    }
                    if name in old:
                        rows = old[name]["models"][model]["captures"][key]["vectors"]
                        require(
                            len(rows) == count
                            and all(
                                bound.used[
                                    root, f"{folder}/rank_{rank}/step_{s:02d}.pt"
                                ]
                                == rows[s]["capture_sha256"]
                                for s in range(count)
                            ),
                            "old analysis/capture SHA correspondence mismatch",
                        )
        item["cpu_top10"] = [top(v, count=10) for v in reference]
        for name, captures in groups.items():
            comparisons = {
                "tp2_vs_tp1": compare_steps(
                    captures["tp2_rank0"], captures["tp1_rank0"]
                ),
                "tp2_rank1_vs_rank0": compare_steps(
                    captures["tp2_rank1"], captures["tp2_rank0"]
                ),
            }
            item["comparisons"][name] = {
                key: {"steps": rows, "summary": summary(rows)}
                for key, rows in comparisons.items()
            }
        for previous in ("r2", "r9"):
            item["comparisons"][f"r10_vs_{previous}"] = {
                key: {
                    "steps": compare_steps(value, groups[previous][key]),
                    "summary": summary(compare_steps(value, groups[previous][key])),
                }
                for key, value in groups["r10"].items()
            }
        report["models"][model] = item
    verify_core(roots["source"])
    bound.recheck()
    require(
        sha(args.input_cohort) == cohort_sha and sys.modules.get("torch_npu") is None,
        "cohort changed or device backend loaded",
    )
    report["source_and_inputs_reverified_after"] = True
    report["consumed_file_sha256"] = {
        name: {
            path: digest for (root, path), digest in bound.used.items() if root == name
        }
        for name in ROOT_NAMES
    }
    report["arrays"] = {
        name: {"shape": list(a.shape), "dtype": str(a.dtype), "sha256": array_sha(a)}
        for name, a in arrays.items()
    }
    with npz_path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    report["vectors_file"] = {
        "name": npz_path.name,
        "sha256": sha(npz_path),
        "selected_vectors": sum(a.shape[0] for a in arrays.values()),
    }
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "status": "analyzed",
                "models": 2,
                "exported_vectors": report["vectors_file"]["selected_vectors"],
                "thresholds_added": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "reason": (
                        str(error)
                        if isinstance(error, ValueError)
                        else "input or execution failure"
                    ),
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)
