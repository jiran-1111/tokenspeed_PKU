# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Freeze explicit inputs only after the selected four-job controller completed."""

import argparse
import json
import sys
from pathlib import Path

from analysis_math import require
from analyze_r10 import MODELS, ROOT_NAMES, relative, required_inputs, sha, verify_core


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "source-root",
        "task-root",
        "tools-root",
        "reference-root",
        "jobs-selection",
        "output",
    ):
        parser.add_argument(f"--{name}", type=Path, required=True)
    args = parser.parse_args()
    roots = {
        name: getattr(args, f"{name}_root").resolve(strict=True) for name in ROOT_NAMES
    }
    require(
        args.output.parent.is_dir() and not args.output.exists(),
        "new cohort output required",
    )
    selection = json.loads(args.jobs_selection.read_text(encoding="utf-8"))
    require(
        set(selection)
        == {"jobs", "tools_manifest_sha256", "case_sha256", "reference_identities"},
        "explicit job/tool/case/reference selection required",
    )
    inputs = required_inputs(roots, jobs=selection["jobs"])
    verify_core(roots["source"])
    files = {
        root: {name: sha(relative(roots[root], name)) for name in sorted(names)}
        for root, names in inputs.items()
    }
    require(
        files["tools"]["tool_manifest.json"] == selection["tools_manifest_sha256"],
        "selected tool manifest SHA mismatch",
    )
    for model, (_, _, ref_name) in MODELS.items():
        require(
            files["tools"][f"case_{model}.json"] == selection["case_sha256"][model],
            "selected original case SHA mismatch",
        )
        expected = selection["reference_identities"][model]
        require(
            files["reference"][f"{ref_name}/reference_state.json"]
            == expected["reference_state_sha256"]
            and files["reference"][f"{ref_name}/input_128_greedy_logits.pt"]
            == expected["logits_sha256"],
            "selected CPU reference SHA mismatch",
        )
    cohort = {"schema_version": 1, **selection, "files": files}
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(cohort, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "status": "cohort_frozen",
                "files": sum(map(len, files.values())),
                "sha256": sha(args.output),
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "reason": (
                        str(error) if isinstance(error, ValueError) else "input failure"
                    ),
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)
