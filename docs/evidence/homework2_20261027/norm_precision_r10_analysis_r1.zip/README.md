# R10 completed-cohort CPU analysis

The analyzer never waits and never starts a model or device worker. It requires
all four selected tasks to be collected, exit 0, own-context released, dtype
verified, and the original queue retained paused. Failed/partial cohorts cannot
be combined. It validates the frozen 1531 core files before and after analysis.

`jobs_selection.json` is the explicitly pinned **retry2 selection**, including
the tool manifest supplied by the parent, original case SHA values and original
CPU reference identities. Retry2 later failed its fourth task; this selection
is retained and must not produce a complete cohort. For a new retry, create a
new selection file with all four source-relative job paths and its new hardware
tools manifest SHA. No analyzer code changes or automatic fallback are needed.

Required roots:

- `source-root`: frozen `source_final`, including new raw jobs under
  `results/raw/homework2_20261027/`.
- `task-root`: the task directory containing `frontier_analysis_r2.json` and
  `precision_analysis_r9.json`.
- `tools-root`: the selected retry's complete hardware tool snapshot, including
  `state.json`, `preparation.json`, `tool_manifest.json`, original cases,
  `validate_r10_dtype.py` and each `{job}.dtype_validation.json`.
- `reference-root`: original `source_final/results/raw/homework2_20261024`,
  containing both original CPU references and original R2/R9 raw jobs.

All paths and all analysis arguments are explicit. Output files must not exist.
The cohort builder hashes every selected file, then the analyzer verifies each
read against this cohort and checks consumed hashes again after computation.
Model config/index hashes are matched to the frozen model artifacts. Runtime
weights are not re-exported or certified; the original CPU projected-weight
identity and model revisions are checked instead.

```bash
python -B -m pytest "$ANALYSIS/test_analysis_r10.py" -q -p no:cacheprovider \
  --basetemp "$ANALYSIS/new-pytest-workspace" -W error

python -B "$ANALYSIS/prepare_cohort.py" \
  --source-root "$SOURCE" --task-root "$TASK" --tools-root "$TOOLS" \
  --reference-root "$REFERENCE" --jobs-selection "$NEW_SELECTION" \
  --output "$NEW_COHORT"

python -B "$ANALYSIS/analyze_r10.py" \
  --source-root "$SOURCE" --task-root "$TASK" --tools-root "$TOOLS" \
  --reference-root "$REFERENCE" --input-cohort "$NEW_COHORT" \
  --output "$NEW_REPORT" --threads 8
```

`analyze_r10.py` blocks Torch device backend autoload before importing Torch.
The same selected `validate_job(job, case=..., config=..., model_config=...)`
is rerun against all R10 logs and compared to the controller's saved validation.
Only absolute-root spelling in evidence paths is normalized; hashes, fields and
values remain strict. PT tensor contents are separately validated here: full
vocabulary, dtype, case/input/positions, raw argmax, broadcasts and fixed prefix.

The JSON records every vector comparison, deterministic top10 (ties by low
token ID), raw argmax/margins, CPU/R2/R9 comparisons and complete provenance.
Temperature1 TV is an offline transformation, not the original greedy sampler.
There are no numeric pass thresholds. Candidate math is explicitly marked as
an external override and not final source validation; the 4B head remains BF16.

The adjacent `*.vectors.npz` retains all selected R10, R2, R9 and CPU reference
vectors: 280 full vectors across the two models. Each of its 20 arrays has shape
`[steps,248320]`, original FP32 capture values and a canonical little-endian SHA
in the JSON. This supports independent local NumPy recomputation without
Torch or the server. Array keys are `{model}_{r10|r2|r9}_tp{tp}_rank{rank}` and
`{model}_cpu_reference`. Load with `numpy.load(path, allow_pickle=False)`.

Local testing covers pure NumPy math, strict controller/frontier/cohort rules
and fail-fast cohort preparation. Real Torch PT loading and the complete
archived-input invocation still require the parent's CPU server run.
