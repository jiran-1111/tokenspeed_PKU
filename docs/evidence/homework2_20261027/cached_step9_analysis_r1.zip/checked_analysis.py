#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Bind the CPU analysis to immutable original input files and released jobs."""

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path, PureWindowsPath

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while data := f.read(8 * 1024 * 1024):
            digest.update(data)
    return digest.hexdigest()


def within(root, name):
    if (
        not isinstance(name, str)
        or not name
        or Path(name).is_absolute()
        or PureWindowsPath(name).drive
        or PureWindowsPath(name).root
    ):
        raise ValueError("evidence path must be relative")
    result = (root / name).resolve()
    if result == root or not result.is_relative_to(root):
        raise ValueError("evidence path escapes root")
    return result


def check_inputs(root, manifest):
    root = Path(root).resolve()
    if not isinstance(manifest, dict) or not manifest:
        raise ValueError("nonempty SHA-bound inputs required")
    for name, expected in manifest.items():
        path = within(root, name)
        if (
            not isinstance(expected, str)
            or not re.fullmatch("[0-9a-f]{64}", expected)
            or sha(path) != expected
        ):
            raise ValueError("original input SHA mismatch")
    return len(manifest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("task-root", "input-manifest", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    if args.threads < 1:
        raise ValueError("positive CPU threads required")
    root = args.task_root.resolve()
    selection = json.loads(args.input_manifest.read_text())
    count = check_inputs(root, selection["files"])
    source = root / "source_final"
    core = source / "docs/evidence/homework2_20261023/source_manifest.json"
    if sha(core) != CORE_SHA:
        raise ValueError("fixed source manifest mismatch")
    core_files = json.loads(core.read_text())
    if len(core_files) != 1531:
        raise ValueError("fixed core count mismatch")
    check_inputs(source, core_files)
    controller = json.loads(within(root, selection["controller"]).read_text())
    if (
        controller["status"] != "collected"
        or controller["source_manifest_sha256"] != CORE_SHA
        or len(controller["finished"]) != 2
    ):
        raise ValueError("source/controller completion mismatch")
    if (
        not all(
            v["exit_code"] == 0 and v["own_contexts_released"] is True
            for v in controller["finished"].values()
        )
        or len({v["npu_id"] for v in controller["finished"].values()}) != 1
    ):
        raise ValueError("outer release or same-card scope unverified")
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    import analyze_cached

    previous = sys.argv
    try:
        sys.argv = [
            str(Path(__file__).with_name("analyze_cached.py")),
            "--jobs-manifest",
            str(Path(__file__).with_name("selected_jobs.json")),
            "--baseline-jobs-manifest",
            str(Path(__file__).with_name("baseline_jobs.json")),
            "--output",
            str(args.output),
            "--threads",
            str(args.threads),
        ]
        for name in ("root", "baseline-root", "cpu-norm-reference"):
            sys.argv += [
                "--" + name,
                str(within(root, selection["analysis_paths"][name])),
            ]
        analyze_cached.main()
    finally:
        sys.argv = previous
    check_inputs(root, selection["files"])
    check_inputs(source, core_files)
    receipt = {
        "passed": True,
        "source_files": 1531,
        "source_manifest_sha256": CORE_SHA,
        "source_unchanged": True,
        "input_files": count,
        "input_files_unchanged": True,
        "input_manifest_sha256": sha(args.input_manifest),
        "wrapper_sha256": sha(Path(__file__)),
        "analysis_sha256": sha(args.output),
        "outer_release_verified": True,
        "same_card_verified": True,
        "npu_execution": False,
        "thresholds_added": False,
    }
    with args.output.with_suffix(".checked.json").open("x") as f:
        json.dump(receipt, f, indent=2)
        f.write("\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
