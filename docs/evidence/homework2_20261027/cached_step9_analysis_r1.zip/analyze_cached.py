#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU-only references for the observed 9B cached step9, without replaying history."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path, PureWindowsPath

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
NORM_LABELS = (
    "fa7.input_layernorm",
    "fa7.post_attention_layernorm",
    *(
        f"l{layer}.{name}"
        for layer in (8, 9, 10)
        for name in ("input_layernorm", "post_attention_layernorm")
    ),
    "l11.input_layernorm",
)
MODULE_LABELS = {
    "fa7",
    "fa7.input_layernorm",
    "fa7.post_attention_layernorm",
    "fa7.qkv_proj",
    "fa7.rotary_emb",
    "fa7.attn",
    "fa7.o_proj",
    "fa7.mlp.gate_up_proj",
    "fa7.mlp.down_proj",
    "l11.input_layernorm",
    *(
        f"l{layer}.{name}"
        for layer in (8, 9, 10)
        for name in (
            "input_layernorm",
            "post_attention_layernorm",
            "linear_attn",
            "linear_attn.in_proj_qkvzba",
            "linear_attn.norm",
            "linear_attn.out_proj",
            "mlp.gate_up_proj",
            "mlp.down_proj",
        )
    ),
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def compare(actual, reference, *, head_axis=None):
    import numpy as np

    actual, reference = np.asarray(actual), np.asarray(reference)
    require(
        actual.shape == reference.shape and actual.size > 0, "comparison shape mismatch"
    )
    require(
        np.isfinite(actual).all() and np.isfinite(reference).all(),
        "comparison requires finite values",
    )
    delta = actual.astype(np.float64) - reference.astype(np.float64)
    norm, denominator = np.linalg.norm(delta.ravel()), np.linalg.norm(
        reference.astype(np.float64).ravel()
    )
    result = {
        "shape": list(actual.shape),
        "relative_l2": (
            float(norm / denominator) if denominator else (0.0 if norm == 0 else None)
        ),
        "reference_zero": bool(denominator == 0),
        "max_abs": float(np.abs(delta).max()),
        "max_abs_index": [
            int(x) for x in np.unravel_index(np.abs(delta).argmax(), delta.shape)
        ],
        "different_elements": int(np.count_nonzero(delta)),
        "elements": int(actual.size),
        "exact_equal": bool(np.array_equal(actual, reference)),
        "value_bits_equal": bool(
            np.array_equal(
                actual.astype(np.float32).view(np.uint32),
                reference.astype(np.float32).view(np.uint32),
            )
        ),
    }
    if head_axis is not None:
        result["head_axis"] = head_axis
        result["per_head"] = [
            compare(
                np.take(actual, index, axis=head_axis),
                np.take(reference, index, axis=head_axis),
            )
            for index in range(actual.shape[head_axis])
        ]
    return result


def storage_reference(value, dtype):
    import numpy as np

    value = np.asarray(value, dtype=np.float32)
    require(np.isfinite(value).all(), "storage reference requires finite values")
    if dtype == "torch.float32":
        return value.copy()
    require(dtype == "torch.bfloat16", "unsupported actual storage dtype")
    bits = value.view(np.uint32)
    return (
        (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(0xFFFF0000)
    ).view(np.float32)


def cached_gqa(q, k, v, *, scaling):
    import numpy as np

    require(
        q.ndim == k.ndim == v.ndim == 3
        and q.shape[0] == 1
        and k.shape == v.shape
        and k.shape[0] == 137
        and q.shape[1] % k.shape[1] == 0
        and q.shape[2] == k.shape[2],
        "cached GQA shape mismatch",
    )
    index = np.arange(q.shape[1]) // (q.shape[1] // k.shape[1])
    score = np.einsum("thd,shd->hts", q, k[:, index], optimize=True) * np.float32(
        scaling
    )
    probability = np.exp(score - score.max(axis=-1, keepdims=True))
    probability /= probability.sum(axis=-1, keepdims=True)
    return np.einsum("hts,shd->thd", probability, v[:, index], optimize=True)


def kv_checks(before, after, current_k, current_v):
    require(
        before["k"].shape == before["v"].shape == (136, *current_k.shape[1:])
        and after["k"].shape == after["v"].shape == (137, *current_k.shape[1:])
        and current_k.shape == current_v.shape
        and current_k.shape[0] == 1,
        "KV prefix/current shape mismatch",
    )
    return {
        f"{name}_prefix_before_vs_after": compare(
            after[name][:-1], before[name], head_axis=1
        )
        for name in ("k", "v")
    } | {
        "k_current_vs_actual_input": compare(after["k"][-1:], current_k, head_axis=1),
        "v_current_vs_actual_input": compare(after["v"][-1:], current_v, head_axis=1),
    }


def join_packed(ranks, *, widths, axis):
    import numpy as np

    require(
        all(value.shape[axis] == sum(widths) for value in ranks),
        "packed channel shape mismatch",
    )
    segments = [np.split(value, np.cumsum(widths)[:-1], axis=axis) for value in ranks]
    return np.concatenate(
        [
            np.concatenate([rank[i] for rank in segments], axis=axis)
            for i in range(len(widths))
        ],
        axis=axis,
    )


def text_position(value):
    import numpy as np

    require(
        value.dtype.kind in "iu"
        and value.shape in ((1,), (3, 1))
        and bool(np.all(value == 136)),
        "actual position must be integer136 on one or three identical axes",
    )
    return value.reshape(-1)[:1]


def select_jobs(root, manifest):
    require(
        isinstance(manifest, dict)
        and set(manifest) == {"9b"}
        and isinstance(manifest["9b"], dict)
        and set(manifest["9b"]) == {"tp1", "tp2"},
        "jobs manifest coverage mismatch",
    )
    root = Path(root).resolve()
    selected = {}
    for key in ("tp1", "tp2"):
        name = manifest["9b"][key]
        require(
            isinstance(name, str) and bool(name),
            "jobs manifest requires nonempty relative paths",
        )
        relative = Path(name)
        require(
            not relative.is_absolute()
            and not PureWindowsPath(name).drive
            and not PureWindowsPath(name).root,
            "jobs manifest paths must be relative",
        )
        target = (root / relative).resolve()
        require(
            target != root and target.is_relative_to(root),
            "jobs manifest path escapes root",
        )
        selected[key] = target
    return selected


def validate_run(run):
    require(run["status"] == "collected", "diagnostic is not collected")
    guard = run["guard"]
    require(
        guard["sources_sha"] == guard["sources_after_sha"] == CORE_SHA
        and guard["sources_unchanged"] is True
        and guard["own_children_released"] is True
        and guard["violations"] == [],
        "diagnostic guard mismatch",
    )
    require(
        run["diagnostic_only"] is True
        and run["execution_mode"] == "eager"
        and run["performance_eligible"] is False
        and run["original_graph_failures_preserved"] is True,
        "diagnostic scope mismatch",
    )


def gdn_local_references(decode, scan, before, after, *, reference, ssm_dtype):
    import numpy as np

    conv = reference.conv_update_reference(
        decode["mixed_qkv"][0],
        before["conv_state"],
        decode["conv_weights"],
        activation=decode["metadata"]["activation"],
    )
    actual_conv = np.concatenate(
        [scan[name][0, 0].reshape(-1) for name in ("q", "k", "v")]
    )
    # Recurrence always consumes the ACTUAL conv/scan operands, never conv[output].
    recurrent = reference.gdn_decode_reference(
        scan["q"][0, 0],
        scan["k"][0, 0],
        scan["v"][0, 0],
        before["ssm_state"],
        A_log=scan["A_log"],
        a=scan["a"][0],
        dt_bias=scan["dt_bias"],
        b=scan["b"][0],
        use_qk_l2norm=True,
    )
    return {
        "conv_output_fp32": compare(actual_conv, conv["output"]),
        "conv_output_storage_bf16": compare(
            actual_conv, storage_reference(conv["output"], "torch.bfloat16")
        ),
        "conv_after_state_fp32": compare(after["conv_state"], conv["conv_after"]),
        "conv_after_state_storage": compare(
            after["conv_state"], storage_reference(conv["conv_after"], "torch.bfloat16")
        ),
        "recurrence_output_fp32": compare(
            scan["output"][0, 0], recurrent["output"], head_axis=0
        ),
        "recurrence_output_storage_bf16": compare(
            scan["output"][0, 0],
            storage_reference(recurrent["output"], "torch.bfloat16"),
            head_axis=0,
        ),
        "recurrence_after_state_fp32": compare(
            after["ssm_state"], recurrent["state"], head_axis=0
        ),
        "recurrence_after_state_storage": compare(
            after["ssm_state"],
            storage_reference(recurrent["state"], ssm_dtype),
            head_axis=0,
        ),
        "recurrence_uses_actual_scan_inputs": True,
        "kernel_intermediate_precision_emulated": False,
    }


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def convert_tensors(value, *, torch, dtypes, path=""):
    import numpy as np

    if isinstance(value, torch.Tensor):
        require(
            value.device.type == "cpu"
            and value.numel() > 0
            and bool(torch.isfinite(value).all()),
            "capture requires nonempty finite CPU tensors",
        )
        require(
            value.dtype in (torch.bfloat16, torch.float32, torch.int32, torch.int64),
            "unsupported original capture dtype",
        )
        dtypes[path] = str(value.dtype)
        return (
            value.float().numpy() if value.is_floating_point() else value.numpy()
        ).copy()
    if isinstance(value, dict):
        return {
            key: convert_tensors(
                item, torch=torch, dtypes=dtypes, path=f"{path}/{key}".lstrip("/")
            )
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [
            convert_tensors(item, torch=torch, dtypes=dtypes, path=f"{path}/{index}")
            for index, item in enumerate(value)
        ]
    require(
        value is None
        or isinstance(value, (str, bool, int))
        or isinstance(value, float)
        and np.isfinite(value),
        "unknown capture value type",
    )
    return value


def operand(data, label, side="outputs", index=0, shape=None):
    import numpy as np

    value = data["observed"]["modules"][label][side][index]
    require(
        isinstance(value, np.ndarray)
        and (shape is None or value.shape == tuple(shape)),
        f"operand shape mismatch: {label}/{side}/{index}",
    )
    return value


def validate_capture(data, dtypes, *, rank, tp):
    import numpy as np

    require(
        set(data) == {"metadata", "observed", "effective_norms", "rotary_cache"},
        "cached file field coverage mismatch",
    )
    meta, obs = data["metadata"], data["observed"]
    require(
        meta["rank"] == rank
        and meta["tp"] == tp
        and meta["step"] == 9
        and meta["position"] == 136
        and meta["prefix_length_before"] == 136
        and meta["prefix_length_after"] == 137
        and "_9b_" in meta["case_id"],
        "cached case/rank/step identity mismatch",
    )
    require(
        meta["performance_eligible"] is False
        and meta["original_graph_failures_preserved"] is True,
        "capture scope mismatch",
    )
    require(
        set(obs)
        == {"modules", "kv", "states", "backend", "norm_boundaries", "output_head"}
        and set(obs["modules"]) == MODULE_LABELS
        and set(obs["kv"]) == {"before", "after"}
        and set(obs["states"]) == set(obs["backend"]) == {8, 9, 10},
        "cached observation coverage mismatch",
    )
    require(
        set(data["effective_norms"]) == set(meta["norm_eps"]) == set(NORM_LABELS)
        and set(meta["communication"]) == {7, 8, 9, 10, 11},
        "norm/communication coverage mismatch",
    )
    for comm in meta["communication"].values():
        require(
            comm["should_fuse"] is False
            and comm["use_all_reduce"] is True
            and (
                comm["attention_tp_rank"],
                comm["dense_tp_rank"],
                comm["attention_tp_size"],
                comm["dense_tp_size"],
            )
            == (rank, rank, tp, tp),
            "unobserved fused/RSAG/rank communication path",
        )
    fa = meta["fa"]
    require(
        (fa["heads"], fa["kv_heads"], fa["head_dim"], fa["scaling"])
        == (16 // tp, 4 // tp, 256, 0.0625)
        and fa["rotary_is_neox_style"] is True
        and 0 < fa["rotary_dim"] <= 256
        and fa["rotary_dim"] % 2 == 0,
        "FA geometry mismatch",
    )
    require(
        data["rotary_cache"].shape == (137, fa["rotary_dim"]),
        "actual rotary cache prefix shape mismatch",
    )
    for label, sample in obs["modules"].items():
        require(
            set(sample) == {"inputs", "outputs"}
            and isinstance(sample["inputs"], list)
            and isinstance(sample["outputs"], list),
            "module operand schema mismatch",
        )
        for side, values in sample.items():
            for index, value in enumerate(values):
                if value is not None:
                    key = f"observed/modules/{label}/{side}/{index}"
                    if (
                        label in ("fa7", "fa7.rotary_emb")
                        and side == "inputs"
                        and index == 0
                    ):
                        text_position(value)
                    else:
                        require(
                            dtypes[key] == "torch.bfloat16",
                            "module operands must retain BF16",
                        )
                        if label in {
                            f"l{layer}.linear_attn.norm" for layer in (8, 9, 10)
                        }:
                            require(
                                value.shape == (32 // tp, 128),
                                "GDN gated norm single-token shape mismatch",
                            )
                        else:
                            require(
                                value.ndim >= 1 and value.shape[0] == 1,
                                "module operand must contain exactly one decode token",
                            )
    text_position(operand(data, "fa7.rotary_emb", "inputs", 0))
    hidden = operand(data, "fa7.input_layernorm", "inputs", 0).shape[-1]
    for label in NORM_LABELS:
        require(
            data["effective_norms"][label].shape == (hidden,)
            and dtypes[f"effective_norms/{label}"] == "torch.float32"
            and np.isfinite(meta["norm_eps"][label])
            and meta["norm_eps"][label] > 0,
            "effective norm shape/dtype/epsilon mismatch",
        )
        for side in ("inputs", "outputs"):
            for index in (0, 1):
                operand(data, label, side, index, (1, hidden))
    for phase, length in (("before", 136), ("after", 137)):
        kv = obs["kv"][phase]
        km = kv["metadata"]
        require(
            km["phase"] == phase
            and km["rank"] == rank
            and km["tp"] == tp
            and km["layer_id"] == 7
            and km["step"] == 9
            and km["valid_length"] == length
            and km["actual_seq_lens"] == [137]
            and km["current_kv_included"] == (phase == "after")
            and km["prefix_recomputed"] is False
            and km["entire_pool_exported"] is False
            and km["shard_count"] == 1,
            "KV snapshot identity mismatch",
        )
        require(
            kv["k"].shape == kv["v"].shape == (length, 4 // tp, 256)
            and kv["seq_lens"].tolist() == [137]
            and kv["page_table"].ndim == 2
            and kv["page_table"].shape[0] == 1
            and kv["page_table"].tolist() == km["actual_page_table"]
            and kv["write_locations"].shape == (1,)
            and kv["write_locations"].tolist() == km["actual_write_locations"],
            "KV tensor/metadata shape mismatch",
        )
        for name in ("k", "v"):
            require(
                dtypes[f"observed/kv/{phase}/{name}"] == "torch.bfloat16",
                "KV original dtype must be BF16",
            )
        for name in ("page_table", "seq_lens", "write_locations"):
            require(
                dtypes[f"observed/kv/{phase}/{name}"] in ("torch.int32", "torch.int64"),
                "KV addressing metadata must remain integer tensors",
            )
    hq, hk = 16 // tp, 4 // tp
    for index, width in ((0, hq * 256), (1, hk * 256), (2, hk * 256)):
        operand(data, "fa7.attn", "inputs", index, (1, width))
    operand(data, "fa7.attn", shape=(1, hq * 256))
    for layer in (8, 9, 10):
        states, backend = obs["states"][layer], obs["backend"][layer]
        require(
            set(states) == {"before", "after"} and set(backend) == {"decode", "scan"},
            "GDN snapshot coverage mismatch",
        )
        decode, scan = backend["decode"], backend["scan"]
        require(
            set(decode)
            == {
                "mixed_qkv",
                "conv_weights",
                "bias",
                "A_log",
                "dt_bias",
                "a",
                "b",
                "z",
                "metadata",
                "output",
            }
            and set(scan)
            == {
                "q",
                "k",
                "v",
                "read_indices",
                "write_indices",
                "A_log",
                "dt_bias",
                "a",
                "b",
                "output",
            },
            "GDN backend seam coverage mismatch",
        )
        dm = decode["metadata"]
        require(
            dm["activation"] in ("silu", "swish")
            and dm["key_dim"] == 2048
            and dm["value_dim"] == 4096
            and dm["attention_tp_size"] == tp
            and dm["head_k_dim"] == dm["head_v_dim"] == 128
            and dm["seq_len"] == 1
            and decode["bias"] is None,
            "unobserved GDN bias/activation/geometry",
        )
        local_k, local_v, channels = 16 // tp, 32 // tp, 8192 // tp
        require(
            decode["mixed_qkv"].shape == (1, channels)
            and decode["conv_weights"].shape == (channels, 4)
            and decode["z"].shape == (1, local_v, 128),
            "GDN mixed/conv/z shape mismatch",
        )
        for name in ("q", "k"):
            require(
                scan[name].shape == (1, 1, local_k, 128),
                "GDN actual scan Q/K shape mismatch",
            )
        require(
            scan["v"].shape
            == scan["output"].shape
            == decode["output"].shape
            == (1, 1, local_v, 128),
            "GDN actual scan V/output shape mismatch",
        )
        for seam, names in (
            ("decode", ("mixed_qkv", "conv_weights", "z", "output")),
            ("scan", ("q", "k", "v", "output")),
        ):
            require(
                all(
                    dtypes[f"observed/backend/{layer}/{seam}/{name}"]
                    == "torch.bfloat16"
                    for name in names
                ),
                "GDN original operand dtype must remain BF16",
            )
        require(
            all(
                dtypes[f"observed/backend/{layer}/scan/{name}"]
                in ("torch.int32", "torch.int64")
                for name in ("read_indices", "write_indices")
            ),
            "GDN state indices must remain integers",
        )
        for seam in ("decode", "scan"):
            for name, shape in (
                ("A_log", (local_v,)),
                ("dt_bias", (local_v,)),
                ("a", (1, local_v)),
                ("b", (1, local_v)),
            ):
                require(backend[seam][name].shape == shape, "GDN gate shape mismatch")
                require(
                    dtypes[f"observed/backend/{layer}/{seam}/{name}"]
                    == (
                        "torch.float32"
                        if name in ("A_log", "dt_bias")
                        else "torch.bfloat16"
                    ),
                    "GDN gate original dtype mismatch",
                )
        for phase in ("before", "after"):
            state = states[phase]
            sm = state["metadata"]
            require(
                sm["phase"] == phase
                and sm["layer_id"] == layer
                and sm["pool_rank"] == rank
                and sm["cache_group_family"] == "state"
                and sm["cache_group_shard_count"] == 1
                and sm["cache_group_retention"] == "full_history"
                and sm["recomputed_prefix"] is False
                and sm["runtime_state_written"] is False
                and sm["ssm_layout"]
                == "local_value_heads, value_head_dim, key_head_dim (K-last)"
                and sm["heads"]
                == {
                    "local_key_heads": local_k,
                    "local_value_heads": local_v,
                    "key_head_dim": 128,
                    "value_head_dim": 128,
                },
                "GDN state identity/head mapping mismatch",
            )
            require(
                state["conv_state"].shape == (channels, 3)
                and state["ssm_state"].shape == (local_v, 128, 128)
                and sm["conv_snapshot_shape"] == [channels, 3]
                and sm["ssm_snapshot_shape"] == [local_v, 128, 128],
                "GDN state shape mismatch",
            )
            for name, dtype_field in (
                ("conv_state", "conv_dtype"),
                ("ssm_state", "ssm_dtype"),
            ):
                require(
                    dtypes[f"observed/states/{layer}/{phase}/{name}"]
                    == sm[dtype_field],
                    "state original dtype metadata mismatch",
                )
            require(
                sm["conv_dtype"] == "torch.bfloat16"
                and sm["ssm_dtype"] in ("torch.bfloat16", "torch.float32"),
                "unobserved GDN state storage dtype",
            )
        before_meta, after_meta = (
            states["before"]["metadata"],
            states["after"]["metadata"],
        )
        require(
            scan["read_indices"].shape == scan["write_indices"].shape == (1,)
            and scan["read_indices"].tolist() == [before_meta["state_in_slot"]]
            and scan["write_indices"].tolist() == [after_meta["state_out_slot"]]
            and before_meta["selected_state_slot"] == before_meta["state_in_slot"]
            and after_meta["selected_state_slot"] == after_meta["state_out_slot"]
            and before_meta["state_in_slot"] == after_meta["state_in_slot"]
            and before_meta["state_out_slot"] == after_meta["state_out_slot"]
            and before_meta["cache_group_id"] == after_meta["cache_group_id"],
            "scan/state read-write binding mismatch",
        )

    from step9_contract import NORM_BOUNDARIES, validate_norm_boundaries

    require(hidden == 4096, "original9B hidden width mismatch")
    validate_norm_boundaries(obs["norm_boundaries"], dtypes, hidden=hidden)
    boundary_meta = meta["additional_layerwise_boundaries"]
    require(
        set(boundary_meta)
        == {"decoder_layers", "norm_count", "names", "reference_contract"}
        and boundary_meta["decoder_layers"] == 32
        and boundary_meta["norm_count"] == 65
        and boundary_meta["names"] == list(NORM_BOUNDARIES)
        and boundary_meta["reference_contract"]
        == "layerwise R3 norm_09.pt norms keys; normalized/residual are last-token FP32 copies",
        "additional norm metadata mismatch",
    )
    require(
        meta["precision"] == obs["output_head"]["precision"]
        and meta["output_head_weight"] == obs["output_head"]["weight"],
        "output head metadata/observation mismatch",
    )
    for label in NORM_LABELS:
        key = label.replace("fa7.", "layers.7.")
        if label.startswith("l"):
            layer, kind = label.split(".", 1)
            key = f"layers.{layer[1:]}.{kind}"
        item = obs["norm_boundaries"][key]
        require(
            np.array_equal(item["effective_gamma"], data["effective_norms"][label])
            and item["epsilon"] == meta["norm_eps"][label],
            "duplicate norm gamma/epsilon disagreement",
        )
        for side in ("inputs", "outputs"):
            require(
                all(
                    np.array_equal(value, operand(data, label, side, index))
                    for index, value in enumerate(item[side])
                ),
                "duplicate norm operand disagreement",
            )


def analyze_rank(data, dtypes, *, reference):
    import numpy as np

    meta, obs = data["metadata"], data["observed"]
    fa, tp = meta["fa"], meta["tp"]
    q = operand(data, "fa7.attn", "inputs", 0).reshape(1, fa["heads"], 256)
    k = operand(data, "fa7.attn", "inputs", 1).reshape(1, fa["kv_heads"], 256)
    v = operand(data, "fa7.attn", "inputs", 2).reshape(1, fa["kv_heads"], 256)
    attention = cached_gqa(
        q, obs["kv"]["after"]["k"], obs["kv"]["after"]["v"], scaling=fa["scaling"]
    )
    actual = operand(data, "fa7.attn").reshape(1, fa["heads"], 256)
    result = {
        "metadata": meta,
        "kv": kv_checks(obs["kv"]["before"], obs["kv"]["after"], k, v),
        "cached_attention_fp32": compare(actual, attention, head_axis=1),
        "cached_attention_storage_bf16": compare(
            actual, storage_reference(attention, "torch.bfloat16"), head_axis=1
        ),
        "gdn": {},
        "norms": {},
        "original_dtypes": dtypes,
    }
    for layer in (8, 9, 10):
        states, backend = obs["states"][layer], obs["backend"][layer]
        item = gdn_local_references(
            backend["decode"],
            backend["scan"],
            states["before"],
            states["after"],
            reference=reference,
            ssm_dtype=dtypes[f"observed/states/{layer}/after/ssm_state"],
        )
        item["state_metadata"] = {
            phase: states[phase]["metadata"] for phase in ("before", "after")
        }
        item["decode_scan_output_continuity"] = compare(
            backend["decode"]["output"], backend["scan"]["output"]
        )
        item["scan_to_gated_norm_continuity"] = compare(
            operand(data, f"l{layer}.linear_attn.norm", "inputs", 0),
            backend["scan"]["output"].reshape(32 // tp, 128),
        )
        item["gate_operand_continuity"] = {
            name: compare(backend["decode"][name], backend["scan"][name])
            for name in ("A_log", "dt_bias", "a", "b")
        }
        result["gdn"][str(layer)] = item
    for label in NORM_LABELS:
        x, residual = (operand(data, label, "inputs", index) for index in (0, 1))
        actual_norm, updated_residual = (
            operand(data, label, "outputs", index) for index in (0, 1)
        )
        residual_ref = x + residual
        norm_ref = (
            updated_residual
            / np.sqrt(
                np.mean(updated_residual * updated_residual, axis=-1, keepdims=True)
                + np.float32(meta["norm_eps"][label])
            )
            * data["effective_norms"][label]
        )
        result["norms"][label] = {
            "residual_add_fp32": compare(updated_residual, residual_ref),
            "residual_add_actual_storage": compare(
                updated_residual,
                storage_reference(
                    residual_ref, dtypes[f"observed/modules/{label}/outputs/1"]
                ),
            ),
            "norm_from_actual_updated_residual_fp32": compare(actual_norm, norm_ref),
            "norm_actual_output_storage": compare(
                actual_norm,
                storage_reference(
                    norm_ref, dtypes[f"observed/modules/{label}/outputs/0"]
                ),
            ),
        }
    from step9_contract import analyze_norm_boundaries

    result["all_norm_boundaries"] = analyze_norm_boundaries(
        obs["norm_boundaries"], dtypes
    )
    return result


def compare_ranks(ranks, dtype_maps):
    import numpy as np

    one, left, right = ranks
    result = {"kv": {}, "gdn": {}, "norms": {}, "sums": {}}
    for phase in ("before", "after"):
        for name in ("k", "v"):
            combined = np.concatenate(
                [r["observed"]["kv"][phase][name] for r in (left, right)], axis=1
            )
            result["kv"][f"{phase}.{name}.head_reassembly"] = compare(
                combined, one["observed"]["kv"][phase][name], head_axis=1
            )
    for layer in (8, 9, 10):
        item = {}
        for phase in ("before", "after"):
            states = [r["observed"]["states"][layer][phase] for r in ranks]
            item[f"{phase}.ssm_value_heads"] = compare(
                np.concatenate([r["ssm_state"] for r in states[1:]], axis=0),
                states[0]["ssm_state"],
                head_axis=0,
            )
            item[f"{phase}.conv_qkv_channels"] = compare(
                join_packed(
                    [r["conv_state"] for r in states[1:]],
                    widths=[1024, 1024, 2048],
                    axis=0,
                ),
                states[0]["conv_state"],
            )
        backends = [r["observed"]["backend"][layer] for r in ranks]
        item["mixed_qkv_logical_reassembly"] = compare(
            join_packed(
                [r["decode"]["mixed_qkv"] for r in backends[1:]],
                widths=[1024, 1024, 2048],
                axis=1,
            ),
            backends[0]["decode"]["mixed_qkv"],
        )
        for name in ("q", "k", "v", "output"):
            item[f"scan.{name}.head_reassembly"] = compare(
                np.concatenate([r["scan"][name] for r in backends[1:]], axis=2),
                backends[0]["scan"][name],
                head_axis=2,
            )
        result["gdn"][str(layer)] = item
    for label in NORM_LABELS:
        result["norms"][label] = {
            "tp2_vs_tp1": compare(operand(left, label), operand(one, label)),
            "tp2_rank_equality": compare(operand(right, label), operand(left, label)),
        }
    boundaries = [
        ("fa7.o_proj", "fa7.post_attention_layernorm"),
        ("fa7.mlp.down_proj", "l8.input_layernorm"),
    ]
    for layer in (8, 9, 10):
        boundaries += [
            (f"l{layer}.linear_attn.out_proj", f"l{layer}.post_attention_layernorm"),
            (f"l{layer}.mlp.down_proj", f"l{layer+1}.input_layernorm"),
        ]
    for projection, norm in boundaries:
        partial_sum = operand(left, projection) + operand(right, projection)
        result["sums"][projection] = {
            "tp1_partial_vs_return": compare(
                operand(one, norm, "inputs"), operand(one, projection)
            ),
            "actual_bf16_partials_fp32_sum_to_each_return_dtype": [
                compare(
                    operand(r, norm, "inputs"),
                    storage_reference(
                        partial_sum, dtypes[f"observed/modules/{norm}/inputs/0"]
                    ),
                )
                for r, dtypes in zip((left, right), dtype_maps[1:])
            ],
            "tp2_return_vs_tp1": compare(
                operand(left, norm, "inputs"), operand(one, norm, "inputs")
            ),
        }
    from step9_contract import NORM_BOUNDARIES

    result["all_norm_boundaries"] = {
        key: {
            "tp2_vs_tp1": compare(
                left["observed"]["norm_boundaries"][key]["normalized"],
                one["observed"]["norm_boundaries"][key]["normalized"],
            ),
            "tp2_rank_equality": compare(
                right["observed"]["norm_boundaries"][key]["normalized"],
                left["observed"]["norm_boundaries"][key]["normalized"],
            ),
        }
        for key in NORM_BOUNDARIES
    }
    heads = [rank["observed"]["output_head"] for rank in ranks]
    assembled = np.concatenate([head["matmul"]["output"] for head in heads[1:]], axis=1)
    result["head_local_shards_to_full"] = [
        compare(assembled, head["output"]) for head in heads[1:]
    ]
    require(
        all(item["value_bits_equal"] for item in result["head_local_shards_to_full"]),
        "TP2 local head shards do not reproduce original full logits",
    )
    result["interpretation"] = (
        "Cross-TP values include propagated input/history differences. Physical page/slot IDs are not expected to match across ranks. No new pass threshold."
    )
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--jobs-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--baseline-root", type=Path, required=True)
    parser.add_argument("--baseline-jobs-manifest", type=Path, required=True)
    parser.add_argument("--cpu-norm-reference", type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    require(args.threads > 0, "threads must be positive")
    manifest = json.loads(args.jobs_manifest.read_text())
    jobs = select_jobs(args.root, manifest)
    baseline_manifest = json.loads(args.baseline_jobs_manifest.read_text())
    baseline_jobs = select_jobs(args.baseline_root, baseline_manifest)
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    require("torch_npu" not in sys.modules, "CPU analyzer must start without torch_npu")
    sys.modules["torch_npu"] = None
    import gdn_reference
    import torch
    from step9_contract import (
        NORM_BOUNDARIES,
        validate_cpu_norm_reference,
        validate_output_head,
        validate_preserved_frontier,
    )

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "thresholds_added": False,
        "core_source_sha256": CORE_SHA,
        "cpu_threads": args.threads,
        "analyzer_sha256": sha(__file__),
        "gdn_reference_sha256": sha(Path(__file__).with_name("gdn_reference.py")),
        "selection": {
            "path": str(args.jobs_manifest),
            "sha256": sha(args.jobs_manifest),
            "jobs": manifest,
        },
        "runs": {},
        "baseline_runs": {},
        "ranks": {},
        "scope": "Actual step9 only; own-operand references, no full-model projections or recomputed prefix. Gamma is captured FP32; checkpoint identity is outside this analyzer.",
    }
    cpu_path = args.cpu_norm_reference
    require(
        cpu_path.name == "norm_09.pt"
        and cpu_path.parent.name == "auxiliary_cpu_fp32_layerwise_9b_r3",
        "explicit CPU norm09 path contract mismatch",
    )
    cpu_receipt_path = cpu_path.with_name("reference_state.json")
    cpu_receipt = json.loads(cpu_receipt_path.read_text())
    cpu_dtypes = {}
    cpu_norm = convert_tensors(
        torch.load(cpu_path, map_location="cpu", weights_only=True),
        torch=torch,
        dtypes=cpu_dtypes,
    )
    report["cpu_norm_reference"] = {
        "path": str(cpu_path),
        "sha256": sha(cpu_path),
        "receipt_path": str(cpu_receipt_path),
        "receipt_sha256": sha(cpu_receipt_path),
        "role": "independent CPU FP32 full-prefix model reference; includes propagated input/history differences",
    }
    report["baseline_selection"] = {
        "root": str(args.baseline_root),
        "path": str(args.baseline_jobs_manifest),
        "sha256": sha(args.baseline_jobs_manifest),
        "jobs": baseline_manifest,
    }
    ranks, dtype_maps, cases = [], [], []
    for tp in (1, 2):
        directory = jobs[f"tp{tp}"]
        run_path = directory / "diagnostic.json"
        run = json.loads(run_path.read_text())
        validate_run(run)
        require(run["capture_step"] == 9, "diagnostic capture_step must be explicitly9")
        baseline_run_path = baseline_jobs[f"tp{tp}"] / "diagnostic.json"
        baseline_run = json.loads(baseline_run_path.read_text())
        validate_run(baseline_run)
        report["baseline_runs"][f"tp{tp}"] = {
            "path": str(baseline_run_path),
            "sha256": sha(baseline_run_path),
            "guard_verified": True,
        }
        case = run["case"]
        require(
            baseline_run["case"]["input_ids"] == case["input_ids"]
            and baseline_run["case"]["continuation_ids"] == case["continuation_ids"],
            "baseline/current frozen case mismatch",
        )
        validate_cpu_norm_reference(
            cpu_norm, cpu_dtypes, cpu_receipt, case=case, core_sha=CORE_SHA
        )
        require(
            "_9b_" in case["case_id"]
            and len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) == 9
            and case["vector_count"] == 10,
            "original9Bcase coverage mismatch",
        )
        cases.append(case)
        report["runs"][f"tp{tp}"] = {
            "path": str(run_path),
            "sha256": sha(run_path),
            "guard_verified": True,
        }
        for rank in range(tp):
            path = directory / f"rank_{rank}" / "cached_step9.pt"
            metadata_path = path.with_name("cached_step9_metadata.json")
            loaded = torch.load(path, map_location="cpu", weights_only=True)
            dtypes = {}
            data = convert_tensors(loaded, torch=torch, dtypes=dtypes)
            require(
                json.loads(json.dumps(data["metadata"], allow_nan=False))
                == json.loads(metadata_path.read_text()),
                "tensor file/metadata sidecar mismatch",
            )
            require(
                data["metadata"]["case_id"] == case["case_id"],
                "capture/run case identity mismatch",
            )
            validate_capture(data, dtypes, rank=rank, tp=tp)
            analysis = analyze_rank(data, dtypes, reference=gdn_reference)
            current_records, baseline_records, vector_files = [], [], []
            current_rank = directory / f"rank_{rank}"
            baseline_rank = baseline_jobs[f"tp{tp}"] / f"rank_{rank}"
            for rank_path in (current_rank, baseline_rank):
                require(
                    {file.name for file in rank_path.glob("step_*.pt")}
                    == {f"step_{step:02d}.pt" for step in range(10)},
                    "frontier vector file coverage mismatch",
                )
            for step in range(10):
                for rank_path, records in (
                    (current_rank, current_records),
                    (baseline_rank, baseline_records),
                ):
                    vector_path = rank_path / f"step_{step:02d}.pt"
                    vector_dtypes = {}
                    vector = convert_tensors(
                        torch.load(vector_path, map_location="cpu", weights_only=True),
                        torch=torch,
                        dtypes=vector_dtypes,
                    )
                    require(
                        vector_dtypes["logits"] == "torch.float32",
                        "saved original logits must be FP32",
                    )
                    records.append(vector)
                    vector_files.append(
                        {"path": str(vector_path), "sha256": sha(vector_path)}
                    )
            analysis["original_logits_preservation"] = validate_preserved_frontier(
                current_records, baseline_records, case=case, rank=rank
            )
            analysis["frontier_files"] = vector_files
            analysis["output_head"] = validate_output_head(
                data["observed"]["output_head"],
                dtypes,
                tp=tp,
                hidden=4096,
                final_norm=data["observed"]["norm_boundaries"]["final_norm"]["outputs"][
                    0
                ],
                step_logits=current_records[9]["logits"],
            )
            analysis["independent_cpu_norms"] = {
                key: compare(
                    data["observed"]["norm_boundaries"][key]["normalized"],
                    cpu_norm["norms"][key]["normalized"],
                )
                for key in NORM_BOUNDARIES
            }
            analysis["files"] = {
                name.name: {"path": str(name), "sha256": sha(name)}
                for name in (path, metadata_path)
            }
            report["ranks"][f"tp{tp}_rank{rank}"] = analysis
            ranks.append(data)
            dtype_maps.append(dtypes)
    require(
        cases[0]["input_ids"] == cases[1]["input_ids"]
        and cases[0]["continuation_ids"] == cases[1]["continuation_ids"],
        "cross-TP original inputs differ",
    )
    report["cross_tp"] = compare_ranks(ranks, dtype_maps)
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "rank_captures": 3,
                "step": 9,
                "gdn_layers": 3,
                "diagnostic_only": True,
                "thresholds_added": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps({"status": "failed", "error_type": type(error).__name__}),
            file=sys.stderr,
        )
        sys.exit(1)
