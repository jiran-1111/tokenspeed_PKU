#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import hashlib

import pytest
from checked_analysis import check_inputs


def test_original_sha_is_checked(tmp_path):
    (tmp_path / "sample").write_bytes(b"original")
    manifest = {"sample": hashlib.sha256(b"original").hexdigest()}
    assert check_inputs(tmp_path, manifest) == 1
    (tmp_path / "sample").write_bytes(b"tampered")
    with pytest.raises(ValueError):
        check_inputs(tmp_path, manifest)


@pytest.mark.parametrize(
    "path", ["../outside", "/absolute", "C:/outside", "C:relative"]
)
def test_outside_paths_are_rejected(tmp_path, path):
    with pytest.raises(ValueError):
        check_inputs(tmp_path, {path: "a" * 64})


def test_empty_manifest_is_not_valid_evidence(tmp_path):
    with pytest.raises(ValueError):
        check_inputs(tmp_path, {})
