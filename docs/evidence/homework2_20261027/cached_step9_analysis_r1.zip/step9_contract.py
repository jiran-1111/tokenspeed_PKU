#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Strict step9 boundaries/head/frontier contracts and own-operand CPU math."""

from __future__ import annotations

import numpy as np

from analyze_cached import compare, require, storage_reference

NORM_BOUNDARIES = tuple(
    [
        f"layers.{layer}.{kind}"
        for layer in range(32)
        for kind in ("input_layernorm", "post_attention_layernorm")
    ]
    + ["final_norm"]
)
CPU_WEIGHT_SHA = "3fb5b1bfbf1fe8817ecafdbe4b0fc0bf58447cd6b6b4a9738f73670578b86834"


def validate_norm_boundaries(boundaries, dtypes, *, hidden):
    require(set(boundaries) == set(NORM_BOUNDARIES), "65 norm boundary names mismatch")
    for key, item in boundaries.items():
        first = key == "layers.0.input_layernorm"
        expected_fields = {
            "inputs",
            "outputs",
            "effective_gamma",
            "epsilon",
            "shape",
            "dtype",
            "normalized",
        }
        if not first:
            expected_fields.add("residual")
        require(
            set(item) == expected_fields,
            f"norm boundary field coverage mismatch: {key}",
        )
        require(
            isinstance(item["inputs"], list)
            and isinstance(item["outputs"], list)
            and len(item["inputs"]) == len(item["outputs"]) == (1 if first else 2),
            f"norm residual/operand contract mismatch: {key}",
        )
        prefix = f"observed/norm_boundaries/{key}"
        for side in ("inputs", "outputs"):
            for index, value in enumerate(item[side]):
                require(
                    isinstance(value, np.ndarray)
                    and value.shape == (1, hidden)
                    and np.isfinite(value).all()
                    and dtypes[f"{prefix}/{side}/{index}"] == "torch.bfloat16",
                    f"norm boundary original shape/dtype mismatch: {key}",
                )
        require(
            item["effective_gamma"].shape == (hidden,)
            and np.isfinite(item["effective_gamma"]).all()
            and dtypes[f"{prefix}/effective_gamma"] == "torch.float32"
            and type(item["epsilon"]) is float
            and np.isfinite(item["epsilon"])
            and item["epsilon"] > 0,
            f"norm boundary gamma/epsilon mismatch: {key}",
        )
        require(
            item["shape"] == [1, hidden]
            and item["dtype"] == "torch.bfloat16"
            and item["normalized"].shape == (hidden,)
            and dtypes[f"{prefix}/normalized"] == "torch.float32"
            and np.array_equal(item["normalized"], item["outputs"][0][0]),
            f"norm boundary normalized snapshot mismatch: {key}",
        )
        if not first:
            require(
                item["residual"].shape == (hidden,)
                and dtypes[f"{prefix}/residual"] == "torch.float32"
                and np.array_equal(item["residual"], item["outputs"][1][0]),
                f"norm boundary residual snapshot mismatch: {key}",
            )


def analyze_norm_boundaries(boundaries, dtypes):
    result = {}
    for key, item in boundaries.items():
        has_residual = len(item["inputs"]) == 2
        actual_source = item["outputs"][1] if has_residual else item["inputs"][0]
        inverse_rms = np.float32(1) / np.sqrt(
            np.mean(
                actual_source * actual_source, axis=-1, keepdims=True, dtype=np.float32
            )
            + np.float32(item["epsilon"])
        )
        reference = (actual_source * inverse_rms) * item["effective_gamma"]
        report = {
            "has_residual": has_residual,
            "norm_from_actual_source_fp32": compare(item["outputs"][0], reference),
            "norm_output_bf16_candidate": compare(
                item["outputs"][0], storage_reference(reference, "torch.bfloat16")
            ),
            "source": (
                "actual stored updated residual"
                if has_residual
                else "actual input without residual"
            ),
            "kernel_intermediate_precision_emulated": False,
        }
        if has_residual:
            residual_reference = item["inputs"][0] + item["inputs"][1]
            report["residual_add_fp32"] = compare(
                item["outputs"][1], residual_reference
            )
            report["residual_add_bf16_candidate"] = compare(
                item["outputs"][1],
                storage_reference(residual_reference, "torch.bfloat16"),
            )
        result[key] = report
    return result


def validate_output_head(head, dtypes, *, tp, hidden, final_norm, step_logits):
    require(
        set(head) == {"weight", "precision", "input", "matmul", "output"},
        "output head field coverage mismatch",
    )
    weight, precision, matmul = head["weight"], head["precision"], head["matmul"]
    require(
        set(weight) == {"shape", "dtype"}
        and weight == {"shape": [248320 // tp, hidden], "dtype": "torch.float32"},
        "output head weight shape/dtype mismatch",
    )
    require(
        set(precision)
        == {"npu_matmul_allow_hf32", "npu_conv_allow_hf32", "float32_matmul_precision"}
        and type(precision["npu_matmul_allow_hf32"]) is bool
        and type(precision["npu_conv_allow_hf32"]) is bool
        and precision["float32_matmul_precision"] in ("highest", "high", "medium"),
        "output head precision flags mismatch",
    )
    require(
        set(matmul) == {"input", "rhs_shape", "rhs_dtype", "weight_exported", "output"}
        and matmul["rhs_shape"] == [hidden, 248320 // tp]
        and matmul["rhs_dtype"] == "torch.float32"
        and matmul["weight_exported"] is False,
        "output head actual matmul metadata mismatch",
    )
    for name, value, shape, dtype in (
        ("input", head["input"], (1, hidden), "torch.bfloat16"),
        ("matmul/input", matmul["input"], (1, hidden), "torch.float32"),
        ("matmul/output", matmul["output"], (1, 248320 // tp), "torch.float32"),
        ("output", head["output"], (1, 248320), "torch.float32"),
    ):
        require(
            isinstance(value, np.ndarray)
            and value.shape == shape
            and np.isfinite(value).all()
            and dtypes[f"observed/output_head/{name}"] == dtype,
            f"output head shape/dtype mismatch: {name}",
        )
    checks = {
        "final_norm_to_head_input": compare(head["input"], final_norm),
        "cast_input_continuity": compare(matmul["input"], head["input"]),
        "cast_input_bf16_roundtrip": compare(
            matmul["input"], storage_reference(matmul["input"], "torch.bfloat16")
        ),
        "full_output_vs_step9_logits": compare(head["output"][0], step_logits),
    }
    require(
        all(item["value_bits_equal"] for item in checks.values()),
        "output head input/cast/logits continuity mismatch",
    )
    if tp == 1:
        checks["tp1_local_to_full_output"] = compare(matmul["output"], head["output"])
        require(
            checks["tp1_local_to_full_output"]["value_bits_equal"],
            "TP1 local/full logits mismatch",
        )
    return checks | {
        "precision": precision,
        "weight": weight,
        "weight_identity_verified": False,
        "head_matmul_replayed": False,
        "precision_applies_to": "this captured step9 run only; historical flags were not captured",
    }


def validate_preserved_frontier(current, baseline, *, case, rank):
    require(len(current) == len(baseline) == 10, "frontier must have all ten vectors")
    report = []
    for step, (new, old) in enumerate(zip(current, baseline)):
        expected_ids = (
            case["input_ids"] if step == 0 else [case["continuation_ids"][step - 1]]
        )
        expected_positions = list(range(128)) if step == 0 else [127 + step]
        for record in (new, old):
            require(
                record["case_id"] == case["case_id"]
                and record["rank"] == rank
                and record["step"] == step
                and record["prefix_length"] == 128 + step
                and record["input_ids"] == expected_ids
                and record["positions"] == expected_positions,
                "original frontier identity/token/position mismatch",
            )
            axes = record["position_axes"]
            require(
                axes == expected_positions or axes == [expected_positions] * 3,
                "original frontier position axes mismatch",
            )
            require(
                record["logits"].shape == (248320,)
                and record["logits"].dtype == np.float32
                and np.isfinite(record["logits"]).all(),
                "original logits shape/dtype mismatch",
            )
            require(
                record["raw_greedy_id"] == int(record["logits"].argmax()),
                "original logits greedy ID mismatch",
            )
        require(
            new["original_dtype"] == old["original_dtype"] == "torch.float32",
            "original logits dtype changed",
        )
        check = compare(new["logits"], old["logits"])
        require(check["value_bits_equal"], f"original logits changed at step{step}")
        report.append({"step": step, **check})
    return report


def validate_cpu_norm_reference(data, dtypes, receipt, *, case, core_sha):
    require(
        set(data) == {"step", "norms", "purpose"}
        and data["step"] == 9
        and data["purpose"]
        == "last-token replicated normalization outputs; no performance conclusion"
        and set(data["norms"]) == set(NORM_BOUNDARIES),
        "CPU norm09 coverage/step mismatch",
    )
    require(
        receipt["status"] == "collected"
        and receipt["vectors"] == 10
        and receipt["norms_per_vector"] == 65
        and receipt["source_manifest_sha256"] == core_sha
        and receipt["source_unchanged"] is True
        and receipt["npu_import_blocked"] is True
        and receipt["projected_weight_sha256"] == CPU_WEIGHT_SHA
        and receipt["case"]["input_ids"] == case["input_ids"]
        and receipt["case"]["continuation_ids"] == case["continuation_ids"],
        "CPU norm reference source/case/weight receipt mismatch",
    )
    for key, item in data["norms"].items():
        require(
            set(item) == {"shape", "dtype", "normalized"}
            and item["shape"] == [1, 1, 4096]
            and item["dtype"] == "torch.float32"
            and item["normalized"].shape == (4096,)
            and dtypes[f"norms/{key}/normalized"] == "torch.float32",
            f"CPU norm reference shape/dtype mismatch: {key}",
        )
