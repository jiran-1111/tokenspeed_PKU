#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy

import numpy as np
import pytest

from analyze_cached import storage_reference
from step9_contract import (
    NORM_BOUNDARIES,
    analyze_norm_boundaries,
    validate_norm_boundaries,
    validate_output_head,
    validate_preserved_frontier,
)


def norm_fixture():
    boundaries, dtypes = {}, {}
    for key in NORM_BOUNDARIES:
        x = np.array([[1.0, 2.0, 3.0, 4.0]], dtype=np.float32)
        residual = np.ones_like(x)
        first = key == "layers.0.input_layernorm"
        actual_source = (
            x if first else storage_reference(x + residual, "torch.bfloat16")
        )
        normalized = storage_reference(
            actual_source
            / np.sqrt(
                np.mean(actual_source**2, axis=-1, keepdims=True) + np.float32(1e-6)
            ),
            "torch.bfloat16",
        )
        item = {
            "inputs": [x] if first else [x, residual],
            "outputs": [normalized] if first else [normalized, actual_source],
            "effective_gamma": np.ones(4, dtype=np.float32),
            "epsilon": 1e-6,
            "shape": [1, 4],
            "dtype": "torch.bfloat16",
            "normalized": normalized[0].copy(),
        }
        if not first:
            item["residual"] = actual_source[0].copy()
        boundaries[key] = item
        prefix = f"observed/norm_boundaries/{key}"
        for side in ("inputs", "outputs"):
            for index, value in enumerate(item[side]):
                dtypes[f"{prefix}/{side}/{index}"] = "torch.bfloat16"
        for name in ("effective_gamma", "normalized", "residual"):
            if name in item:
                dtypes[f"{prefix}/{name}"] = "torch.float32"
    return boundaries, dtypes


def test_all_65_norms_validate_and_use_actual_stored_residual():
    boundaries, dtypes = norm_fixture()
    validate_norm_boundaries(boundaries, dtypes, hidden=4)
    result = analyze_norm_boundaries(boundaries, dtypes)
    assert len(result) == 65
    assert result["final_norm"]["norm_output_bf16_candidate"]["exact_equal"]
    assert result["final_norm"]["residual_add_bf16_candidate"]["exact_equal"]
    assert result["layers.0.input_layernorm"]["has_residual"] is False


@pytest.mark.parametrize(
    "bad", ["name", "gamma_dtype", "epsilon", "shape", "snapshot", "unknown_field"]
)
def test_norm_contract_rejects_unknown_or_corrupt_boundary(bad):
    boundaries, dtypes = norm_fixture()
    key = "final_norm"
    if bad == "name":
        boundaries["unexpected"] = boundaries.pop(key)
    elif bad == "gamma_dtype":
        dtypes[f"observed/norm_boundaries/{key}/effective_gamma"] = "torch.bfloat16"
    elif bad == "epsilon":
        boundaries[key]["epsilon"] = 0
    elif bad == "shape":
        boundaries[key]["outputs"][0] = np.zeros((2, 4), dtype=np.float32)
    elif bad == "snapshot":
        boundaries[key]["normalized"][0] += 1
    else:
        boundaries[key]["unvalidated"] = True
    with pytest.raises(ValueError):
        validate_norm_boundaries(boundaries, dtypes, hidden=4)


def head_fixture(tp):
    hidden, vocab = 4, 248320
    input_value = np.array([[1.0, 2.0, 3.0, 4.0]], dtype=np.float32)
    local = np.zeros((1, vocab // tp), dtype=np.float32)
    full = np.zeros((1, vocab), dtype=np.float32)
    head = {
        "weight": {"shape": [vocab // tp, hidden], "dtype": "torch.float32"},
        "precision": {
            "npu_matmul_allow_hf32": False,
            "npu_conv_allow_hf32": True,
            "float32_matmul_precision": "highest",
        },
        "input": input_value.copy(),
        "matmul": {
            "input": input_value.copy(),
            "rhs_shape": [hidden, vocab // tp],
            "rhs_dtype": "torch.float32",
            "weight_exported": False,
            "output": local,
        },
        "output": full,
    }
    dtypes = {
        "observed/output_head/input": "torch.bfloat16",
        "observed/output_head/matmul/input": "torch.float32",
        "observed/output_head/matmul/output": "torch.float32",
        "observed/output_head/output": "torch.float32",
    }
    return head, dtypes, input_value, full[0]


@pytest.mark.parametrize("tp", [1, 2])
def test_output_head_cast_roundtrip_full_logits_and_flags(tp):
    head, dtypes, final, logits = head_fixture(tp)
    result = validate_output_head(
        head, dtypes, tp=tp, hidden=4, final_norm=final, step_logits=logits
    )
    assert result["cast_input_continuity"]["exact_equal"]
    assert result["cast_input_bf16_roundtrip"]["exact_equal"]
    assert result["full_output_vs_step9_logits"]["exact_equal"]
    assert result["weight_identity_verified"] is False


@pytest.mark.parametrize(
    "bad",
    [
        "flag_type",
        "cast_dtype",
        "cast_value",
        "local_shape",
        "full_value",
        "weight_dtype",
    ],
)
def test_head_contract_rejects_inconsistent_dtype_flags_and_continuity(bad):
    head, dtypes, final, logits = head_fixture(2)
    logits = logits.copy()
    if bad == "flag_type":
        head["precision"]["npu_matmul_allow_hf32"] = 1
    elif bad == "cast_dtype":
        dtypes["observed/output_head/matmul/input"] = "torch.bfloat16"
    elif bad == "cast_value":
        head["matmul"]["input"][0, 0] += 0.001
    elif bad == "local_shape":
        head["matmul"]["output"] = head["output"].copy()
    elif bad == "full_value":
        head["output"][0, 5] += 1
    else:
        head["weight"]["dtype"] = "torch.bfloat16"
    with pytest.raises(ValueError):
        validate_output_head(
            head, dtypes, tp=2, hidden=4, final_norm=final, step_logits=logits
        )


def test_frontier_preservation_rejects_a_single_changed_logit_or_position():
    case = {
        "case_id": "original_9b_case",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(9)),
    }
    records = []
    for step in range(10):
        positions = list(range(128)) if step == 0 else [127 + step]
        records.append(
            {
                "case_id": case["case_id"],
                "rank": 0,
                "step": step,
                "prefix_length": 128 + step,
                "input_ids": case["input_ids"] if step == 0 else [step - 1],
                "positions": positions,
                "position_axes": positions,
                "original_dtype": "torch.float32",
                "raw_greedy_id": 0,
                "logits": np.zeros(248320, dtype=np.float32),
            }
        )
    baseline = copy.deepcopy(records)
    result = validate_preserved_frontier(records, baseline, case=case, rank=0)
    assert len(result) == 10 and all(item["exact_equal"] for item in result)
    baseline[9]["logits"][123] = 1
    with pytest.raises(ValueError, match="logits"):
        validate_preserved_frontier(records, baseline, case=case, rank=0)
    baseline = copy.deepcopy(records)
    records[9]["positions"] = [135]
    with pytest.raises(ValueError, match="frontier"):
        validate_preserved_frontier(records, baseline, case=case, rank=0)


def test_cpu_norm09_reference_requires_frozen_source_case_and_dtype_receipt():
    from analyze_cached import CORE_SHA
    from step9_contract import CPU_WEIGHT_SHA, validate_cpu_norm_reference

    case = {"input_ids": list(range(128)), "continuation_ids": list(range(9))}
    data = {
        "step": 9,
        "purpose": "last-token replicated normalization outputs; no performance conclusion",
        "norms": {
            key: {
                "shape": [1, 1, 4096],
                "dtype": "torch.float32",
                "normalized": np.zeros(4096, dtype=np.float32),
            }
            for key in NORM_BOUNDARIES
        },
    }
    dtypes = {f"norms/{key}/normalized": "torch.float32" for key in NORM_BOUNDARIES}
    receipt = {
        "status": "collected",
        "vectors": 10,
        "norms_per_vector": 65,
        "source_manifest_sha256": CORE_SHA,
        "source_unchanged": True,
        "npu_import_blocked": True,
        "projected_weight_sha256": CPU_WEIGHT_SHA,
        "case": case,
    }
    validate_cpu_norm_reference(data, dtypes, receipt, case=case, core_sha=CORE_SHA)
    for bad in (
        {**receipt, "source_manifest_sha256": "wrong"},
        {**receipt, "projected_weight_sha256": "wrong"},
        {**receipt, "case": {**case, "continuation_ids": list(range(8))}},
    ):
        with pytest.raises(ValueError, match="receipt"):
            validate_cpu_norm_reference(data, dtypes, bad, case=case, core_sha=CORE_SHA)
    with pytest.raises(ValueError, match="step"):
        validate_cpu_norm_reference(
            {**data, "step": 8}, dtypes, receipt, case=case, core_sha=CORE_SHA
        )
    dtypes["norms/final_norm/normalized"] = "torch.bfloat16"
    with pytest.raises(ValueError, match="dtype"):
        validate_cpu_norm_reference(data, dtypes, receipt, case=case, core_sha=CORE_SHA)
