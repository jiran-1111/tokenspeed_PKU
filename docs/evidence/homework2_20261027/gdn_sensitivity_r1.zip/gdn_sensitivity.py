# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Pure NumPy FP32 diagnostics; no device imports or acceptance thresholds.

Inputs must already be finite FP32 arrays with logically reassembled heads.
Results describe this arithmetic, not a bitwise emulation of device kernels.
No inputs are modified and no intermediate is clipped or rounded to BF16.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def _array(value: NDArray[np.float32], name: str) -> NDArray[np.float32]:
    if (
        not isinstance(value, np.ndarray)
        or value.dtype != np.float32
        or not np.isfinite(value).all()
    ):
        raise ValueError(f"{name} must be a finite FP32 array")
    return value


def softplus_tail_diagnostic(
    a: NDArray[np.float32],
    dt_bias: NDArray[np.float32],
    A_log: NDArray[np.float32],
) -> dict[str, object]:
    """Compare frozen beta=1/threshold=20 gate math with stable softplus.

    All inputs are nonempty [Hv]. Differences are runtime minus stable and
    retain their signs. Cancellation indices require runtime softplus == 0
    while stable softplus > 0; ordinary FP32 underflow in both is not counted.
    Runtime's unused positive exp branch is not evaluated. FP32 arithmetic
    overflow raises ValueError; decay underflow to zero is retained.
    """
    a, dt_bias, A_log = (
        _array(v, name)
        for v, name in ((a, "a"), (dt_bias, "dt_bias"), (A_log, "A_log"))
    )
    if a.ndim != 1 or a.size == 0 or dt_bias.shape != a.shape or A_log.shape != a.shape:
        raise ValueError("a, dt_bias and A_log must have matching nonempty [Hv] shapes")
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
            x = a + dt_bias
            runtime = x.copy()
            low = x <= np.float32(20)
            runtime[low] = np.log(np.float32(1) + np.exp(x[low]))
            stable = np.maximum(x, np.float32(0)) + np.log1p(np.exp(-np.abs(x)))
            coefficient = -np.exp(A_log)
            runtime_g, stable_g = coefficient * runtime, coefficient * stable
            runtime_decay, stable_decay = np.exp(runtime_g), np.exp(stable_g)
            g_difference = runtime_g - stable_g
            decay_difference = runtime_decay - stable_decay
    except FloatingPointError as error:
        raise ValueError(
            "gate diagnostic encountered invalid FP32 arithmetic"
        ) from error
    return {
        "x": x,
        "x_min": float(x.min()),
        "x_max": float(x.max()),
        "cancellation_zero_indices": np.flatnonzero((runtime == 0) & (stable > 0)),
        "runtime_softplus": runtime,
        "stable_softplus": stable,
        "runtime_g": runtime_g,
        "stable_g": stable_g,
        "runtime_decay": runtime_decay,
        "stable_decay": stable_decay,
        "g_difference": g_difference,
        "decay_difference": decay_difference,
    }


def gated_norm_cross(
    core1: NDArray[np.float32],
    z1: NDArray[np.float32],
    core2: NDArray[np.float32],
    z2: NDArray[np.float32],
    weight: NDArray[np.float32],
    *,
    eps: float,
) -> dict[str, object]:
    """Cross two [Hv,128] core/z pairs with one actual shared [128] weight.

    The only supported math is norm-before-gate with SiLU:
    core * rsqrt(mean(core**2) + eps) * weight * silu(z).
    Return four raw FP32 outputs and per-head RMS/inverse scale, z range and
    SiLU range. The four arms include interactions, not additive causal shares.
    Per-head weights and alternate norm/gate selectors are intentionally absent.
    """
    core1, z1, core2, z2, weight = (
        _array(v, name)
        for v, name in (
            (core1, "core1"),
            (z1, "z1"),
            (core2, "core2"),
            (z2, "z2"),
            (weight, "weight"),
        )
    )
    if (
        core1.ndim != 2
        or core1.shape[0] == 0
        or core1.shape[1] != 128
        or any(v.shape != core1.shape for v in (z1, core2, z2))
        or weight.shape != (128,)
    ):
        raise ValueError(
            "core/z must share nonempty [Hv,128]; weight must be shared [128]"
        )
    if (
        isinstance(eps, (bool, np.bool_))
        or not isinstance(eps, (int, float, np.integer, np.floating))
        or not np.isfinite(eps)
        or eps <= 0
    ):
        raise ValueError("eps must be finite and positive")
    try:
        with np.errstate(over="raise", invalid="raise", divide="raise", under="ignore"):
            epsilon = np.float32(eps)
            if epsilon <= 0:
                raise ValueError("eps must be positive when represented in FP32")
            cores, gates, result = {}, {}, {}
            for name, core in (("core1", core1), ("core2", core2)):
                variance = np.mean(core * core, axis=-1, dtype=np.float32)
                inverse = np.float32(1) / np.sqrt(variance + epsilon)
                cores[name] = core * inverse[:, None] * weight
                result[name] = {"rms": np.sqrt(variance), "inv_scale": inverse}
            for name, z in (("z1", z1), ("z2", z2)):
                exponential = np.exp(-np.abs(z))
                sigmoid = np.where(
                    z >= 0,
                    np.float32(1) / (np.float32(1) + exponential),
                    exponential / (np.float32(1) + exponential),
                )
                gates[name] = z * sigmoid
                result[name] = {
                    "min": z.min(axis=-1),
                    "max": z.max(axis=-1),
                    "silu_min": gates[name].min(axis=-1),
                    "silu_max": gates[name].max(axis=-1),
                }
            result["outputs"] = {
                f"{core_name}_{gate_name}": core * gate
                for core_name, core in cores.items()
                for gate_name, gate in gates.items()
            }
    except FloatingPointError as error:
        raise ValueError("gated norm encountered invalid FP32 arithmetic") from error
    return result
