# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Synthetic contracts for diagnostic math, without model acceptance limits."""

import numpy as np
import pytest

try:
    import gdn_sensitivity as ref
except ModuleNotFoundError as error:
    if error.name != "gdn_sensitivity":
        raise
    ref = None


def test_implementation_exists():
    assert ref is not None, "gdn_sensitivity has not been implemented"


def f32(value):
    return np.asarray(value, dtype=np.float32)


def inputs():
    return [
        np.full((2, 128), value, dtype=np.float32) for value in (1e-4, 1, 0.1, 2)
    ] + [np.ones(128, dtype=np.float32)]


def test_softplus_negative_tail_exposes_cancellation_and_signed_decay_difference():
    a = f32([-20, 0])
    result = ref.softplus_tail_diagnostic(a, f32([0, 0]), f32([15, 0]))
    np.testing.assert_array_equal(result["x"], a)
    assert result["x_min"] == -20 and result["x_max"] == 0
    np.testing.assert_array_equal(result["cancellation_zero_indices"], [0])
    assert result["runtime_softplus"][0] == 0
    np.testing.assert_allclose(result["stable_softplus"][0], np.exp(-20), rtol=2e-7)
    assert result["runtime_g"][0] == 0 and result["stable_g"][0] < 0
    assert result["runtime_decay"][0] == 1
    assert result["stable_decay"][0] < 1
    np.testing.assert_array_equal(
        result["g_difference"], result["runtime_g"] - result["stable_g"]
    )
    np.testing.assert_array_equal(
        result["decay_difference"], result["runtime_decay"] - result["stable_decay"]
    )
    assert result["decay_difference"][0] > 0


def test_softplus_threshold_and_extreme_finite_inputs_have_no_unused_branch_overflow():
    around = f32(
        [
            np.nextafter(np.float32(20), np.float32(0)),
            20,
            np.nextafter(np.float32(20), np.float32(100)),
            1000,
            -1000,
        ]
    )
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        result = ref.softplus_tail_diagnostic(
            around, np.zeros_like(around), np.zeros_like(around)
        )
    np.testing.assert_array_equal(result["runtime_softplus"][:4], around[:4])
    np.testing.assert_array_equal(result["runtime_g"][:4], -around[:4])
    assert result["runtime_decay"][3] == 0
    assert result["runtime_decay"][4] == 1
    assert result["cancellation_zero_indices"].size == 0
    for key, value in result.items():
        if isinstance(value, np.ndarray) and key != "cancellation_zero_indices":
            assert value.dtype == np.float32 and np.isfinite(value).all()


def test_softplus_adds_bias_before_gate_and_does_not_modify_or_alias_inputs():
    args = [f32([-21, -1]), f32([1, 1]), f32([15, 0])]
    saved = [value.copy() for value in args]
    result = ref.softplus_tail_diagnostic(*args)
    np.testing.assert_array_equal(result["x"], [-20, 0])
    for original, before in zip(args, saved):
        np.testing.assert_array_equal(original, before)
        assert not np.shares_memory(result["x"], original)


@pytest.mark.parametrize(
    "bad",
    [
        np.zeros(0, dtype=np.float32),
        np.zeros((1, 1), dtype=np.float32),
        np.ones(2, dtype=np.float64),
        f32([np.nan, 1]),
        f32([np.inf, 1]),
        np.ones(3, dtype=np.float32),
    ],
)
def test_softplus_rejects_invalid_shape_dtype_and_values(bad):
    with pytest.raises(ValueError):
        ref.softplus_tail_diagnostic(f32([1, 2]), bad, f32([0, 0]))


def test_softplus_rejects_derived_fp32_overflow_without_clipping():
    with pytest.raises(ValueError, match="FP32"):
        ref.softplus_tail_diagnostic(f32([0]), f32([0]), f32([1000]))


def test_gated_norm_identity_and_per_head_statistics():
    core = np.stack([np.ones(128), np.full(128, 2)]).astype(np.float32)
    z = np.stack([np.ones(128), np.full(128, -2)]).astype(np.float32)
    weight = np.linspace(0.5, 1.5, 128, dtype=np.float32)
    result = ref.gated_norm_cross(core, z, core, z, weight, eps=1e-6)
    expected = core / np.sqrt(np.mean(core * core, axis=-1, keepdims=True) + 1e-6)
    expected = expected * weight * z / (1 + np.exp(-z))
    for output in result["outputs"].values():
        assert output.dtype == np.float32
        np.testing.assert_allclose(output, expected, rtol=5e-7)
    np.testing.assert_array_equal(result["core1"]["rms"], [1, 2])
    np.testing.assert_array_equal(result["z1"]["min"], [1, -2])
    np.testing.assert_array_equal(result["z1"]["max"], [1, -2])
    assert np.all(result["z1"]["silu_min"] == result["z1"]["silu_max"])


def test_gated_norm_cross_keeps_core_scale_and_z_interactions():
    args = inputs()
    result = ref.gated_norm_cross(*args, eps=1e-6)
    outputs = result["outputs"]
    scale1 = 1e-4 / np.sqrt(1e-8 + 1e-6)
    scale2 = 0.1 / np.sqrt(0.01 + 1e-6)
    for c, scale in ((1, scale1), (2, scale2)):
        for z, value in ((1, 1.0), (2, 2.0)):
            expected = scale * value / (1 + np.exp(-value))
            np.testing.assert_allclose(outputs[f"core{c}_z{z}"], expected, rtol=5e-7)
    interaction = (
        outputs["core2_z2"]
        - outputs["core1_z2"]
        - outputs["core2_z1"]
        + outputs["core1_z1"]
    )
    assert np.all(interaction > 0)
    np.testing.assert_allclose(
        result["core1"]["inv_scale"], 1 / np.sqrt(1e-8 + 1e-6), rtol=3e-7
    )
    assert "contribution_percent" not in result


def test_gated_norm_handles_zero_core_and_extreme_gate_without_overflow():
    core = np.zeros((2, 128), dtype=np.float32)
    z = np.stack([np.full(128, -1000), np.full(128, 1000)]).astype(np.float32)
    with np.errstate(over="raise", invalid="raise", divide="raise"):
        result = ref.gated_norm_cross(
            core, z, core, z, np.ones(128, dtype=np.float32), eps=1e-6
        )
    for output in result["outputs"].values():
        np.testing.assert_array_equal(output, 0)
    np.testing.assert_array_equal(result["z1"]["silu_min"], [0, 1000])


def test_gated_norm_does_not_modify_inputs_or_return_aliased_outputs():
    args = inputs()
    saved = [value.copy() for value in args]
    result = ref.gated_norm_cross(*args, eps=1e-6)
    for original, before in zip(args, saved):
        np.testing.assert_array_equal(original, before)
        for output in result["outputs"].values():
            assert not np.shares_memory(original, output)


@pytest.mark.parametrize(
    "index,bad",
    [
        (0, np.ones((0, 128), dtype=np.float32)),
        (0, np.ones((2, 127), dtype=np.float32)),
        (1, np.ones((1, 128), dtype=np.float32)),
        (2, np.ones((2, 128), dtype=np.float64)),
        (3, np.full((2, 128), np.nan, dtype=np.float32)),
        (4, np.ones((2, 128), dtype=np.float32)),
        (4, np.full(128, np.inf, dtype=np.float32)),
    ],
)
def test_gated_norm_rejects_invalid_geometry_dtype_and_nonfinite(index, bad):
    args = inputs()
    args[index] = bad
    with pytest.raises(ValueError):
        ref.gated_norm_cross(*args, eps=1e-6)


@pytest.mark.parametrize("eps", [0, -1, np.nan, np.inf, True, 1e-100, 1e100])
def test_gated_norm_requires_finite_positive_representable_epsilon(eps):
    with pytest.raises(ValueError):
        ref.gated_norm_cross(*inputs(), eps=eps)


def test_gated_norm_epsilon_is_required_and_fp32_overflow_is_not_clipped():
    with pytest.raises(TypeError):
        ref.gated_norm_cross(*inputs())
    args = inputs()
    args[0].fill(np.finfo(np.float32).max)
    with pytest.raises(ValueError, match="FP32"):
        ref.gated_norm_cross(*args, eps=1e-6)
