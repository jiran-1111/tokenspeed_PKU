# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read-only CPU diagnostics for authenticated 9B cached step8 GDN operands."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path, PurePosixPath, PureWindowsPath

REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"
LAYERS = (8, 9, 10)
NORM = "linear_attn.norm.weight"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bound_path(root: Path, relative: str, *, boundary: Path) -> Path:
    require(isinstance(relative, str) and bool(relative), "empty relative file path")
    posix, windows = PurePosixPath(relative), PureWindowsPath(relative)
    require(
        not posix.is_absolute()
        and not windows.drive
        and not windows.root
        and "\\" not in relative
        and all(p not in (".", "..") for p in posix.parts)
        and posix.as_posix() == relative,
        "noncanonical relative file path",
    )
    root, boundary = Path(root).resolve(), Path(boundary).resolve()
    path = (root / relative).resolve()
    require(
        root.is_relative_to(boundary)
        and path.is_relative_to(boundary)
        and path != boundary,
        "file path escapes explicit boundary",
    )
    return path


def verify_files(
    root: Path, expected: dict[str, str], *, boundary: Path
) -> dict[str, str]:
    require(isinstance(expected, dict) and bool(expected), "missing SHA file mapping")
    actual = {}
    for relative, digest in expected.items():
        require(
            isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest),
            "invalid expected SHA256",
        )
        actual[relative] = sha(bound_path(root, relative, boundary=boundary))
        require(actual[relative] == digest, f"file SHA mismatch: {relative}")
    return actual


def validate_certificate(
    cert: dict,
    *,
    rank: int,
    tp: int,
    layer: int,
    eps: float,
    original_sha: str,
    runtime_sha: str,
) -> None:
    require(
        (cert["rank"], cert["tp"], cert["model_revision"]) == (rank, tp, REVISION),
        "actual weight certificate rank/model identity mismatch",
    )
    item = cert["layers"][str(layer)]
    semantics = item["gated_norm"]
    require(
        semantics["eps"] == eps
        and semantics["group_size"] is None
        and semantics["norm_before_gate"] is True
        and semantics["sigmoid_gate"] is False,
        "gated norm semantics mismatch",
    )
    parameter = item["parameters"][NORM]
    require(
        parameter["actual_shape"] == parameter["expected_shape"] == [128]
        and parameter["actual_dtype"] == parameter["expected_dtype"] == "torch.bfloat16"
        and parameter["actual_sha256"]
        == parameter["checkpoint_expected_sha256"]
        == runtime_sha
        and parameter["exact_match"] is True,
        "actual shared norm weight identity mismatch",
    )
    checkpoint = item["checkpoint_tensors"][NORM]
    require(
        checkpoint["shape"] == [128]
        and checkpoint["dtype"] == "torch.float32"
        and checkpoint["checkpoint_tensor_sha256"] == original_sha,
        "original checkpoint norm tensor identity mismatch",
    )


def summary(value: object) -> object:
    import numpy as np

    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {key: summary(item) for key, item in value.items()}
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for name in (
        "root",
        "jobs-manifest",
        "source-root",
        "workspace-root",
        "input-manifest",
        "output",
    ):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--threads", type=int, required=True)
    args = parser.parse_args()
    require(args.threads > 0, "threads must be positive")
    output_npz = args.output.with_suffix(".npz")
    require(
        args.output.suffix == ".json"
        and not args.output.exists()
        and not output_npz.exists(),
        "new .json and companion .npz outputs required",
    )
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    require("torch_npu" not in sys.modules, "CPU analyzer must start without torch_npu")
    sys.modules["torch_npu"] = None
    import analyze_cached as cached
    import gdn_sensitivity as sensitivity
    import numpy as np
    import torch
    from safetensors import safe_open

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    workspace, source, root = (
        p.resolve() for p in (args.workspace_root, args.source_root, args.root)
    )
    require(
        source.is_relative_to(workspace) and root.is_relative_to(workspace),
        "source/job roots must be inside explicit workspace",
    )
    selection_sha, input_sha = sha(args.jobs_manifest), sha(args.input_manifest)
    selection = json.loads(args.jobs_manifest.read_text())
    jobs = cached.select_jobs(root, selection)
    inputs = json.loads(args.input_manifest.read_text())
    require(
        set(inputs) == {"schema_version", "job_files", "source_files"}
        and inputs["schema_version"] == 1,
        "input manifest schema mismatch",
    )
    expected_jobs = set()
    for tp in (1, 2):
        directory = jobs[f"tp{tp}"].relative_to(root).as_posix()
        expected_jobs.add(f"{directory}/diagnostic.json")
        for rank in range(tp):
            for name in (
                "cached_step8.pt",
                "cached_step8_metadata.json",
                "gdn_actual_checkpoint_identity.json",
            ):
                expected_jobs.add(f"{directory}/rank_{rank}/{name}")
    require(
        set(inputs["job_files"]) == expected_jobs, "job input SHA coverage mismatch"
    )
    job_before = verify_files(root, inputs["job_files"], boundary=root)
    source_before = verify_files(source, inputs["source_files"], boundary=workspace)
    core_relative = "docs/evidence/homework2_20261023/source_manifest.json"
    artifacts_relative = "docs/evidence/homework2_20261023/model_artifacts.json"
    config_relative = "configs/homework2/qwen35_9b_tp1.yaml"
    require(
        source_before.get(core_relative) == cached.CORE_SHA,
        "frozen source manifest mismatch",
    )
    core_manifest = json.loads((source / core_relative).read_text())
    require(len(core_manifest) == 1531, "frozen source coverage mismatch")
    core_before = verify_files(source, core_manifest, boundary=source)
    config = json.loads((source / config_relative).read_text())
    require(
        config["model_revision"] == REVISION and config["dtype"] == "bfloat16",
        "configured checkpoint protocol mismatch",
    )
    checkpoint_relative = config["local_model_path"]
    checkpoint = bound_path(source, checkpoint_relative, boundary=workspace)
    config_model = checkpoint / "config.json"
    indices = list(checkpoint.glob("*.safetensors.index.json"))
    require(len(indices) == 1, "checkpoint index ambiguity")
    index_path = indices[0]
    index = json.loads(index_path.read_text())["weight_map"]
    norm_keys = {
        layer: f"model.language_model.layers.{layer}.{NORM}" for layer in LAYERS
    }
    shards = {index[key] for key in norm_keys.values()}
    model_files = {"config.json", index_path.name} | shards
    expected_source = {core_relative, artifacts_relative, config_relative} | {
        f"{checkpoint_relative}/{name}" for name in model_files
    }
    require(
        set(inputs["source_files"]) == expected_source,
        "source input SHA coverage mismatch",
    )
    models = json.loads((source / artifacts_relative).read_text())["models"]
    model = [
        m
        for m in models
        if m["model_id"] == "Qwen/Qwen3.5-9B" and m["model_revision"] == REVISION
    ]
    require(len(model) == 1, "9B model artifact identity mismatch")
    for name in model_files:
        relative = f"{checkpoint_relative}/{name}"
        bound_path(source, relative, boundary=workspace)
        require(
            source_before[relative] == model[0]["files"][name]["sha256"],
            f"frozen checkpoint file SHA mismatch: {name}",
        )
    text = json.loads(config_model.read_text())["text_config"]
    require(
        (
            text["linear_num_key_heads"],
            text["linear_num_value_heads"],
            text["linear_key_head_dim"],
            text["linear_value_head_dim"],
            text["hidden_act"],
        )
        == (16, 32, 128, 128, "silu"),
        "checkpoint geometry/activation mismatch",
    )
    eps = text["rms_norm_eps"]
    weights, weight_ids, arrays = {}, {}, {"eps": np.asarray(eps, dtype=np.float32)}
    for layer, key in norm_keys.items():
        with safe_open(checkpoint / index[key], framework="pt", device="cpu") as reader:
            original = reader.get_tensor(key)
        require(
            tuple(original.shape) == (128,)
            and original.dtype == torch.float32
            and bool(torch.isfinite(original).all()),
            "checkpoint norm shape/dtype mismatch",
        )
        runtime = original.to(dtype=torch.bfloat16).contiguous()
        digest = lambda t: hashlib.sha256(
            t.contiguous().view(torch.uint8).numpy().tobytes()
        ).hexdigest()
        weight_ids[layer] = {
            "original_sha256": digest(original),
            "runtime_sha256": digest(runtime),
        }
        weights[layer] = runtime.float().numpy().copy()
        arrays[f"l{layer}_weight_original_fp32"] = original.numpy().copy()
        arrays[f"l{layer}_weight_runtime_bf16_as_fp32"] = weights[layer]
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "original_graph_failures_preserved": True,
        "thresholds_added": False,
        "npu_execution": False,
        "cpu_threads": args.threads,
        "configured_model_revision": REVISION,
        "core_source_sha256": cached.CORE_SHA,
        "selection": selection,
        "ranks": {},
        "layers": {},
        "runs": {},
        "scope": "Actual 9B step8 only. Certified shared BF16 norm weights; FP32 arithmetic references and final BF16 candidates. Four arms include interactions and propagated input/history differences, not additive causal shares. No original graph failure is repaired or reclassified.",
        "math": "F(core,z)=core*rsqrt(mean(core**2)+eps)*weight*silu(z)",
        "tool_sha256": {
            name: sha(Path(__file__).with_name(name))
            for name in (
                Path(__file__).name,
                "analyze_cached.py",
                "gdn_reference.py",
                "gdn_sensitivity.py",
            )
        },
    }
    captures, cases = [], []
    for tp in (1, 2):
        directory = jobs[f"tp{tp}"]
        run = json.loads((directory / "diagnostic.json").read_text())
        cached.validate_run(run)
        case = run["case"]
        require(
            "_9b_" in case["case_id"]
            and len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) == 9
            and case["vector_count"] == 10,
            "original 9B case mismatch",
        )
        cases.append(case)
        report["runs"][f"tp{tp}"] = {"case": case, "guard": run["guard"]}
        for rank in range(tp):
            name = f"tp{tp}_rank{rank}"
            path = directory / f"rank_{rank}/cached_step8.pt"
            cert = json.loads(
                path.with_name("gdn_actual_checkpoint_identity.json").read_text()
            )
            dtypes = {}
            data = cached.convert_tensors(
                torch.load(path, map_location="cpu", weights_only=True),
                torch=torch,
                dtypes=dtypes,
            )
            cached.validate_capture(data, dtypes, rank=rank, tp=tp)
            require(
                data["metadata"]["case_id"] == case["case_id"],
                "capture/run identity mismatch",
            )
            require(
                json.loads(json.dumps(data["metadata"], allow_nan=False))
                == json.loads(path.with_name("cached_step8_metadata.json").read_text()),
                "capture metadata sidecar mismatch",
            )
            rank_report = {"original_metadata": data["metadata"], "layers": {}}
            for layer in LAYERS:
                validate_certificate(
                    cert,
                    rank=rank,
                    tp=tp,
                    layer=layer,
                    eps=eps,
                    original_sha=weight_ids[layer]["original_sha256"],
                    runtime_sha=weight_ids[layer]["runtime_sha256"],
                )
                label = f"l{layer}.linear_attn.norm"
                core, z = (
                    cached.operand(data, label, "inputs", i, (32 // tp, 128))
                    for i in (0, 1)
                )
                actual = cached.operand(data, label, "outputs", 0, (32 // tp, 128))
                own = sensitivity.gated_norm_cross(
                    core, z, core, z, weights[layer], eps=eps
                )
                reference = own["outputs"]["core1_z1"]
                candidate = cached.storage_reference(reference, "torch.bfloat16")
                scan = data["observed"]["backend"][layer]["scan"]
                gate = sensitivity.softplus_tail_diagnostic(
                    scan["a"][0], scan["dt_bias"], scan["A_log"]
                )
                gate_report = {
                    "x_min": gate["x_min"],
                    "x_max": gate["x_max"],
                    "cancellation_zero_indices": gate[
                        "cancellation_zero_indices"
                    ].tolist(),
                    "cancellation_zero_count": int(
                        gate["cancellation_zero_indices"].size
                    ),
                }
                for metric in (
                    "runtime_softplus",
                    "stable_softplus",
                    "runtime_g",
                    "stable_g",
                    "runtime_decay",
                    "stable_decay",
                    "g_difference",
                    "decay_difference",
                ):
                    values = gate[metric]
                    gate_report[metric] = {
                        "min": float(values.min()),
                        "max": float(values.max()),
                        "max_abs": float(np.abs(values).max()),
                    }
                rank_report["layers"][str(layer)] = {
                    "actual_weight_certificate_verified": True,
                    "fp32": cached.compare(actual, reference, head_axis=0),
                    "final_bf16_candidate": cached.compare(
                        actual, candidate, head_axis=0
                    ),
                    "own_statistics": summary(
                        {key: value for key, value in own.items() if key != "outputs"}
                    ),
                    "softplus": gate_report,
                    "scan_core_continuity": cached.compare(
                        core, scan["output"].reshape(core.shape)
                    ),
                    "decode_z_continuity": cached.compare(
                        z,
                        data["observed"]["backend"][layer]["decode"]["z"].reshape(
                            z.shape
                        ),
                    ),
                }
                prefix = f"l{layer}_{name}"
                for key, value in (
                    ("core", core),
                    ("z", z),
                    ("actual_norm", actual),
                    ("own_reference_fp32", reference),
                    ("own_final_bf16_candidate", candidate),
                    ("a", scan["a"][0]),
                    ("dt_bias", scan["dt_bias"]),
                    ("A_log", scan["A_log"]),
                ):
                    arrays[f"{prefix}_{key}"] = value.copy()
                for key, value in gate.items():
                    if isinstance(value, np.ndarray):
                        arrays[f"{prefix}_softplus_{key}"] = value.copy()
            captures.append((tp, rank, data))
            report["ranks"][name] = rank_report
    require(
        cases[0]["input_ids"] == cases[1]["input_ids"]
        and cases[0]["continuation_ids"] == cases[1]["continuation_ids"],
        "cross-TP original case mismatch",
    )
    arrays["case_input_ids"] = np.asarray(cases[0]["input_ids"], dtype=np.int64)
    arrays["case_continuation_ids"] = np.asarray(
        cases[0]["continuation_ids"], dtype=np.int64
    )
    for layer in LAYERS:
        prefix = f"l{layer}"
        label = f"l{layer}.linear_attn.norm"
        operands = [
            tuple(cached.operand(data, label, "inputs", i) for i in (0, 1))
            for _, _, data in captures
        ]
        core1, z1 = operands[0]
        core2, z2 = (
            np.concatenate([pair[i] for pair in operands[1:]], axis=0) for i in (0, 1)
        )
        cross = sensitivity.gated_norm_cross(
            core1, z1, core2, z2, weights[layer], eps=eps
        )
        arms = cross.pop("outputs")
        actuals = [cached.operand(data, label) for _, _, data in captures]
        report["layers"][str(layer)] = {
            "weight_identities": weight_ids[layer],
            "eps": eps,
            "statistics": summary(cross),
            "arms_vs_F_core1_z1": {
                key: cached.compare(value, arms["core1_z1"], head_axis=0)
                for key, value in arms.items()
            },
            "actual_TP2_vs_TP1": cached.compare(
                np.concatenate(actuals[1:], axis=0), actuals[0], head_axis=0
            ),
        }
        for key, value in arms.items():
            arrays[f"{prefix}_arm_{key}"] = value.copy()
    job_after = verify_files(root, inputs["job_files"], boundary=root)
    source_after = verify_files(source, inputs["source_files"], boundary=workspace)
    core_after = verify_files(source, core_manifest, boundary=source)
    require(
        sha(args.jobs_manifest) == selection_sha
        and sha(args.input_manifest) == input_sha,
        "selection/input manifest changed during analysis",
    )
    report["source_files"] = {"before": source_before, "after": source_after}
    report["job_files"] = {"before": job_before, "after": job_after}
    report["core_source_files"] = {"before": core_before, "after": core_after}
    report["input_manifest_sha256"] = input_sha
    report["jobs_manifest_sha256"] = selection_sha
    require(
        "torch_npu" in sys.modules and sys.modules["torch_npu"] is None,
        "torch_npu loaded during CPU analysis",
    )
    with output_npz.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    report["npz"] = {
        "path": str(output_npz),
        "sha256": sha(output_npz),
        "keys": sorted(arrays),
    }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "status": "collected",
                "rank_captures": 3,
                "layers": 3,
                "gate_diagnostics": 9,
                "npu_execution": False,
                "thresholds_added": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "reason": (
                        str(error)[:200]
                        if isinstance(error, ValueError)
                        else "input or dependency failure"
                    ),
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)
