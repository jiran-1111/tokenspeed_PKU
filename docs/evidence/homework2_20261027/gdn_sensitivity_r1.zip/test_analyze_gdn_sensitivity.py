# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Identity and file contracts for the isolated CPU diagnostic."""

import copy
import hashlib

import pytest

try:
    import analyze_gdn_sensitivity as runner
except ModuleNotFoundError as error:
    if error.name != "analyze_gdn_sensitivity":
        raise
    runner = None


def test_implementation_exists():
    assert runner is not None


def certificate():
    parameter = {
        "actual_shape": [128],
        "expected_shape": [128],
        "actual_dtype": "torch.bfloat16",
        "expected_dtype": "torch.bfloat16",
        "actual_sha256": "a" * 64,
        "checkpoint_expected_sha256": "a" * 64,
        "exact_match": True,
    }
    layer = {
        "gated_norm": {
            "eps": 1e-6,
            "group_size": None,
            "norm_before_gate": True,
            "sigmoid_gate": False,
        },
        "parameters": {"linear_attn.norm.weight": parameter},
        "checkpoint_tensors": {
            "linear_attn.norm.weight": {
                "shape": [128],
                "dtype": "torch.float32",
                "checkpoint_tensor_sha256": "b" * 64,
            }
        },
    }
    return {
        "rank": 0,
        "tp": 1,
        "model_revision": runner.REVISION,
        "layers": {str(i): copy.deepcopy(layer) for i in (8, 9, 10)},
    }


def validate(cert):
    return runner.validate_certificate(
        cert,
        rank=0,
        tp=1,
        layer=8,
        eps=1e-6,
        original_sha="b" * 64,
        runtime_sha="a" * 64,
    )


def test_certificate_accepts_shared_certified_weight():
    validate(certificate())


@pytest.mark.parametrize(
    "field,value",
    [
        ("actual_shape", [32, 128]),
        ("expected_shape", [127]),
        ("actual_dtype", "torch.float32"),
        ("exact_match", False),
        ("actual_sha256", "c" * 64),
        ("checkpoint_expected_sha256", "d" * 64),
    ],
)
def test_certificate_rejects_parameter_mismatch(field, value):
    cert = certificate()
    cert["layers"]["8"]["parameters"]["linear_attn.norm.weight"][field] = value
    with pytest.raises(ValueError):
        validate(cert)


@pytest.mark.parametrize(
    "field,value", [("rank", 1), ("tp", 2), ("model_revision", "unbound")]
)
def test_certificate_rejects_case_identity(field, value):
    cert = certificate()
    cert[field] = value
    with pytest.raises(ValueError):
        validate(cert)


def test_certificate_rejects_original_checkpoint_mismatch():
    cert = certificate()
    cert["layers"]["8"]["checkpoint_tensors"]["linear_attn.norm.weight"][
        "checkpoint_tensor_sha256"
    ] = ("c" * 64)
    with pytest.raises(ValueError):
        validate(cert)


@pytest.mark.parametrize(
    "field,value",
    [
        ("norm_before_gate", False),
        ("sigmoid_gate", True),
        ("group_size", 128),
        ("eps", 1e-5),
    ],
)
def test_certificate_rejects_other_norm_semantics(field, value):
    cert = certificate()
    cert["layers"]["8"]["gated_norm"][field] = value
    with pytest.raises(ValueError):
        validate(cert)


def test_bound_files_verify_and_detect_mutation(tmp_path):
    path = tmp_path / "capture.pt"
    path.write_bytes(b"frozen")
    expected = {"capture.pt": hashlib.sha256(b"frozen").hexdigest()}
    assert runner.verify_files(tmp_path, expected, boundary=tmp_path) == expected
    path.write_bytes(b"changed")
    with pytest.raises(ValueError):
        runner.verify_files(tmp_path, expected, boundary=tmp_path)


@pytest.mark.parametrize(
    "relative", ["../escape", "/absolute", "C:/outside", "a/../file"]
)
def test_bound_files_reject_noncanonical_paths(tmp_path, relative):
    with pytest.raises(ValueError):
        runner.bound_path(tmp_path, relative, boundary=tmp_path)


def test_source_symlink_is_allowed_only_within_workspace(tmp_path):
    source = tmp_path / "source"
    source.mkdir()
    model = tmp_path / "models"
    model.mkdir()
    (model / "config.json").write_text("{}")
    try:
        (source / "models").symlink_to(model, target_is_directory=True)
    except OSError:
        pytest.skip("symlink permission unavailable")
    assert (
        runner.bound_path(source, "models/config.json", boundary=tmp_path)
        == model / "config.json"
    )
    with pytest.raises(ValueError):
        runner.bound_path(source, "models/config.json", boundary=source)
