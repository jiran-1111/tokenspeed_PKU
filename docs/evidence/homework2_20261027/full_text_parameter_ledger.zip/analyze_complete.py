# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import hashlib
import json
import os
import sys
from pathlib import Path

os.environ['TORCH_DEVICE_BACKEND_AUTOLOAD']='0'
os.environ['ASCEND_RT_VISIBLE_DEVICES']=''
os.environ['CUDA_VISIBLE_DEVICES']=''
sys.modules['torch_npu']=None
import numpy as np
import torch

task=Path.home()/'tokenspeed/.tmp/hw2-20261023';source=task/'source_final'
tools=task/'full_parameter_identity_r2_20261027'
output=tools/'analysis.json';npz=tools/'original_math_vectors.npz'
assert not output.exists() and not npz.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
bound={}
def read(path):
    digest=sha(path);name=path.relative_to(task).as_posix()
    if name in bound:assert bound[name]==digest
    bound[name]=digest
    return json.loads(path.read_text())
core_path=source/'docs/evidence/homework2_20261023/source_manifest.json'
assert sha(core_path)=='2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3'
core=read(core_path);assert len(core)==1531
assert all(sha(source/name)==expected for name,expected in core.items())
state=read(tools/'state.json');assert state['status']=='collected' and state['original_queue_retained_paused']
assert state['runtime_math_changed_by_external_override'] is False
manifest=read(tools/'tool_manifest.json')
assert all(sha(tools/name)==expected for name,expected in manifest.items())
prep=read(tools/'preparation.json');assert prep['passed'] and prep['zero_skips'] and prep['cpu_tests']==29
artifact=read(source/'docs/evidence/homework2_20261023/model_artifacts.json')
previous=read(task/'frontier_analysis_r2.json')
results={};arrays={};checks=0;vectors=0
for model,count in [('4b',18),('9b',10)]:
    cases=read(tools/f'case_{model}.json');cards=[]
    model_result={'ranks':{},'heads':{},'original_logits_preserved':0}
    for tp in (1,2):
        job=f'full_parameter_{model}_tp{tp}_20261027_r2';driver=state['finished'][job]
        assert driver['exit_code']==0 and driver['own_contexts_released'] and driver['all_parameter_identities_verified']
        cards.append(driver['npu_id'])
        directory=source/'results/raw/homework2_20261027'/job
        run=read(directory/'diagnostic.json');guard=run['guard']
        assert run['status']=='collected' and run['runtime_math_changed_by_external_override'] is False
        assert run['case']==cases and run['original_full_logits_preserved']==count*tp and run['vectors_per_rank']==count
        assert guard['parent_pid']==driver['pid'] and guard['violations']==[] and guard['own_children_released']
        assert guard['sources_sha']==guard['sources_after_sha']==sha(core_path) and guard['sources_unchanged']
        baseline=tools/f'{job}.baseline.json';background=read(baseline)
        assert guard['baseline_sha256']==sha(baseline) and guard['approved_background']==background
        for rank in range(tp):
            key=f'tp{tp}_rank{rank}'
            identity=read(directory/f'rank_{rank}/full_parameter_identity.json')
            assert identity['status']=='verified' and identity['all_exact'] and identity['parameter_checks']==len(identity['parameters'])==412
            assert identity['visual_parameter_identity_certified'] is False and identity['armed_text_forward_visual_module_calls_blocked'] is True
            assert identity['excluded_visual_parameters'] and all(name.startswith('visual.') for name in identity['excluded_visual_parameters'])
            assert identity['rank']==rank and identity['tp']==tp and identity['runtime_math_changed'] is False and identity['runtime_state_written'] is False
            assert identity['checkpoint_files_before']==identity['checkpoint_files_after']
            match=next(row for row in artifact['models'] if row['model_id']==identity['model_id'] and row['model_revision']==identity['model_revision'])
            assert all(match['files'][name]['sha256']==digest for name,digest in identity['checkpoint_files_before'].items())
            for p in identity['parameters'].values():
                assert p['exact_match'] and p['actual_sha256']==p['checkpoint_expected_sha256'] and p['shape']==p['expected_shape'] and p['dtype']==p['expected_dtype'] and p['chunks']>0
                checks+=1
            matrix=[]
            for step in range(count):
                name=f'rank_{rank}/step_{step:02d}.pt';current=directory/name
                old=source/'results/raw/homework2_20261024'/f'frontier_diagnostic_{model}_tp{tp}_20261024_r2'/name
                old_sha=sha(old);assert old_sha==previous['models'][model]['captures'][key]['vectors'][step]['capture_sha256']
                bound[current.relative_to(task).as_posix()]=sha(current);bound[old.relative_to(task).as_posix()]=old_sha
                a=torch.load(current,map_location='cpu',weights_only=True);b=torch.load(old,map_location='cpu',weights_only=True)
                assert a['logits'].dtype==b['logits'].dtype==torch.float32 and list(a['logits'].shape)==[248320]
                assert torch.equal(a['logits'].view(torch.uint8),b['logits'].view(torch.uint8))
                assert a['input_ids']==(cases['input_ids'] if step==0 else [cases['continuation_ids'][step-1]])
                assert a['positions']==(list(range(128)) if step==0 else [127+step])
                sample=read(current.with_suffix('.json'))
                assert sample['raw_greedy_id']==int(a['logits'].argmax()) and sample['rank']==rank
                assert sample['emitted_id']==(cases['continuation_ids'][step] if step<count-1 else sample['broadcast_sampled_id'])
                matrix.append(a['logits'].numpy().copy());vectors+=1
            arrays[f'{model}_{key}']=np.stack(matrix)
            model_result['ranks'][key]={'job':job,'identity':identity,'collector_parent_matches':True,'baseline_matches':True,'own_contexts_released':True,'original_full_logits_preserved':count}
            model_result['heads'][key]=identity['parameters']['lm_head.weight']['actual_sha256']
            model_result['original_logits_preserved']+=count
    assert cards[0]==cards[1]==3
    results[model]=model_result
assert checks==2472 and vectors==84 and len(arrays)==6
assert all(sha(source/name)==expected for name,expected in core.items())
assert all(sha(task/name)==expected for name,expected in bound.items())
with npz.open('xb') as f:np.savez_compressed(f,**arrays)
record={'passed':True,'scope':'New original-math pure-text requests only; no visual-parameter, cache/state/operator, greedy-agreement or semantic-quality certification','runtime_math_changed':False,'npu_execution':False,'core_source_sha256':sha(core_path),'core_files':1531,'tool_manifest_sha256':sha(tools/'tool_manifest.json'),'parameter_checks':2472,'checks_per_rank':412,'original_full_logits_preserved':84,'models':results,'arrays':{name:{'shape':list(a.shape),'dtype':str(a.dtype),'sha256':hashlib.sha256(a.astype('<f4',copy=False).tobytes()).hexdigest()} for name,a in arrays.items()},'npz_sha256':sha(npz),'input_files':bound,'script_sha256':sha(Path(__file__)),'original_failures_preserved':True,'thresholds_added':False,'source_and_inputs_unchanged_after':True}
with output.open('x') as f:json.dump(record,f,indent=2)
print(json.dumps({'passed':True,'parameter_checks':checks,'original_vectors_preserved':vectors,'all_own_contexts_released':True,'report_sha256':sha(output),'npz_sha256':sha(npz),'visual_parameters_certified':False}))
