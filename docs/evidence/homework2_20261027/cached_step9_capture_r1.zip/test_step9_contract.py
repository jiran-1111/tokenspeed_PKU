# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pytest
from decode_kv_capture import capture_decode_kv
from frontier_capture import install
from test_decode_kv_capture import TORCH, Tensor, fixture


def test_step9_reads_136_before_and_137_after():
    ctx, layer, leaf, router, pool, key, value, calls = fixture()
    leaf.forward_decode_metadata.seq_lens = Tensor([137], "torch.int32")
    router.write_locations = lambda layer, mode: Tensor([136], "torch.int64")
    key.values[1, 7] = 135
    value.values[1, 7] = 1135
    before = capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=9)
    assert before["k"].shape == (136, 2, 256)
    assert before["metadata"]["step"] == 9
    assert before["metadata"]["current_position_contract"] == 136
    key.values[1, 8] = 136
    value.values[1, 8] = 1136
    after = capture_decode_kv(ctx, layer, torch=TORCH, phase="after", capture_step=9)
    assert after["k"].shape == (137, 2, 256)
    np.testing.assert_array_equal(after["k"].values[:, 0, 0], np.arange(137))


class ForwardTensor(Tensor):
    def reshape(self, *shape):
        return ForwardTensor(self.values.reshape(*shape), self.dtype)

    def clone(self):
        return ForwardTensor(self.values.copy(), self.dtype)

    def float(self):
        return self

    def argmax(self):
        return ForwardTensor(self.values.argmax())

    def item(self):
        return self.values.item()

    def fill_(self, value):
        self.values.fill(value)

    def __getitem__(self, index):
        return ForwardTensor(self.values[index], self.dtype)


def test_final_forward_is_observed_without_extra_token_or_logit_change(tmp_path):
    import json

    case = {
        "case_id": "original_9b_case",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(9)),
        "capture_step": 9,
        "output": str(tmp_path),
    }
    arm = tmp_path / "arm.json"
    arm.write_text(json.dumps(case))
    trace, saved = [], []
    vector = ForwardTensor(np.arange(248320).reshape(1, -1))

    class Runner:
        global_rank = 0
        model = object()

        def forward(self, ctx, input_ids, positions):
            trace.append(("forward", input_ids.tolist()))
            return SimpleNamespace(next_token_logits=vector)

    class Executor:
        def _run_sampling(self, logits_output, sampling_info, ctx, candidates=None):
            return ForwardTensor([248319]), ForwardTensor([1])

    @contextmanager
    def capture(model, ctx, **kwargs):
        trace.append(("capture", kwargs["step"], kwargs["capture_step"]))
        yield

    torch = SimpleNamespace(
        isfinite=TORCH.isfinite,
        equal=lambda left, right: np.array_equal(left.values, right.values),
        save=lambda record, stream: saved.append(record),
    )
    with patch("cached_capture.capture_cached", capture):
        install(Runner, Executor, torch=torch, arm_path=arm, capture_step=9)
        runner, executor = Runner(), Executor()
        for step in range(10):
            ids = (
                case["input_ids"] if step == 0 else [case["continuation_ids"][step - 1]]
            )
            positions = list(range(128)) if step == 0 else [127 + step]
            result = runner.forward(None, ForwardTensor(ids), ForwardTensor(positions))
            assert result.next_token_logits is vector
            emitted, _ = executor._run_sampling(result, None, None)
            assert emitted.item() == (
                case["continuation_ids"][step] if step < 9 else 248319
            )
        with pytest.raises(ValueError, match="step"):
            runner.forward(None, ForwardTensor([248319]), ForwardTensor([137]))
    assert [event for event in trace if event[0] == "capture"] == [("capture", 9, 9)]
    assert len([event for event in trace if event[0] == "forward"]) == 10
    assert len(saved) == 10
    assert [record["step"] for record in saved] == list(range(10))
    assert all(
        np.array_equal(record["logits"].values, vector.values[0]) for record in saved
    )
    assert len(list((tmp_path / "rank_0").glob("step_*.pt"))) == 10


@pytest.mark.parametrize("capture_step", [None, True, 0, 7, 10])
def test_capture_step_must_be_explicit_supported_integer(capture_step):
    ctx, layer, *_ = fixture()
    with pytest.raises(ValueError, match="capture_step"):
        capture_decode_kv(
            ctx, layer, torch=TORCH, phase="before", capture_step=capture_step
        )


def test_step9_rejects_step8_lengths_and_wrong_current_slot():
    ctx, layer, leaf, router, *_ = fixture()
    with pytest.raises(ValueError, match="length137"):
        capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=9)
    leaf.forward_decode_metadata.seq_lens = Tensor([137], "torch.int32")
    with pytest.raises(ValueError, match="write slot"):
        capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=9)


@pytest.mark.parametrize("tp,page_size", [(1, 128), (2, 64)])
def test_step9_reads_only_valid_rows_in_actual_page_order(tp, page_size):
    ctx, layer, leaf, router, pool, key, value, _ = fixture(tp, page_size)
    table = leaf.forward_decode_metadata.page_table.tolist()[0]
    leaf.forward_decode_metadata.seq_lens = Tensor([137], "torch.int32")
    page, offset = table[135 // page_size], 135 % page_size
    key.values[page, offset] = 135
    value.values[page, offset] = 1135
    slot = table[136 // page_size] * page_size + 136 % page_size
    router.write_locations = lambda layer, mode: Tensor([slot], "torch.int64")
    before = capture_decode_kv(ctx, layer, torch=TORCH, phase="before", capture_step=9)
    assert before["k"].shape == (136, 4 // tp, 256)
    assert sum(shape[0] for shape in key.reads) == 136
    assert not before["metadata"]["entire_pool_exported"]
    assert not before["metadata"]["prefix_recomputed"]
    np.testing.assert_array_equal(before["k"].values[:, 0, 0], np.arange(136))
    with pytest.raises(ValueError, match="finite"):
        capture_decode_kv(ctx, layer, torch=TORCH, phase="after", capture_step=9)


@pytest.mark.parametrize(
    "position,cache_length,error",
    [(136, 300, None), (135, 300, "positions"), (136, 136, "rotary cache")],
)
def test_cached_step9_metadata_rotary_range_and_filename(
    tmp_path, position, cache_length, error
):
    import cached_capture

    case = {
        "case_id": "original_9b_case",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(9)),
    }
    comm = SimpleNamespace(should_fuse=lambda _: False, use_all_reduce=lambda _: True)
    mapping = SimpleNamespace(
        attn=SimpleNamespace(tp_rank=0, tp_size=1),
        dense=SimpleNamespace(tp_rank=0, tp_size=1),
    )
    layers = {
        index: SimpleNamespace(comm_manager=comm, is_moe=False, mapping=mapping)
        for index in (7, 8, 9, 10, 11)
    }
    fa = layers[7]
    fa.attn_tp_rank = 0
    fa.attn_tp_size = 1
    fa.num_heads, fa.num_kv_heads, fa.head_dim, fa.scaling = 16, 4, 256, 0.0625
    fa.rotary_emb = SimpleNamespace(
        rotary_dim=64,
        is_neox_style=True,
        cos_sin_cache=ForwardTensor(np.ones((cache_length, 64))),
    )
    ctx = SimpleNamespace(
        bs=1,
        input_num_tokens=1,
        num_extends=0,
        forward_mode=SimpleNamespace(is_decode=lambda: True),
        attn_backend=type(
            "HybridLinearAttnBackend", (), {"linear_attn_backend": object()}
        )(),
    )
    saved = []
    torch = SimpleNamespace(save=lambda record, stream: saved.append(record))

    @contextmanager
    def observe(*args, **kwargs):
        yield {
            "modules": {
                "fa7.rotary_emb": {"inputs": [ForwardTensor([position])], "outputs": []}
            },
            "kv": {"before": {}, "after": {}},
            "states": {index: {"before": {}, "after": {}} for index in (8, 9, 10)},
            "backend": {index: {"decode": {}, "scan": {}} for index in (8, 9, 10)},
        }

    @contextmanager
    def norm_observe(*args, **kwargs):
        yield {f"norm{index}": {} for index in range(65)}

    @contextmanager
    def head_observe(*args, **kwargs):
        yield {
            "precision": {"npu_matmul_allow_hf32": False},
            "weight": {"dtype": "torch.float32", "shape": [248320, 4096]},
        }

    with patch.object(
        cached_capture,
        "targets_for_layers",
        return_value=(layers, {"fa7.rotary_emb": object()}),
    ), patch.object(cached_capture, "observe_cached_targets", observe), patch(
        "norm_boundaries.observe_norm_boundaries", norm_observe
    ), patch(
        "output_head_capture.observe_output_head", head_observe
    ):
        if error:
            with pytest.raises(ValueError, match=error):
                with cached_capture.capture_cached(
                    object(),
                    ctx,
                    torch=torch,
                    output=tmp_path,
                    rank=0,
                    case=case,
                    step=9,
                    capture_step=9,
                ):
                    pass
            assert not list(tmp_path.glob("cached_step*.pt"))
            return
        with cached_capture.capture_cached(
            object(),
            ctx,
            torch=torch,
            output=tmp_path,
            rank=0,
            case=case,
            step=9,
            capture_step=9,
        ):
            pass
    record = saved[0]
    assert record["metadata"]["step"] == 9
    assert (
        record["metadata"]["position"]
        == record["metadata"]["prefix_length_before"]
        == 136
    )
    assert record["metadata"]["prefix_length_after"] == 137
    assert record["rotary_cache"].shape[0] == 137
    assert (tmp_path / "cached_step9.pt").exists()
    assert (tmp_path / "cached_step9_metadata.json").exists()
    assert not (tmp_path / "cached_step8.pt").exists()


def test_cached_step9_rejects_wrong_forward_before_reading_context(tmp_path):
    from cached_capture import capture_cached

    case = {
        "case_id": "original_9b_case",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(9)),
    }
    with pytest.raises(ValueError, match="capture_step"):
        with capture_cached(
            object(),
            object(),
            torch=object(),
            output=tmp_path,
            rank=0,
            case=case,
            step=8,
            capture_step=9,
        ):
            pass


def test_partial_cached_hook_registration_failure_removes_prior_handle():
    from cached_capture import observe_cached_targets

    handles = []

    class Module:
        def register_forward_pre_hook(self, hook):
            handles.append(hook)
            return SimpleNamespace(remove=lambda: handles.remove(hook))

        def register_forward_hook(self, hook, **kwargs):
            raise RuntimeError("registration failed")

    class Backend:
        def forward_decode(self):
            pass

        def _decode_scan(self):
            pass

    with pytest.raises(RuntimeError, match="registration failed"):
        with observe_cached_targets(
            {"fa7": Module()},
            object(),
            Backend(),
            torch=TORCH,
            kv_capture=None,
            gdn_capture=None,
        ):
            pass
    assert not handles
