# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read all 65 original9B norm boundaries at the selected decode forward."""

from __future__ import annotations

import re
from contextlib import contextmanager


def targets_for_norm_boundaries(model) -> dict:
    modules = dict(model.named_modules())
    layer_paths = [
        (name, match)
        for name in modules
        if (match := re.fullmatch(r"(?:(.*)\.)?layers\.(\d+)", name))
    ]
    parents = {match[1] or "" for _, match in layer_paths}
    if (
        len(parents) != 1
        or len(layer_paths) != 32
        or {int(match[2]) for _, match in layer_paths} != set(range(32))
    ):
        raise ValueError(
            "Norm boundaries require exactly the original9B 32 decoder layers"
        )
    parent = parents.pop()
    prefix = f"{parent}." if parent else ""
    targets = {}
    for index in range(32):
        for kind in ("input_layernorm", "post_attention_layernorm"):
            key = f"layers.{index}.{kind}"
            path = f"{prefix}{key}"
            if path not in modules:
                raise ValueError(f"Missing norm boundary {path}")
            targets[key] = modules[path]
    final_path = f"{prefix}norm"
    if final_path not in modules:
        raise ValueError(f"Missing explicit decoder final norm {final_path}")
    targets["final_norm"] = modules[final_path]
    if len({id(module) for module in targets.values()}) != 65:
        raise ValueError("Norm boundary modules must be distinct")
    return targets


@contextmanager
def observe_norm_boundaries(model, *, torch):
    targets = targets_for_norm_boundaries(model)
    observed, handles = {}, []

    def clone(value):
        return value.detach().cpu().clone() if isinstance(value, torch.Tensor) else None

    def values(value):
        return value if isinstance(value, tuple) else (value,)

    def pre(key):
        def hook(module, inputs):
            if key in observed:
                raise ValueError(f"Norm boundary {key} invoked more than once")
            observed[key] = {
                "inputs": [clone(value) for value in inputs],
                "effective_gamma": clone(module.gemma_weight),
                "epsilon": module.variance_epsilon,
            }

        return hook

    def post(key):
        def hook(module, inputs, output):
            outputs = values(output)
            normalized = outputs[0]
            if (
                not isinstance(normalized, torch.Tensor)
                or normalized.ndim not in (2, 3)
                or normalized.numel() != normalized.shape[-1]
            ):
                raise ValueError("Norm boundary requires one actual decode token")
            item = observed[key]
            item["outputs"] = [clone(value) for value in outputs]
            item["shape"] = list(normalized.shape)
            item["dtype"] = str(normalized.dtype)
            # These keys match the old layerwise R3 norm_09.pt output contract.
            item["normalized"] = (
                normalized.detach()
                .reshape(-1, normalized.shape[-1])[-1]
                .cpu()
                .float()
                .clone()
            )
            if len(outputs) > 1 and outputs[1] is not None:
                residual = outputs[1]
                item["residual"] = (
                    residual.detach()
                    .reshape(-1, residual.shape[-1])[-1]
                    .cpu()
                    .float()
                    .clone()
                )

        return hook

    try:
        for key, module in targets.items():
            handles.append(module.register_forward_pre_hook(pre(key)))
            handles.append(module.register_forward_hook(post(key)))
        yield observed
    finally:
        for handle in handles:
            handle.remove()
    if set(observed) != set(targets) or any(
        "outputs" not in item for item in observed.values()
    ):
        raise ValueError("Norm boundary observation incomplete")
