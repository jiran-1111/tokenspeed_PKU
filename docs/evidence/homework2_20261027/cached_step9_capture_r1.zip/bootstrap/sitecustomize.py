#!/usr/bin/env python3
# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Preserve frozen import ordering, install only once both runtime classes exist."""

import builtins
import os
import runpy
import sys
from pathlib import Path

source = Path(os.environ["TOKENSPEED_SOURCE_SNAPSHOT"])
runpy.run_path(str(source / ".tmp/import_bootstrap/sitecustomize.py"))
original_import = builtins.__import__
installed = False


def monitored_import(name, globals=None, locals=None, fromlist=(), level=0):
    global installed
    result = original_import(name, globals, locals, fromlist, level)
    runner = sys.modules.get("tokenspeed.runtime.execution.model_runner")
    executor = sys.modules.get("tokenspeed.runtime.execution.model_executor")
    if (
        not installed
        and runner is not None
        and executor is not None
        and "ModelRunner" in runner.__dict__
        and "ModelExecutor" in executor.__dict__
    ):
        installed = True
        builtins.__import__ = original_import
        from frontier_capture import install

        install(
            runner.__dict__["ModelRunner"],
            executor.__dict__["ModelExecutor"],
            torch=sys.modules["torch"],
            arm_path=Path(os.environ["TOKENSPEED_HW2_DIAGNOSTIC_ARM"]),
            capture_step=int(os.environ["TOKENSPEED_HW2_CAPTURE_STEP"]),
        )
    return result


builtins.__import__ = monitored_import
