# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest
from types import SimpleNamespace

import pytest

torch = pytest.importorskip(
    "torch", reason="real CPU Torch checks require the server environment"
)

from precision_residual import normalize


class ResidualTests(unittest.TestCase):
    def norm(self, x, gamma, epsilon):
        return x * torch.rsqrt(x.square().mean(-1, keepdim=True) + epsilon) * gamma

    def test_residual_and_norm_output_fp32_without_inplace_mutation(self):
        module = SimpleNamespace(
            gemma_weight=torch.tensor([1.25, 0.75]), variance_epsilon=1e-6
        )
        hidden = torch.tensor([[0.0078125, -0.00390625]], dtype=torch.float32)
        residual = torch.tensor([[1.0, 2.0]], dtype=torch.float32)
        old = residual.clone()
        output, actual = normalize(
            module, hidden, residual, torch=torch, rmsnorm=self.norm
        )
        self.assertEqual(output.dtype, torch.float32)
        self.assertEqual(actual.dtype, torch.float32)
        self.assertTrue(torch.equal(actual, old + hidden))
        self.assertTrue(torch.equal(residual, old))
        self.assertTrue(
            torch.equal(output, self.norm(old + hidden, module.gemma_weight, 1e-6))
        )

    def test_first_residual_and_reject_bf16_storage(self):
        module = SimpleNamespace(gemma_weight=torch.ones(2), variance_epsilon=1e-6)
        hidden = torch.tensor([[1, 2]], dtype=torch.bfloat16)
        _, residual = normalize(module, hidden, None, torch=torch, rmsnorm=self.norm)
        self.assertTrue(torch.equal(residual, hidden.float()))
        with self.assertRaises(ValueError):
            normalize(module, hidden, hidden, torch=torch, rmsnorm=self.norm)


if __name__ == "__main__":
    unittest.main()
