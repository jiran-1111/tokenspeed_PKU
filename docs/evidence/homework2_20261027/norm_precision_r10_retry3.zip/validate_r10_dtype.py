# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Strict CPU-only validation of every armed R10 dtype log and frontier sidecar."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path


def require(condition, message):
    if not condition:
        raise ValueError(message)


def contract(case, config, model_config):
    require(
        "text_config" in model_config and "layer_types" in model_config["text_config"],
        "explicit text_config.layer_types required; no interval fallback",
    )
    text = model_config["text_config"]
    types = text["layer_types"]
    require(
        text["num_hidden_layers"] == 32
        and isinstance(types, list)
        and len(types) == 32
        and all(value in ("linear_attention", "full_attention") for value in types),
        "actual model must declare all 32 supported layer_types",
    )
    tp = config["tp_size"]
    require(
        type(tp) is int and tp in (1, 2) and config["dtype"] == "bfloat16",
        "original TP/dtype config mismatch",
    )
    identities = {
        "Qwen/Qwen3.5-4B": ("_4b_", 2560, 17),
        "Qwen/Qwen3.5-9B": ("_9b_", 4096, 9),
    }
    require(config["model_id"] in identities, "unsupported original model identity")
    tag, hidden, continuation = identities[config["model_id"]]
    require(
        text["hidden_size"] == hidden
        and tag in case["case_id"]
        and len(case["input_ids"]) == 128
        and len(case["continuation_ids"]) == continuation
        and case["vector_count"] == continuation + 1,
        "original case/model shape mismatch",
    )
    require(
        all(
            type(token) is int and token >= 0
            for token in case["input_ids"] + case["continuation_ids"]
        ),
        "original IDs must be explicit nonnegative integers",
    )
    return types, hidden, tp, continuation + 1


def projection_order(types, *, role, tp):
    result = []
    for layer, kind in enumerate(types):
        if role == "row_output":
            attention = (
                "linear_attn.out_proj"
                if kind == "linear_attention"
                else "self_attn.o_proj"
            )
            mlp, attn_kind = "mlp.down_proj", "row"
        else:
            attention = (
                "linear_attn.in_proj_qkvzba"
                if kind == "linear_attention"
                else "self_attn.qkv_proj"
            )
            mlp, attn_kind = "mlp.gate_up_proj", "column"
        for suffix, projection_kind in (
            (attention, attn_kind),
            (mlp, "replicated" if tp == 1 else attn_kind),
        ):
            result.append(
                (f"model.language_model.layers.{layer}.{suffix}", projection_kind)
            )
    return result


def validate_logs(norms, rows, columns, *, case, config, model_config, rank):
    types, hidden, tp, forwards = contract(case, config, model_config)
    require(type(rank) is int and 0 <= rank < tp, "rank outside explicit TP config")
    require(
        len(norms) == 65 * forwards and len(rows) == len(columns) == 64 * forwards,
        "incomplete per-forward norm/row/column log counts",
    )
    norm_fields = {
        "rank",
        "layer",
        "boundary",
        "call_index",
        "normalized_dtype",
        "residual_dtype",
        "shape",
    }
    norm_order = [
        (layer, boundary)
        for layer in range(32)
        for boundary in ("input", "post_attention")
    ] + [(31, "final")]
    for index, item in enumerate(norms):
        step, offset = divmod(index, 65)
        tokens = 128 if step == 0 else 1
        require(
            set(item) == norm_fields
            and type(item["rank"]) is int
            and item["rank"] == rank
            and (item["layer"], item["boundary"]) == norm_order[offset],
            "norm rank/boundary/order mismatch",
        )
        require(
            type(item["call_index"]) is int and item["call_index"] == index + 1,
            "norm call_index must cover every armed call",
        )
        require(
            item["normalized_dtype"] == item["residual_dtype"] == "torch.float32"
            and item["shape"] == [tokens, hidden],
            "norm actual output/residual dtype or forward shape mismatch",
        )
    fields = {
        "rank",
        "prefix",
        "kind",
        "role",
        "call_index",
        "input_shape",
        "weight_shape",
        "input_dtype",
        "weight_dtype",
        "output_dtype",
        "calculation_dtype",
        "hf32_allowed",
    }
    groups = Counter()
    shapes = {}
    for role, items in (("row_output", rows), ("column_output", columns)):
        expected = projection_order(types, role=role, tp=tp)
        for index, item in enumerate(items):
            step, offset = divmod(index, 64)
            tokens = 128 if step == 0 else 1
            require(
                set(item) == fields
                and type(item["rank"]) is int
                and item["rank"] == rank
                and item["role"] == role
                and (item["prefix"], item["kind"]) == expected[offset],
                "projection prefix/kind/role/rank or per-forward coverage mismatch",
            )
            group = item["kind"], role, rank
            groups[group] += 1
            require(
                type(item["call_index"]) is int and item["call_index"] == groups[group],
                "projection call_index must be consecutive per(kind,role,rank)",
            )
            input_dtype, output_dtype = (
                ("torch.bfloat16", "torch.float32")
                if role == "row_output"
                else ("torch.float32", "torch.bfloat16")
            )
            require(
                item["input_dtype"] == input_dtype
                and item["output_dtype"] == output_dtype
                and item["weight_dtype"] == "torch.bfloat16"
                and item["calculation_dtype"] == "torch.float32"
                and item["hf32_allowed"] is False,
                "projection actual dtype/HF32 contract mismatch",
            )
            ins, weight = item["input_shape"], item["weight_shape"]
            require(
                isinstance(ins, list)
                and isinstance(weight, list)
                and len(ins) == len(weight) == 2
                and all(type(size) is int and size > 0 for size in ins + weight)
                and ins[0] == tokens
                and ins[1] == weight[1]
                and (weight[0] == hidden if role == "row_output" else ins[1] == hidden),
                "projection shape or forward token count mismatch",
            )
            identity = item["prefix"], item["kind"]
            if identity in shapes:
                require(
                    shapes[identity] == weight,
                    "projection weight shape changed across forwards",
                )
            shapes[identity] = weight
    return {
        "passed": True,
        "rank": rank,
        "tp": tp,
        "forward_count": forwards,
        "norm_count": len(norms),
        "row_count": len(rows),
        "column_count": len(columns),
        "per_forward": [
            {
                "forward_ordinal": step,
                "input_token_count": 128 if step == 0 else 1,
                "norms": 65,
                "row_prefixes": 64,
                "column_prefixes": 64,
            }
            for step in range(forwards)
        ],
        "call_groups": [
            {"kind": kind, "role": role, "rank": group_rank, "calls": count}
            for (kind, role, group_rank), count in sorted(groups.items())
        ],
        "tp1_replicated_column_calls": groups[("replicated", "column_output", rank)],
        "norm_input_dtype_observed": False,
        "forward_binding": "strict chronological blocks aligned with original fixed-frontier sidecars; log lines do not carry explicit step IDs",
        "thresholds_added": False,
        "performance_eligible": False,
    }


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream]


def file_sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_job(job, *, case, config, model_config):
    _, _, tp, forwards = contract(case, config, model_config)
    run_path = job / "diagnostic.json"
    run = json.loads(run_path.read_text(encoding="utf-8"))
    require(
        run["status"] == "collected"
        and run["case"] == case
        and run["vectors_per_rank"] == forwards
        and run["diagnostic_only"] is True
        and run["performance_eligible"] is False
        and run["runtime_math_changed_by_external_override"] is True,
        "diagnostic/case/frontier identity mismatch",
    )
    expected_config = {
        **config,
        "enforce_eager": True,
        "overlap_schedule": False,
        "prefix_caching": False,
        "disable_kvstore": True,
        "prometheus_port": 39581,
        "tokenspeed_metrics_port": 39582,
    }
    require(run["config"] == expected_config, "diagnostic actual config mismatch")
    expected_ranks = {f"rank_{rank}" for rank in range(tp)}
    require(
        {path.name for path in job.glob("rank_*") if path.is_dir()} == expected_ranks,
        "frontier rank directory coverage mismatch",
    )
    expected_json = {f"step_{step:02d}.json" for step in range(forwards)}
    expected_pt = {f"step_{step:02d}.pt" for step in range(forwards)}
    for stem in ("precision_residual", "precision_rows", "precision_columns"):
        require(
            {path.name for path in job.glob(f"{stem}_rank*.jsonl")}
            == {f"{stem}_rank{rank}.jsonl" for rank in range(tp)},
            "dtype log rank coverage mismatch",
        )
    ranks, files = {}, [run_path]
    for rank in range(tp):
        directory = job / f"rank_{rank}"
        require(
            {path.name for path in directory.glob("step_*.json")} == expected_json
            and {path.name for path in directory.glob("step_*.pt")} == expected_pt,
            "original frontier vector/sidecar file coverage mismatch",
        )
        for step in range(forwards):
            path = directory / f"step_{step:02d}.json"
            record = json.loads(path.read_text(encoding="utf-8"))
            require(
                record["rank"] == rank
                and record["forced"] is (step < forwards - 1)
                and record["emitted_id"]
                == (
                    case["continuation_ids"][step]
                    if step < forwards - 1
                    else record["broadcast_sampled_id"]
                ),
                "original fixed-frontier sampled metadata mismatch",
            )
            if rank == 0:
                require(
                    record["broadcast_sampled_id"] == record["raw_greedy_id"],
                    "rank-zero original greedy/broadcast mismatch",
                )
            files.append(path)
            files.append(directory / f"step_{step:02d}.pt")
        paths = [
            job / f"{stem}_rank{rank}.jsonl"
            for stem in ("precision_residual", "precision_rows", "precision_columns")
        ]
        ranks[str(rank)] = validate_logs(
            *(read_jsonl(path) for path in paths),
            case=case,
            config=config,
            model_config=model_config,
            rank=rank,
        )
        files.extend(paths)
    return {
        "passed": True,
        "diagnostic_only": True,
        "performance_eligible": False,
        "thresholds_added": False,
        "ranks": ranks,
        "evidence_files": {str(path): file_sha(path) for path in files},
        "tensor_payload_validation": "PT files hashed and counted; logits tensor contents are outside this stdlib dtype-log validator",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("job", "case", "config", "model-config", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    args = parser.parse_args()
    paths = {
        "case": args.case,
        "config": args.config,
        "model_config": args.model_config,
    }
    inputs = {
        name: json.loads(path.read_text(encoding="utf-8"))
        for name, path in paths.items()
    }
    result = validate_job(args.job, **inputs)
    result["input_files"] = {
        name: {"path": str(path), "sha256": file_sha(path)}
        for name, path in paths.items()
    }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {"passed": True, "ranks": len(result["ranks"]), "thresholds_added": False}
        )
    )


if __name__ == "__main__":
    main()
