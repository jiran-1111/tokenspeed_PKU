# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import copy

import pytest
from validate_r10_dtype import validate_logs


def fixture(tp, model_id):
    hidden, continuation = {"4b": (2560, 17), "9b": (4096, 9)}[model_id]
    model = {
        "text_config": {
            "num_hidden_layers": 32,
            "hidden_size": hidden,
            "layer_types": [
                "linear_attention",
                "linear_attention",
                "linear_attention",
                "full_attention",
            ]
            * 8,
        }
    }
    case = {
        "case_id": f"hw2_{model_id}_test",
        "input_ids": list(range(128)),
        "continuation_ids": list(range(continuation)),
        "vector_count": continuation + 1,
    }
    config = {
        "tp_size": tp,
        "dtype": "bfloat16",
        "model_id": f"Qwen/Qwen3.5-{model_id.upper()}",
    }
    norm, rows, columns = [], [], []
    counts = {}
    for step in range(continuation + 1):
        tokens = 128 if step == 0 else 1
        for layer, layer_type in enumerate(model["text_config"]["layer_types"]):
            for boundary in ("input", "post_attention"):
                norm.append(
                    {
                        "rank": 0,
                        "layer": layer,
                        "boundary": boundary,
                        "call_index": len(norm) + 1,
                        "normalized_dtype": "torch.float32",
                        "residual_dtype": "torch.float32",
                        "shape": [tokens, hidden],
                    }
                )
            for role, target in (("row_output", rows), ("column_output", columns)):
                attention = (
                    (
                        "self_attn.o_proj"
                        if role == "row_output"
                        else "self_attn.qkv_proj"
                    )
                    if layer_type == "full_attention"
                    else (
                        "linear_attn.out_proj"
                        if role == "row_output"
                        else "linear_attn.in_proj_qkvzba"
                    )
                )
                mlp = "mlp.down_proj" if role == "row_output" else "mlp.gate_up_proj"
                for suffix in (attention, mlp):
                    kind = (
                        "replicated"
                        if tp == 1 and suffix.startswith("mlp.")
                        else ("row" if role == "row_output" else "column")
                    )
                    group = kind, role
                    counts[group] = counts.get(group, 0) + 1
                    target.append(
                        {
                            "rank": 0,
                            "prefix": f"model.language_model.layers.{layer}.{suffix}",
                            "kind": kind,
                            "role": role,
                            "call_index": counts[group],
                            "input_shape": [tokens, hidden],
                            "weight_shape": [hidden, hidden],
                            "input_dtype": (
                                "torch.bfloat16"
                                if role == "row_output"
                                else "torch.float32"
                            ),
                            "weight_dtype": "torch.bfloat16",
                            "output_dtype": (
                                "torch.float32"
                                if role == "row_output"
                                else "torch.bfloat16"
                            ),
                            "calculation_dtype": "torch.float32",
                            "hf32_allowed": False,
                        }
                    )
        norm.append(
            {
                "rank": 0,
                "layer": 31,
                "boundary": "final",
                "call_index": len(norm) + 1,
                "normalized_dtype": "torch.float32",
                "residual_dtype": "torch.float32",
                "shape": [tokens, hidden],
            }
        )
    return norm, rows, columns, case, config, model


@pytest.mark.parametrize("tp", [1, 2])
def test_complete_10_forward_logs_and_tp1_replicated_column(tp):
    norm, rows, columns, case, config, model = fixture(tp, "9b")
    result = validate_logs(
        norm, rows, columns, case=case, config=config, model_config=model, rank=0
    )
    assert result["forward_count"] == 10
    assert (
        result["norm_count"] == 650
        and result["row_count"] == result["column_count"] == 640
    )
    assert result["tp1_replicated_column_calls"] == (320 if tp == 1 else 0)
    assert result["norm_input_dtype_observed"] is False
    assert result["thresholds_added"] is False


@pytest.mark.parametrize(
    "bad",
    [
        "missing_norm",
        "missing_row",
        "missing_column",
        "duplicate_prefix",
        "wrong_layer_type",
        "index",
        "kind",
        "rank",
        "norm_dtype",
        "column_input",
        "row_input",
        "row_output",
        "column_output",
        "weight_dtype",
        "hf32",
        "tokens",
        "unlogged_field",
    ],
)
def test_incomplete_or_wrong_dtype_and_routing_is_rejected(bad):
    norm, rows, columns, case, config, model = fixture(1, "9b")
    if bad == "missing_norm":
        norm.pop()
    elif bad == "missing_row":
        rows.pop()
    elif bad == "missing_column":
        columns.pop()
    elif bad == "duplicate_prefix":
        columns[1]["prefix"] = columns[0]["prefix"]
    elif bad == "wrong_layer_type":
        model["text_config"]["layer_types"][0] = "full_attention"
    elif bad == "index":
        columns[65]["call_index"] = 1
    elif bad == "kind":
        columns[1]["kind"] = "column"
    elif bad == "rank":
        rows[-1]["rank"] = 1
    elif bad == "norm_dtype":
        norm[-1]["normalized_dtype"] = "torch.bfloat16"
    elif bad == "column_input":
        columns[-1]["input_dtype"] = "torch.bfloat16"
    elif bad == "row_input":
        rows[-1]["input_dtype"] = "torch.float32"
    elif bad == "row_output":
        rows[-1]["output_dtype"] = "torch.bfloat16"
    elif bad == "column_output":
        columns[-1]["output_dtype"] = "torch.float32"
    elif bad == "weight_dtype":
        columns[-1]["weight_dtype"] = "torch.float32"
    elif bad == "hf32":
        rows[-1]["hf32_allowed"] = True
    elif bad == "tokens":
        norm[65]["shape"][0] = 128
    else:
        norm[-1]["hidden_input_dtype"] = "torch.float32"
    with pytest.raises(ValueError):
        validate_logs(
            norm, rows, columns, case=case, config=config, model_config=model, rank=0
        )


def test_missing_model_layer_types_is_not_inferred_from_interval():
    norm, rows, columns, case, config, model = fixture(1, "9b")
    del model["text_config"]["layer_types"]
    model["text_config"]["full_attention_interval"] = 4
    with pytest.raises(ValueError, match="layer_types"):
        validate_logs(
            norm, rows, columns, case=case, config=config, model_config=model, rank=0
        )


@pytest.mark.parametrize("tp", [1, 2])
def test_4b_has_all_18_fixed_forwards(tp):
    norm, rows, columns, case, config, model = fixture(tp, "4b")
    result = validate_logs(
        norm, rows, columns, case=case, config=config, model_config=model, rank=0
    )
    assert result["forward_count"] == 18
    assert result["norm_count"] == 1170
    assert result["row_count"] == result["column_count"] == 1152


def write_job(tmp_path):
    import json

    norm, rows, columns, case, config, model = fixture(1, "9b")
    run = {
        "status": "collected",
        "case": case,
        "vectors_per_rank": 10,
        "diagnostic_only": True,
        "performance_eligible": False,
        "runtime_math_changed_by_external_override": True,
        "config": {
            **config,
            "enforce_eager": True,
            "prefix_caching": False,
            "overlap_schedule": False,
            "disable_kvstore": True,
            "prometheus_port": 39581,
            "tokenspeed_metrics_port": 39582,
        },
    }
    (tmp_path / "diagnostic.json").write_text(json.dumps(run))
    directory = tmp_path / "rank_0"
    directory.mkdir()
    for step in range(10):
        (directory / f"step_{step:02d}.pt").write_bytes(
            b"fixture payload not claimed to be Torch"
        )
        sample = {
            "rank": 0,
            "forced": step < 9,
            "emitted_id": case["continuation_ids"][step] if step < 9 else 7,
            "broadcast_sampled_id": 7,
            "raw_greedy_id": 7,
        }
        (directory / f"step_{step:02d}.json").write_text(json.dumps(sample))
    for stem, items in (
        ("precision_residual", norm),
        ("precision_rows", rows),
        ("precision_columns", columns),
    ):
        (tmp_path / f"{stem}_rank0.jsonl").write_text(
            "".join(json.dumps(item) + "\n" for item in items)
        )
    return case, config, model


def test_job_binds_original_sidecars_counts_and_hashes_without_torch(tmp_path):
    from validate_r10_dtype import validate_job

    case, config, model = write_job(tmp_path)
    result = validate_job(tmp_path, case=case, config=config, model_config=model)
    assert result["passed"] is True
    assert len(result["evidence_files"]) == 24
    assert result["ranks"]["0"]["forward_count"] == 10


@pytest.mark.parametrize(
    "bad", ["missing_vector", "extra_rank", "wrong_continuation", "duplicate_log_rank"]
)
def test_job_rejects_missing_or_misbound_frontier_evidence(tmp_path, bad):
    import json

    from validate_r10_dtype import validate_job

    case, config, model = write_job(tmp_path)
    if bad == "missing_vector":
        (tmp_path / "rank_0/step_09.pt").unlink()
    elif bad == "extra_rank":
        (tmp_path / "rank_1").mkdir()
    elif bad == "duplicate_log_rank":
        (tmp_path / "precision_columns_rank1.jsonl").write_text("{}\n")
    else:
        p = tmp_path / "rank_0/step_08.json"
        sample = json.loads(p.read_text())
        sample["emitted_id"] = 999
        p.write_text(json.dumps(sample))
    with pytest.raises(ValueError):
        validate_job(tmp_path, case=case, config=config, model_config=model)


def test_tp2_rank1_has_independent_complete_call_indices():
    norm, rows, columns, case, config, model = fixture(2, "9b")
    for item in norm + rows + columns:
        item["rank"] = 1
    result = validate_logs(
        norm, rows, columns, case=case, config=config, model_config=model, rank=1
    )
    assert result["rank"] == 1 and result["column_count"] == 640
    assert all(group["rank"] == 1 for group in result["call_groups"])
