# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""CPU fake-interface contracts for the R9-relative norm storage experiment."""

import json
from types import SimpleNamespace

import numpy as np
import precision_residual
import precision_rows
import pytest


def bf16(value):
    bits = np.asarray(value, dtype=np.float32).view(np.uint32)
    return (
        (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(0xFFFF0000)
    ).view(np.float32)


class Tensor:
    def __init__(self, value, dtype="torch.float32"):
        self.dtype = dtype
        self.values = np.asarray(value, dtype=np.float32).copy()
        if dtype == "torch.bfloat16":
            self.values = bf16(self.values)
        self.shape = self.values.shape

    def float(self):
        return Tensor(self.values)

    def to(self, dtype):
        return Tensor(self.values, dtype)

    def __add__(self, other):
        assert self.dtype == other.dtype == "torch.float32"
        return Tensor(self.values + other.values)


def fake_torch():
    calls = []

    def linear(value, weight, bias):
        assert value.dtype == weight.dtype == "torch.float32" and bias is None
        calls.append((value.values.copy(), weight.values.copy()))
        return Tensor(value.values @ weight.values.T)

    return SimpleNamespace(
        bfloat16="torch.bfloat16",
        float32="torch.float32",
        nn=SimpleNamespace(functional=SimpleNamespace(linear=linear)),
        npu=SimpleNamespace(matmul=SimpleNamespace(allow_hf32=True)),
        calls=calls,
    )


def rmsnorm(value, gamma, epsilon):
    assert value.dtype == gamma.dtype == "torch.float32"
    x = value.values
    return Tensor(
        x
        / np.sqrt(np.mean(x * x, axis=-1, keepdims=True) + np.float32(epsilon))
        * gamma.values
    )


class Gemma:
    def __init__(self):
        self.gemma_weight = Tensor([1.25, 0.75])
        self.variance_epsilon = 1e-6


def test_norm_preserves_actual_fp32_result_without_mutation_or_storage_cast():
    torch = fake_torch()
    module = Gemma()
    hidden, residual = Tensor([[0.0078125, -0.00390625]]), Tensor([[1, 2]])
    before = residual.values.copy()
    output, accumulated = precision_residual.normalize(
        module, hidden, residual, torch=torch, rmsnorm=rmsnorm
    )
    expected = rmsnorm(Tensor(before + hidden.values), module.gemma_weight, 1e-6)
    assert output.dtype == accumulated.dtype == torch.float32
    np.testing.assert_array_equal(output.values, expected.values)
    assert np.any(output.values != bf16(output.values))
    np.testing.assert_array_equal(residual.values, before)


def test_first_norm_extends_bf16_hidden_and_rejects_bf16_residual_storage():
    torch = fake_torch()
    hidden = Tensor([[1, 2]], torch.bfloat16)
    output, residual = precision_residual.normalize(
        Gemma(), hidden, None, torch=torch, rmsnorm=rmsnorm
    )
    assert output.dtype == residual.dtype == torch.float32
    with pytest.raises(ValueError, match="FP32 residual"):
        precision_residual.normalize(
            Gemma(), hidden, hidden, torch=torch, rmsnorm=rmsnorm
        )


def test_norm_rejects_unexpected_lower_precision_kernel_result():
    torch = fake_torch()
    with pytest.raises(ValueError, match="FP32"):
        precision_residual.normalize(
            Gemma(),
            Tensor([[1, 2]]),
            None,
            torch=torch,
            rmsnorm=lambda *args: Tensor([[1, 2]], torch.bfloat16),
        )


def layer():
    class UnquantizedLinearMethod:
        pass

    return SimpleNamespace(
        prefix="model.layers.0.linear_attn.in_proj_qkvzba",
        tp_rank=0,
        input_is_parallel=True,
        reduce_results=False,
        gather_output=False,
        bias=None,
        weight=Tensor([[1, 2, 3]], "torch.bfloat16"),
        quant_method=UnquantizedLinearMethod(),
    )


@pytest.mark.parametrize("kind", ["column", "replicated"])
def test_column_accepts_actual_fp32_norm_input_but_retains_bf16_output(kind):
    torch = fake_torch()
    x = Tensor([[1.0039, 3, -4]])
    output, bias = precision_rows.projection(
        layer(), x, kind=kind, role="column_output", torch=torch
    )
    assert output.dtype == torch.bfloat16 and bias is None
    np.testing.assert_array_equal(torch.calls[0][0], x.values)
    np.testing.assert_array_equal(
        output.values, bf16(x.values @ layer().weight.values.T)
    )


@pytest.mark.parametrize("kind", ["row", "replicated"])
def test_row_still_requires_bf16_activations_and_retains_fp32_output(kind):
    torch = fake_torch()
    with pytest.raises(ValueError):
        precision_rows.projection(
            layer(), Tensor([[1, 2, 3]]), kind=kind, role="row_output", torch=torch
        )
    result, _ = precision_rows.projection(
        layer(),
        Tensor([[1, 2, 3]], torch.bfloat16),
        kind=kind,
        role="row_output",
        torch=torch,
    )
    assert result.dtype == torch.float32


@pytest.mark.parametrize("restriction", ["bias", "weight", "input", "gather", "reduce"])
def test_existing_projection_restrictions_remain_explicit(restriction):
    torch, module, x, kind, role = (
        fake_torch(),
        layer(),
        Tensor([[1, 2, 3]]),
        "column",
        "column_output",
    )
    if restriction == "bias":
        module.bias = Tensor([1])
    elif restriction == "weight":
        module.weight = module.weight.float()
    elif restriction == "input":
        x.dtype = "torch.float16"
    elif restriction == "gather":
        module.gather_output = True
    else:
        module.reduce_results, kind, role = True, "row", "row_output"
        x = x.to(torch.bfloat16)
    with pytest.raises(ValueError):
        precision_rows.projection(module, x, kind=kind, role=role, torch=torch)


def test_selected_wrapper_rejects_kwargs_and_quantization(tmp_path):
    torch, module = fake_torch(), layer()
    wrapped = precision_rows.wrap_projection(
        lambda *a, **k: None, kind="column", torch=torch, arm_path=tmp_path / "absent"
    )
    with pytest.raises(ValueError):
        wrapped(module, Tensor([[1, 2, 3]]), scale=7)
    module.quant_method = object()
    with pytest.raises(ValueError):
        wrapped(module, Tensor([[1, 2, 3]]))


@pytest.mark.parametrize(
    "prefix", ["visual.layers.0.mlp.down_proj", "lm_head", "model.embed_tokens"]
)
def test_nonselected_scope_preserves_all_arguments_and_result(tmp_path, prefix):
    sentinel, calls = object(), []

    def original(this, *args, **kwargs):
        calls.append((this, args, kwargs))
        return sentinel

    module = SimpleNamespace(prefix=prefix)
    wrapped = precision_rows.wrap_projection(
        original, kind="replicated", torch=fake_torch(), arm_path=tmp_path / "absent"
    )
    assert wrapped(module, 3, scale=7) is sentinel
    assert calls == [(module, (3,), {"scale": 7})]


def test_every_armed_column_call_records_actual_dtype_after_the_old_sampling_limit(
    tmp_path,
):
    torch, module = fake_torch(), layer()
    arm = tmp_path / "arm.json"
    arm.write_text(json.dumps({"output": str(tmp_path)}))
    wrapped = precision_rows.wrap_projection(
        lambda *a: None, kind="column", torch=torch, arm_path=arm
    )
    for _ in range(150):
        wrapped(module, Tensor([[1, 2, 3]]))
    rows = [
        json.loads(line)
        for line in (tmp_path / "precision_columns_rank0.jsonl")
        .read_text()
        .splitlines()
    ]
    assert len(rows) == 150
    assert [row["call_index"] for row in rows] == list(range(1, 151))
    assert all(
        row["input_dtype"] == torch.float32
        and row["output_dtype"] == torch.bfloat16
        and row["weight_dtype"] == torch.bfloat16
        for row in rows
    )


def comm_fixture():
    calls = []

    class Comm:
        def __init__(self):
            self.input_layernorm = Gemma()
            self.post_attn_layernorm = Gemma()
            self.layer_id = 3
            self.mapping = SimpleNamespace(attn=SimpleNamespace(tp_rank=0))

        def should_fuse(self, count):
            return False

        def input_reduce_norm(self, *args):
            calls.append(("original_input", args))
            return "input_fallback"

        def post_attn_reduce_norm(self, *args):
            calls.append(("original_post", args))
            return "post_fallback"

        def final_norm(self, *args):
            calls.append(("original_final", args))
            return "final_fallback"

        def post_attn_comm(self, hidden, residual, ctx):
            calls.append(("post_attn_comm", ctx))
            return hidden, residual

        def post_final_norm_comm(self, hidden, residual, ctx):
            calls.append(("post_final_norm_comm", ctx))
            return hidden, residual

    return Comm, calls


def test_all_three_norm_wrappers_preserve_comm_and_record_every_actual_output(tmp_path):
    torch, (Comm, calls) = fake_torch(), comm_fixture()
    arm = tmp_path / "arm.json"
    arm.write_text(json.dumps({"output": str(tmp_path)}))
    precision_residual.install(Comm, Gemma, torch=torch, rmsnorm=rmsnorm, arm_path=arm)
    comm, x, residual = Comm(), Tensor([[0.1, 0.2]]), Tensor([[1, 2]])
    ctx = SimpleNamespace(forward_mode=SimpleNamespace(is_idle=lambda: False))
    for _ in range(135):
        result = comm.input_reduce_norm(x, residual)
        assert result[0].dtype == torch.float32
    assert comm.post_attn_reduce_norm(x, residual, ctx)[0].dtype == torch.float32
    assert comm.final_norm(x, residual, ctx, Gemma())[0].dtype == torch.float32
    rows = [
        json.loads(line)
        for line in (tmp_path / "precision_residual_rank0.jsonl")
        .read_text()
        .splitlines()
    ]
    assert len(rows) == 137 and [row["call_index"] for row in rows] == list(
        range(1, 138)
    )
    assert [row["boundary"] for row in rows[-2:]] == ["post_attention", "final"]
    assert all(
        row["normalized_dtype"] == row["residual_dtype"] == torch.float32
        for row in rows
    )
    assert calls == [("post_attn_comm", ctx), ("post_final_norm_comm", ctx)]


def test_nongemma_and_idle_wrappers_preserve_original_arguments(tmp_path):
    torch, (Comm, calls) = fake_torch(), comm_fixture()
    precision_residual.install(
        Comm, Gemma, torch=torch, rmsnorm=rmsnorm, arm_path=tmp_path / "absent"
    )
    comm, x, residual, ctx, norm = Comm(), object(), object(), object(), object()
    comm.input_layernorm = comm.post_attn_layernorm = object()
    assert comm.input_reduce_norm(x, residual) == "input_fallback"
    assert comm.post_attn_reduce_norm(x, residual, ctx) == "post_fallback"
    assert comm.final_norm(x, residual, ctx, norm) == "final_fallback"
    assert calls == [
        ("original_input", (x, residual)),
        ("original_post", (x, residual, ctx)),
        ("original_final", (x, residual, ctx, norm)),
    ]
