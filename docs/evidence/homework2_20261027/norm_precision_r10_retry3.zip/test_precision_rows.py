# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import unittest
from pathlib import Path
from types import SimpleNamespace

import pytest

torch = pytest.importorskip(
    "torch", reason="real CPU Torch checks require the server environment"
)

from precision_rows import projection, selected, wrap_projection


class PrecisionAllTextTests(unittest.TestCase):
    def layer(self):
        return SimpleNamespace(
            input_is_parallel=True,
            reduce_results=False,
            gather_output=False,
            bias=None,
            weight=torch.tensor([[1, 2, 3]], dtype=torch.bfloat16),
        )

    def test_same_calculation_row_fp32_column_bf16_storage(self):
        layer = self.layer()
        x = torch.tensor([[0.125, 3, -4]], dtype=torch.bfloat16)
        row, _ = projection(layer, x, kind="row", role="row_output", torch=torch)
        column, _ = projection(
            layer, x, kind="column", role="column_output", torch=torch
        )
        replicated, _ = projection(
            layer, x, kind="replicated", role="column_output", torch=torch
        )
        self.assertEqual(row.dtype, torch.float32)
        self.assertEqual(column.dtype, torch.bfloat16)
        self.assertTrue(torch.equal(column, row.bfloat16()))
        self.assertTrue(torch.equal(column, replicated))

    def test_gather_and_unexpected_bias_rejected(self):
        layer = self.layer()
        layer.gather_output = True
        with self.assertRaises(ValueError):
            projection(
                layer,
                torch.ones(1, 3, dtype=torch.bfloat16),
                kind="column",
                role="column_output",
                torch=torch,
            )
        layer.bias = torch.ones(1)
        with self.assertRaises(ValueError):
            projection(
                layer,
                torch.ones(1, 3, dtype=torch.bfloat16),
                kind="replicated",
                role="row_output",
                torch=torch,
            )

    def test_semantic_scope(self):
        self.assertEqual(selected("model.layers.0.linear_attn.out_proj"), "row_output")
        self.assertEqual(
            selected("model.layers.0.linear_attn.in_proj_qkvzba"), "column_output"
        )
        self.assertEqual(selected("model.layers.3.self_attn.qkv_proj"), "column_output")
        self.assertEqual(selected("model.layers.0.mlp.gate_up_proj"), "column_output")
        self.assertIsNone(selected("visual.layers.0.mlp.down_proj"))

    def test_unselected_explicit_arguments_preserved(self):
        sentinel = object()

        def original(layer, value, scale=None):
            self.assertEqual((value, scale), (3, 7))
            return sentinel

        wrapper = wrap_projection(
            original,
            kind="column",
            torch=torch,
            arm_path=Path(__file__).parent / "absent.arm",
        )
        self.assertIs(
            wrapper(SimpleNamespace(prefix="visual.blocks.0.attn.proj"), 3, scale=7),
            sentinel,
        )

    def test_fp32_column_preserves_unrounded_norm_input(self):
        module = self.layer()
        x = torch.tensor([[1.0039, 0, -1 / 3]], dtype=torch.float32)
        result, bias = projection(
            module, x, kind="column", role="column_output", torch=torch
        )
        expected = torch.tensor([[0.0039]], dtype=torch.bfloat16)
        rounded_input = torch.nn.functional.linear(
            x.bfloat16().float(), module.weight.float()
        ).bfloat16()
        self.assertEqual(result.dtype, torch.bfloat16)
        self.assertIsNone(bias)
        self.assertTrue(torch.equal(result, expected))
        self.assertFalse(torch.equal(result, rounded_input))

    def test_fp32_replicated_column_preserves_unrounded_norm_input(self):
        module = self.layer()
        x = torch.tensor([[1.0039, 0, -1 / 3]], dtype=torch.float32)
        result, bias = projection(
            module, x, kind="replicated", role="column_output", torch=torch
        )
        expected = torch.tensor([[0.0039]], dtype=torch.bfloat16)
        rounded_input = torch.nn.functional.linear(
            x.bfloat16().float(), module.weight.float()
        ).bfloat16()
        self.assertEqual(result.dtype, torch.bfloat16)
        self.assertIsNone(bias)
        self.assertTrue(torch.equal(result, expected))
        self.assertFalse(torch.equal(result, rounded_input))

    def test_fp32_row_inputs_rejected_for_parallel_and_replicated_rows(self):
        for kind in ("row", "replicated"):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                projection(
                    self.layer(),
                    torch.ones((1, 3), dtype=torch.float32),
                    kind=kind,
                    role="row_output",
                    torch=torch,
                )


if __name__ == "__main__":
    unittest.main()
