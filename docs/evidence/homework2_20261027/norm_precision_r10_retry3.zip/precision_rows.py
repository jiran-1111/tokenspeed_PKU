# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""R10 projection adapter: accept FP32 norm outputs; retain R9 GEMM stores."""

import json
from functools import wraps
from pathlib import Path


def selected(prefix):
    if "layers." not in prefix or any(
        word in prefix for word in ("visual", "vision", "mtp")
    ):
        return None
    if prefix.endswith(
        (".linear_attn.out_proj", ".self_attn.o_proj", ".mlp.down_proj")
    ):
        return "row_output"
    if prefix.endswith(
        (".linear_attn.in_proj_qkvzba", ".self_attn.qkv_proj", ".mlp.gate_up_proj")
    ):
        return "column_output"
    return None


def projection(layer, input_, *, kind, role, torch):
    if kind == "row" and (not layer.input_is_parallel or layer.reduce_results):
        raise ValueError("expected local row output before the existing collective")
    if kind == "column" and layer.gather_output:
        raise ValueError("internal column gather is outside this experiment")
    allowed_inputs = (
        (torch.bfloat16, torch.float32)
        if role == "column_output"
        else (torch.bfloat16,)
    )
    if (
        layer.bias is not None
        or layer.weight.dtype != torch.bfloat16
        or input_.dtype not in allowed_inputs
    ):
        raise ValueError(
            "expected BF16 weights, BF16 row or BF16/FP32 column input, and no bias"
        )
    calculated = torch.nn.functional.linear(
        input_.float(), layer.weight.float(), bias=None
    )
    assert calculated.dtype == torch.float32
    return (calculated if role == "row_output" else calculated.to(torch.bfloat16)), None


def wrap_projection(original, *, kind, torch, arm_path):
    counts = {}

    @wraps(original)
    def forward(self, *args, **kwargs):
        role = selected(self.prefix)
        if role is None:
            return original(self, *args, **kwargs)
        if (
            len(args) != 1
            or kwargs
            or type(self.quant_method).__name__ != "UnquantizedLinearMethod"
        ):
            raise ValueError(
                "unsupported explicit arguments or quantization in precision experiment"
            )
        result = projection(self, args[0], kind=kind, role=role, torch=torch)
        if arm_path.exists():
            rank = self.tp_rank if kind in ("row", "column") else 0
            key = rank, role
            counts[key] = counts.get(key, 0) + 1
            case = json.loads(arm_path.read_text())
            filename = "precision_rows" if role == "row_output" else "precision_columns"
            with (Path(case["output"]) / f"{filename}_rank{rank}.jsonl").open(
                "a"
            ) as stream:
                stream.write(
                    json.dumps(
                        {
                            "rank": rank,
                            "prefix": self.prefix,
                            "kind": kind,
                            "role": role,
                            "call_index": counts[key],
                            "input_shape": list(args[0].shape),
                            "weight_shape": list(self.weight.shape),
                            "input_dtype": str(args[0].dtype),
                            "weight_dtype": str(self.weight.dtype),
                            "output_dtype": str(result[0].dtype),
                            "calculation_dtype": "torch.float32",
                            "hf32_allowed": torch.npu.matmul.allow_hf32,
                        }
                    )
                    + "\n"
                )
        return result

    return forward


def install(row_class, replicated_class, column_class, *, torch, arm_path):
    torch.npu.matmul.allow_hf32 = False
    assert torch.npu.matmul.allow_hf32 is False
    for cls, kind in (
        (row_class, "row"),
        (replicated_class, "replicated"),
        (column_class, "column"),
    ):
        cls.forward = wrap_projection(
            cls.forward, kind=kind, torch=torch, arm_path=arm_path
        )
