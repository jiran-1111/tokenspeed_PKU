# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""R10 diagnostic: retain R9 residuals and decoder norm outputs in FP32."""

import json
from functools import wraps
from pathlib import Path


def normalize(module, hidden, residual, *, torch, rmsnorm):
    if hidden.dtype not in (torch.bfloat16, torch.float32):
        raise ValueError("unexpected hidden dtype")
    if residual is not None and residual.dtype != torch.float32:
        raise ValueError("precision experiment requires FP32 residual storage")
    accumulated = hidden.float() if residual is None else residual + hidden.float()
    normalized = rmsnorm(accumulated, module.gemma_weight, module.variance_epsilon)
    if normalized.dtype != torch.float32:
        raise ValueError("normalization must return actual FP32 output")
    return normalized, accumulated


def install(comm_class, gemma_class, *, torch, rmsnorm, arm_path):
    original_input = comm_class.input_reduce_norm
    original_post = comm_class.post_attn_reduce_norm
    original_final = comm_class.final_norm
    counts = {}

    def log(self, label, normalized, residual):
        if arm_path.exists():
            rank = self.mapping.attn.tp_rank
            counts[rank] = counts.get(rank, 0) + 1
            case = json.loads(arm_path.read_text())
            with (Path(case["output"]) / f"precision_residual_rank{rank}.jsonl").open(
                "a"
            ) as stream:
                stream.write(
                    json.dumps(
                        {
                            "rank": rank,
                            "layer": self.layer_id,
                            "boundary": label,
                            "call_index": counts[rank],
                            "normalized_dtype": str(normalized.dtype),
                            "residual_dtype": str(residual.dtype),
                            "shape": list(normalized.shape),
                        }
                    )
                    + "\n"
                )

    @wraps(original_input)
    def input_norm(self, hidden, residual):
        if not isinstance(self.input_layernorm, gemma_class):
            return original_input(self, hidden, residual)
        assert not self.should_fuse(hidden.shape[0])
        result = normalize(
            self.input_layernorm, hidden, residual, torch=torch, rmsnorm=rmsnorm
        )
        log(self, "input", *result)
        return result

    @wraps(original_post)
    def post_norm(self, hidden, residual, ctx):
        if not isinstance(self.post_attn_layernorm, gemma_class):
            return original_post(self, hidden, residual, ctx)
        assert not self.should_fuse(hidden.shape[0])
        hidden, residual = self.post_attn_comm(hidden, residual, ctx)
        result = normalize(
            self.post_attn_layernorm, hidden, residual, torch=torch, rmsnorm=rmsnorm
        )
        log(self, "post_attention", *result)
        return result

    @wraps(original_final)
    def final_norm(self, hidden, residual, ctx, norm):
        if not isinstance(norm, gemma_class) or ctx.forward_mode.is_idle():
            return original_final(self, hidden, residual, ctx, norm)
        assert not self.should_fuse(hidden.shape[0])
        output, residual_out = normalize(
            norm, hidden, residual, torch=torch, rmsnorm=rmsnorm
        )
        output, _ = self.post_final_norm_comm(output, residual_out, ctx)
        log(self, "final", output, residual_out)
        return output, residual_out

    comm_class.input_reduce_norm = input_norm
    comm_class.post_attn_reduce_norm = post_norm
    comm_class.final_norm = final_norm
