# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

parser=argparse.ArgumentParser()
for name in ('archive','previous-bundle','source-root','head-reference','output'):
    parser.add_argument(f'--{name}',type=Path,required=True)
args=parser.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
manifest=read(args.archive/'export_manifest.json')
assert all(sha(args.archive/name)==expected for name,expected in manifest.items())
base=args.archive/'tools/full_parameter_identity_r2_20261027'
report=read(base/'analysis.json');assert report['passed'] and report['parameter_checks']==2472
assert sha(base/'original_math_vectors.npz')==report['npz_sha256']
arrays=np.load(base/'original_math_vectors.npz',allow_pickle=False)
prior=read(args.previous_bundle/'norm_precision_r10.json')
assert sha(args.previous_bundle/'norm_precision_r10.vectors.npz')==prior['vectors_file']['sha256']
old=np.load(args.previous_bundle/'norm_precision_r10.vectors.npz',allow_pickle=False)
artifacts=read(args.source_root/'docs/evidence/homework2_20261023/model_artifacts.json')
core=args.source_root/'docs/evidence/homework2_20261023/source_manifest.json'
assert sha(core)==report['core_source_sha256']
assert all(sha(args.source_root/name)==expected for name,expected in read(core).items())
count=0;vectors=0;excluded={}
for model,n in [('4b',18),('9b',10)]:
    excluded[model]={}
    for key,item in report['models'][model]['ranks'].items():
        identity=item['identity'];tp=identity['tp']
        config=args.source_root/f'configs/homework2/qwen35_{model}_tp{tp}.yaml'
        assert sha(config)==identity['config_sha256']
        match=next(row for row in artifacts['models'] if row['model_id']==identity['model_id'] and row['model_revision']==identity['model_revision'])
        assert identity['checkpoint_files_before']==identity['checkpoint_files_after']
        assert all(digest==match['files'][name]['sha256'] for name,digest in identity['checkpoint_files_before'].items())
        excluded[model][key]=len(identity['excluded_visual_parameters'])
        assert identity['excluded_visual_parameters'] and all(name.startswith('visual.') for name in identity['excluded_visual_parameters'])
        assert not identity['visual_parameter_identity_certified'] and identity['armed_text_forward_visual_module_calls_blocked']
        assert len(identity['parameters'])==412 and identity['all_exact']
        for entry in identity['parameters'].values():
            assert entry['exact_match'] and entry['actual_sha256']==entry['checkpoint_expected_sha256'] and entry['shape']==entry['expected_shape'] and entry['dtype']==entry['expected_dtype']
            count+=1
        a=arrays[f'{model}_{key}'];b=old[f'{model}_r2_{key}']
        assert a.dtype==b.dtype==np.float32 and a.shape==b.shape==(n,248320)
        meta=report['arrays'][f'{model}_{key}']
        assert hashlib.sha256(a.astype('<f4',copy=False).tobytes()).hexdigest()==meta['sha256']
        np.testing.assert_array_equal(a.view(np.uint32),b.view(np.uint32));vectors+=n
head=read(args.head_reference)
actual=report['models']['9b']['heads']['tp1_rank0']
assert actual==head['projected_head_fp32_tensor_sha256']
assert count==2472 and vectors==84
receipt={'passed':True,'parameter_ledger_entries_verified':count,'checks_per_rank':412,'original_logits_byte_equal_to_independently_bound_r2_npz':vectors,'nine_b_tp1_head_actual_sha_matches_expected_checkpoint_fp32':actual,'excluded_visual_parameter_entries':excluded,'core_files_rehashed':1531,'source_manifest_sha256':sha(core),'raw_parameter_bytes_recomputed_locally':False,'raw_pt_reextracted_locally':False,'scope':'Local JSON ledger, all archive hashes/config/artifact bindings, full vector byte comparison to separate previous exporter; actual NPU/checkpoint byte comparisons were performed by the reviewed frozen server collector, not locally repeated. New job parameter identity does not retroactively certify old job instances or semantic quality.','analysis_sha256':sha(base/'analysis.json'),'npz_sha256':sha(base/'original_math_vectors.npz'),'script_sha256':sha(Path(__file__)),'new_model_threshold':None,'runtime_math_changed':False}
with args.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
