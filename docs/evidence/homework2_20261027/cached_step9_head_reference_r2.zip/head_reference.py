# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""NumPy-only, fixed-input checkpoint head math; no acceptance thresholds.

NumPy is imported only inside functions so the CLI can set BLAS thread counts
before initializing it. No Torch, runtime or hardware modules are imported.
"""

from __future__ import annotations

import hashlib


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def project_bf16(values):
    """Round finite FP32 checkpoint values to BF16 ties-to-even, returned FP32."""
    import numpy as np

    values = np.asarray(values)
    require(
        values.dtype == np.float32 and np.isfinite(values).all(),
        "checkpoint projection requires finite FP32 values",
    )
    bits = values.view(np.uint32)
    rounded = (
        (bits + np.uint32(0x7FFF) + ((bits >> 16) & 1)) & np.uint32(0xFFFF0000)
    ).view(np.float32)
    require(np.isfinite(rounded).all(), "BF16 projection produced nonfinite values")
    return rounded


def head_reference(
    hidden, checkpoint_weight, *, compute_dtype: str, rows_per_chunk: int
):
    """Fixed [1,K] FP32 hidden times BF16-projected [V,K] checkpoint weights.

    Both compute precision and chunk extent are required. Only FP32 or FP64
    arithmetic is supported; the CLI fixes FP64. Output is [1,V] in selected
    precision. This does not certify the actual runtime head parameters.
    """
    import numpy as np

    require(
        compute_dtype in ("float32", "float64"),
        "explicit FP32/FP64 compute dtype required",
    )
    require(
        type(rows_per_chunk) is int and rows_per_chunk > 0,
        "positive integer chunk size required",
    )
    hidden, weight = np.asarray(hidden), np.asarray(checkpoint_weight)
    require(
        hidden.dtype == weight.dtype == np.float32
        and hidden.ndim == weight.ndim == 2
        and hidden.shape[0] == 1
        and hidden.shape[1] > 0
        and weight.shape[0] > 0
        and hidden.shape[1] == weight.shape[1]
        and np.isfinite(hidden).all()
        and np.isfinite(weight).all(),
        "head requires finite FP32 [1,K] hidden and [V,K] checkpoint weight",
    )
    dtype = np.dtype(compute_dtype)
    result = np.empty((1, weight.shape[0]), dtype=dtype)
    left = hidden.astype(dtype)
    try:
        with np.errstate(over="raise", invalid="raise", under="ignore"):
            for start in range(0, weight.shape[0], rows_per_chunk):
                stop = min(start + rows_per_chunk, weight.shape[0])
                right = project_bf16(weight[start:stop]).astype(dtype)
                result[:, start:stop] = left @ right.T
    except FloatingPointError as error:
        raise ValueError("head encountered invalid FP32/FP64 arithmetic") from error
    require(np.isfinite(result).all(), "head reference output must be finite")
    return result


def array_sha256(value) -> str:
    """SHA of canonical little-endian C-order numeric storage; dtype is separate."""
    import numpy as np

    value = np.asarray(value)
    require(
        value.dtype.kind in "fiu" and np.isfinite(value).all(),
        "hash requires finite numeric values",
    )
    little = value.astype(value.dtype.newbyteorder("<"), copy=False)
    return hashlib.sha256(np.ascontiguousarray(little).tobytes()).hexdigest()


def compare_vectors(actual, reference, *, vocab_start: int, top_k: int) -> dict:
    """Full-row FP64 errors, with ties ordered by ascending global token ID.

    The caller retains raw arrays separately. Zero-denominator/nonzero-error
    relative L2 is None, with reference_zero=True; no implicit epsilon is used.
    """
    import numpy as np

    actual, reference = np.asarray(actual), np.asarray(reference)
    require(
        actual.ndim == reference.ndim == 2
        and actual.shape == reference.shape
        and actual.shape[0] == 1
        and actual.shape[1] > 0
        and actual.dtype.kind == reference.dtype.kind == "f"
        and np.isfinite(actual).all()
        and np.isfinite(reference).all(),
        "finite vector shape mismatch",
    )
    require(
        type(vocab_start) is int
        and vocab_start >= 0
        and type(top_k) is int
        and 0 < top_k <= actual.size,
        "invalid vocabulary/top-k geometry",
    )
    a, r = actual[0].astype(np.float64), reference[0].astype(np.float64)
    delta = a - r
    error, denominator = float(np.linalg.norm(delta)), float(np.linalg.norm(r))
    ids = np.arange(a.size, dtype=np.int64) + vocab_start

    def top(value):
        order = np.lexsort((ids, -value))[:top_k]
        return [{"token_id": int(ids[i]), "value": float(value[i])} for i in order]

    probabilities = [0, 0.5, 0.9, 0.99, 1]
    absolute = np.abs(delta)
    return {
        "rows": a.size,
        "vocab_start": vocab_start,
        "relative_l2": (
            error / denominator if denominator else (0.0 if error == 0 else None)
        ),
        "reference_zero": denominator == 0,
        "error_l2": error,
        "reference_l2": denominator,
        "max_abs": float(absolute.max()),
        "max_abs_token_id": int(ids[absolute.argmax()]),
        "different_rows": int(np.count_nonzero(delta)),
        "mean_signed_error": float(delta.mean()),
        "min_signed_error": float(delta.min()),
        "max_signed_error": float(delta.max()),
        "error_quantile_probabilities": probabilities,
        "absolute_error_quantiles": np.quantile(absolute, probabilities).tolist(),
        "actual_argmax": int(ids[a.argmax()]),
        "reference_argmax": int(ids[r.argmax()]),
        "argmax_equal": bool(a.argmax() == r.argmax()),
        "actual_top": top(a),
        "reference_top": top(r),
        "actual_sha256": array_sha256(actual),
        "reference_sha256": array_sha256(reference),
        "signed_error_sha256": array_sha256(delta),
        "absolute_error_sha256": array_sha256(absolute),
    }
