# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Read-only CPU FP64 head replay for the original, SHA-bound cached step9.

Only main imports Torch/safetensors after disabling device backend autoload.
No model is instantiated and no runtime modules or device kernels are imported.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path, PureWindowsPath

from head_reference import (
    array_sha256,
    compare_vectors,
    head_reference,
    project_bf16,
    require,
)

CORE_SHA = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
ARTIFACT_SHA = "169e3069d4fdb70e57aaaffdee9f1a84b3f0001aceb4fe4a007ed66f9eeda1c6"
CONFIG_SHA = "1350758502a20ffc8d5dce0489365fc44c4f8ec751a03db1018f120b5e7cb047"
REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"
RANK_FILES = {
    "cached_step9.pt",
    "cached_step9_metadata.json",
    "step_09.pt",
    "step_09.json",
}
VOCAB, WIDTH = 248320, 4096


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_file(path: Path, expected: str) -> str:
    require(
        isinstance(expected, str)
        and re.fullmatch(r"[0-9a-f]{64}", expected) is not None,
        "invalid expected SHA256",
    )
    digest = sha(path)
    require(digest == expected, f"SHA256 mismatch for {path.name}")
    return digest


def child(root: Path, name: str) -> Path:
    require(
        isinstance(name, str)
        and bool(name)
        and not Path(name).anchor
        and not PureWindowsPath(name).anchor
        and ".." not in Path(name).parts
        and ".." not in PureWindowsPath(name).parts,
        "path must remain relative to its declared root",
    )
    root = root.resolve()
    result = (root / name).resolve()
    require(
        result.is_relative_to(root) and result != root,
        "resolved path escaped declared root",
    )
    return result


def checkpoint_path(root: Path, name: str) -> Path:
    """Permit the frozen deployment's file symlinks; content SHA is mandatory.

    Source/capture paths use child() instead. A checkpoint target may be outside
    source_final because that deployment links the original model files there.
    This helper only reads names supplied by the pinned config/artifact/index.
    """
    require(
        isinstance(name, str)
        and bool(name)
        and not Path(name).anchor
        and not PureWindowsPath(name).anchor
        and ".." not in Path(name).parts
        and ".." not in PureWindowsPath(name).parts,
        "checkpoint name must be a safe relative path",
    )
    return root / name


def head_header(path: Path) -> dict:
    """Read only the exact head entry, independent of safe-slice dtype APIs."""
    with path.open("rb") as stream:
        prefix = stream.read(8)
        require(len(prefix) == 8, "truncated safetensors header")
        length = int.from_bytes(prefix, "little")
        require(
            0 < length <= path.stat().st_size - 8, "invalid safetensors header length"
        )
        header = json.loads(stream.read(length))
    require("lm_head.weight" in header, "safetensors header has no exact head key")
    entry = header["lm_head.weight"]
    require(
        entry["dtype"] in ("BF16", "F32", "F16") and entry["shape"] == [VOCAB, WIDTH],
        "checkpoint head storage dtype/shape mismatch",
    )
    return entry


def validate_selection(root: Path, selection: dict) -> dict:
    require(
        isinstance(selection, dict)
        and set(selection) == {"9b"}
        and set(selection["9b"]) == {"tp1", "tp2"},
        "selection coverage mismatch",
    )
    result = {}
    for tp in (1, 2):
        item = selection["9b"][f"tp{tp}"]
        require(
            set(item) == {"path", "diagnostic_sha256", "captures_sha256"},
            "job hash fields mismatch",
        )
        require(
            item["path"] == f"cached_step9_9b_tp{tp}_20261026_r1",
            "original job name mismatch",
        )
        require(
            set(item["captures_sha256"]) == {str(rank) for rank in range(tp)},
            "rank hash coverage mismatch",
        )
        hashes = [item["diagnostic_sha256"]]
        for values in item["captures_sha256"].values():
            require(set(values) == RANK_FILES, "rank file hash coverage mismatch")
            hashes.extend(values.values())
        require(
            all(
                isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v) for v in hashes
            ),
            "invalid capture hash",
        )
        result[tp] = child(root, item["path"])
    return result


def verify_core(source: Path) -> None:
    path = source / "docs/evidence/homework2_20261023/source_manifest.json"
    verify_file(path, CORE_SHA)
    manifest = json.loads(path.read_text())
    require(
        isinstance(manifest, dict) and len(manifest) == 1531,
        "core file coverage mismatch",
    )
    for name, expected in manifest.items():
        verify_file(child(source, name), expected)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    for name in ("source-root", "jobs-root", "jobs-manifest", "output"):
        result.add_argument(f"--{name}", type=Path, required=True)
    for name in ("threads", "rows-per-chunk"):
        result.add_argument(f"--{name}", type=int, required=True)
    return result


def tensor(value, *, shape: tuple, dtype: str, torch):
    require(
        isinstance(value, torch.Tensor)
        and value.device.type == "cpu"
        and tuple(value.shape) == shape
        and str(value.dtype) == dtype
        and bool(torch.isfinite(value).all()),
        "captured tensor shape/dtype/finite mismatch",
    )
    return value.detach().float().contiguous().numpy().copy()


def load_rank(directory: Path, case: dict, *, tp: int, rank: int, torch) -> dict:
    import numpy as np

    capture = torch.load(
        directory / "cached_step9.pt", map_location="cpu", weights_only=True
    )
    step = torch.load(directory / "step_09.pt", map_location="cpu", weights_only=True)
    meta = capture["metadata"]
    require(
        json.loads(json.dumps(meta))
        == json.loads((directory / "cached_step9_metadata.json").read_text()),
        "capture sidecar mismatch",
    )
    require(
        meta["case_id"] == case["case_id"]
        and meta["tp"] == tp
        and meta["rank"] == rank
        and meta["step"] == 9
        and meta["position"] == meta["prefix_length_before"] == 136
        and meta["prefix_length_after"] == 137,
        "capture frontier identity mismatch",
    )
    require(
        step["case_id"] == case["case_id"]
        and step["step"] == 9
        and step["rank"] == rank
        and step["input_ids"] == [case["continuation_ids"][-1]]
        and step["positions"] == [136]
        and step["prefix_length"] == 137
        and step["original_dtype"] == "torch.float32",
        "original step09 frontier mismatch",
    )
    head = capture["observed"]["output_head"]
    weight = {"shape": [VOCAB // tp, WIDTH], "dtype": "torch.float32"}
    require(
        head["weight"] == weight == meta["output_head_weight"],
        "head shape/dtype metadata mismatch",
    )
    precision = head["precision"]
    require(
        precision == meta["precision"]
        and precision
        == {
            "npu_matmul_allow_hf32": False,
            "npu_conv_allow_hf32": True,
            "float32_matmul_precision": "high",
        },
        "observed original precision flags mismatch",
    )
    matmul = head["matmul"]
    require(
        matmul["rhs_shape"] == [WIDTH, VOCAB // tp]
        and matmul["rhs_dtype"] == "torch.float32"
        and matmul["weight_exported"] is False,
        "head matmul RHS observation mismatch",
    )
    hidden = tensor(
        matmul["input"], shape=(1, WIDTH), dtype="torch.float32", torch=torch
    )
    before_cast = tensor(
        head["input"], shape=(1, WIDTH), dtype="torch.bfloat16", torch=torch
    )
    final = capture["observed"]["norm_boundaries"]["final_norm"]["outputs"][0]
    normalized = tensor(final, shape=(1, WIDTH), dtype="torch.bfloat16", torch=torch)
    require(
        np.array_equal(hidden.view(np.uint32), before_cast.view(np.uint32))
        and np.array_equal(hidden.view(np.uint32), normalized.view(np.uint32))
        and np.array_equal(
            hidden.view(np.uint32), project_bf16(hidden).view(np.uint32)
        ),
        "final norm/head/cast continuity or BF16 representability mismatch",
    )
    local = tensor(
        matmul["output"], shape=(1, VOCAB // tp), dtype="torch.float32", torch=torch
    )
    full = tensor(head["output"], shape=(1, VOCAB), dtype="torch.float32", torch=torch)
    original = tensor(
        step["logits"], shape=(VOCAB,), dtype="torch.float32", torch=torch
    )[None, :]
    require(
        np.array_equal(full.view(np.uint32), original.view(np.uint32)),
        "head output differs from step09 logits",
    )
    require(
        np.array_equal(
            full[:, rank * (VOCAB // tp) : (rank + 1) * (VOCAB // tp)].view(np.uint32),
            local.view(np.uint32),
        ),
        "local head output is not its full-vocab row slice",
    )
    sampling = json.loads((directory / "step_09.json").read_text())
    greedy = int(full.argmax())
    require(
        step["raw_greedy_id"] == greedy
        and sampling["rank"] == rank
        and sampling["raw_greedy_id"]
        == sampling["broadcast_sampled_id"]
        == sampling["emitted_id"]
        == greedy
        and sampling["forced"] is False,
        "original terminal sampling mismatch",
    )
    raw_sha = lambda t: hashlib.sha256(
        t.detach().contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    return {
        "hidden": hidden,
        "actual_local": local,
        "actual_full": full,
        "precision": precision,
        "identity": {
            "tp": tp,
            "rank": rank,
            "vocab_start": rank * (VOCAB // tp),
            "weight": weight,
            "hidden_sha256": array_sha256(hidden),
            "before_cast_fp32_sha256": array_sha256(before_cast),
            "before_cast_bf16_storage_sha256": raw_sha(head["input"]),
            "final_norm_bf16_storage_sha256": raw_sha(final),
            "hidden_bf16_roundtrip_exact": True,
            "actual_local_sha256": array_sha256(local),
            "actual_full_sha256": array_sha256(full),
            "original_step09_sha256": array_sha256(original),
            "runtime_weight_identity_certified": False,
        },
    }


def main() -> None:
    args = parser().parse_args()
    require(
        args.threads > 0 and args.rows_per_chunk > 0,
        "positive threads and rows-per-chunk required",
    )
    require(
        "torch" not in sys.modules and "torch_npu" not in sys.modules,
        "CPU replay must start in a clean process",
    )
    for name in (
        "OMP_NUM_THREADS",
        "OPENBLAS_NUM_THREADS",
        "MKL_NUM_THREADS",
        "NUMEXPR_NUM_THREADS",
    ):
        os.environ[name] = str(args.threads)
    os.environ["TORCH_DEVICE_BACKEND_AUTOLOAD"] = "0"
    os.environ["ASCEND_RT_VISIBLE_DEVICES"] = ""
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    sys.modules["torch_npu"] = None
    import numpy as np
    import torch
    from safetensors import safe_open

    torch.set_num_threads(args.threads)
    torch.set_num_interop_threads(1)
    source = args.source_root.resolve(strict=True)
    output = args.output.resolve()
    vectors = output.with_suffix(".vectors.npz")
    require(
        output != vectors and not output.exists() and not vectors.exists(),
        "output must be new",
    )
    require(output.parent.is_dir(), "output parent directory must already exist")
    verify_core(source)
    artifacts_path = source / "docs/evidence/homework2_20261023/model_artifacts.json"
    verify_file(artifacts_path, ARTIFACT_SHA)
    config_path = source / "configs/homework2/qwen35_9b_tp1.yaml"
    verify_file(config_path, CONFIG_SHA)
    config = json.loads(config_path.read_text())
    require(
        config["model_id"] == "Qwen/Qwen3.5-9B"
        and config["model_revision"] == REVISION
        and config["dtype"] == "bfloat16"
        and config["tp_size"] == 1
        and config["hf_overrides"]["npu_lm_head_dtype"] == "float32",
        "fixed model config mismatch",
    )
    artifact = [
        row
        for row in json.loads(artifacts_path.read_text())["models"]
        if row["model_id"] == config["model_id"] and row["model_revision"] == REVISION
    ]
    require(len(artifact) == 1, "checkpoint artifact ambiguity")
    expected_files = artifact[0]["files"]
    checkpoint = checkpoint_path(source, config["local_model_path"])
    verified_files = {}

    def verify_checkpoint(name):
        require(name in expected_files, "checkpoint file absent from frozen artifacts")
        path = checkpoint_path(checkpoint, name)
        require(
            path.stat().st_size == expected_files[name]["bytes"],
            "checkpoint byte size mismatch",
        )
        verified_files[name] = verify_file(path, expected_files[name]["sha256"])
        return path

    model_config = json.loads(verify_checkpoint("config.json").read_text())
    text = model_config["text_config"]
    require(
        text["hidden_size"] == WIDTH
        and text["vocab_size"] == VOCAB
        and not model_config.get("tie_word_embeddings", False)
        and not text.get("tie_word_embeddings", False),
        "head geometry/tied embedding mismatch",
    )
    index_path = verify_checkpoint("model.safetensors.index.json")
    indices = json.loads(index_path.read_text())["weight_map"]
    require(
        "lm_head.weight" in indices, "exact untied lm_head.weight index key required"
    )
    weight_path = verify_checkpoint(indices["lm_head.weight"])
    checkpoint_dtype = head_header(weight_path)["dtype"]
    selection = json.loads(args.jobs_manifest.read_text())
    selected = validate_selection(args.jobs_root, selection)
    bound_files, ranks, cases = {}, {}, []
    for tp, directory in selected.items():
        entry = selection["9b"][f"tp{tp}"]
        diagnostic = directory / "diagnostic.json"
        bound_files[diagnostic] = entry["diagnostic_sha256"]
        verify_file(diagnostic, entry["diagnostic_sha256"])
        run = json.loads(diagnostic.read_text())
        guard = run["guard"]
        require(
            run["status"] == "collected"
            and run["capture_step"] == 9
            and run["vectors_per_rank"] == 10
            and run["execution_mode"] == "eager"
            and run["diagnostic_only"] is True
            and run["performance_eligible"] is False
            and run["original_graph_failures_preserved"] is True
            and guard["sources_sha"] == guard["sources_after_sha"] == CORE_SHA
            and guard["sources_unchanged"] is True
            and guard["own_children_released"] is True
            and guard["violations"] == [],
            "capture run/guard mismatch",
        )
        case = run["case"]
        require(
            case["case_id"] == "hw2_9b_short_first_divergence"
            and len(case["input_ids"]) == 128
            and len(case["continuation_ids"]) == 9
            and case["vector_count"] == 10,
            "original case mismatch",
        )
        cases.append(case)
        for rank in range(tp):
            rank_dir = directory / f"rank_{rank}"
            for name, digest in entry["captures_sha256"][str(rank)].items():
                path = rank_dir / name
                bound_files[path] = digest
                verify_file(path, digest)
            ranks[tp, rank] = load_rank(rank_dir, case, tp=tp, rank=rank, torch=torch)
    require(cases[0] == cases[1], "cross-TP original cases differ")
    require(
        np.array_equal(
            ranks[2, 0]["actual_full"].view(np.uint32),
            ranks[2, 1]["actual_full"].view(np.uint32),
        ),
        "TP2 full vectors differ",
    )
    raw_weight_digest, projected_weight_digest = hashlib.sha256(), hashlib.sha256()
    with safe_open(weight_path, framework="pt", device="cpu") as reader:
        require(
            "lm_head.weight" in reader.keys(),
            "index-selected file has no exact head key",
        )
        sliced = reader.get_slice("lm_head.weight")
        require(sliced.get_shape() == [VOCAB, WIDTH], "checkpoint head shape mismatch")
        for item in ranks.values():
            item["reference"] = np.empty_like(item["actual_local"], dtype=np.float64)
        for start in range(0, VOCAB, args.rows_per_chunk):
            stop = min(VOCAB, start + args.rows_per_chunk)
            original = sliced[start:stop, :].contiguous()
            require(bool(torch.isfinite(original).all()), "nonfinite checkpoint head")
            raw_weight_digest.update(original.view(torch.uint8).numpy().tobytes())
            projected = original.to(torch.bfloat16).float().numpy()
            projected_weight_digest.update(
                np.ascontiguousarray(projected.astype("<f4", copy=False)).tobytes()
            )
            for (tp, rank), item in ranks.items():
                offset = rank * (VOCAB // tp)
                lo, hi = max(start, offset), min(stop, offset + VOCAB // tp)
                if lo < hi:
                    item["reference"][:, lo - offset : hi - offset] = head_reference(
                        item["hidden"],
                        projected[lo - start : hi - start],
                        compute_dtype="float64",
                        rows_per_chunk=args.rows_per_chunk,
                    )
    report = {
        "diagnostic_only": True,
        "performance_eligible": False,
        "thresholds_added": False,
        "original_graph_failures_preserved": True,
        "runtime_weight_identity_certified": False,
        "scope": "Each actual fixed head input times checkpoint-expected BF16-projected weights; no runtime parameter identity certificate.",
        "compute_dtype": "float64",
        "rows_per_chunk": args.rows_per_chunk,
        "threads": args.threads,
        "core_source_sha256": CORE_SHA,
        "core_files": 1531,
        "model_revision": REVISION,
        "analyzer_sha256": sha(Path(__file__)),
        "math_sha256": sha(Path(__file__).with_name("head_reference.py")),
        "jobs_manifest_sha256": sha(args.jobs_manifest),
        "selection": selection,
        "model_artifacts_sha256": ARTIFACT_SHA,
        "runtime_config_sha256": CONFIG_SHA,
        "checkpoint_files": verified_files,
        "checkpoint_head_key": "lm_head.weight",
        "checkpoint_head_storage_dtype": checkpoint_dtype,
        "checkpoint_head_tensor_sha256": raw_weight_digest.hexdigest(),
        "projected_head_fp32_tensor_sha256": projected_weight_digest.hexdigest(),
        "versions": {"numpy": np.__version__, "torch": str(torch.__version__)},
        "ranks": {},
    }
    arrays = {}
    for (tp, rank), item in ranks.items():
        name = f"tp{tp}_rank{rank}"
        offset = rank * (VOCAB // tp)
        report["ranks"][name] = {
            **item["identity"],
            "precision": item["precision"],
            "own_input_reference": compare_vectors(
                item["actual_local"], item["reference"], vocab_start=offset, top_k=10
            ),
        }
        delta = item["actual_local"].astype(np.float64) - item["reference"]
        for suffix, value in {
            "hidden": item["hidden"],
            "actual_local": item["actual_local"],
            "actual_full": item["actual_full"],
            "reference": item["reference"],
            "signed_error": delta,
            "absolute_error": np.abs(delta),
            "token_ids": np.arange(offset, offset + VOCAB // tp, dtype=np.int64),
        }.items():
            arrays[f"{name}_{suffix}"] = value
    combined = np.concatenate([ranks[2, r]["reference"] for r in range(2)], axis=1)
    report["full_vocabulary"] = {
        "tp1_actual_vs_own_reference": compare_vectors(
            ranks[1, 0]["actual_full"],
            ranks[1, 0]["reference"],
            vocab_start=0,
            top_k=10,
        ),
        "tp2_actual_vs_own_reference": compare_vectors(
            ranks[2, 0]["actual_full"], combined, vocab_start=0, top_k=10
        ),
        "tp2_actual_vs_tp1_actual": compare_vectors(
            ranks[2, 0]["actual_full"],
            ranks[1, 0]["actual_full"],
            vocab_start=0,
            top_k=10,
        ),
        "tp2_own_reference_vs_tp1_own_reference": compare_vectors(
            combined, ranks[1, 0]["reference"], vocab_start=0, top_k=10
        ),
    }
    arrays["tp2_full_reference"] = combined
    verify_core(source)
    verify_file(artifacts_path, ARTIFACT_SHA)
    verify_file(config_path, CONFIG_SHA)
    for name, expected in verified_files.items():
        verify_file(checkpoint_path(checkpoint, name), expected)
    for path, expected in bound_files.items():
        verify_file(path, expected)
    require(sys.modules.get("torch_npu") is None, "device backend must remain blocked")
    report["source_and_bound_inputs_reverified_after"] = True
    report["arrays"] = {
        name: {
            "shape": list(value.shape),
            "dtype": str(value.dtype),
            "sha256": array_sha256(value),
        }
        for name, value in arrays.items()
    }
    with vectors.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    report["vectors_file"] = {"name": vectors.name, "sha256": sha(vectors)}
    with output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    print(
        json.dumps(
            {
                "status": "analyzed",
                "ranks": 3,
                "rows": VOCAB,
                "compute_dtype": "float64",
                "runtime_weight_identity_certified": False,
            }
        )
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(
            json.dumps(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "reason": (
                        str(error)
                        if isinstance(error, ValueError)
                        else "input or execution failure"
                    ),
                }
            ),
            file=sys.stderr,
        )
        sys.exit(1)
