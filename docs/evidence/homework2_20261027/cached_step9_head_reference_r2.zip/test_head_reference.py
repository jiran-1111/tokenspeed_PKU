# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent small examples; no hardware, checkpoint or acceptance threshold."""

import hashlib
import json

import numpy as np
import pytest

try:
    import head_reference as ref
except ModuleNotFoundError as error:
    if error.name != "head_reference":
        raise
    ref = None


def test_hand_dot_reference_uses_checkpoint_bf16_projection():
    assert ref is not None, "head reference is not implemented"
    hidden = np.array([[2, -1]], dtype=np.float32)
    weights = np.array([[1 + 1 / 256, 3], [1 + 3 / 256, 1]], dtype=np.float32)
    actual = ref.head_reference(
        hidden, weights, compute_dtype="float64", rows_per_chunk=1
    )
    np.testing.assert_array_equal(actual, [[-1, 1 + 1 / 32]])
    assert actual.dtype == np.float64


@pytest.mark.parametrize("dtype", ["float32", "float64"])
@pytest.mark.parametrize("chunk", [1, 2, 8])
def test_chunks_cover_every_vocab_row_and_do_not_mutate_inputs(dtype, chunk):
    hidden = np.array([[3, 4]], dtype=np.float32)
    weights = np.array([[1, 0], [0, 1], [1, -1]], dtype=np.float32)
    saved = hidden.copy(), weights.copy()
    output = ref.head_reference(
        hidden, weights, compute_dtype=dtype, rows_per_chunk=chunk
    )
    np.testing.assert_array_equal(output, [[3, 4, -1]])
    assert output.dtype == np.dtype(dtype)
    for before, after in zip(saved, (hidden, weights)):
        np.testing.assert_array_equal(before, after)


def test_float64_accumulation_retains_a_small_term_lost_in_float32_product():
    hidden = np.array([[1 + 2**-12, 1]], dtype=np.float32)
    weights = np.array([[1 + 2**-7, -1]], dtype=np.float32)
    exact = (1 + 2**-12) * (1 + 2**-7) - 1
    output = ref.head_reference(
        hidden, weights, compute_dtype="float64", rows_per_chunk=1
    )
    assert output[0, 0] == exact


def test_bf16_projection_ties_to_even_and_preserves_negative_values():
    x = np.array(
        [1 + 1 / 256, 1 + 3 / 256, -1 - 1 / 256, -1 - 3 / 256], dtype=np.float32
    )
    np.testing.assert_array_equal(ref.project_bf16(x), [1, 1 + 1 / 64, -1, -1 - 1 / 64])
    assert ref.project_bf16(x).dtype == np.float32


def test_comparison_keeps_every_signed_row_and_deterministic_global_top_ids():
    actual = np.array([[3, 3, 0, 1]], dtype=np.float32)
    reference = np.array([[2, 3, -1, 1]], dtype=np.float64)
    metrics = ref.compare_vectors(actual, reference, vocab_start=20, top_k=3)
    assert metrics["actual_argmax"] == 20 and metrics["reference_argmax"] == 21
    assert [r["token_id"] for r in metrics["actual_top"]] == [20, 21, 23]
    assert [r["token_id"] for r in metrics["reference_top"]] == [21, 20, 23]
    assert metrics["max_abs"] == 1 and metrics["max_abs_token_id"] == 20
    assert metrics["different_rows"] == 2 and metrics["rows"] == 4
    np.testing.assert_allclose(metrics["relative_l2"], np.sqrt(2 / 15))
    np.testing.assert_array_equal(
        metrics["error_quantile_probabilities"], [0, 0.5, 0.9, 0.99, 1]
    )


def test_zero_reference_has_explicit_null_ratio_without_acceptance_threshold():
    value = np.zeros((1, 2), dtype=np.float32)
    same = ref.compare_vectors(value, value, vocab_start=0, top_k=2)
    assert same["reference_zero"] and same["relative_l2"] == 0
    other = ref.compare_vectors(value + 1, value, vocab_start=0, top_k=2)
    assert other["reference_zero"] and other["relative_l2"] is None
    assert "passed" not in other and "threshold" not in other


@pytest.mark.parametrize(
    "dtype,chunk",
    [(None, 1), ("float16", 1), ("float64", 0), ("float64", True), ("float64", 1.5)],
)
def test_rejects_implicit_or_invalid_math_selectors(dtype, chunk):
    with pytest.raises(ValueError):
        ref.head_reference(
            np.ones((1, 2), dtype=np.float32),
            np.ones((3, 2), dtype=np.float32),
            compute_dtype=dtype,
            rows_per_chunk=chunk,
        )


@pytest.mark.parametrize(
    "hidden,weights",
    [
        (np.ones((2, 2), dtype=np.float32), np.ones((3, 2), dtype=np.float32)),
        (np.ones((1, 2), dtype=np.float64), np.ones((3, 2), dtype=np.float32)),
        (np.ones((1, 2), dtype=np.float32), np.ones((0, 2), dtype=np.float32)),
        (np.ones((1, 2), dtype=np.float32), np.ones((3, 1), dtype=np.float32)),
        (np.full((1, 2), np.nan, dtype=np.float32), np.ones((3, 2), dtype=np.float32)),
        (np.ones((1, 2), dtype=np.float32), np.full((3, 2), np.inf, dtype=np.float32)),
    ],
)
def test_rejects_invalid_operands(hidden, weights):
    with pytest.raises(ValueError):
        ref.head_reference(hidden, weights, compute_dtype="float64", rows_per_chunk=1)


def test_compute_selector_has_no_default_and_fp32_overflow_is_rejected():
    hidden = np.full((1, 2), np.finfo(np.float32).max, dtype=np.float32)
    weights = np.ones((1, 2), dtype=np.float32)
    with pytest.raises(TypeError):
        ref.head_reference(hidden, weights, rows_per_chunk=1)
    with pytest.raises(ValueError, match="FP32|finite"):
        ref.head_reference(hidden, weights, compute_dtype="float32", rows_per_chunk=1)


def test_array_hash_is_canonical_little_endian_c_order():
    x = np.array([[1, 2]], dtype=np.float32)
    assert ref.array_sha256(x) == hashlib.sha256(x.astype("<f4").tobytes()).hexdigest()


def test_selection_requires_all_rank_hashes_and_original_job_names(tmp_path):
    import run_head_reference as cli

    files = (
        "cached_step9.pt",
        "cached_step9_metadata.json",
        "step_09.pt",
        "step_09.json",
    )
    selection = {
        "9b": {
            f"tp{tp}": {
                "path": f"cached_step9_9b_tp{tp}_20261026_r1",
                "diagnostic_sha256": "a" * 64,
                "captures_sha256": {
                    str(rank): {name: "b" * 64 for name in files} for rank in range(tp)
                },
            }
            for tp in (1, 2)
        }
    }
    selected = cli.validate_selection(tmp_path, selection)
    assert len(selected) == 2
    del selection["9b"]["tp2"]["captures_sha256"]["1"]["step_09.pt"]
    with pytest.raises(ValueError, match="hash|coverage"):
        cli.validate_selection(tmp_path, selection)


@pytest.mark.parametrize(
    "name", ["../escape", "/absolute", "C:/outside", "x/../../outside"]
)
def test_source_paths_cannot_escape_the_declared_root(tmp_path, name):
    import run_head_reference as cli

    with pytest.raises(ValueError):
        cli.child(tmp_path, name)


def test_expected_file_digest_is_verified_before_any_loading(tmp_path):
    import run_head_reference as cli

    path = tmp_path / "synthetic"
    path.write_bytes(b"plain fixture")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert cli.verify_file(path, digest) == digest
    with pytest.raises(ValueError, match="SHA"):
        cli.verify_file(path, "0" * 64)


def test_cli_requires_every_parameter_and_has_no_device_option():
    import run_head_reference as cli

    parser = cli.parser()
    with pytest.raises(SystemExit):
        parser.parse_args([])
    args = parser.parse_args(
        [
            "--source-root",
            "s",
            "--jobs-root",
            "j",
            "--jobs-manifest",
            "m",
            "--output",
            "o",
            "--threads",
            "1",
            "--rows-per-chunk",
            "16",
        ]
    )
    assert args.rows_per_chunk == 16 and not hasattr(args, "device")


def test_checkpoint_links_are_allowed_only_for_lexically_safe_frozen_names(tmp_path):
    import run_head_reference as cli

    assert (
        cli.checkpoint_path(tmp_path, "model.safetensors.index.json")
        == tmp_path / "model.safetensors.index.json"
    )
    for name in ("../outside", "C:/outside", "/outside"):
        with pytest.raises(ValueError):
            cli.checkpoint_path(tmp_path, name)


def test_safetensors_header_uses_exact_key_and_checks_metadata(tmp_path):
    import run_head_reference as cli

    header = {
        "lm_head.weight": {
            "dtype": "BF16",
            "shape": [248320, 4096],
            "data_offsets": [0, 248320 * 4096 * 2],
        }
    }
    payload = json.dumps(header).encode()
    path = tmp_path / "header-only-fixture"
    path.write_bytes(len(payload).to_bytes(8, "little") + payload)
    assert cli.head_header(path)["dtype"] == "BF16"
    header["other.weight"] = header.pop("lm_head.weight")
    payload = json.dumps(header).encode()
    path.write_bytes(len(payload).to_bytes(8, "little") + payload)
    with pytest.raises(ValueError, match="head"):
        cli.head_header(path)


class FakeTensor:
    """Tiny CPU tensor protocol for verifying capture validation without Torch."""

    def __init__(self, value, dtype="torch.float32"):
        from types import SimpleNamespace

        self.values = np.asarray(value)
        self.dtype = dtype
        self.shape = self.values.shape
        self.device = SimpleNamespace(type="cpu")

    def detach(self):
        return self

    def float(self):
        return FakeTensor(self.values.astype(np.float32))

    def contiguous(self):
        return self

    def numpy(self):
        return self.values

    def view(self, dtype):
        if self.dtype == "torch.bfloat16":
            value = (self.values.astype(np.float32).view(np.uint32) >> 16).astype(
                np.uint16
            )
        else:
            value = self.values
        return FakeTensor(value.view(dtype), "torch.uint8")


def captured_head_fixture(tmp_path, *, tp, rank):
    from types import SimpleNamespace

    import run_head_reference as cli

    hidden = np.ones((1, cli.WIDTH), dtype=np.float32)
    full = np.zeros((1, cli.VOCAB), dtype=np.float32)
    full[0, 25389] = 1
    precision = {
        "npu_matmul_allow_hf32": False,
        "npu_conv_allow_hf32": True,
        "float32_matmul_precision": "high",
    }
    weight = {"shape": [cli.VOCAB // tp, cli.WIDTH], "dtype": "torch.float32"}
    head = {
        "weight": weight,
        "precision": precision,
        "input": FakeTensor(hidden, "torch.bfloat16"),
        "output": FakeTensor(full),
        "matmul": {
            "input": FakeTensor(hidden.copy()),
            "output": FakeTensor(
                full[
                    :, rank * (cli.VOCAB // tp) : (rank + 1) * (cli.VOCAB // tp)
                ].copy()
            ),
            "rhs_shape": [cli.WIDTH, cli.VOCAB // tp],
            "rhs_dtype": "torch.float32",
            "weight_exported": False,
        },
    }
    case = {
        "case_id": "hw2_9b_short_first_divergence",
        "continuation_ids": list(range(9)),
    }
    meta = {
        "case_id": case["case_id"],
        "tp": tp,
        "rank": rank,
        "step": 9,
        "position": 136,
        "prefix_length_before": 136,
        "prefix_length_after": 137,
        "output_head_weight": weight,
        "precision": precision,
    }
    capture = {
        "metadata": meta,
        "observed": {
            "output_head": head,
            "norm_boundaries": {
                "final_norm": {"outputs": [FakeTensor(hidden, "torch.bfloat16")]}
            },
        },
    }
    step = {
        "case_id": case["case_id"],
        "step": 9,
        "rank": rank,
        "input_ids": [8],
        "positions": [136],
        "prefix_length": 137,
        "original_dtype": "torch.float32",
        "logits": FakeTensor(full[0].copy()),
        "raw_greedy_id": 25389,
    }
    sampling = {
        "rank": rank,
        "raw_greedy_id": 25389,
        "broadcast_sampled_id": 25389,
        "emitted_id": 25389,
        "forced": False,
    }
    (tmp_path / "cached_step9_metadata.json").write_text(json.dumps(meta))
    (tmp_path / "step_09.json").write_text(json.dumps(sampling))
    torch = SimpleNamespace(
        Tensor=FakeTensor,
        uint8=np.uint8,
        isfinite=lambda t: np.isfinite(t.values),
        load=lambda p, **kwargs: capture if p.name == "cached_step9.pt" else step,
    )
    return case, capture, step, sampling, torch


@pytest.mark.parametrize("tp,rank", [(1, 0), (2, 0), (2, 1)])
def test_original_capture_validates_bf16_cast_head_and_full_vector_continuity(
    tmp_path, tp, rank
):
    import run_head_reference as cli

    case, _, _, _, torch = captured_head_fixture(tmp_path, tp=tp, rank=rank)
    result = cli.load_rank(tmp_path, case, tp=tp, rank=rank, torch=torch)
    assert result["identity"]["hidden_bf16_roundtrip_exact"]
    assert result["identity"]["runtime_weight_identity_certified"] is False
    assert result["actual_local"].shape == (1, cli.VOCAB // tp)
    assert (
        result["identity"]["actual_full_sha256"]
        == result["identity"]["original_step09_sha256"]
    )


@pytest.mark.parametrize(
    "failure", ["flag", "cast", "slice", "full", "position", "sampling"]
)
def test_capture_mismatches_are_rejected_before_head_reference(tmp_path, failure):
    import run_head_reference as cli

    case, capture, step, sampling, torch = captured_head_fixture(tmp_path, tp=2, rank=0)
    head = capture["observed"]["output_head"]
    if failure == "flag":
        head["precision"]["npu_matmul_allow_hf32"] = True
    elif failure == "cast":
        head["matmul"]["input"].values[0, 0] = np.float32(1.001)
    elif failure == "slice":
        head["matmul"]["output"].values[0, 0] += 1
    elif failure == "full":
        step["logits"].values[0] += 1
    elif failure == "position":
        capture["metadata"]["position"] = 135
    else:
        sampling["forced"] = True
        (tmp_path / "step_09.json").write_text(json.dumps(sampling))
    with pytest.raises(ValueError):
        cli.load_rank(tmp_path, case, tp=2, rank=0, torch=torch)


def test_json_sidecar_accepts_nested_integer_layer_keys_without_mutating_metadata(
    tmp_path,
):
    from copy import deepcopy

    import run_head_reference as cli

    case, capture, _, _, torch = captured_head_fixture(tmp_path, tp=2, rank=0)
    meta = capture["metadata"]
    meta["communication"] = {
        7: {"attention_tp_rank": 0, "attention_tp_size": 2, "should_fuse": False},
        8: {"attention_tp_rank": 0, "attention_tp_size": 2, "should_fuse": False},
    }
    before = deepcopy(meta)
    (tmp_path / "cached_step9_metadata.json").write_text(json.dumps(meta))
    result = cli.load_rank(tmp_path, case, tp=2, rank=0, torch=torch)
    assert result["identity"]["hidden_bf16_roundtrip_exact"]
    assert capture["metadata"] is meta and meta == before
    assert set(meta["communication"]) == {7, 8}


@pytest.mark.parametrize("difference", ["number", "field"])
def test_json_key_normalization_preserves_nested_value_and_field_mismatch_rejection(
    tmp_path, difference
):
    import run_head_reference as cli

    case, capture, _, _, torch = captured_head_fixture(tmp_path, tp=2, rank=0)
    meta = capture["metadata"]
    meta["communication"] = {
        7: {"attention_tp_rank": 0, "attention_tp_size": 2, "should_fuse": False}
    }
    sidecar = json.loads(json.dumps(meta))
    if difference == "number":
        sidecar["communication"]["7"]["attention_tp_size"] = 1
    else:
        del sidecar["communication"]["7"]["should_fuse"]
    (tmp_path / "cached_step9_metadata.json").write_text(json.dumps(sidecar))
    with pytest.raises(ValueError, match="capture sidecar mismatch"):
        cli.load_rank(tmp_path, case, tp=2, rank=0, torch=torch)
    assert set(meta["communication"]) == {7}
    assert meta["communication"][7]["attention_tp_size"] == 2
    assert meta["communication"][7]["should_fuse"] is False
