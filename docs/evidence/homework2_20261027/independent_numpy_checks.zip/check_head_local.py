# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import hashlib
import json
from pathlib import Path

import numpy as np

root = Path(__file__).parent
base = root.parent / 'hw2-20261023/supplement_export_cpu_step9_and_sensitivity_20261027'
folder = base / 'step9_head_reference_r2_20261027'
report = json.loads((folder / 'head_reference.json').read_text(encoding='utf-8'))
data = np.load(folder / 'head_reference.vectors.npz', allow_pickle=False)
checked = {}
for name, rank in report['ranks'].items():
    actual = data[f'{name}_actual_local'].astype(np.float64)
    reference = data[f'{name}_reference']
    error = actual - reference
    np.testing.assert_array_equal(error, data[f'{name}_signed_error'])
    np.testing.assert_array_equal(np.abs(error), data[f'{name}_absolute_error'])
    metrics = {'relative_l2': float(np.linalg.norm(error) / np.linalg.norm(reference)), 'max_abs': float(np.max(np.abs(error)))}
    for key, value in metrics.items():
        np.testing.assert_allclose(value, rank['own_input_reference'][key], rtol=2e-14, atol=0)
    checked[name] = metrics
np.testing.assert_array_equal(np.concatenate([data['tp2_rank0_reference'], data['tp2_rank1_reference']], axis=-1), data['tp2_full_reference'])
np.testing.assert_array_equal(np.concatenate([data['tp2_rank0_actual_local'], data['tp2_rank1_actual_local']], axis=-1), data['tp2_rank0_actual_full'])
np.testing.assert_array_equal(data['tp2_rank0_actual_full'], data['tp2_rank1_actual_full'])
tp1 = data['tp1_rank0_actual_full'].astype(np.float64)
tp2 = data['tp2_rank0_actual_full'].astype(np.float64)
ref1 = data['tp1_rank0_reference']
ref2 = data['tp2_full_reference']
cross = {label: {'relative_l2': float(np.linalg.norm(b-a)/np.linalg.norm(a)), 'max_abs': float(np.max(np.abs(b-a))), 'argmax': [int(a.argmax()), int(b.argmax())]} for label, a, b in [('actual',tp1,tp2), ('own_cpu_reference',ref1,ref2)]}
receipt = {'passed': True, 'own_input_metrics': checked, 'cross_tp': cross, 'npz_sha256': hashlib.sha256((folder/'head_reference.vectors.npz').read_bytes()).hexdigest(), 'scope': 'Independent NumPy recomputation of saved full vectors, not a local matrix replay or runtime weight identity certificate', 'runtime_weight_identity_certified': False, 'new_threshold': None}
with (root/'head_local_verification.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt))
