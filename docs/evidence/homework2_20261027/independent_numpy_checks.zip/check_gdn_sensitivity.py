# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Independent NumPy review; imports no producer, torch or device modules.

SHA, shapes, exact identities and discrete comparison fields are asserted.
Floating discrepancies are measured and retained, without an acceptance limit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform

import numpy as np

RANKS = ("tp1_rank0", "tp2_rank0", "tp2_rank1")
LAYERS = (8, 9, 10)
CORE = "2a1a2196dba54928cc0bde375eb8412df0c222f8cf98cf4ff94c9f66c13f2af3"
REVISION = "c202236235762e1c871ad0ccb60c8ee5ba337b9a"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def difference(local, stored):
    local, stored = np.asarray(local), np.asarray(stored)
    assert local.shape == stored.shape
    assert np.isfinite(local).all() and np.isfinite(stored).all()
    delta = local.astype(np.float64) - stored.astype(np.float64)
    result = {"elements": int(local.size), "exact_equal": bool(np.array_equal(local, stored)),
              "different_elements": int(np.count_nonzero(delta)),
              "max_abs": float(np.max(np.abs(delta))) if delta.size else 0.0}
    if local.dtype == stored.dtype == np.float32 and local.size:
        # Map negative and positive IEEE bit patterns into monotonic integer order.
        def ordered(value):
            bits = value.view(np.uint32).astype(np.int64)
            return np.where(bits >= 0x80000000, 0xFFFFFFFF - bits, bits + 0x80000000)
        result["max_fp32_ulp_distance"] = int(np.max(np.abs(ordered(local) - ordered(stored))))
    return result


def bf16(value):
    bits = np.asarray(value, dtype=np.float32).view(np.uint32)
    return ((bits + np.uint32(32767) + ((bits >> 16) & 1))
            & np.uint32(0xFFFF0000)).view(np.float32)


def core_statistics(core, eps):
    squares = np.mean(core * core, axis=-1, dtype=np.float32)
    return {"rms": np.sqrt(squares), "inv_scale": np.float32(1) / np.sqrt(squares + eps)}


def z_statistics(z):
    e = np.exp(-np.abs(z))
    sigmoid = np.where(z >= 0, np.float32(1) / (np.float32(1) + e),
                       e / (np.float32(1) + e))
    silu = z * sigmoid
    return silu, {"min": np.min(z, axis=-1), "max": np.max(z, axis=-1),
                  "silu_min": np.min(silu, axis=-1), "silu_max": np.max(silu, axis=-1)}


def norm_output(core, z, weight, eps):
    stats = core_statistics(core, eps)
    silu, zstats = z_statistics(z)
    return core * stats["inv_scale"][:, None] * weight * silu, stats, zstats


def softplus(a, bias, alog):
    x = a + bias
    runtime = x.copy()
    mask = x <= np.float32(20)
    runtime[mask] = np.log(np.float32(1) + np.exp(x[mask]))
    stable = np.maximum(x, np.float32(0)) + np.log1p(np.exp(-np.abs(x)))
    coefficient = -np.exp(alog)
    rg, sg = coefficient * runtime, coefficient * stable
    rd, sd = np.exp(rg), np.exp(sg)
    return {"x": x, "cancellation_zero_indices": np.flatnonzero((runtime == 0) & (stable > 0)),
            "runtime_softplus": runtime, "stable_softplus": stable,
            "runtime_g": rg, "stable_g": sg, "runtime_decay": rd, "stable_decay": sd,
            "g_difference": rg - sg, "decay_difference": rd - sd}


def comparison(actual, reference):
    delta = actual.astype(np.float64) - reference.astype(np.float64)
    denominator = np.linalg.norm(reference.astype(np.float64).ravel())
    magnitude = np.linalg.norm(delta.ravel())
    return {"shape": list(actual.shape),
            "relative_l2": float(magnitude / denominator) if denominator else (0.0 if magnitude == 0 else None),
            "reference_zero": bool(denominator == 0), "max_abs": float(np.abs(delta).max()),
            "max_abs_index": list(map(int, np.unravel_index(np.abs(delta).argmax(), delta.shape))),
            "different_elements": int(np.count_nonzero(delta)), "elements": int(actual.size),
            "exact_equal": bool(np.array_equal(actual, reference)),
            "value_bits_equal": bool(np.array_equal(actual.view(np.uint32), reference.view(np.uint32)))}


def review_comparison(actual, reference, stored):
    computed = comparison(actual, reference)
    deltas = {}
    for key, value in computed.items():
        if key in ("relative_l2", "max_abs") and value is not None:
            deltas[key] = float(value - stored[key])
        else:
            assert value == stored[key], (key, value, stored[key])
    if "per_head" in stored:
        assert stored["head_axis"] == 0 and len(stored["per_head"]) == len(actual)
        heads = [review_comparison(a, b, report) for a, b, report in
                 zip(actual, reference, stored["per_head"], strict=True)]
        deltas["per_head_max_abs_relative_l2_delta"] = max(abs(h["relative_l2"]) for h in heads)
        deltas["per_head_max_abs_max_abs_delta"] = max(abs(h["max_abs"]) for h in heads)
    return deltas


def review_stats(local, stored):
    return {name: {key: difference(value, np.asarray(stored[name][key], dtype=np.float32))
                   for key, value in values.items()} for name, values in local.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "raw-root", "source-root", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    args = parser.parse_args()
    bundle = args.bundle.resolve()
    files_before = {path.name: sha(path) for path in bundle.iterdir() if path.is_file()}
    report = read(bundle / "sensitivity.json")
    inputs = read(bundle / "input_manifest.json")
    selection = read(bundle / "selected_jobs.json")
    server_receipt = read(bundle / "receipt.json")
    tools = read(bundle / "tool_manifest.json")
    for name, digest in tools.items():
        assert files_before[name] == digest
    assert server_receipt["analysis_sha256"] == files_before["sensitivity.json"]
    assert server_receipt["tool_manifest_sha256"] == files_before["tool_manifest.json"]
    assert report["npz"]["sha256"] == files_before["sensitivity.npz"]
    assert report["selection"] == selection
    assert report["input_manifest_sha256"] == files_before["input_manifest.json"]
    assert report["jobs_manifest_sha256"] == files_before["selected_jobs.json"]
    for name, digest in report["tool_sha256"].items():
        assert files_before[name] == digest
    assert report["core_source_sha256"] == CORE
    assert report["configured_model_revision"] == REVISION
    assert report["diagnostic_only"] is True and report["performance_eligible"] is False
    assert report["original_graph_failures_preserved"] is True
    assert report["thresholds_added"] is False and report["npu_execution"] is False
    assert inputs["schema_version"] == 1
    assert report["job_files"]["before"] == report["job_files"]["after"] == inputs["job_files"]
    assert report["source_files"]["before"] == report["source_files"]["after"] == inputs["source_files"]
    core = read(args.source_root / "docs/evidence/homework2_20261023/source_manifest.json")
    assert len(core) == 1531
    assert report["core_source_files"]["before"] == report["core_source_files"]["after"] == core
    expected_job_files = set()
    for tp in (1, 2):
        job = selection["9b"][f"tp{tp}"]
        expected_job_files.add(f"{job}/diagnostic.json")
        for rank in range(tp):
            for name in ("cached_step8.pt", "cached_step8_metadata.json", "gdn_actual_checkpoint_identity.json"):
                expected_job_files.add(f"{job}/rank_{rank}/{name}")
    assert expected_job_files == set(inputs["job_files"]) and len(expected_job_files) == 11
    for relative, digest in inputs["job_files"].items():
        assert sha(args.raw_root / relative) == digest
    available_sources, unavailable_sources = [], []
    for relative, digest in inputs["source_files"].items():
        path = args.source_root / relative
        if path.is_file():
            assert sha(path) == digest
            available_sources.append(relative)
        else:
            unavailable_sources.append(relative)
    artifacts = read(args.source_root / "docs/evidence/homework2_20261023/model_artifacts.json")
    model = next(m for m in artifacts["models"] if m["model_id"] == "Qwen/Qwen3.5-9B")
    assert model["model_revision"] == REVISION
    for relative, digest in inputs["source_files"].items():
        if relative.startswith("models/Qwen3.5-9B/"):
            assert digest == model["files"][Path(relative).name]["sha256"]
    with np.load(bundle / "sensitivity.npz", allow_pickle=False) as archive:
        assert sorted(archive.files) == report["npz"]["keys"]
        data = {key: archive[key] for key in archive.files}
    assert len(data) == 183
    for array in data.values():
        assert array.dtype.kind in "fiu" and np.isfinite(array).all()
    eps = data["eps"]
    assert eps.shape == () and eps.dtype == np.float32
    assert data["case_input_ids"].shape == (128,)
    assert data["case_continuation_ids"].shape == (9,)
    result = {"schema_version": 1, "review_script_sha256": sha(__file__),
              "python": platform.python_version(), "platform": platform.platform(),
              "numpy_version": np.__version__, "bundle_sha256_before": files_before,
              "bound_raw_files_rehashed": 11, "core_sha_mapping_entries": 1531,
              "source_files_rehashed_locally": available_sources,
              "source_files_unavailable_locally": unavailable_sources,
              "raw_pt_operand_values_independently_extracted": False,
              "npz_arrays": len(data), "gate_diagnostics": {}, "layers": {}, "own_operands": {},
              "new_acceptance_thresholds": None, "quality_or_original_failure_pass_claim": False}
    for layer in LAYERS:
        pre = f"l{layer}"
        layer_report = report["layers"][str(layer)]
        assert eps == np.float32(layer_report["eps"])
        original, weight = data[f"{pre}_weight_original_fp32"], data[f"{pre}_weight_runtime_bf16_as_fp32"]
        assert original.shape == weight.shape == (128,)
        assert original.dtype == weight.dtype == np.float32
        assert np.array_equal(bf16(original), weight)
        original_digest = hashlib.sha256(original.astype("<f4").tobytes()).hexdigest()
        runtime_digest = hashlib.sha256((weight.view(np.uint32) >> 16).astype("<u2").tobytes()).hexdigest()
        assert original_digest == layer_report["weight_identities"]["original_sha256"]
        assert runtime_digest == layer_report["weight_identities"]["runtime_sha256"]
        cores, gates, actuals = [], [], []
        for rank_name in RANKS:
            prefix = f"{pre}_{rank_name}"
            tp, rank = (1, 0) if rank_name == "tp1_rank0" else (2, int(rank_name[-1]))
            item = report["ranks"][rank_name]["layers"][str(layer)]
            meta = report["ranks"][rank_name]["original_metadata"]
            assert (meta["tp"], meta["rank"], meta["step"], meta["position"], meta["prefix_length_after"]) == (tp, rank, 8, 135, 136)
            run = report["runs"][f"tp{tp}"]
            assert meta["case_id"] == run["case"]["case_id"]
            assert run["guard"]["sources_sha"] == run["guard"]["sources_after_sha"] == CORE
            assert run["guard"]["sources_unchanged"] is True and run["guard"]["violations"] == []
            assert np.array_equal(data["case_input_ids"], run["case"]["input_ids"])
            assert np.array_equal(data["case_continuation_ids"], run["case"]["continuation_ids"])
            cert_path = args.raw_root / selection["9b"][f"tp{tp}"] / f"rank_{rank}/gdn_actual_checkpoint_identity.json"
            cert = read(cert_path)
            assert (cert["tp"], cert["rank"], cert["model_revision"]) == (tp, rank, REVISION)
            certified = cert["layers"][str(layer)]
            p = certified["parameters"]["linear_attn.norm.weight"]
            assert p["actual_shape"] == p["expected_shape"] == [128]
            assert p["actual_dtype"] == p["expected_dtype"] == "torch.bfloat16"
            assert p["actual_sha256"] == p["checkpoint_expected_sha256"] == runtime_digest
            assert p["exact_match"] is True
            checkpoint = certified["checkpoint_tensors"]["linear_attn.norm.weight"]
            assert checkpoint["dtype"] == "torch.float32" and checkpoint["shape"] == [128]
            assert checkpoint["checkpoint_tensor_sha256"] == original_digest
            assert certified["gated_norm"] == {"eps": layer_report["eps"], "group_size": None,
                                                 "norm_before_gate": True, "sigmoid_gate": False}
            core_value, z, actual = (data[f"{prefix}_{name}"] for name in ("core", "z", "actual_norm"))
            assert core_value.shape == z.shape == actual.shape == (32 // tp, 128)
            for value in (core_value, z, actual):
                assert value.dtype == np.float32 and np.all((value.view(np.uint32) & 0xFFFF) == 0)
            cores.append(core_value); gates.append(z); actuals.append(actual)
            for gate_input in ("a", "dt_bias", "A_log"):
                assert data[f"{prefix}_{gate_input}"].shape == (32 // tp,)
                assert data[f"{prefix}_{gate_input}"].dtype == np.float32
            output, cstats, zstats = norm_output(core_value, z, weight, eps)
            saved_output = data[f"{prefix}_own_reference_fp32"]
            saved_candidate = data[f"{prefix}_own_final_bf16_candidate"]
            assert np.array_equal(saved_candidate, bf16(saved_output))
            result["own_operands"][prefix] = {
                "local_output_vs_saved": difference(output, saved_output),
                "local_bf16_candidate_vs_saved": difference(bf16(output), saved_candidate),
                "saved_fp32_metric_recompute": review_comparison(actual, saved_output, item["fp32"]),
                "saved_bf16_metric_recompute": review_comparison(actual, saved_candidate, item["final_bf16_candidate"]),
                "per_head_statistics": review_stats({"core1": cstats, "core2": cstats,
                                                       "z1": zstats, "z2": zstats}, item["own_statistics"]),
                "reported_fp32_relative_l2": item["fp32"]["relative_l2"],
                "reported_bf16_relative_l2": item["final_bf16_candidate"]["relative_l2"]}
            local_gate = softplus(data[f"{prefix}_a"], data[f"{prefix}_dt_bias"], data[f"{prefix}_A_log"])
            gate_summary = item["softplus"]
            assert float(local_gate["x"].min()) == gate_summary["x_min"]
            assert float(local_gate["x"].max()) == gate_summary["x_max"]
            indices = local_gate["cancellation_zero_indices"]
            assert indices.tolist() == gate_summary["cancellation_zero_indices"]
            assert indices.size == gate_summary["cancellation_zero_count"]
            gate_result = {"x_min": gate_summary["x_min"], "x_max": gate_summary["x_max"],
                           "cancellation_zero_count": int(indices.size), "arrays": {}, "reported_summaries": {}}
            for name, value in local_gate.items():
                saved = data[f"{prefix}_softplus_{name}"]
                gate_result["arrays"][name] = difference(value, saved)
                if name in gate_summary and isinstance(gate_summary[name], dict):
                    expected = {"min": float(saved.min()), "max": float(saved.max()),
                                "max_abs": float(np.abs(saved).max())}
                    assert gate_summary[name] == expected
                    gate_result["reported_summaries"][name] = expected
            result["gate_diagnostics"][prefix] = gate_result
        core_pair = {"core1": cores[0], "core2": np.concatenate(cores[1:], axis=0)}
        z_pair = {"z1": gates[0], "z2": np.concatenate(gates[1:], axis=0)}
        stats = {name: core_statistics(value, eps) for name, value in core_pair.items()}
        stats.update({name: z_statistics(value)[1] for name, value in z_pair.items()})
        layer_result = {"per_head_statistics": review_stats(stats, layer_report["statistics"]), "arms": {}}
        for cn, cv in core_pair.items():
            for zn, zv in z_pair.items():
                arm = f"{cn}_{zn}"
                output = norm_output(cv, zv, weight, eps)[0]
                saved = data[f"{pre}_arm_{arm}"]
                metric = layer_report["arms_vs_F_core1_z1"][arm]
                layer_result["arms"][arm] = {
                    "local_output_vs_saved": difference(output, saved),
                    "saved_metric_recompute": review_comparison(saved, data[f"{pre}_arm_core1_z1"], metric),
                    "reported_relative_l2": metric["relative_l2"], "reported_max_abs": metric["max_abs"]}
        layer_result["actual_TP2_vs_TP1_relative_l2"] = layer_report["actual_TP2_vs_TP1"]["relative_l2"]
        layer_result["saved_actual_metric_recompute"] = review_comparison(
            np.concatenate(actuals[1:], axis=0), actuals[0], layer_report["actual_TP2_vs_TP1"])
        layer_result["ranges"] = {name: {key: [float(value.min()), float(value.max())]
                                        for key, value in st.items()} for name, st in stats.items()}
        result["layers"][str(layer)] = layer_result
    files_after = {path.name: sha(path) for path in bundle.iterdir() if path.is_file()}
    assert files_before == files_after
    for relative, digest in inputs["job_files"].items():
        assert sha(args.raw_root / relative) == digest
    result["bundle_sha256_after"] = files_after
    result["structural_identity_and_discrete_checks_completed"] = True
    result["floating_verification_policy"] = "Record every numerical discrepancy without acceptance thresholds; cross-platform FP32 transcendental results are not required to be bitwise identical."
    result["selection_binding_scope"] = {
        "model": "Qwen/Qwen3.5-9B", "revision": REVISION, "step": 8,
        "position": 135, "prefix_length_after": 136, "layers": list(LAYERS),
        "tp_rank_selection": list(RANKS), "heads_after_tp2_concat": 32,
        "raw_capture_hashes_verified_but_pt_operands_not_independently_deserialized": True,
        "server_before_after_core_maps_matched_frozen_manifest_but_local_core_files_not_rehashed": True,
        "checkpoint_file_hashes_matched_frozen_model_artifacts_but_local_checkpoint_bytes_unavailable": True,
    }
    result["summary"] = {
        "observed_x_min": min(v["x_min"] for v in result["gate_diagnostics"].values()),
        "observed_x_max": max(v["x_max"] for v in result["gate_diagnostics"].values()),
        "cancellation_zero_count": sum(v["cancellation_zero_count"] for v in result["gate_diagnostics"].values()),
        "reported_max_abs_runtime_minus_stable_g": max(v["reported_summaries"]["g_difference"]["max_abs"] for v in result["gate_diagnostics"].values()),
        "reported_max_abs_runtime_minus_stable_decay": max(v["reported_summaries"]["decay_difference"]["max_abs"] for v in result["gate_diagnostics"].values()),
        "local_four_arm_vs_saved_max_abs": max(a["local_output_vs_saved"]["max_abs"] for l in result["layers"].values() for a in l["arms"].values()),
        "local_four_arm_vs_saved_max_fp32_ulp_distance": max(a["local_output_vs_saved"]["max_fp32_ulp_distance"] for l in result["layers"].values() for a in l["arms"].values()),
        "local_bf16_candidate_exact_matches_saved_count": sum(v["local_bf16_candidate_vs_saved"]["exact_equal"] for v in result["own_operands"].values()),
    }
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps({"structural_checks": "completed", "gate_diagnostics": 9,
                      "four_arm_outputs": 12, "own_operand_outputs": 9,
                      "acceptance_thresholds": None, "receipt": str(args.output)}))


if __name__ == "__main__":
    main()
