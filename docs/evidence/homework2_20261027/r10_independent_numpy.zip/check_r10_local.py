# Copyright (c) 2026 LightSeek Foundation
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import argparse
import hashlib
import json
import os
from pathlib import Path

for variable in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS'):
    os.environ[variable]='1'
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('--bundle',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
report_path=args.bundle/'norm_precision_r10.json'
npz_path=args.bundle/'norm_precision_r10.vectors.npz'
report=json.loads(report_path.read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(npz_path)==report['vectors_file']['sha256']
arrays=np.load(npz_path,allow_pickle=False)
assert set(arrays.files)==set(report['arrays']) and len(arrays.files)==20
cached={}
for name,meta in report['arrays'].items():
    a=arrays[name]
    assert list(a.shape)==meta['shape'] and str(a.dtype)==meta['dtype']
    assert a.dtype==np.float32 and np.isfinite(a).all()
    assert hashlib.sha256(a.astype('<f4',copy=False).tobytes()).hexdigest()==meta['sha256']
    cached[name]=a
maximum_difference=0.0
comparisons=0

def check_pair(a,r,saved):
    global maximum_difference,comparisons
    delta=a.astype(np.float64)-r.astype(np.float64)
    abs_delta=np.abs(delta)
    denominator=np.sqrt(np.sum(r.astype(np.float64)**2))
    p=np.exp(a.astype(np.float64)-float(a.max()));p/=p.sum()
    q=np.exp(r.astype(np.float64)-float(r.max()));q/=q.sum()
    result={'relative_l2':float(np.sqrt(np.sum(delta**2))/denominator), 'reference_zero':False,'max_abs':float(abs_delta.max()),'max_abs_token_id':int(abs_delta.argmax()),'mean_signed_difference':float(delta.mean()),'argmax_equal':bool(a.argmax()==r.argmax()),'value_bits_equal':bool(np.array_equal(a.view(np.uint32),r.view(np.uint32))),'offline_temperature1_tv':float(np.sum(np.abs(p-q))*.5)}
    assert denominator>0
    for k,v in result.items():
        if type(v) is float:
            difference=abs(v-saved[k]);maximum_difference=max(maximum_difference,difference)
            assert difference<=1e-12,(k,v,saved[k])
        else:assert v==saved[k],(k,v,saved[k])
    comparisons+=1

tables={}
for model,steps in [('4b',18),('9b',10)]:
    item=report['models'][model];reference=cached[f'{model}_cpu_reference']
    for capture,content in item['captures'].items():
        matrix=cached[f'{model}_{capture}']
        for step in range(steps):
            check_pair(matrix[step],reference[step],content['vs_cpu'][step])
            a=matrix[step]
            ids=np.lexsort((np.arange(a.size),-a))[:10]
            top=content['top10'][step]
            assert ids.tolist()==top['ids'] and a[ids].astype(np.float64).tolist()==top['values']
            assert int(a.argmax())==top['argmax'] and int((a==a.max()).sum())==top['maximum_tie_count']
    for name,comparisons_group in item['comparisons'].items():
        if name in ('r2','r9','r10'):
            pairs={'tp2_vs_tp1':(cached[f'{model}_{name}_tp2_rank0'],cached[f'{model}_{name}_tp1_rank0']),'tp2_rank1_vs_rank0':(cached[f'{model}_{name}_tp2_rank1'],cached[f'{model}_{name}_tp2_rank0'])}
        else:
            previous=name.removeprefix('r10_vs_')
            pairs={key:(cached[f'{model}_r10_{key}'],cached[f'{model}_{previous}_{key}']) for key in ('tp1_rank0','tp2_rank0','tp2_rank1')}
        for key,(a,r) in pairs.items():
            rows=comparisons_group[key]['steps']
            for step in range(steps):check_pair(a[step],r[step],rows[step])
    tables[model]={name:item['comparisons'][name]['tp2_vs_tp1']['summary'] for name in ('r2','r9','r10')}
record={'passed':True,'scope':'Independent NumPy recomputation from full saved vectors; raw PT interpretation remains the bound CPU producer; no model acceptance threshold','arrays':20,'vectors':sum(a.shape[0] for a in cached.values()),'pair_comparisons':comparisons,'max_floating_metric_difference':maximum_difference,'formula_recomputation_tolerance':1e-12,'formula_tolerance_is_engine_gate':False,'array_hashes_all_equal':True,'top10_exact':True,'report_sha256':digest(report_path),'npz_sha256':digest(npz_path),'script_sha256':digest(Path(__file__)),'summary':tables,'candidate_adopted':False}
with args.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
